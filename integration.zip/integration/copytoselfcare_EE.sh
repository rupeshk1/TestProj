chmod -R 777 ../integration
cp ./svallo-model-common/target/svallo-model-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-common/target/svallo-service-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./selfcare-services/target/selfcare-services-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ../techmahindra-components/techmahindra-logwrapper/target/techmahindra-logwrapper-0.0.1-SNAPSHOT.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ../techmahindra-components/techmahindra-propertyresource/target/techmahindra-propertyresource-0.0.1-SNAPSHOT.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ../techmahindra-components/techmahindra-throttling/target/techmahindra-throttling-0.0.1-SNAPSHOT.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib

cp ./svallo-service-dashboard/target/svallo-service-dashboard-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-dashboard/target/svallo-model-dashboard-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-payment/target/svallo-service-payment-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-payment/target/svallo-model-payment-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-registration_login-service/target/svallo-registration_login-service-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/pre-registration-portlet/docroot/WEB-INF/lib
cp ./svallo-registration_login-service/target/svallo-registration_login-service-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-addon/target/svallo-model-addon-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-addon/target/svallo-service-addon-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-portin/target/svallo-model-portin-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-portin/target/svallo-service-portin-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-callingfeatures/target/svallo-model-callingfeatures-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-callingfeatures/target/svallo-service-callingfeatures-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-takeabreak/target/svallo-service-takeabreak-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-takeabreak/target/svallo-model-takeabreak-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib

cp /appl/cpw-svn-Enterprise/Sandbox/Binaries/tomcat-7.0.42/webapps/pre-registration-portlet/registeraccount_email.jsp /appl/cpw-svn-Enterprise/Sandbox/Binaries/tomcat-7.0.42/webapps/ROOT
cp ./selfcare-services/target/selfcare-services-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/pre-registration-portlet/docroot/WEB-INF/lib
cp ./selfcare-services/target/selfcare-services-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/forgotusernamepassword-portlet/docroot/WEB-INF/lib
cp ./svallo-registration_login-service/target/svallo-registration_login-service-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/forgotusernamepassword-portlet/docroot/WEB-INF/lib
cp ./svallo-service-myallowances/target/svallo-service-myallowances-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-myallowances/target/svallo-model-myallowances-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-model-singlesignon/target/svallo-model-singlesignon-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/forgotusernamepassword-portlet/docroot/WEB-INF/lib
cp ./svallo-service-singlesignon/target/svallo-service-singlesignon-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/forgotusernamepassword-portlet/docroot/WEB-INF/lib
cp ./svallo-service-oneofpayment/target/svallo-service-oneofpayment-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/payment-portlet/docroot/WEB-INF/lib
cp ./svallo-model-oneofpayment/target/svallo-model-oneofpayment-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/payment-portlet/docroot/WEB-INF/lib
cp ./selfcare-services/target/selfcare-services-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/payment-portlet/docroot/WEB-INF/lib

cp ./svallo-model-myprofile/target/svallo-model-myprofile-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-myprofile/target/svallo-service-myprofile-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib

cp ./svallo-model-addressval/target/svallo-model-addressval-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-addressval/target/svallo-service-addressval-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib

cp ./svallo-model-common/target/svallo-model-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/payment-portlet/docroot/WEB-INF/lib
cp ./svallo-service-common/target/svallo-service-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/payment-portlet/docroot/WEB-INF/lib

cp ./svallo-model-common/target/svallo-model-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/pre-registration-portlet/docroot/WEB-INF/lib
cp ./svallo-service-common/target/svallo-service-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/pre-registration-portlet/docroot/WEB-INF/lib

cp ./svallo-model-common/target/svallo-model-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/forgotusernamepassword-portlet/docroot/WEB-INF/lib
cp ./svallo-service-common/target/svallo-service-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/forgotusernamepassword-portlet/docroot/WEB-INF/lib

cp ./svallo-model-myprofile/target/svallo-model-myprofile-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/pre-registration-portlet/docroot/WEB-INF/lib
cp ./svallo-service-myprofile/target/svallo-service-myprofile-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/pre-registration-portlet/docroot/WEB-INF/lib

cp ./svallo-model-rollover/target/svallo-model-rollover-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-rollover/target/svallo-service-rollover-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib

cp ./svallo-model-topup/target/svallo-model-topup-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-topup/target/svallo-service-topup-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib

cp ./svallo-model-bundle/target/svallo-model-bundle-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib
cp ./svallo-service-bundle/target/svallo-service-bundle-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/selfcare-portlet/docroot/WEB-INF/lib

cp ./svallo-model-topup/target/svallo-model-topup-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/payment-portlet/docroot/WEB-INF/lib
cp ./svallo-service-topup/target/svallo-service-topup-0.1.jar  ../liferay/6.2.0-ce-ga2/plugins/portlets/payment-portlet/docroot/WEB-INF/lib

cp ./svallo-model-common/target/svallo-model-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib
cp ./svallo-service-common/target/svallo-service-common-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib
cp ./svallo-service-myprofile/target/svallo-service-myprofile-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib
cp ./svallo-registration_login-service/target/svallo-registration_login-service-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib
cp ./svallo-service-aio/target/svallo-service-aio-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib
cp ./svallo-model-aio/target/svallo-model-aio-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib
cp ./selfcare-services/target/selfcare-services-0.1.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib

cp ../techmahindra-components/techmahindra-logwrapper/target/techmahindra-logwrapper-0.0.1-SNAPSHOT.jar ../liferay/6.2.0-ce-ga2/plugins/portlets/aio-portlet/docroot/WEB-INF/lib




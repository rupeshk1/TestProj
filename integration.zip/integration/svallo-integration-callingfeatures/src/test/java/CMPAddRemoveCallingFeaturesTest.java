import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;

import junit.framework.TestCase;


public class CMPAddRemoveCallingFeaturesTest extends TestCase{
		
	Transformer transformer;
	String successmessage="Success";
	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	
	public void testAddCMPFeatures(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/addCMPFeatures.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/addCMPFeatures_out.xml"));
			Source xsl = new StreamSource(new File("src/test/resources/xsl/MDS_CreateService-Add.xsl"));
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);			
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/addCMPFeatures_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
		    
			
		    String cfRoamMessage = doc.getElementsByTagName("cfRoamMessage").item(0).getTextContent();		   
		    
		    System.out.println("cfRoamMessage for add:" +cfRoamMessage);
		    assertEquals("Error in Add calling features Resposne for CMP user",successmessage,cfRoamMessage);
		    
		   
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	} 
	
	
	public void testRemoveCMPFeatures(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/removeCMPFeatures.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/removeCMPFeatures_out.xml"));
			Source xsl = new StreamSource(new File("src/test/resources/xsl/MDS_UpdateService-Remove.xsl"));
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);			
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/removeCMPFeatures_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
		    
			
		    String cfRoamMessage = doc.getElementsByTagName("cfRoamMessage").item(0).getTextContent();		   
		    
		    System.out.println("cfRoamMessage for remove:" +cfRoamMessage);
		    assertEquals("Error in remove calling features Resposne for CMP user",successmessage,cfRoamMessage);
		    
		   
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	} 
	
	

}

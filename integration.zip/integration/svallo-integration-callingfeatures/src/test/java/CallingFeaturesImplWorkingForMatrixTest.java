import java.io.File;
import junit.framework.TestCase;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class CallingFeaturesImplWorkingForMatrixTest extends TestCase {	
	
	Source xsl = new StreamSource(new File("src/test/resources/xsl/MATRIX_ProdCatal-CallingFeaturesStd.xsl"));
	Transformer transformer;
	String dateValue="1111-11-11Z";
		
	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	public void testsuccessCallingFeatures(){		
		try {
			
		
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/QuerySubscriptionResponse_Matrix.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/QuerySubscriptionResponse_Matrix_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);	
		   
		   /*
		    System.out.println("################## Start of Three Months Data #########################");
		    String filepath = "src/test/resources/output_xml/3_correct_data_check_sucessful_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					String tempDate="";
					String tempAvailableAmount="";
					String tempUsedAmount="";
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;					
					tempDate=eElement.getElementsByTagName("effectiveDate").item(0).getTextContent();
					tempAvailableAmount=eElement.getElementsByTagName("availableAmount").item(0).getTextContent();
					tempUsedAmount=eElement.getElementsByTagName("usedAmount").item(0).getTextContent();
					System.out.println("AvailableAmount for first month "+tempDate+" is "+tempAvailableAmount);
					System.out.println("UsedAmount for first month "+tempDate+" is "+tempUsedAmount);
				}
				
				// for first month 
				if(itr1==0){
				  assertEquals("AvailableAmount for first month "+tempDate+" not matching","2000", tempAvailableAmount);
				  assertEquals("UsedAmount for first month "+tempDate+" not matching","1580", tempUsedAmount);	
				}
				// for second month 
				if(itr1==1){
				  assertEquals("AvailableAmount for second month "+tempDate+" not matching","1220", tempAvailableAmount);
				  assertEquals("UsedAmount for second month "+tempDate+" not matching","1220", tempUsedAmount);	
				}				
				// for third month 
				if(itr1==2){
				  assertEquals("AvailableAmount for third month "+tempDate+" not matching","0", tempAvailableAmount);
				  assertEquals("UsedAmount for third month "+tempDate+" not matching","0", tempUsedAmount);	
				}
	          }
			}			
			*/
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	} 
	
	
	public void testCallingFeaturesSec1(){		
		try {
					
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/testCallingFeaturesSec1.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/testCallingFeaturesSec1_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);	
		   
		   /*
		    System.out.println("################## Start of Three Months Data #########################");
		    String filepath = "src/test/resources/output_xml/3_correct_data_check_sucessful_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					String tempDate="";
					String tempAvailableAmount="";
					String tempUsedAmount="";
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;					
					tempDate=eElement.getElementsByTagName("effectiveDate").item(0).getTextContent();
					tempAvailableAmount=eElement.getElementsByTagName("availableAmount").item(0).getTextContent();
					tempUsedAmount=eElement.getElementsByTagName("usedAmount").item(0).getTextContent();
					System.out.println("AvailableAmount for first month "+tempDate+" is "+tempAvailableAmount);
					System.out.println("UsedAmount for first month "+tempDate+" is "+tempUsedAmount);
				}
				
				// for first month 
				if(itr1==0){
				  assertEquals("AvailableAmount for first month "+tempDate+" not matching","2000", tempAvailableAmount);
				  assertEquals("UsedAmount for first month "+tempDate+" not matching","1580", tempUsedAmount);	
				}
				// for second month 
				if(itr1==1){
				  assertEquals("AvailableAmount for second month "+tempDate+" not matching","1220", tempAvailableAmount);
				  assertEquals("UsedAmount for second month "+tempDate+" not matching","1220", tempUsedAmount);	
				}				
				// for third month 
				if(itr1==2){
				  assertEquals("AvailableAmount for third month "+tempDate+" not matching","0", tempAvailableAmount);
				  assertEquals("UsedAmount for third month "+tempDate+" not matching","0", tempUsedAmount);	
				}
	          }
			}			
			*/
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	} 
	
	// FeatureEnabled = true
	// AllowEnable=False
	// AllowDisable=False
	// Do not display the feature
	
	public void testFeatureEnabledCond1(){		
		try {
			
			System.out.println("***************** Start of Feature Enabled Condition 1 ***************");					
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond1_Matrix.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond1_Matrix_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);	
		   
		    String filepath = "src/test/resources/output_xml/FeatureEnabledCond1_Matrix_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
						
			NodeList nList = doc.getElementsByTagName("services");
		
			//do this the old way, because nodeList is not iterable	
				String count = "0";
				for (int temp = 0; temp < nList.getLength(); temp++) {
					String serviceCode="";
					Node nNode = nList.item(temp);
							
					System.out.println("\nCurrent Element :" + nNode.getNodeName());
							
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
						System.out.println("Service Code="+serviceCode);
					}
					
					if(serviceCode.equalsIgnoreCase("FINTL")){						
						  count = "1";
						}						
				}
				
				assertSame("Service code FINTL is present, which should not be present","0",count);
				System.out.println("***************** End of Feature Enabled Condition 1 ***************");	
				System.out.println("");	
			}		
		 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	} 
	
	    // FeatureEnabled = true
		// AllowEnable=False
		// AllowDisable=True
	    // Display �Turn Off� button
		
		public void testFeatureEnabledCond2(){		
			try {
				System.out.println("***************** Start of Feature Enabled Condition 2 ***************");		
				Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond2_Matrix.xml"));		
				Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond2_Matrix_out.xml"));	
				
				transformer = TransformerFactory.newInstance().newTransformer(xsl);
			    transformer.transform(xmlInput, xmlOutput);	
			   
			    String filepath = "src/test/resources/output_xml/FeatureEnabledCond2_Matrix_out.xml";
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(filepath);
			    doc.getDocumentElement().normalize();
				System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
							
				NodeList nList = doc.getElementsByTagName("services");
			
				//do this the old way, because nodeList is not iterable	
					String count= "0";
					for (int temp = 0; temp < nList.getLength(); temp++) {
						String serviceCode="";
						String active="";
						Node nNode = nList.item(temp);
								
						System.out.println("\nCurrent Element :" + nNode.getNodeName());
								
						if (nNode.getNodeType() == Node.ELEMENT_NODE) {
							Element eElement = (Element) nNode;
							serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
							active = eElement.getElementsByTagName("active").item(0).getTextContent();
							
							System.out.println("Service Code="+serviceCode);
							System.out.println("active="+active);
						}					
						// for Serice Code FINTL 
						if(serviceCode.equalsIgnoreCase("FINTL")){
						  assertEquals("Button is not turn off ","true", active);	
						  count = "1";
						}
					}
				
					assertEquals("service code FINTL is not present, which should be present","1",count);					
					System.out.println("***************** End of Feature Enabled Condition 2 ***************");	
					System.out.println("");	
				}			
			 catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		} 
		
		        // FeatureEnabled = true
				// AllowEnable=True
				// AllowDisable=False
				// Do not display the feature
				
				public void testFeatureEnabledCond3(){		
					try {
						System.out.println("***************** Start of Feature Enabled Condition 3 ***************");		
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond3_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond3_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond3_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode="";							
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
								}
								
								if(serviceCode.equalsIgnoreCase("FINTL")){						
								  count = "1";
								}	
								
							}	
							assertSame("Service code FINTL is present, which should not be present","0",count);
							System.out.println("***************** End of Feature Enabled Condition 3 ***************");	
							System.out.println("");	
						}					
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
				
				
				// FeatureEnabled = true
				// AllowEnable=True
				// AllowDisable=False
				// Display �Turn Off� button
				
				public void testFeatureEnabledCond4(){		
					try {
						System.out.println("***************** Start of Feature Enabled Condition 4 ***************");		
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond4_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond4_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond4_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode = "";
								String active = "";
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									active = eElement.getElementsByTagName("active").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
									System.out.println("active="+active);
								}
								
								// for Serice Code FINTL 
								if(serviceCode.equalsIgnoreCase("FINTL")){
								  assertEquals("Button is not turn off ","true", active);	
								  count = "1";
								}
								
							}	
							assertEquals("service code FINTL is not present, which should be present","1",count);
							System.out.println("***************** End of Feature Enabled Condition 4 ***************");	
							System.out.println("");	
						}					
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
				
				
				// FeatureEnabled = False
				// AllowEnable=False
				// AllowDisable=False
				// Do not display the feature
				
				public void testFeatureEnabledCond5(){		
					try {
						
						System.out.println("***************** Start of Feature Enabled Condition 5 ***************");					
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond5_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond5_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond5_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode="";
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
								}
								
								if(serviceCode.equalsIgnoreCase("FINTL")){						
									  count = "1";
									}						
							}
							
							assertSame("Service code FINTL is present, which should not be present","0",count);
							System.out.println("***************** End of Feature Enabled Condition 5 ***************");	
							System.out.println("");	
						}		
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
				
				
				// FeatureEnabled = False
				// AllowEnable=False
				// AllowDisable=True
				// Do not display the feature
				
				public void testFeatureEnabledCond6(){		
					try {
						
						System.out.println("***************** Start of Feature Enabled Condition 6 ***************");					
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond6_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond6_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond6_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode="";
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
								}
								
								if(serviceCode.equalsIgnoreCase("FINTL")){						
									  count = "1";
									}						
							}
							
							assertSame("Service code FINTL is present, which should not be present","0",count);
							System.out.println("***************** End of Feature Enabled Condition 6 ***************");	
							System.out.println("");	
						}		
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
				
				// FeatureEnabled = false
				// AllowEnable=True
				// AllowDisable=false
				// Display �Turn On� button
				
				public void testFeatureEnabledCond7(){		
					try {
						System.out.println("***************** Start of Feature Enabled Condition 7 ***************");		
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond7_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond7_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond7_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode = "";
								String active = "";
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									active = eElement.getElementsByTagName("active").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
									System.out.println("active="+active);
								}
								
								// for Serice Code FINTL 
								if(serviceCode.equalsIgnoreCase("FINTL")){
								  assertEquals("Button is not turn on ","false", active);	
								  count = "1";
								}
								
							}	
							assertEquals("service code FINTL is not present, which should be present","1",count);
							System.out.println("***************** End of Feature Enabled Condition 7 ***************");	
							System.out.println("");	
						}					
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
				
				
				// FeatureEnabled = false
				// AllowEnable=True
				// AllowDisable=True
				// Display �Turn On� button
				
				public void testFeatureEnabledCond8(){		
					try {
						System.out.println("***************** Start of Feature Enabled Condition 8 ***************");		
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond8_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond8_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond8_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode = "";
								String active = "";
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									active = eElement.getElementsByTagName("active").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
									System.out.println("active="+active);
								}
								
								// for Serice Code FINTL 
								if(serviceCode.equalsIgnoreCase("FINTL")){
								  assertEquals("Button is not turn on ","false", active);	
								  count = "1";
								}
								
							}	
							assertEquals("service code FINTL is not present, which should be present","1",count);
							System.out.println("***************** End of Feature Enabled Condition 8 ***************");	
							System.out.println("");	
						}					
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
				
				
			
				// FeatureBarred = True				
				// Do not display the feature
				
				public void testFeatureEnabledCond9(){		
					try {
						
						System.out.println("***************** Start of Feature Enabled Condition 9 ***************");					
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond9_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond9_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond9_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode="";
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
								}
								
								if(serviceCode.equalsIgnoreCase("FINTL")){						
									  count = "1";
									}						
							}
							
							assertSame("Service code FINTL is present, which should not be present","0",count);
							System.out.println("***************** End of Feature Enabled Condition 9 ***************");	
							System.out.println("");	
						}		
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
		
				
				// FeatureActivityPending = True				
				// Display with Processing icon
				
				public void testFeatureEnabledCond10(){		
					try {
						System.out.println("***************** Start of Feature Enabled Condition 10 ***************");		
						Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/FeatureEnabledCond10_Matrix.xml"));		
						Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/FeatureEnabledCond10_Matrix_out.xml"));	
						
						transformer = TransformerFactory.newInstance().newTransformer(xsl);
					    transformer.transform(xmlInput, xmlOutput);	
					   
					    String filepath = "src/test/resources/output_xml/FeatureEnabledCond10_Matrix_out.xml";
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.parse(filepath);
					    doc.getDocumentElement().normalize();
						System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
									
						NodeList nList = doc.getElementsByTagName("services");
					
						//do this the old way, because nodeList is not iterable	
							String count = "0";
							for (int temp = 0; temp < nList.getLength(); temp++) {
								String serviceCode = "";
								String active = "";
								Node nNode = nList.item(temp);
										
								System.out.println("\nCurrent Element :" + nNode.getNodeName());
										
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									serviceCode = eElement.getElementsByTagName("serviceCode").item(0).getTextContent();
									active = eElement.getElementsByTagName("active").item(0).getTextContent();
									System.out.println("Service Code="+serviceCode);
									System.out.println("active="+active);
								}
								
								// for Serice Code FINTL 
								if(serviceCode.equalsIgnoreCase("FINTL")){
								  assertEquals("Button is not turn on ","pending", active);	
								  count = "1";
								}
								
							}	
							assertEquals("service code FINTL is not present, which should be present","1",count);
							System.out.println("***************** End of Feature Enabled Condition 10 ***************");	
							System.out.println("");	
						}					
					 catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			
				} 
	
}

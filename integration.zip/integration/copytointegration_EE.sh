chmod -R 777 ../integration
cp  ./svallo-integration-common/target/svallo-integration-common-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp  ./svallo-integration-dashboard/target/svallo-integration-dashboard-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp  ./svallo-integration-payment/target/svallo-integration-payment-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp  ./svallo-registration_login-integration/target/svallo-registration_login-integration-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-addon/target/svallo-integration-addon-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-portin/target/svallo-integration-portin-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-callingfeatures/target/svallo-integration-callingfeatures-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp  ./svallo-integration-takeabreak/target/svallo-integration-takeabreak-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp  ./svallo-integration-myprofile/target/svallo-integration-myprofile-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp  ./svallo-integration-myallowances/target/svallo-integration-myallowances-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp  ./svallo-integration-singlesignon/target/svallo-integration-singlesignon-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-addressval/target/svallo-integration-addressval-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-oneofpayment/target/svallo-integration-oneofpayment-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-rollover/target/svallo-integration-rollover-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-bundle/target/svallo-integration-bundle-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-topup/target/svallo-integration-topup-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
cp ./svallo-integration-aio/target/svallo-integration-aio-0.1.jar ../../Sandbox/Binaries/tomcat-7.0.42/integration_webapps/integration/WEB-INF/lib
@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/byot/2015/03/12", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.techmahindra.online.svallo.model.byot._2015._03._12;

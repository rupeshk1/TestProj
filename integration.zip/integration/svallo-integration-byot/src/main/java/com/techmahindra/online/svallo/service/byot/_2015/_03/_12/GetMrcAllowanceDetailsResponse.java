
package com.techmahindra.online.svallo.service.byot._2015._03._12;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.techmahindra.online.svallo.model.byot._2015._03._12.QuerySubscriptionResponse;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getMrcAllowanceDetailsReturn" type="{http://online.techmahindra.com/svallo/model/byot/2015/03/12}QuerySubscriptionResponse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getMrcAllowanceDetailsReturn"
})
@XmlRootElement(name = "getMrcAllowanceDetailsResponse")
public class GetMrcAllowanceDetailsResponse {

    @XmlElement(required = true)
    protected QuerySubscriptionResponse getMrcAllowanceDetailsReturn;

    /**
     * Gets the value of the getMrcAllowanceDetailsReturn property.
     * 
     * @return
     *     possible object is
     *     {@link QuerySubscriptionResponse }
     *     
     */
    public QuerySubscriptionResponse getGetMrcAllowanceDetailsReturn() {
        return getMrcAllowanceDetailsReturn;
    }

    /**
     * Sets the value of the getMrcAllowanceDetailsReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuerySubscriptionResponse }
     *     
     */
    public void setGetMrcAllowanceDetailsReturn(QuerySubscriptionResponse value) {
        this.getMrcAllowanceDetailsReturn = value;
    }

}

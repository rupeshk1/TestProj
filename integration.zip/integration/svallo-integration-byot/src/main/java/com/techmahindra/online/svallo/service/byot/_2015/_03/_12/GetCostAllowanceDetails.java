
package com.techmahindra.online.svallo.service.byot._2015._03._12;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.techmahindra.online.svallo.model.byot._2015._03._12.SearchForPriceListsRequest;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="searchForPriceListsRequest" type="{http://online.techmahindra.com/svallo/model/byot/2015/03/12}SearchForPriceListsRequest"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "searchForPriceListsRequest"
})
@XmlRootElement(name = "getCostAllowanceDetails")
public class GetCostAllowanceDetails {

    @XmlElement(required = true)
    protected SearchForPriceListsRequest searchForPriceListsRequest;

    /**
     * Gets the value of the searchForPriceListsRequest property.
     * 
     * @return
     *     possible object is
     *     {@link SearchForPriceListsRequest }
     *     
     */
    public SearchForPriceListsRequest getSearchForPriceListsRequest() {
        return searchForPriceListsRequest;
    }

    /**
     * Sets the value of the searchForPriceListsRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchForPriceListsRequest }
     *     
     */
    public void setSearchForPriceListsRequest(SearchForPriceListsRequest value) {
        this.searchForPriceListsRequest = value;
    }

}

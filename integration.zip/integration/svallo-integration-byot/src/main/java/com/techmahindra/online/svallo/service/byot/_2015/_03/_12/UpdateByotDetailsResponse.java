
package com.techmahindra.online.svallo.service.byot._2015._03._12;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.techmahindra.online.svallo.model.byot._2015._03._12.ByotResponse;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="updateByotDetailsReturn" type="{http://online.techmahindra.com/svallo/model/byot/2015/03/12}ByotResponse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "updateByotDetailsReturn"
})
@XmlRootElement(name = "updateByotDetailsResponse")
public class UpdateByotDetailsResponse {

    @XmlElement(required = true)
    protected ByotResponse updateByotDetailsReturn;

    /**
     * Gets the value of the updateByotDetailsReturn property.
     * 
     * @return
     *     possible object is
     *     {@link ByotResponse }
     *     
     */
    public ByotResponse getUpdateByotDetailsReturn() {
        return updateByotDetailsReturn;
    }

    /**
     * Sets the value of the updateByotDetailsReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ByotResponse }
     *     
     */
    public void setUpdateByotDetailsReturn(ByotResponse value) {
        this.updateByotDetailsReturn = value;
    }

}


package com.techmahindra.online.svallo.model.callingfeatures._2014._09._15;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.techmahindra.online.svallo.model.callingfeatures._2014._09._15 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.techmahindra.online.svallo.model.callingfeatures._2014._09._15
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SvalloCallingFeaturesRequest }
     * 
     */
    public SvalloCallingFeaturesRequest createSvalloCallingFeaturesRequest() {
        return new SvalloCallingFeaturesRequest();
    }

    /**
     * Create an instance of {@link CfRoamResponse }
     * 
     */
    public CfRoamResponse createCfRoamResponse() {
        return new CfRoamResponse();
    }

    /**
     * Create an instance of {@link CfRoamDetails }
     * 
     */
    public CfRoamDetails createCfRoamDetails() {
        return new CfRoamDetails();
    }

    /**
     * Create an instance of {@link Service }
     * 
     */
    public Service createService() {
        return new Service();
    }

    /**
     * Create an instance of {@link Services }
     * 
     */
    public Services createServices() {
        return new Services();
    }

}

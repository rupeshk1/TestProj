@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/callingfeatures/2014/09/15")
package com.techmahindra.online.svallo.model.callingfeatures._2014._09._15;

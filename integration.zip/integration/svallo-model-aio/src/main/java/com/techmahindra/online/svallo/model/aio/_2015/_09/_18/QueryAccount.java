
package com.techmahindra.online.svallo.model.aio._2015._09._18;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for QueryAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QueryAccount">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adressLine1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adressLine2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adressLine3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adressLine4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adressLine5" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="agreementNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="custLastAmendedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="eventCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="eventNumberAlias" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="externalReference" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="mobileNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="postCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="simNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subLastAmendDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriptionNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="surname" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="firstname" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dateofbirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastAmendedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="tAndC" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="attributeId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="eventTypeCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryAccount", propOrder = {
    "accountIdentifier",
    "accountNumber",
    "adressLine1",
    "adressLine2",
    "adressLine3",
    "adressLine4",
    "adressLine5",
    "agreementNumber",
    "custLastAmendedDate",
    "eventCode",
    "eventNumberAlias",
    "externalReference",
    "mobileNumber",
    "postCode",
    "simNumber",
    "subLastAmendDate",
    "subPassword",
    "subscriptionNumber",
    "surname",
    "firstname",
    "dateofbirth",
    "lastAmendedDate",
    "title",
    "userName",
    "tAndC",
    "attributeId",
    "eventTypeCode"
})
public class QueryAccount {

    @XmlElement(required = true, nillable = true)
    protected String accountIdentifier;
    @XmlElement(required = true, nillable = true)
    protected String accountNumber;
    @XmlElement(required = true, nillable = true)
    protected String adressLine1;
    @XmlElement(required = true, nillable = true)
    protected String adressLine2;
    @XmlElement(required = true, nillable = true)
    protected String adressLine3;
    @XmlElement(required = true, nillable = true)
    protected String adressLine4;
    @XmlElement(required = true, nillable = true)
    protected String adressLine5;
    @XmlElement(required = true, nillable = true)
    protected String agreementNumber;
    @XmlElement(required = true, nillable = true)
    protected String custLastAmendedDate;
    @XmlElement(required = true, nillable = true)
    protected String eventCode;
    @XmlElement(required = true, nillable = true)
    protected String eventNumberAlias;
    @XmlElement(required = true, nillable = true)
    protected String externalReference;
    @XmlElement(required = true, nillable = true)
    protected String mobileNumber;
    @XmlElement(required = true, nillable = true)
    protected String postCode;
    @XmlElement(required = true, nillable = true)
    protected String simNumber;
    @XmlElement(required = true, nillable = true)
    protected String subLastAmendDate;
    @XmlElement(required = true, nillable = true)
    protected String subPassword;
    @XmlElement(required = true, nillable = true)
    protected String subscriptionNumber;
    @XmlElement(required = true, nillable = true)
    protected String surname;
    @XmlElement(required = true, nillable = true)
    protected String firstname;
    @XmlElement(required = true, nillable = true)
    protected String dateofbirth;
    @XmlElement(required = true, nillable = true)
    protected String lastAmendedDate;
    @XmlElement(required = true, nillable = true)
    protected String title;
    @XmlElement(required = true, nillable = true)
    protected String userName;
    @XmlElement(required = true, nillable = true)
    protected String tAndC;
    @XmlElement(required = true, nillable = true)
    protected String attributeId;
    @XmlElement(required = true, nillable = true)
    protected String eventTypeCode;

    /**
     * Gets the value of the accountIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountIdentifier() {
        return accountIdentifier;
    }

    /**
     * Sets the value of the accountIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountIdentifier(String value) {
        this.accountIdentifier = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the adressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdressLine1() {
        return adressLine1;
    }

    /**
     * Sets the value of the adressLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdressLine1(String value) {
        this.adressLine1 = value;
    }

    /**
     * Gets the value of the adressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdressLine2() {
        return adressLine2;
    }

    /**
     * Sets the value of the adressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdressLine2(String value) {
        this.adressLine2 = value;
    }

    /**
     * Gets the value of the adressLine3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdressLine3() {
        return adressLine3;
    }

    /**
     * Sets the value of the adressLine3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdressLine3(String value) {
        this.adressLine3 = value;
    }

    /**
     * Gets the value of the adressLine4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdressLine4() {
        return adressLine4;
    }

    /**
     * Sets the value of the adressLine4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdressLine4(String value) {
        this.adressLine4 = value;
    }

    /**
     * Gets the value of the adressLine5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdressLine5() {
        return adressLine5;
    }

    /**
     * Sets the value of the adressLine5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdressLine5(String value) {
        this.adressLine5 = value;
    }

    /**
     * Gets the value of the agreementNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgreementNumber() {
        return agreementNumber;
    }

    /**
     * Sets the value of the agreementNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgreementNumber(String value) {
        this.agreementNumber = value;
    }

    /**
     * Gets the value of the custLastAmendedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustLastAmendedDate() {
        return custLastAmendedDate;
    }

    /**
     * Sets the value of the custLastAmendedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustLastAmendedDate(String value) {
        this.custLastAmendedDate = value;
    }

    /**
     * Gets the value of the eventCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventCode() {
        return eventCode;
    }

    /**
     * Sets the value of the eventCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventCode(String value) {
        this.eventCode = value;
    }

    /**
     * Gets the value of the eventNumberAlias property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventNumberAlias() {
        return eventNumberAlias;
    }

    /**
     * Sets the value of the eventNumberAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventNumberAlias(String value) {
        this.eventNumberAlias = value;
    }

    /**
     * Gets the value of the externalReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalReference() {
        return externalReference;
    }

    /**
     * Sets the value of the externalReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalReference(String value) {
        this.externalReference = value;
    }

    /**
     * Gets the value of the mobileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Sets the value of the mobileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileNumber(String value) {
        this.mobileNumber = value;
    }

    /**
     * Gets the value of the postCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostCode() {
        return postCode;
    }

    /**
     * Sets the value of the postCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostCode(String value) {
        this.postCode = value;
    }

    /**
     * Gets the value of the simNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSimNumber() {
        return simNumber;
    }

    /**
     * Sets the value of the simNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSimNumber(String value) {
        this.simNumber = value;
    }

    /**
     * Gets the value of the subLastAmendDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubLastAmendDate() {
        return subLastAmendDate;
    }

    /**
     * Sets the value of the subLastAmendDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubLastAmendDate(String value) {
        this.subLastAmendDate = value;
    }

    /**
     * Gets the value of the subPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubPassword() {
        return subPassword;
    }

    /**
     * Sets the value of the subPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubPassword(String value) {
        this.subPassword = value;
    }

    /**
     * Gets the value of the subscriptionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionNumber() {
        return subscriptionNumber;
    }

    /**
     * Sets the value of the subscriptionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionNumber(String value) {
        this.subscriptionNumber = value;
    }

    /**
     * Gets the value of the surname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Sets the value of the surname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurname(String value) {
        this.surname = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstname(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the dateofbirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateofbirth() {
        return dateofbirth;
    }

    /**
     * Sets the value of the dateofbirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateofbirth(String value) {
        this.dateofbirth = value;
    }

    /**
     * Gets the value of the lastAmendedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastAmendedDate() {
        return lastAmendedDate;
    }

    /**
     * Sets the value of the lastAmendedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastAmendedDate(String value) {
        this.lastAmendedDate = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the tAndC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAndC() {
        return tAndC;
    }

    /**
     * Sets the value of the tAndC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAndC(String value) {
        this.tAndC = value;
    }

    /**
     * Gets the value of the attributeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttributeId() {
        return attributeId;
    }

    /**
     * Sets the value of the attributeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttributeId(String value) {
        this.attributeId = value;
    }

    /**
     * Gets the value of the eventTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventTypeCode() {
        return eventTypeCode;
    }

    /**
     * Sets the value of the eventTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventTypeCode(String value) {
        this.eventTypeCode = value;
    }

}

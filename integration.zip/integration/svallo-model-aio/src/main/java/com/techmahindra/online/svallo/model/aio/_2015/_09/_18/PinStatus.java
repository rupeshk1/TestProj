
package com.techmahindra.online.svallo.model.aio._2015._09._18;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PinStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PinStatus">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pinMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pinStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PinStatus", propOrder = {
    "pinMessage",
    "pinStatus"
})
public class PinStatus {

    @XmlElement(required = true, nillable = true)
    protected String pinMessage;
    @XmlElement(required = true, nillable = true)
    protected String pinStatus;

    /**
     * Gets the value of the pinMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinMessage() {
        return pinMessage;
    }

    /**
     * Sets the value of the pinMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinMessage(String value) {
        this.pinMessage = value;
    }

    /**
     * Gets the value of the pinStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinStatus() {
        return pinStatus;
    }

    /**
     * Sets the value of the pinStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinStatus(String value) {
        this.pinStatus = value;
    }

}

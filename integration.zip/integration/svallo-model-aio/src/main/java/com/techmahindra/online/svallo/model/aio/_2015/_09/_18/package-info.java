@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/aio/2015/09/18", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.techmahindra.online.svallo.model.aio._2015._09._18;

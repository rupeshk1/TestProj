
package com.techmahindra.online.svallo.model.aio._2015._09._18;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SubscriptionDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubscriptionDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="activationcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="addressNumberAccountlevel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="agreementNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="customerLastAmendedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="networkSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="networkSerialStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriptionLastAmendedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriptionNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="updateAddressMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="mobileNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="updateAddressAccountLevelMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="updateAddressSubscriptionLevelMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubscriptionDetail", propOrder = {
    "accountNumber",
    "activationcode",
    "addressNumberAccountlevel",
    "agreementNumber",
    "customerLastAmendedDate",
    "networkSerialNumber",
    "networkSerialStatus",
    "subscriptionLastAmendedDate",
    "subscriptionNumber",
    "updateAddressMessage",
    "mobileNumber",
    "updateAddressAccountLevelMessage",
    "updateAddressSubscriptionLevelMessage"
})
public class SubscriptionDetail {

    @XmlElement(required = true, nillable = true)
    protected String accountNumber;
    @XmlElement(required = true, nillable = true)
    protected String activationcode;
    @XmlElement(required = true, nillable = true)
    protected String addressNumberAccountlevel;
    @XmlElement(required = true, nillable = true)
    protected String agreementNumber;
    @XmlElement(required = true, nillable = true)
    protected String customerLastAmendedDate;
    @XmlElement(required = true, nillable = true)
    protected String networkSerialNumber;
    @XmlElement(required = true, nillable = true)
    protected String networkSerialStatus;
    @XmlElement(required = true, nillable = true)
    protected String subscriptionLastAmendedDate;
    @XmlElement(required = true, nillable = true)
    protected String subscriptionNumber;
    @XmlElement(required = true, nillable = true)
    protected String updateAddressMessage;
    @XmlElement(required = true, nillable = true)
    protected String mobileNumber;
    @XmlElement(required = true, nillable = true)
    protected String updateAddressAccountLevelMessage;
    @XmlElement(required = true, nillable = true)
    protected String updateAddressSubscriptionLevelMessage;

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the activationcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivationcode() {
        return activationcode;
    }

    /**
     * Sets the value of the activationcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivationcode(String value) {
        this.activationcode = value;
    }

    /**
     * Gets the value of the addressNumberAccountlevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressNumberAccountlevel() {
        return addressNumberAccountlevel;
    }

    /**
     * Sets the value of the addressNumberAccountlevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressNumberAccountlevel(String value) {
        this.addressNumberAccountlevel = value;
    }

    /**
     * Gets the value of the agreementNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgreementNumber() {
        return agreementNumber;
    }

    /**
     * Sets the value of the agreementNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgreementNumber(String value) {
        this.agreementNumber = value;
    }

    /**
     * Gets the value of the customerLastAmendedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerLastAmendedDate() {
        return customerLastAmendedDate;
    }

    /**
     * Sets the value of the customerLastAmendedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerLastAmendedDate(String value) {
        this.customerLastAmendedDate = value;
    }

    /**
     * Gets the value of the networkSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkSerialNumber() {
        return networkSerialNumber;
    }

    /**
     * Sets the value of the networkSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkSerialNumber(String value) {
        this.networkSerialNumber = value;
    }

    /**
     * Gets the value of the networkSerialStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkSerialStatus() {
        return networkSerialStatus;
    }

    /**
     * Sets the value of the networkSerialStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkSerialStatus(String value) {
        this.networkSerialStatus = value;
    }

    /**
     * Gets the value of the subscriptionLastAmendedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionLastAmendedDate() {
        return subscriptionLastAmendedDate;
    }

    /**
     * Sets the value of the subscriptionLastAmendedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionLastAmendedDate(String value) {
        this.subscriptionLastAmendedDate = value;
    }

    /**
     * Gets the value of the subscriptionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionNumber() {
        return subscriptionNumber;
    }

    /**
     * Sets the value of the subscriptionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionNumber(String value) {
        this.subscriptionNumber = value;
    }

    /**
     * Gets the value of the updateAddressMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateAddressMessage() {
        return updateAddressMessage;
    }

    /**
     * Sets the value of the updateAddressMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateAddressMessage(String value) {
        this.updateAddressMessage = value;
    }

    /**
     * Gets the value of the mobileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Sets the value of the mobileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileNumber(String value) {
        this.mobileNumber = value;
    }

    /**
     * Gets the value of the updateAddressAccountLevelMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateAddressAccountLevelMessage() {
        return updateAddressAccountLevelMessage;
    }

    /**
     * Sets the value of the updateAddressAccountLevelMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateAddressAccountLevelMessage(String value) {
        this.updateAddressAccountLevelMessage = value;
    }

    /**
     * Gets the value of the updateAddressSubscriptionLevelMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateAddressSubscriptionLevelMessage() {
        return updateAddressSubscriptionLevelMessage;
    }

    /**
     * Sets the value of the updateAddressSubscriptionLevelMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateAddressSubscriptionLevelMessage(String value) {
        this.updateAddressSubscriptionLevelMessage = value;
    }

}

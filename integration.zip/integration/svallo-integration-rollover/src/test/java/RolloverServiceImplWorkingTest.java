
import junit.framework.TestCase;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class RolloverServiceImplWorkingTest extends TestCase{	
	
	Source xsl = new StreamSource(new File("src/test/resources/xsl/QuerySubscription-RolloverSTD.xsl"));
	Transformer transformer;
	String dateValue="1111-11-11Z";
		
	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	public void testNoMonthMinutes(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/no_customer_basket_minutes.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/no_customer_basket_minutes_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/no_customer_basket_minutes_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for no month minutes : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in no month minutes response",3, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testOneMonthMinutes(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/1_customer_basket_minutes.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/1_customer_basket_minutes_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/1_customer_basket_minutes_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for one month minutes : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in one month minutes response",2, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
		
	
	public void testTwoMonthMinutes(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/2_customer_basket_minutes.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/2_customer_basket_minutes_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/2_customer_basket_minutes_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for two month minutes : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in two month minutes response",1, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	public void testOneMonthZeroValueMinutes(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/1_0_customer_basket_minutes.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/1_0_customer_basket_minutes_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/1_0_customer_basket_minutes_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for one month zero value minutes : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in one month minutes zero value response",2, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testTwoMonthZeroValueMinutes(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/2_0_customer_basket_minutes.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/2_0_customer_basket_minutes_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/2_0_customer_basket_minutes_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for two month zero value minutes : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in two month minutes zero value response",1, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	public void testThreeMonthZeroValueMinutes(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/3_0_customer_basket_minutes.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/3_0_customer_basket_minutes_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/3_0_customer_basket_minutes_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for three month zero value minutes : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in three month minutes zero value response",0, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	public void testFourMonthMinutes(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/4_customer_basket_minutes.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/4_customer_basket_minutes_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/4_customer_basket_minutes_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("minsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for four month minutes : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
	         
				assertEquals("Error in four month minutes response",3, list1.getLength());	
			}		    
					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	/* minutes end */
	
	
	/* text start */
	public void testNoMonthText(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/no_customer_basket_text.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/no_customer_basket_text_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/no_customer_basket_text_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("textsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for no month text : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in no month text response",3, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testOneMonthText(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/1_customer_basket_text.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/1_customer_basket_text_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/1_customer_basket_text_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("textsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for one month text : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in one month text response",2, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 

	
	public void testTwoMonthText(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/2_customer_basket_text.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/2_customer_basket_text_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/2_customer_basket_text_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("textsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for two month text : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in two month text response",1, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testOneMonthZeroValueText(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/1_0_customer_basket_text.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/1_0_customer_basket_text_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/1_0_customer_basket_text_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("textsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for one month zero value text : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in one month text zero value response",2, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testTwoMonthZeroValueText(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/2_0_customer_basket_text.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/2_0_customer_basket_text_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/2_0_customer_basket_text_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("textsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for two month zero value text: "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in two month text zero value response",1, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	public void testThreeMonthZeroValueText(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/3_0_customer_basket_text.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/3_0_customer_basket_text_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/3_0_customer_basket_text_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("textsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for three month zero value text : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in three month text zero value response",0, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testFourMonthText(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/4_customer_basket_text.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/4_customer_basket_text_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/4_customer_basket_text_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("textsRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for four month text : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
	         
				assertEquals("Error in four month text response",3, list1.getLength());	
			}		    
					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	
	
	/* Data Start */
	
	
	public void testNoMonthData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/no_customer_basket_data.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/no_customer_basket_data_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/no_customer_basket_data_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for no month data : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in no month data response",3, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testOneMonthData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/1_customer_basket_data.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/1_customer_basket_data_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/1_customer_basket_data_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for one month data : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in one month data response",2, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 

	
	public void testTwoMonthData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/2_customer_basket_data.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/2_customer_basket_data_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/2_customer_basket_data_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for two month data : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in two month data response",1, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testOneMonthZeroValueData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/1_0_customer_basket_data.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/1_0_customer_basket_data_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/1_0_customer_basket_data_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for one month zero value data : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
			}		    
			assertEquals("Error in one month data zero value response",2, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	
	public void testTwoMonthZeroValueData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/2_0_customer_basket_data.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/2_0_customer_basket_data_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/2_0_customer_basket_data_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for two month zero value data: "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				  }
	            }
			  }		    
			assertEquals("Error in two month data zero value response",1, countVal);			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
	
	public void testThreeMonthZeroValueData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/3_0_customer_basket_data.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/3_0_customer_basket_data_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/3_0_customer_basket_data_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for three month zero value data : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				  }
	            }
			  }		    
			assertEquals("Error in three month data zero value response",0, countVal);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	  } 
	
	
	public void testFourMonthData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/4_customer_basket_data.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/4_customer_basket_data_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/4_customer_basket_data_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for four month data : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
	         
				assertEquals("Error in four month data response",3, list1.getLength());	
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	

	
	public void testBasketPositionInterChangeData(){		
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/content_interchange_customer_basket.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/content_interchange_customer_basket_out.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);		   
		    
		    int countVal = 0;
		    System.out.println("###########################################");
		    String filepath = "src/test/resources/output_xml/content_interchange_customer_basket_out.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList list = doc.getElementsByTagName("dataRollover");		
			//System.out.println("Total of elements : " + list.getLength());	
			
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < list.getLength(); itr++) {
				Node node = list.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());				
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());				
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;
					System.out.println("effectiveDate for basket position interchange : "+eElement.getElementsByTagName("effectiveDate").item(0).getTextContent());
					if(dateValue.equalsIgnoreCase(eElement.getElementsByTagName("effectiveDate").item(0).getTextContent())){
						countVal = countVal+1;
					}
				}
	          }
	         
				assertEquals("Error in basket position interchange response",3, list1.getLength());	
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 System.out.println("###########################################");
		 System.out.println("");
	} 
	
}

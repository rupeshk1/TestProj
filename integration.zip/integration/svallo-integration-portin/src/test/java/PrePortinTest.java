import junit.framework.TestCase;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class PrePortinTest extends TestCase{	
	
	Source xsl = new StreamSource(new File("src/main/resources/META-INF/xsl/MDS_PrePortIn-SvalloPrePortIn.xsl"));
	Transformer transformer;
	//String externalReference="SELFCARE-PORTAL";
	//String createdDate = "2014-10-21T12:12:12Z";
	//String currentUserID = "123";
	//String eventCode = "PTIN";
	//String eventNumber = "7890";
	//String eventStatus = "RESOLVE";
	//String eventType = "PROV";
	//String queryLimitExceeded = "false";
		
	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	public void testPrePortin_0Workflow(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_0Workflow.xml"));
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_0Workflow.xml"));
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_0Workflow.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			/*String MDS_createdDate = doc.getElementsByTagName("ns1:createdDate").item(0).getTextContent();			
			String MDS_currentUserID = doc.getElementsByTagName("ns1:currentUserID").item(0).getTextContent();
			String MDS_eventCode = doc.getElementsByTagName("ns1:eventCode").item(0).getTextContent();
			String MDS_eventNumber = doc.getElementsByTagName("ns1:eventNumber").item(0).getTextContent();
			String MDS_eventStatus = doc.getElementsByTagName("ns1:eventStatus").item(0).getTextContent();
			String MDS_eventType = doc.getElementsByTagName("ns1:eventType").item(0).getTextContent();*/
			String MDS_queryLimitExceeded = doc.getElementsByTagName("ns1:queryLimitExceeded").item(0).getTextContent();
			
			System.out.println("**************** 0 Workflow ******************************");
			/*System.out.println("MDS_createdDate: " +MDS_createdDate);
			System.out.println("MDS_currentUserID: " +MDS_currentUserID);
			System.out.println("MDS_eventCode: " +MDS_eventCode);
			System.out.println("MDS_eventNumber: " +MDS_eventNumber);
			System.out.println("MDS_eventStatus: " +MDS_eventStatus);
			System.out.println("MDS_eventType: " +MDS_eventType);*/
			System.out.println("MDS_queryLimitExceeded: " +MDS_queryLimitExceeded);
			System.out.println("**********************************************");
			
			/*assertEquals("Test success(createdDate): ", "", MDS_createdDate);
			assertEquals("Test success(currentUserID): ", "", MDS_currentUserID);
			assertEquals("Test success(eventCode): ", "", MDS_eventCode);
			assertEquals("Test success(eventNumber): ", "", MDS_eventNumber);
			assertEquals("Test success(eventStatus): ", "", MDS_eventStatus);
			assertEquals("Test success(eventType): ", "", MDS_eventType);*/
			assertEquals("Test success(queryLimitExceeded): ", "false", MDS_queryLimitExceeded);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}
	
	public void testPrePortin_1Workflow(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_1Workflow.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_1Workflow.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_1Workflow.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			String MDS_createdDate = doc.getElementsByTagName("ns1:createdDate").item(0).getTextContent();			
			String MDS_currentUserID = doc.getElementsByTagName("ns1:currentUserID").item(0).getTextContent();
			String MDS_eventCode = doc.getElementsByTagName("ns1:eventCode").item(0).getTextContent();
			String MDS_eventNumber = doc.getElementsByTagName("ns1:eventNumber").item(0).getTextContent();
			String MDS_eventStatus = doc.getElementsByTagName("ns1:eventStatus").item(0).getTextContent();
			String MDS_eventType = doc.getElementsByTagName("ns1:eventType").item(0).getTextContent();
			String MDS_queryLimitExceeded = doc.getElementsByTagName("ns1:queryLimitExceeded").item(0).getTextContent();
			
			System.out.println("************** 1 Workflow ********************************");
			System.out.println("MDS_createdDate: " +MDS_createdDate);
			System.out.println("MDS_currentUserID: " +MDS_currentUserID);
			System.out.println("MDS_eventCode: " +MDS_eventCode);
			System.out.println("MDS_eventNumber: " +MDS_eventNumber);
			System.out.println("MDS_eventStatus: " +MDS_eventStatus);
			System.out.println("MDS_eventType: " +MDS_eventType);
			System.out.println("MDS_queryLimitExceeded: " +MDS_queryLimitExceeded);
			System.out.println("**********************************************");
			
			assertEquals("Test success(createdDate): ", "2014-10-21T12:12:12Z", MDS_createdDate);
			assertEquals("Test success(currentUserID): ", "123", MDS_currentUserID);
			assertEquals("Test success(eventCode): ", "PTIN", MDS_eventCode);
			assertEquals("Test success(eventNumber): ", "7890", MDS_eventNumber);
			assertEquals("Test success(eventStatus): ", "RESOLVE", MDS_eventStatus);
			assertEquals("Test success(eventType): ", "PROV", MDS_eventType);
			assertEquals("Test success(queryLimitExceeded): ", "false", MDS_queryLimitExceeded);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}
	
	public void testPrePortin_1Workflow_DifferentData(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_1Workflow_DifferentData.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_1Workflow_DifferentData.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_1Workflow_DifferentData.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			String MDS_createdDate = doc.getElementsByTagName("ns1:createdDate").item(0).getTextContent();			
			String MDS_currentUserID = doc.getElementsByTagName("ns1:currentUserID").item(0).getTextContent();
			String MDS_eventCode = doc.getElementsByTagName("ns1:eventCode").item(0).getTextContent();
			String MDS_eventNumber = doc.getElementsByTagName("ns1:eventNumber").item(0).getTextContent();
			String MDS_eventStatus = doc.getElementsByTagName("ns1:eventStatus").item(0).getTextContent();
			String MDS_eventType = doc.getElementsByTagName("ns1:eventType").item(0).getTextContent();
			String MDS_queryLimitExceeded = doc.getElementsByTagName("ns1:queryLimitExceeded").item(0).getTextContent();
			
			System.out.println("***************** 1 Workflow Different data *****************************");
			System.out.println("MDS_createdDate: " +MDS_createdDate);
			System.out.println("MDS_currentUserID: " +MDS_currentUserID);
			System.out.println("MDS_eventCode: " +MDS_eventCode);
			System.out.println("MDS_eventNumber: " +MDS_eventNumber);
			System.out.println("MDS_eventStatus: " +MDS_eventStatus);
			System.out.println("MDS_eventType: " +MDS_eventType);
			System.out.println("MDS_queryLimitExceeded: " +MDS_queryLimitExceeded);
			System.out.println("**********************************************");
			
			assertEquals("Test success(createdDate): ", "2013-01-21T12:12:12Z", MDS_createdDate);
			assertEquals("Test success(currentUserID): ", "111", MDS_currentUserID);
			assertEquals("Test success(eventCode): ", "PTIN", MDS_eventCode);
			assertEquals("Test success(eventNumber): ", "1211", MDS_eventNumber);
			assertEquals("Test success(eventStatus): ", "RESOLVED", MDS_eventStatus);
			assertEquals("Test success(eventType): ", "PROV", MDS_eventType);
			assertEquals("Test success(queryLimitExceeded): ", "true", MDS_queryLimitExceeded);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}
	
	public void testPrePortin_1Workflow_EmptyElements(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_1Workflow_EmptyElements.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_1Workflow_EmptyElements.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_1Workflow_EmptyElements.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			String MDS_createdDate = doc.getElementsByTagName("ns1:createdDate").item(0).getTextContent();			
			String MDS_currentUserID = doc.getElementsByTagName("ns1:currentUserID").item(0).getTextContent();
			String MDS_eventCode = doc.getElementsByTagName("ns1:eventCode").item(0).getTextContent();
			String MDS_eventNumber = doc.getElementsByTagName("ns1:eventNumber").item(0).getTextContent();
			String MDS_eventStatus = doc.getElementsByTagName("ns1:eventStatus").item(0).getTextContent();
			String MDS_eventType = doc.getElementsByTagName("ns1:eventType").item(0).getTextContent();
			String MDS_queryLimitExceeded = doc.getElementsByTagName("ns1:queryLimitExceeded").item(0).getTextContent();
			
			System.out.println("**************** 1 Workflow empty elements******************************");
			System.out.println("MDS_createdDate: " +MDS_createdDate);
			System.out.println("MDS_currentUserID: " +MDS_currentUserID);
			System.out.println("MDS_eventCode: " +MDS_eventCode);
			System.out.println("MDS_eventNumber: " +MDS_eventNumber);
			System.out.println("MDS_eventStatus: " +MDS_eventStatus);
			System.out.println("MDS_eventType: " +MDS_eventType);
			System.out.println("MDS_queryLimitExceeded: " +MDS_queryLimitExceeded);
			System.out.println("**********************************************");
			
			assertEquals("Test success(createdDate): ", "", MDS_createdDate);
			assertEquals("Test success(currentUserID): ", "", MDS_currentUserID);
			assertEquals("Test success(eventCode): ", "", MDS_eventCode);
			assertEquals("Test success(eventNumber): ", "", MDS_eventNumber);
			assertEquals("Test success(eventStatus): ", "", MDS_eventStatus);
			assertEquals("Test success(eventType): ", "", MDS_eventType);
			assertEquals("Test success(queryLimitExceeded): ", "", MDS_queryLimitExceeded);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}
	
	public void testPrePortin_2Workflow(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_2Workflow.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_2Workflow.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_2Workflow.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			String MDS_createdDate = doc.getElementsByTagName("ns1:createdDate").item(0).getTextContent();			
			String MDS_currentUserID = doc.getElementsByTagName("ns1:currentUserID").item(0).getTextContent();
			String MDS_eventCode = doc.getElementsByTagName("ns1:eventCode").item(0).getTextContent();
			String MDS_eventNumber = doc.getElementsByTagName("ns1:eventNumber").item(0).getTextContent();
			String MDS_eventStatus = doc.getElementsByTagName("ns1:eventStatus").item(0).getTextContent();
			String MDS_eventType = doc.getElementsByTagName("ns1:eventType").item(0).getTextContent();
			String MDS_queryLimitExceeded = doc.getElementsByTagName("ns1:queryLimitExceeded").item(0).getTextContent();
			
			System.out.println("****************** 2 Workflow ****************************");
			System.out.println("MDS_createdDate: " +MDS_createdDate);
			System.out.println("MDS_currentUserID: " +MDS_currentUserID);
			System.out.println("MDS_eventCode: " +MDS_eventCode);
			System.out.println("MDS_eventNumber: " +MDS_eventNumber);
			System.out.println("MDS_eventStatus: " +MDS_eventStatus);
			System.out.println("MDS_eventType: " +MDS_eventType);
			System.out.println("MDS_queryLimitExceeded: " +MDS_queryLimitExceeded);
			System.out.println("**********************************************");
			
			assertEquals("Test success(createdDate): ", "2014-10-21T12:12:12Z", MDS_createdDate);
			assertEquals("Test success(currentUserID): ", "123", MDS_currentUserID);
			assertEquals("Test success(eventCode): ", "PTIN", MDS_eventCode);
			assertEquals("Test success(eventNumber): ", "7890", MDS_eventNumber);
			assertEquals("Test success(eventStatus): ", "RESOLVE", MDS_eventStatus);
			assertEquals("Test success(eventType): ", "PROV", MDS_eventType);
			assertEquals("Test success(queryLimitExceeded): ", "false", MDS_queryLimitExceeded);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void testPrePortin_3Workflow(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_3Workflow.xml"));
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_3Workflow.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_3Workflow.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			String MDS_createdDate = doc.getElementsByTagName("ns1:createdDate").item(0).getTextContent();			
			String MDS_currentUserID = doc.getElementsByTagName("ns1:currentUserID").item(0).getTextContent();
			String MDS_eventCode = doc.getElementsByTagName("ns1:eventCode").item(0).getTextContent();
			String MDS_eventNumber = doc.getElementsByTagName("ns1:eventNumber").item(0).getTextContent();
			String MDS_eventStatus = doc.getElementsByTagName("ns1:eventStatus").item(0).getTextContent();
			String MDS_eventType = doc.getElementsByTagName("ns1:eventType").item(0).getTextContent();
			String MDS_queryLimitExceeded = doc.getElementsByTagName("ns1:queryLimitExceeded").item(0).getTextContent();
			
			System.out.println("******************* 3 Workflow ***************************");
			System.out.println("MDS_createdDate: " +MDS_createdDate);
			System.out.println("MDS_currentUserID: " +MDS_currentUserID);
			System.out.println("MDS_eventCode: " +MDS_eventCode);
			System.out.println("MDS_eventNumber: " +MDS_eventNumber);
			System.out.println("MDS_eventStatus: " +MDS_eventStatus);
			System.out.println("MDS_eventType: " +MDS_eventType);
			System.out.println("MDS_queryLimitExceeded: " +MDS_queryLimitExceeded);
			System.out.println("**********************************************");
			
			assertEquals("Test success(createdDate): ", "2014-10-21T12:12:12Z", MDS_createdDate);
			assertEquals("Test success(currentUserID): ", "123", MDS_currentUserID);
			assertEquals("Test success(eventCode): ", "PTIN", MDS_eventCode);
			assertEquals("Test success(eventNumber): ", "7890", MDS_eventNumber);
			assertEquals("Test success(eventStatus): ", "RESOLVE", MDS_eventStatus);
			assertEquals("Test success(eventType): ", "PROV", MDS_eventType);
			assertEquals("Test success(queryLimitExceeded): ", "false", MDS_queryLimitExceeded);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	}

import junit.framework.TestCase;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class PortinTest extends TestCase{	
	
	Source xsl = new StreamSource(new File("src/main/resources/META-INF/xsl/MDS_PortIn-SvalloPortIn.xsl"));
	Transformer transformer;	
		
	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	public void testPortinSuccess(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_WithExternalReference.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_WithExternalReference.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_WithExternalReference.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
						
			String MDS_externalReference = doc.getElementsByTagName("ns1:message").item(0).getTextContent();
			
			System.out.println("***************** Portin with externalreference *****************************");
			System.out.println("MDS_externalReference: " +MDS_externalReference);			
			System.out.println("**********************************************");
			
			assertEquals("Test success(externalReference): ", "SELFCARE-PORTAL", MDS_externalReference);			
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}
	
	public void testPortinFailure(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_WithExternalReference_Failure.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_WithExternalReference_Failure.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_WithExternalReference_Failure.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
						
			String MDS_externalReference = doc.getElementsByTagName("ns1:message").item(0).getTextContent();
			
			System.out.println("*****************Portin with external reference as empty element *****************************");
			System.out.println("MDS_externalReference: " +MDS_externalReference);			
			System.out.println("**********************************************");
			
			assertEquals("Test success(externalReference): ", "", MDS_externalReference);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}
	
	public void testPortinFailure1(){
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/successful_in_WithExternalReference_Failure1.xml"));		
			Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/successful_out_WithExternalReference_Failure1.xml"));	
			
			transformer = TransformerFactory.newInstance().newTransformer(xsl);
		    transformer.transform(xmlInput, xmlOutput);
		    
		    String filepath = "src/test/resources/output_xml/successful_out_WithExternalReference_Failure1.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
		    //doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
						
			String MDS_externalReference = doc.getElementsByTagName("ns1:message").item(0).getTextContent();
			
			System.out.println("*****************Portin with no external reference element *****************************");
			System.out.println("MDS_externalReference: " +MDS_externalReference);
			System.out.println("**********************************************");
			
			assertEquals("Test success(externalReference): ", "", MDS_externalReference);
		    
		    //assertEquals("Hello", "Hello");
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
	}
	
	}

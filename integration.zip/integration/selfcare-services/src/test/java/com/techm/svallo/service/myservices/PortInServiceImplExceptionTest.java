package com.techm.svallo.service.myservices;

import java.io.File;
import java.net.URL;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPortInDetails;
import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPortInDetailsResponse;
import com.techmahindra.online.svallo.service.common.exception.portin.SvalloPortinIntegrationException;
import com.techmahindra.online.svallo.service.portin.impl._2014._09._18.SvalloPortInImpl;

import junit.framework.TestCase;

public class PortInServiceImplExceptionTest extends TestCase {

	private String exceptionMessage="failure";
	
	//File file = new File("C:\\Users\\HP00350933\\Desktop\\Junit\\svallo-service-portin-beans.xml");
	SvalloPortInImpl impl = null;

	/**
	 *  this method is used for to create the instance of classes.
	 */
	
	public void setUp() throws Exception {
		super.setUp();		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("svallo-service-portin-beans.xml");  
		impl = (SvalloPortInImpl) ctx.getBean("portinServiceException");
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	@Test
	public void testPortInException(){	
		try{
		SvalloPortInDetails svalloPortInDetails = new SvalloPortInDetails();
		svalloPortInDetails.setSubscriptionNumber("12345");
		svalloPortInDetails.setPacCode("123456789");
		svalloPortInDetails.setPortDate("2014-09-01");
		svalloPortInDetails.setNumberToPort("88888888888");
		SvalloPortInDetailsResponse getPortInDetailsResponse = impl.getPortInDetails(svalloPortInDetails);				
		String result = getPortInDetailsResponse.getMessage();
		assertEquals("Exception - excpetion in port-in",exceptionMessage, result);
		fail("MyException expected.");
		} catch(SvalloPortinIntegrationException spie){			
			assertTrue("Service Down", false);
		}
	}
	
}

package com.techm.svallo.service.myservices;

import java.io.File;
import java.net.URL;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPortInDetails;
import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPortInDetailsResponse;
import com.techmahindra.online.svallo.service.portin.impl._2014._09._18.SvalloPortInImpl;

import junit.framework.TestCase;

public class PortInServiceImplFailureTest extends TestCase {

	private String failureMessage="failure";
	
	//File file = new File("C:\\Users\\HP00350933\\Desktop\\Junit\\svallo-service-portin-beans.xml");
	SvalloPortInImpl impl = null;

	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("svallo-service-portin-beans.xml");  
		impl = (SvalloPortInImpl) ctx.getBean("portinService");
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	public void testPortInFailure(){	
		SvalloPortInDetails svalloPortInDetails = new SvalloPortInDetails();
		svalloPortInDetails.setSubscriptionNumber("12345");
		svalloPortInDetails.setPacCode("123456789");
		svalloPortInDetails.setPortDate("2014-09-01");
		svalloPortInDetails.setNumberToPort("9975882877");
		SvalloPortInDetailsResponse getPortInDetailsResponse = impl.getPortInDetails(svalloPortInDetails);
		String result = getPortInDetailsResponse.getMessage();
		assertEquals("failure - port-in not successful",failureMessage, result);
	}
	
	public void testPortInNull(){		
		SvalloPortInDetails svalloPortInDetails = new SvalloPortInDetails();
		svalloPortInDetails.setSubscriptionNumber("");
		svalloPortInDetails.setPacCode("123456789");
		svalloPortInDetails.setPortDate("2014-09-01");
		svalloPortInDetails.setNumberToPort("9975882877");
		SvalloPortInDetailsResponse getPortInDetailsResponse = impl.getPortInDetails(svalloPortInDetails);
		assertNull("subscriptionNumber must not be null.",svalloPortInDetails.getSubscriptionNumber());		
		String result = getPortInDetailsResponse.getMessage();		
	}
	
}

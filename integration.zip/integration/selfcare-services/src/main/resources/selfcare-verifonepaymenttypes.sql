DROP TABLE IF EXISTS `selfcare`.`verifone_payment_types`;
CREATE TABLE `selfcare`.`verifone_payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(45) DEFAULT NULL,
  `payment_type_desc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


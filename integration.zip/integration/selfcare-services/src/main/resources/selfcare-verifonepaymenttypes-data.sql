/*
-- Query: SELECT * FROM selfcare.verifone_payment_types
LIMIT 0, 1000

-- Date: 2015-01-29 18:35
*/
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (1,'MANUAL','Manual Payment (Non-DD Fee)');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (2,'DD','Direct Debit');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (3,'MANEXC','Manual Payment (No Non-DD Fee)');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (4,'REDIR','Credit/Debit Card');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (5,'AMEX','American Express');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (6,'VISA','Visa');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (7,'MASTER','Mastercard');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (8,'DINERS','Diners');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (9,'VISADB','Visa Debit');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (10,'JCB','JCB');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (11,'TRADUK','Time/Trade UK Account Card');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (12,'SOLO','Solo');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (13,'ELECTR','Electron');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (14,'VISCPC','Visa CPC');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (15,'ALLCPC','AllStar CPC');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (16,'EDC','EDC/Maestro (INT) / Laser');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (17,'LTF','LTF');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (18,'CAF','CAF (Charity Aids Foundation)');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (19,'CREATI','Creation');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (20,'CLYDES','Clydesdale');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (21,'BHS','BHS Gold');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (22,'MOTHER','Mothercare Card');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (23,'ARCADI','Arcadia Group Card');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (24,'BAAIR','BA AirPlus');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (25,'AMEXCP','Amex CPC');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (26,'FCUK','FCUK Card (Style)');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (27,'PREMIN','Premier Inn Business Account');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (28,'MASTDB','MasterCard Debit');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (29,'IKEA','IKEA Home Card (IKANO)');
INSERT INTO `selfcare`.`verifone_payment_types` (`id`,`payment_type`,`payment_type_desc`) VALUES (30,'HFC','HFC Store Card');

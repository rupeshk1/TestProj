DROP TABLE IF EXISTS `selfcare`.`portin`;
CREATE TABLE `selfcare`.`portin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountnumber` varchar(45) DEFAULT NULL,
  `portin_date` varchar(45) DEFAULT NULL,
  `ported_date` varchar(45) DEFAULT NULL,
  `mobile_number` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


TRUNCATE TABLE  invoicesummary;
commit;

INSERT INTO invoicesummary VALUES (11,'00113','5','01-01-2014','30-01-2014','11.11','paid','27-01-2014');
INSERT INTO invoicesummary VALUES (12,'00115','5','01-04-2014','30-04-2014','44.44','paid','27-04-2014');
INSERT INTO invoicesummary VALUES (13,'00116','5','01-05-2014','30-05-2014','55.55','paid','27-05-2014');
INSERT INTO invoicesummary VALUES (14,'00117','5','01-06-2014','30-06-2014','66.66','paid','27-06-2014');
INSERT INTO invoicesummary VALUES (15,'00118','5','01-07-2014','30-07-2014','77.77','paid','27-07-2014');
INSERT INTO invoicesummary VALUES (16,'00119','5','01-08-2014','30-08-2014','88.88','paid','27-08-2014');
INSERT INTO invoicesummary VALUES (17,'00120','5','01-09-2014','30-09-2014','99.99','paid','27-09-2014');
commit;


INSERT INTO invoicesummary VALUES (21,'00113','10','01-01-2014','30-01-2014','11.11','paid','27-01-2014');
INSERT INTO invoicesummary VALUES (22,'00115','10','01-04-2014','30-04-2014','44.44','paid','27-04-2014');
INSERT INTO invoicesummary VALUES (23,'00116','10','01-05-2014','30-05-2014','55.55','paid','27-05-2014');
INSERT INTO invoicesummary VALUES (24,'00117','10','01-06-2014','30-06-2014','66.66','paid','27-06-2014');
INSERT INTO invoicesummary VALUES (25,'00118','10','01-07-2014','30-07-2014','77.77','paid','27-07-2014');
INSERT INTO invoicesummary VALUES (26,'00119','10','01-08-2014','30-08-2014','88.88','paid','27-08-2014');
INSERT INTO invoicesummary VALUES (27,'00120','10','01-09-2014','30-09-2014','99.99','paid','27-09-2014');
commit;

INSERT INTO invoicesummary VALUES (28,'00113','3','01-01-2014','30-01-2014','11.11','paid','27-01-2014');
INSERT INTO invoicesummary VALUES (29,'00115','3','01-04-2014','30-04-2014','44.44','paid','27-04-2014');
INSERT INTO invoicesummary VALUES (30,'00116','3','01-05-2014','30-05-2014','55.55','paid','27-05-2014');
INSERT INTO invoicesummary VALUES (31,'00117','3','01-06-2014','30-06-2014','66.66','paid','27-06-2014');
INSERT INTO invoicesummary VALUES (32,'00118','3','01-07-2014','30-07-2014','77.77','paid','27-07-2014');
INSERT INTO invoicesummary VALUES (33,'00119','3','01-08-2014','30-08-2014','88.88','paid','27-08-2014');
INSERT INTO invoicesummary VALUES (34,'00120','3','01-09-2014','30-09-2014','99.99','paid','27-09-2014');
commit;

INSERT INTO invoicesummary VALUES (35,'00113','10120030','01-01-2014','30-01-2014','11.11','paid','27-01-2014');
INSERT INTO invoicesummary VALUES (36,'00115','10120030','01-04-2014','30-04-2014','44.44','paid','27-04-2014');
INSERT INTO invoicesummary VALUES (37,'00116','10120030','01-05-2014','30-05-2014','55.55','paid','27-05-2014');
INSERT INTO invoicesummary VALUES (38,'00117','10120030','01-06-2014','30-06-2014','66.66','paid','27-06-2014');
INSERT INTO invoicesummary VALUES (39,'00118','10120030','01-07-2014','30-07-2014','77.77','paid','27-07-2014');
INSERT INTO invoicesummary VALUES (40,'00119','10120030','01-08-2014','30-08-2014','88.88','paid','27-08-2014');
INSERT INTO invoicesummary VALUES (41,'00120','10120030','01-09-2014','30-09-2014','99.99','paid','27-09-2014');
commit;

INSERT INTO invoicesummary VALUES (42,'00113','10120031','01-01-2014','30-01-2014','11.11','paid','27-01-2014');
INSERT INTO invoicesummary VALUES (43,'00115','10120031','01-04-2014','30-04-2014','44.44','paid','27-04-2014');
INSERT INTO invoicesummary VALUES (44,'00116','10120031','01-05-2014','30-05-2014','55.55','paid','27-05-2014');
INSERT INTO invoicesummary VALUES (45,'00117','10120031','01-06-2014','30-06-2014','66.66','paid','27-06-2014');
INSERT INTO invoicesummary VALUES (46,'00118','10120031','01-07-2014','30-07-2014','77.77','paid','27-07-2014');
INSERT INTO invoicesummary VALUES (47,'00119','10120031','01-08-2014','30-08-2014','88.88','paid','27-08-2014');
INSERT INTO invoicesummary VALUES (48,'00120','10120031','01-09-2014','30-09-2014','99.99','paid','27-09-2014');
commit;

INSERT INTO invoicesummary VALUES (49,'00113','6','01-01-2014','30-01-2014','11.11','paid','27-01-2014');
INSERT INTO invoicesummary VALUES (50,'00115','6','01-04-2014','30-04-2014','44.44','paid','27-04-2014');
INSERT INTO invoicesummary VALUES (51,'00116','6','01-05-2014','30-05-2014','55.55','paid','27-05-2014');
INSERT INTO invoicesummary VALUES (52,'00117','6','01-06-2014','30-06-2014','66.66','paid','27-06-2014');
INSERT INTO invoicesummary VALUES (53,'00118','6','01-07-2014','30-07-2014','77.77','paid','27-07-2014');
INSERT INTO invoicesummary VALUES (54,'00119','6','01-08-2014','30-08-2014','88.88','paid','27-08-2014');
INSERT INTO invoicesummary VALUES (55,'00120','6','01-09-2014','30-09-2014','99.99','paid','27-09-2014');
commit;

INSERT INTO invoicesummary VALUES (56,'00113','8','01-01-2014','30-01-2014','11.11','paid','27-01-2014');
INSERT INTO invoicesummary VALUES (57,'00115','8','01-04-2014','30-04-2014','44.44','paid','27-04-2014');
INSERT INTO invoicesummary VALUES (58,'00116','8','01-05-2014','30-05-2014','55.55','paid','27-05-2014');
INSERT INTO invoicesummary VALUES (59,'00117','8','01-06-2014','30-06-2014','66.66','paid','27-06-2014');
INSERT INTO invoicesummary VALUES (60,'00118','8','01-07-2014','30-07-2014','77.77','paid','27-07-2014');
INSERT INTO invoicesummary VALUES (61,'00119','8','01-08-2014','30-08-2014','88.88','paid','27-08-2014');
INSERT INTO invoicesummary VALUES (62,'00120','6','01-09-2014','30-09-2014','99.99','paid','27-09-2014');
commit;
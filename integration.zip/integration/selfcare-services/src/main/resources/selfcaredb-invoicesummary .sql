DROP TABLE IF EXISTS `selfcare`.`invoicesummary`;
CREATE TABLE  `selfcare`.`invoicesummary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoicenumber` varchar(45) NOT NULL,
  `accountnumber` varchar(45) NOT NULL,
  `billstartdate` varchar(45) NOT NULL,
  `billenddate` varchar(45) NOT NULL,
  `amountdue` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL DEFAULT 'Due',
  `billdate` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_invoicesummary_1` (`accountnumber`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `selfcare`.`areuser`;
 CREATE TABLE `selfcare`.`areuser` (
  `userId` bigint(20)  NOT NULL,
  `status` int(11)  NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
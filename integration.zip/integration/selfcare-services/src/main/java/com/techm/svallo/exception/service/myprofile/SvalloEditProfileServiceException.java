package com.techm.svallo.exception.service.myprofile;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloEditProfileServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

package com.techm.svallo.service.billing;

import java.util.Date;
import java.util.List;

import com.techm.svallo.vo.billing.BillingVO;
import com.techm.svallo.vo.billing.PaymentVO;
import com.techm.svallo.vo.billing.UsageVO;

public interface BillingService {
	
	public BillingVO viewBill( int month );
	
	public List<BillingVO> getBillHistory(int months );
	
	public List<PaymentVO> getPaymentHistory(int months);
	
	public UsageVO viewUsage();
	
}

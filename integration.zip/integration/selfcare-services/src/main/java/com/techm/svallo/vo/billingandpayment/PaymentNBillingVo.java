package com.techm.svallo.vo.billingandpayment;


public class PaymentNBillingVo
{
    protected String amountPaid;
    protected String paymentDate;
    protected String paymentReference;
    protected String transactionType;
    protected String taxDate;
    protected String minusAmountCheck;
    protected String description;
    
	public String getAmountPaid()
	{
		return amountPaid;
	}
	public void setAmountPaid(String amountPaid)
	{
		this.amountPaid = amountPaid;
	}
	public String getPaymentDate()
	{
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate)
	{
		this.paymentDate = paymentDate;
	}
	public String getPaymentReference()
	{
		return paymentReference;
	}
	public void setPaymentReference(String paymentReference)
	{
		this.paymentReference = paymentReference;
	}
	public String getTransactionType()
	{
		return transactionType;
	}
	public void setTransactionType(String transactionType)
	{
		this.transactionType = transactionType;
	}
	public String getTaxDate() {
		return taxDate;
	}
	public void setTaxDate(String taxDate) {
		this.taxDate = taxDate;
	}
	public String getMinusAmountCheck()
	{
		return minusAmountCheck;
	}
	public void setMinusAmountCheck(String minusAmountCheck)
	{
		this.minusAmountCheck = minusAmountCheck;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
    
	
	
    
}

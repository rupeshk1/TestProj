package com.techm.svallo.vo.plansAndServices;

import java.io.Serializable;

public class AddOn implements Serializable
{
	private static final long serialVersionUID = 3971905164629072899L;
	
	private String addOnId="";
	private String addOnName="";
	private String addOnDescription="";
	private int addOnQuantity=0;
	private float addOnCharges=0.0F;
	private String addOnImagePath="";
	
	public String getAddOnId()
	{
		return addOnId;
	}
	public void setAddOnId(String addOnId)
	{
		this.addOnId = addOnId;
	}
	public String getAddOnName()
	{
		return addOnName;
	}
	public void setAddOnName(String addOnName)
	{
		this.addOnName = addOnName;
	}
	public String getAddOnDescription()
	{
		return addOnDescription;
	}
	public void setAddOnDescription(String addOnDescription)
	{
		this.addOnDescription = addOnDescription;
	}
	public int getAddOnQuantity()
	{
		return addOnQuantity;
	}
	public void setAddOnQuantity(int addOnQuantity)
	{
		this.addOnQuantity = addOnQuantity;
	}
	public float getAddOnCharges()
	{
		return addOnCharges;
	}
	public void setAddOnCharges(float addOnCharges)
	{
		this.addOnCharges = addOnCharges;
	}
	public String getAddOnImagePath()
	{
		return addOnImagePath;
	}
	public void setAddOnImagePath(String addOnImagePath)
	{
		this.addOnImagePath = addOnImagePath;
	}
	
	
	
}

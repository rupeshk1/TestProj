package com.techm.svallo.exception.integration.aio;

import com.techm.svallo.exception.integration.SvalloIntegrationException;

public class SvalloAioIntegrationException extends SvalloIntegrationException
{
	private static final long serialVersionUID = 1L;
}

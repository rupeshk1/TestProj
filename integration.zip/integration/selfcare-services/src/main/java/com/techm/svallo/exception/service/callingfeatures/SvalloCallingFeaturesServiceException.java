package com.techm.svallo.exception.service.callingfeatures;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloCallingFeaturesServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

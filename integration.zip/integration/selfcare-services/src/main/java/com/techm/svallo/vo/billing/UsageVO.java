package com.techm.svallo.vo.billing;

public class UsageVO {

	private String usageType;
	private String tariffPlan;
	private String unbilledAmount;
	private String creditLimit;
	private String deposit;
	
	
	public String getUsageType() {
		return usageType;
	}
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	public String getTariffPlan() {
		return tariffPlan;
	}
	public void setTariffPlan(String tariffPlan) {
		this.tariffPlan = tariffPlan;
	}
	public String getUnbilledAmount() {
		return unbilledAmount;
	}
	public void setUnbilledAmount(String unbilledAmount) {
		this.unbilledAmount = unbilledAmount;
	}
	public String getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}
	public String getDeposit() {
		return deposit;
	}
	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}

}

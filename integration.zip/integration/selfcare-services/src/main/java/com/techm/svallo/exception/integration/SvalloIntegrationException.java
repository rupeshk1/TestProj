package com.techm.svallo.exception.integration;

import com.techm.svallo.exception.SvalloException;


public class SvalloIntegrationException extends SvalloException
{
	private static final long serialVersionUID = 1L;
}

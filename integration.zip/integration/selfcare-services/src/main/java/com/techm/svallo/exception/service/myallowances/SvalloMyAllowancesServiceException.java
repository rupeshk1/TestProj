package com.techm.svallo.exception.service.myallowances;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloMyAllowancesServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

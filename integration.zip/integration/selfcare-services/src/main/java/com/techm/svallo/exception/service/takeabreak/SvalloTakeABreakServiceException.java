package com.techm.svallo.exception.service.takeabreak;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloTakeABreakServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

package com.techm.svallo.exception.service.resetapppin;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloResetAppPinServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

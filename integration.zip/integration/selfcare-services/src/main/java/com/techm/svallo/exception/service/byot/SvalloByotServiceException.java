package com.techm.svallo.exception.service.byot;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloByotServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

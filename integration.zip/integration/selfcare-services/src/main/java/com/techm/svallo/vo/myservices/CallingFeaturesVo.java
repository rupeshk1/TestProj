package com.techm.svallo.vo.myservices;

public class CallingFeaturesVo
{
	
 private String name;
 private String price;
 private String active;
 private String serviceCode;
 private String featureButtonValue;

public String getServiceCode() {
	return serviceCode;
}
public void setServiceCode(String serviceCode) {
	this.serviceCode = serviceCode;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getActive() {
	return active;
}
public void setActive(String active) {
	this.active = active;
}
public String getFeatureButtonValue() {
	return featureButtonValue;
}
public void setFeatureButtonValue(String featureButtonValue) {
	this.featureButtonValue = featureButtonValue;
}
 
}

package com.techm.svallo.vo.billing;
import java.sql.Date;
import java.util.*;

public class CustomerAccountVo {
	
	private String accountNumber=null;
	private String accountNickName=null;
	private Date cdate=null;
	private String status=null;
	private Date lastUpdatedDate=null;
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the accountNickName
	 */
	public String getAccountNickName() {
		return accountNickName;
	}
	/**
	 * @param accountNickName the accountNickName to set
	 */
	public void setAccountNickName(String accountNickName) {
		this.accountNickName = accountNickName;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerAccountVo [accountNumber=");
		builder.append(accountNumber);
		builder.append(", accountNickName=");
		builder.append(accountNickName);
		builder.append("]");
		return builder.toString();
	}

	public Date getCdate() {
		return cdate;
	}
	public void setCdate(Date cdate) {
		this.cdate = cdate;
	}	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}	
}

package com.techm.svallo.exception.service;

import com.techm.svallo.exception.SvalloPortalException;

public class SvalloDatabaseException extends SvalloPortalException
{
	private static final long serialVersionUID = 1L;
}

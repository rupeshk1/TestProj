package com.techm.svallo.exception.service.searchaddress;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloSearchPostalAddressServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

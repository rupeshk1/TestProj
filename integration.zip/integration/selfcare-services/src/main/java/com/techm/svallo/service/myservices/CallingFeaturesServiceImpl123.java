package com.techm.svallo.service.myservices;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.callingfeatures.SvalloCallingFeaturesServiceException;
import com.techm.svallo.vo.myservices.CallingFeaturesVo;
import com.techm.svallo.vo.myservices.MyServicesVo;
import com.techmahindra.online.svallo.model.callingfeatures._2014._09._15.CfRoamDetails;
import com.techmahindra.online.svallo.model.callingfeatures._2014._09._15.CfRoamResponse;
import com.techmahindra.online.svallo.model.callingfeatures._2014._09._15.Service;
import com.techmahindra.online.svallo.model.callingfeatures._2014._09._15.Services;
import com.techmahindra.online.svallo.model.callingfeatures._2014._09._15.SvalloCallingFeaturesRequest;
import com.techmahindra.online.svallo.service.callingfeatures._2014._09._15.CallingFeatures;
import com.techmahindra.online.svallo.service.common.exception.callingfeatures.SvalloCallingFeaturesIntegrationException;

public class CallingFeaturesServiceImpl123 implements CallingFeaturesService123
{
	final static PortalLogger logger = PortalLogger.getLogger(CallingFeaturesServiceImpl123.class);
	
	@Autowired
	private CallingFeatures callingFeatures;

	public void setCallingFeatures(CallingFeatures callingFeatures) {
		this.callingFeatures = callingFeatures;
	}

	@Value("${callingFeatures.addFeature.error.message.detail}")
	private String CALLINGFEATURES_ADDFEATURE_ERROR_MESSAGE_DETAIL;
	
	@Value("${callingFeatures.removeFeature.error.message.detail}")
	private String CALLINGFEATURES_REMOVEFEATURE_ERROR_MESSAGE_DETAIL;
	
	@Value("${callingFeatures.getCallingFeatures.error.message.detail}")
	private String CALLINGFEATURES_GETCALLINGFEATURES_ERROR_MESSAGE_DETAIL;
	
	@Value("${data.not.available}")
	private String DATA_NOT_AVAILABLE;
	
	@Value("${data.not.available}")
	private List<CallingFeaturesVo> DATA_NOT_AVAILABLE_CALLINGFEATURES;
	
	
	@Value("${callingfeatures.impl.getcallingFeaturesDetails.error.code}")
	private String CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_ERROR_CODE;
	
	@Value("${callingfeatures.impl.getcallingFeaturesDetails.error.message}")
	private String CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_ERROR_MESSAGE;
	
	@Value("${callingfeatures.impl.getcallingFeaturesDetails.exception.code}")
	private String CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_EXCEPTION_CODE;
	
	@Value("${callingfeatures.impl.getcallingFeaturesDetails.exception.message}")
	private String CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_EXCEPTION_MESSAGE;
		
	
	@Value("${callingfeatures.impl.getAddCallingFeatureDetails.error.code}")
	private String CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_ERROR_CODE;
	
	@Value("${callingfeatures.impl.getAddCallingFeatureDetails.error.message}")
	private String CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_ERROR_MESSAGE;
	
	@Value("${callingfeatures.impl.getAddCallingFeatureDetails.exception.code}")
	private String CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_EXCEPTION_CODE;
	
	@Value("${callingfeatures.impl.getAddCallingFeatureDetails.exception.message}")
	private String CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_EXCEPTION_MESSAGE;
		
	
	@Value("${callingfeatures.impl.getRemoveCallingFeatureDetails.error.code}")
	private String CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_ERROR_CODE;
	
	@Value("${callingfeatures.impl.getRemoveCallingFeatureDetails.error.message}")
	private String CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_ERROR_MESSAGE;
	
	@Value("${callingfeatures.impl.getRemoveCallingFeatureDetails.exception.code}")
	private String CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_EXCEPTION_CODE;
	
	@Value("${callingfeatures.impl.getRemoveCallingFeatureDetails.exception.message}")
	private String CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_EXCEPTION_MESSAGE;
	
	
	public List<MyServicesVo> getcallingFeaturesDetails(MyServicesVo myServicesVo) {
		
		List<MyServicesVo> myServicesList = new ArrayList<MyServicesVo>();
		MyServicesVo myServicesVoList = new MyServicesVo();
		List<CallingFeaturesVo> callingFeaturesList = new ArrayList<CallingFeaturesVo>();
		
		try {			
			CfRoamResponse cfRoamResponse = new CfRoamResponse();
			SvalloCallingFeaturesRequest callingFeaturesRequest =  new SvalloCallingFeaturesRequest();
			
			
			callingFeaturesRequest.setAccountNumber(myServicesVo.getAccountNumber());
			callingFeaturesRequest.setAccountType(myServicesVo.getAccountType());
			
			Services callingFeaturesResponse = callingFeatures.getCallingFeatures(callingFeaturesRequest);
			
			
			for (int i = 0; i < callingFeaturesResponse.getServices().size(); i++)
			{
				Service callingFeaturesResponseList = callingFeaturesResponse.getServices().get(i);
				CallingFeaturesVo callingFeaturesvo = new CallingFeaturesVo();
				
				callingFeaturesvo.setName(callingFeaturesResponseList.getProductName());
				callingFeaturesvo.setPrice(callingFeaturesResponseList.getProductPrice());
				callingFeaturesvo.setServiceCode(callingFeaturesResponseList.getServiceCode());
				callingFeaturesvo.setActive(callingFeaturesResponseList.getActive());
				callingFeaturesvo.setFeatureButtonValue(callingFeaturesResponseList.getFeatureButtonValue());
				callingFeaturesList.add(callingFeaturesvo);	
			}
			myServicesVoList.setCallingFeaturesVoList(callingFeaturesList);
			/*
			
			CallingFeaturesVo callingFeatures1 = new CallingFeaturesVo();
			CallingFeaturesVo callingFeatures2 = new CallingFeaturesVo();
			CallingFeaturesVo callingFeatures3 = new CallingFeaturesVo();

			callingFeatures1.setName("Roaming");
			callingFeatures1.setPrice("� 0.xx");
			callingFeatures1.setServiceCode("SROAM");
			callingFeatures1.setActive(true);			
			callingFeaturesList.add(callingFeatures1);
			
			callingFeatures2.setName("Call Forwarding");
			callingFeatures2.setPrice("� 5.xx");
			callingFeatures2.setServiceCode("SCALLFRWD");
			callingFeatures2.setActive(false);			
			callingFeaturesList.add(callingFeatures2);
			
			callingFeatures3.setName("Voice Mail");
			callingFeatures3.setPrice("� 7.xx");
			callingFeatures3.setServiceCode("SVM");
			callingFeatures3.setActive(true);			
			callingFeaturesList.add(callingFeatures3);
			myServicesVoList.setCallingFeaturesVoList(callingFeaturesList);
		
		*/
			myServicesList.add(myServicesVoList);
		} 
		catch (SvalloCallingFeaturesIntegrationException scfie) {			
			logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getcallingFeaturesDetails() ] SvalloCallingFeaturesServiceException Catch Block");
			logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getcallingFeaturesDetails() ] SvalloCallingFeaturesServiceException Catch Block | Error Code ="+ CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_ERROR_CODE);
			logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getcallingFeaturesDetails() ] SvalloCallingFeaturesServiceException Catch Block | Error Message ="+ CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_ERROR_MESSAGE);
			SvalloCallingFeaturesServiceException svalloCallingFeaturesServiceException = new SvalloCallingFeaturesServiceException();
			svalloCallingFeaturesServiceException.setErrorCode(CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_ERROR_CODE);
			svalloCallingFeaturesServiceException.setErrorMessage(CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_ERROR_MESSAGE);
			svalloCallingFeaturesServiceException.setRootCause(scfie);
			//scfie.printStackTrace();
			myServicesVoList.setMyServicesError(CALLINGFEATURES_GETCALLINGFEATURES_ERROR_MESSAGE_DETAIL);
			myServicesList.add(myServicesVoList);			
		}	
		catch (Exception e) {			
			logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getcallingFeaturesDetails() ] Exception Catch Block");
			logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getcallingFeaturesDetails() ] Exception Catch Block | Error Code ="+ CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getcallingFeaturesDetails() ] Exception Catch Block | Error Message ="+ CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_EXCEPTION_MESSAGE);
			SvalloCallingFeaturesServiceException svalloCallingFeaturesServiceException = new SvalloCallingFeaturesServiceException();
			svalloCallingFeaturesServiceException.setErrorCode(CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_EXCEPTION_CODE);
			svalloCallingFeaturesServiceException.setErrorMessage(CALLINGFEATURES_IMPL_GETCALLINGFEATURESDETAILS_EXCEPTION_MESSAGE);
			svalloCallingFeaturesServiceException.setRootCause(e);
			//e.printStackTrace();
			myServicesVoList.setMyServicesError(CALLINGFEATURES_GETCALLINGFEATURES_ERROR_MESSAGE_DETAIL);
			myServicesList.add(myServicesVoList);			
		}		
		return myServicesList;
	}

	@Override
	public MyServicesVo getAddCallingFeatureDetails(MyServicesVo myServicesVo) {
		MyServicesVo myServicesAdd = new MyServicesVo();
		 try{			 
			 CfRoamDetails addCallingFeaturesRequest = new CfRoamDetails();
			 addCallingFeaturesRequest.setCustLevelReference(myServicesVo.getSubscriptionNumber());
			 addCallingFeaturesRequest.setServiceCode(myServicesVo.getServiceCode());
			 addCallingFeaturesRequest.setEffectiveDate(myServicesVo.getEffectiveDate());
			 
			 CfRoamResponse addCallingFeaturesResponse = callingFeatures.addFeature(addCallingFeaturesRequest);
			 if(addCallingFeaturesResponse != null){
			    myServicesAdd.setMessage(addCallingFeaturesResponse.getCfRoamMessage());
			 }
	     } 
		 catch (SvalloCallingFeaturesIntegrationException scfie) {
			 logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getAddCallingFeatureDetails() ] SvalloCallingFeaturesServiceException Catch Block");
			 logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getAddCallingFeatureDetails() ] SvalloCallingFeaturesServiceException Catch Block | Error Code ="+ CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_ERROR_CODE);
			 logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getAddCallingFeatureDetails() ] SvalloCallingFeaturesServiceException Catch Block | Error Message ="+ CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_ERROR_MESSAGE);
			 SvalloCallingFeaturesServiceException svalloCallingFeaturesServiceException = new SvalloCallingFeaturesServiceException();
			 svalloCallingFeaturesServiceException.setErrorCode(CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_ERROR_CODE);
			 svalloCallingFeaturesServiceException.setErrorMessage(CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_ERROR_MESSAGE);
			 svalloCallingFeaturesServiceException.setRootCause(scfie);
			 //scfie.printStackTrace();
			 myServicesAdd.setMessage(DATA_NOT_AVAILABLE);
	    	 myServicesAdd.setMyServicesError(CALLINGFEATURES_ADDFEATURE_ERROR_MESSAGE_DETAIL);
	     }
		 catch (Exception e) {
			 logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getAddCallingFeatureDetails() ] Exception Catch Block");
			 logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getAddCallingFeatureDetails() ] Exception Catch Block | Error Code ="+ CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_EXCEPTION_CODE);
			 logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getAddCallingFeatureDetails() ] Exception Catch Block | Error Message ="+ CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_EXCEPTION_MESSAGE);
			 SvalloCallingFeaturesServiceException svalloCallingFeaturesServiceException = new SvalloCallingFeaturesServiceException();
			 svalloCallingFeaturesServiceException.setErrorCode(CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_EXCEPTION_CODE);
			 svalloCallingFeaturesServiceException.setErrorMessage(CALLINGFEATURES_IMPL_GETADDCALLINGFEATUREDETAILS_EXCEPTION_MESSAGE);
			 svalloCallingFeaturesServiceException.setRootCause(e);
			 //e.printStackTrace();
			 myServicesAdd.setMessage(DATA_NOT_AVAILABLE);
	    	 myServicesAdd.setMyServicesError(CALLINGFEATURES_ADDFEATURE_ERROR_MESSAGE_DETAIL);
	     }
		return myServicesAdd;
	}

	@Override
	public MyServicesVo getRemoveCallingFeatureDetails(MyServicesVo myServicesVo) {
		MyServicesVo myServicesRemove = new MyServicesVo();
		 try{			 
			 CfRoamDetails removeCallingFeaturesRequest = new CfRoamDetails();
			 removeCallingFeaturesRequest.setCustLevelReference(myServicesVo.getSubscriptionNumber());
			 removeCallingFeaturesRequest.setServiceCode(myServicesVo.getServiceCode());
			 removeCallingFeaturesRequest.setEffectiveDate(myServicesVo.getEffectiveDate());
			 
			 CfRoamResponse addCallingFeaturesResponse = callingFeatures.removeFeature(removeCallingFeaturesRequest);
			 if(addCallingFeaturesResponse != null){	
			   myServicesRemove.setMessage(addCallingFeaturesResponse.getCfRoamMessage());
			 }
	     } 
		  catch (SvalloCallingFeaturesIntegrationException scfie) {	    	 
			 logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getRemoveCallingFeatureDetails() ] SvalloCallingFeaturesServiceException Catch Block");
			 logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getRemoveCallingFeatureDetails() ] SvalloCallingFeaturesServiceException Catch Block | Error Code ="+ CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_ERROR_CODE);
			 logger.error(scfie,"\n[ CallingFeaturesServiceImpl123 | getRemoveCallingFeatureDetails() ] SvalloCallingFeaturesServiceException Catch Block | Error Message ="+ CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_ERROR_MESSAGE);
			 SvalloCallingFeaturesServiceException svalloCallingFeaturesServiceException = new SvalloCallingFeaturesServiceException();
			 svalloCallingFeaturesServiceException.setErrorCode(CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_ERROR_CODE);
			 svalloCallingFeaturesServiceException.setErrorMessage(CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_ERROR_MESSAGE);
			 svalloCallingFeaturesServiceException.setRootCause(scfie);
			 //scfie.printStackTrace();
			 myServicesRemove.setMessage(DATA_NOT_AVAILABLE);
	    	 myServicesRemove.setMyServicesError(CALLINGFEATURES_REMOVEFEATURE_ERROR_MESSAGE_DETAIL);
	     } 
		 catch (Exception e) {	    	 
			 logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getRemoveCallingFeatureDetails() ] Exception Catch Block");
			 logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getRemoveCallingFeatureDetails() ] Exception Catch Block | Error Code ="+ CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_EXCEPTION_CODE);
			 logger.error(e,"\n[ CallingFeaturesServiceImpl123 | getRemoveCallingFeatureDetails() ] Exception Catch Block | Error Message ="+ CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_EXCEPTION_MESSAGE);
			 SvalloCallingFeaturesServiceException svalloCallingFeaturesServiceException = new SvalloCallingFeaturesServiceException();
			 svalloCallingFeaturesServiceException.setErrorCode(CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_EXCEPTION_CODE);
			 svalloCallingFeaturesServiceException.setErrorMessage(CALLINGFEATURES_IMPL_GETREMOVECALLINGFEATUREDETAILS_EXCEPTION_MESSAGE);
			 svalloCallingFeaturesServiceException.setRootCause(e);
			 //e.printStackTrace();
			 myServicesRemove.setMessage(DATA_NOT_AVAILABLE);
	    	 myServicesRemove.setMyServicesError(CALLINGFEATURES_REMOVEFEATURE_ERROR_MESSAGE_DETAIL);
	     }
		return myServicesRemove;
	}

}


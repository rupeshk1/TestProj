package com.techm.svallo.vo.addon;

import java.util.List;
import java.util.Set;

public class AddonListVo
{
	private Set<String> addonTypes;
	private List<AddonVo> existingAddons;
	private List<AddonVo> applicableAddons;
	private List<AddonVo> pendingAddons;
	private Set<String> applicableAddonTypes;
	private String addonError;
	private AddonVo dataRolloverAddon = new AddonVo();
	private AddonVo minsRolloverAddon = new AddonVo();
	private AddonVo textsRolloverAddon = new AddonVo();
	private String dataRolloverPackageCode = "";
	private String textsRolloverPackageCode = "";
	private String minsRolloverPackageCode = "";
	
	public String getDataRolloverPackageCode() {
		return dataRolloverPackageCode;
	}
	public void setDataRolloverPackageCode(String dataRolloverPackageCode) {
		this.dataRolloverPackageCode = dataRolloverPackageCode;
	}
	public String getTextsRolloverPackageCode() {
		return textsRolloverPackageCode;
	}
	public void setTextsRolloverPackageCode(String textsRolloverPackageCode) {
		this.textsRolloverPackageCode = textsRolloverPackageCode;
	}
	public String getMinsRolloverPackageCode() {
		return minsRolloverPackageCode;
	}
	public void setMinsRolloverPackageCode(String minsRolloverPackageCode) {
		this.minsRolloverPackageCode = minsRolloverPackageCode;
	}
	public AddonVo getDataRolloverAddon() {
		return dataRolloverAddon;
	}
	public void setDataRolloverAddon(AddonVo dataRolloverAddon) {
		this.dataRolloverAddon = dataRolloverAddon;
	}
	public AddonVo getMinsRolloverAddon() {
		return minsRolloverAddon;
	}
	public void setMinsRolloverAddon(AddonVo minsRolloverAddon) {
		this.minsRolloverAddon = minsRolloverAddon;
	}
	public AddonVo getTextsRolloverAddon() {
		return textsRolloverAddon;
	}
	public void setTextsRolloverAddon(AddonVo textsRolloverAddon) {
		this.textsRolloverAddon = textsRolloverAddon;
	}

	public Set<String> getAddonTypes()
	{
		return addonTypes;
	}
	
	public void setAddonTypes(Set<String> addonTypes)
	{
		this.addonTypes = addonTypes;
	}
	
	public List<AddonVo> getExistingAddons()
	{
		return existingAddons;
	}
	
	public void setExistingAddons(List<AddonVo> existingAddons)
	{
		this.existingAddons = existingAddons;
	}
	
	public List<AddonVo> getApplicableAddons()
	{
		return applicableAddons;
	}
	
	public void setApplicableAddons(List<AddonVo> applicableAddons)
	{
		this.applicableAddons = applicableAddons;
	}
	
	public List<AddonVo> getPendingAddons()
	{
		return pendingAddons;
	}
	
	public void setPendingAddons(List<AddonVo> pendingAddons)
	{
		this.pendingAddons = pendingAddons;
	}
	
	public Set<String> getApplicableAddonTypes() {
		return applicableAddonTypes;
	}

	public void setApplicableAddonTypes(Set<String> applicableAddonTypes) {
		this.applicableAddonTypes = applicableAddonTypes;
	}

	public String getAddonError() {
		return addonError;
	}

	public void setAddonError(String addonError) {
		this.addonError = addonError;
	}	
}
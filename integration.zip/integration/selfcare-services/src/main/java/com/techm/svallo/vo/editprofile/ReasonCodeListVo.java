package com.techm.svallo.vo.editprofile;

public class ReasonCodeListVo {

	private String reasonCodeNo;

	public String getReasonCodeNo() {
		return reasonCodeNo;
	}

	public void setReasonCodeNo(String reasonCodeNo) {
		this.reasonCodeNo = reasonCodeNo;
	}
	
}

package com.techm.svallo.vo.rollover;

import java.util.ArrayList;
import java.util.List;

public class RolloverListVo {
	
	private List<RolloverVo> minsrolloverValuesList = new ArrayList<RolloverVo>();
	private List<RolloverVo> textsrolloverValuesList = new ArrayList<RolloverVo>();
	private List<RolloverVo> datarolloverValuesList = new ArrayList<RolloverVo>();
	
	public List<RolloverVo> getMinsrolloverValuesList() {
		return minsrolloverValuesList;
	}
	public void setMinsrolloverValuesList(
			List<RolloverVo> minsrolloverValuesList) {
		this.minsrolloverValuesList = minsrolloverValuesList;
	}
	public List<RolloverVo> getTextsrolloverValuesList() {
		return textsrolloverValuesList;
	}
	public void setTextsrolloverValuesList(
			List<RolloverVo> textsrolloverValuesList) {
		this.textsrolloverValuesList = textsrolloverValuesList;
	}
	public List<RolloverVo> getDatarolloverValuesList() {
		return datarolloverValuesList;
	}
	public void setDatarolloverValuesList(
			List<RolloverVo> datarolloverValuesList) {
		this.datarolloverValuesList = datarolloverValuesList;
	}
}

package com.techm.svallo.service.registration;


import com.techm.svallo.vo.registration.RegistrationVo;

public interface RegistrationService
{
	public RegistrationVo getPreRegistrationDetails(RegistrationVo registrationVo);
	public RegistrationVo getRegistrationDetails(RegistrationVo registrationVo);
	public RegistrationVo getSaveRegistrationDetails(RegistrationVo registrationVo);
	public RegistrationVo getPreRegistrationResendPinDetails(RegistrationVo registrationVo);
	public RegistrationVo getPreRegistrationResendEmailDetails(RegistrationVo registrationVo);
	public RegistrationVo getPreRegistrationResendEmail(RegistrationVo registrationVo);
	public RegistrationVo getDisconnectedAccountDetails(RegistrationVo registrationVo);
	public boolean getValidatePIN(String eventNumber, String eventNumberAlias);
}


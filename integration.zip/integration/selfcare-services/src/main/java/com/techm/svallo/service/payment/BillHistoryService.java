package com.techm.svallo.service.payment;

import java.util.List;

import com.techm.svallo.vo.billingandpayment.BillVo;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;
import com.techmahindra.online.svallo.model.payment._2014._09._01.UnbilledUnitSummary;


public interface BillHistoryService
{
	public List<BillVo>getBillHistory(String accountNumber);
	public UnbilledUnitSummary getUnbilledValue(QueryAccount queryAccount);
}

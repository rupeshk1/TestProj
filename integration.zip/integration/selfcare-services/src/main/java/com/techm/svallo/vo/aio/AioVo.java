package com.techm.svallo.vo.aio;

import java.util.ArrayList;
import java.util.List;

public class AioVo
{

	String sim = null;
	String sim1 = null;
	String pin = null;
	String pin1 = null;
	String pin2 = null;
	String pin3 = null;
	String pin4 = null;
	String pin5 = null;
	String pin6 = null;
	String activationnumber = null;
	String securityPinError = null;
	String simcardNumberError = null;
	String activationNumberError = null;

	String mins = null;
	String secs = null;
	String resetFlag = null;

	String title = null;
	String firstName = null;
	String lasttName = null;
	String dateofbirth = null;
	String emailaddress = null;

	String housename = null;
	String postcode = null;

	String addressline1 = null;
	String addressline2 = null;
	String addressline3 = null;
	String county = null;
	String town = null;
	String postcode1 = null;
	String country = null;

	String username = null;
	String password = null;
	private String termsAndCondition = null;
	private String subscriptionNumber = null;
	private String aioSubscriptionNumber = null;

	

	private String workFlowId = null;
	private String accountNumber = null;
	private String serviceDownError = null;
	private String subscriptionStatus = null;

	private String subscriptionException = null;
	private String subscriptionDetailsException = null;
	private String sendSecurityPinException = null;
	private String validateSecurityPinException = null;
	private String updateAddressAccountlevelException = null;
	private String updateAddressSubscriptionlevelException = null;
	private String activateSimException = null;

	private String isAIOUserFromRegister;
	private String isNonAIOPAYGUser;

	List<String> addressRdList = new ArrayList<String>();

	private String addressLine1Validation;
	private String postCodeValidation;
	
	private String emailValidation;
	private String surnameValidation;
	private String dobValidation;
	private String firstnameValidation;
	
	
	public String getSim()
	{
		return sim;
	}

	public void setSim(String sim)
	{
		this.sim = sim;
	}

	public String getSim1()
	{
		return sim1;
	}

	public void setSim1(String sim1)
	{
		this.sim1 = sim1;
	}

	public String getPin()
	{
		return pin;
	}

	public void setPin(String pin)
	{
		this.pin = pin;
	}

	public String getPin1()
	{
		return pin1;
	}

	public void setPin1(String pin1)
	{
		this.pin1 = pin1;
	}

	public String getPin2()
	{
		return pin2;
	}

	public void setPin2(String pin2)
	{
		this.pin2 = pin2;
	}

	public String getPin3()
	{
		return pin3;
	}

	public void setPin3(String pin3)
	{
		this.pin3 = pin3;
	}

	public String getPin4()
	{
		return pin4;
	}

	public void setPin4(String pin4)
	{
		this.pin4 = pin4;
	}

	public String getPin5()
	{
		return pin5;
	}

	public void setPin5(String pin5)
	{
		this.pin5 = pin5;
	}

	public String getPin6()
	{
		return pin6;
	}

	public void setPin6(String pin6)
	{
		this.pin6 = pin6;
	}

	public String getActivationnumber()
	{
		return activationnumber;
	}

	public void setActivationnumber(String activationnumber)
	{
		this.activationnumber = activationnumber;
	}

	public String getSecurityPinError()
	{
		return securityPinError;
	}

	public void setSecurityPinError(String securityPinError)
	{
		this.securityPinError = securityPinError;
	}

	public String getSimcardNumberError()
	{
		return simcardNumberError;
	}

	public void setSimcardNumberError(String simcardNumberError)
	{
		this.simcardNumberError = simcardNumberError;
	}

	public String getActivationNumberError()
	{
		return activationNumberError;
	}

	public void setActivationNumberError(String activationNumberError)
	{
		this.activationNumberError = activationNumberError;
	}

	public String getMins()
	{
		return mins;
	}

	public void setMins(String mins)
	{
		this.mins = mins;
	}

	public String getSecs()
	{
		return secs;
	}

	public void setSecs(String secs)
	{
		this.secs = secs;
	}

	public String getResetFlag()
	{
		return resetFlag;
	}

	public void setResetFlag(String resetFlag)
	{
		this.resetFlag = resetFlag;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLasttName()
	{
		return lasttName;
	}

	public void setLasttName(String lasttName)
	{
		this.lasttName = lasttName;
	}

	public String getDateofbirth()
	{
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth)
	{
		this.dateofbirth = dateofbirth;
	}

	public String getEmailaddress()
	{
		return emailaddress;
	}

	public void setEmailaddress(String emailaddress)
	{
		this.emailaddress = emailaddress;
	}

	public String getHousename()
	{
		return housename;
	}

	public void setHousename(String housename)
	{
		this.housename = housename;
	}

	public String getPostcode()
	{
		return postcode;
	}

	public void setPostcode(String postcode)
	{
		this.postcode = postcode;
	}

	public String getAddressline1()
	{
		return addressline1;
	}

	public void setAddressline1(String addressline1)
	{
		this.addressline1 = addressline1;
	}

	public String getAddressline2()
	{
		return addressline2;
	}

	public void setAddressline2(String addressline2)
	{
		this.addressline2 = addressline2;
	}

	public String getAddressline3()
	{
		return addressline3;
	}

	public void setAddressline3(String addressline3)
	{
		this.addressline3 = addressline3;
	}

	public String getCounty()
	{
		return county;
	}

	public void setCounty(String county)
	{
		this.county = county;
	}

	public String getTown()
	{
		return town;
	}

	public void setTown(String town)
	{
		this.town = town;
	}

	public String getPostcode1()
	{
		return postcode1;
	}

	public void setPostcode1(String postcode1)
	{
		this.postcode1 = postcode1;
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getUsername()
	{
		return username;
	}

	public void setUsername(String username)
	{
		this.username = username;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public String getTermsAndCondition()
	{
		return termsAndCondition;
	}

	public void setTermsAndCondition(String termsAndCondition)
	{
		this.termsAndCondition = termsAndCondition;
	}

	public String getSubscriptionNumber()
	{
		return subscriptionNumber;
	}

	public void setSubscriptionNumber(String subscriptionNumber)
	{
		this.subscriptionNumber = subscriptionNumber;
	}

	public String getWorkFlowId()
	{
		return workFlowId;
	}

	public void setWorkFlowId(String workFlowId)
	{
		this.workFlowId = workFlowId;
	}

	public String getAccountNumber()
	{
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}

	public String getServiceDownError()
	{
		return serviceDownError;
	}

	public void setServiceDownError(String serviceDownError)
	{
		this.serviceDownError = serviceDownError;
	}

	public String getSubscriptionStatus()
	{
		return subscriptionStatus;
	}

	public void setSubscriptionStatus(String subscriptionStatus)
	{
		this.subscriptionStatus = subscriptionStatus;
	}

	public String getSubscriptionException()
	{
		return subscriptionException;
	}

	public void setSubscriptionException(String subscriptionException)
	{
		this.subscriptionException = subscriptionException;
	}

	public String getSubscriptionDetailsException()
	{
		return subscriptionDetailsException;
	}

	public void setSubscriptionDetailsException(String subscriptionDetailsException)
	{
		this.subscriptionDetailsException = subscriptionDetailsException;
	}

	public String getSendSecurityPinException()
	{
		return sendSecurityPinException;
	}

	public void setSendSecurityPinException(String sendSecurityPinException)
	{
		this.sendSecurityPinException = sendSecurityPinException;
	}

	public String getValidateSecurityPinException()
	{
		return validateSecurityPinException;
	}

	public void setValidateSecurityPinException(String validateSecurityPinException)
	{
		this.validateSecurityPinException = validateSecurityPinException;
	}

	public String getUpdateAddressAccountlevelException()
	{
		return updateAddressAccountlevelException;
	}

	public void setUpdateAddressAccountlevelException(String updateAddressAccountlevelException)
	{
		this.updateAddressAccountlevelException = updateAddressAccountlevelException;
	}

	public String getUpdateAddressSubscriptionlevelException()
	{
		return updateAddressSubscriptionlevelException;
	}

	public void setUpdateAddressSubscriptionlevelException(String updateAddressSubscriptionlevelException)
	{
		this.updateAddressSubscriptionlevelException = updateAddressSubscriptionlevelException;
	}

	public String getActivateSimException()
	{
		return activateSimException;
	}

	public void setActivateSimException(String activateSimException)
	{
		this.activateSimException = activateSimException;
	}

	public String getIsAIOUserFromRegister()
	{
		return isAIOUserFromRegister;
	}

	public void setIsAIOUserFromRegister(String isAIOUserFromRegister)
	{
		this.isAIOUserFromRegister = isAIOUserFromRegister;
	}

	public String getIsNonAIOPAYGUser()
	{
		return isNonAIOPAYGUser;
	}

	public void setIsNonAIOPAYGUser(String isNonAIOPAYGUser)
	{
		this.isNonAIOPAYGUser = isNonAIOPAYGUser;
	}

	public List<String> getAddressRdList()
	{
		return addressRdList;
	}

	public void setAddressRdList(List<String> addressRdList)
	{
		this.addressRdList = addressRdList;
	}

	public String getAddressLine1Validation()
	{
		return addressLine1Validation;
	}

	public void setAddressLine1Validation(String addressLine1Validation)
	{
		this.addressLine1Validation = addressLine1Validation;
	}

	public String getPostCodeValidation()
	{
		return postCodeValidation;
	}

	public void setPostCodeValidation(String postCodeValidation)
	{
		this.postCodeValidation = postCodeValidation;
	}
	
	public String getEmailValidation()
	{
		return emailValidation;
	}

	public void setEmailValidation(String emailValidation)
	{
		this.emailValidation = emailValidation;
	}

	public String getSurnameValidation()
	{
		return surnameValidation;
	}

	public void setSurnameValidation(String surnameValidation)
	{
		this.surnameValidation = surnameValidation;
	}
	public String getDobValidation()
	{
		return dobValidation;
	}

	public void setDobValidation(String dobValidation)
	{
		this.dobValidation = dobValidation;
	}

	public String getFirstnameValidation()
	{
		return firstnameValidation;
	}

	public void setFirstnameValidation(String firstnameValidation)
	{
		this.firstnameValidation = firstnameValidation;
	}

	

	public String getAioSubscriptionNumber()
	{
		return aioSubscriptionNumber;
	}

	public void setAioSubscriptionNumber(String aioSubscriptionNumber)
	{
		this.aioSubscriptionNumber = aioSubscriptionNumber;
	}
	
	

}

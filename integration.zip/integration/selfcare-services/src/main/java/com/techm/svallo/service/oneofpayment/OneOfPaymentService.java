package com.techm.svallo.service.oneofpayment;

import com.techm.svallo.vo.oneofpayment.OneOfPaymentVo;

public interface OneOfPaymentService
{
	public OneOfPaymentVo getOneOfPaymentDetails(OneOfPaymentVo oneOfPaymentVo);	
	public String getScreenName(String accountNumber);
	public String getUserPassword(long userId);
	public String getPaymentType(String paymentType);
	/*
	public void insertPaymentDetails(OneOfPaymentVo oneOfPaymentVo);
	public OneOfPaymentVo getUserPaymentDetails(OneOfPaymentVo oneOfPaymentVo);
	*/
}


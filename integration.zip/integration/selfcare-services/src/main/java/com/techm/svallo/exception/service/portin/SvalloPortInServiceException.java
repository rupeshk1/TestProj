package com.techm.svallo.exception.service.portin;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloPortInServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

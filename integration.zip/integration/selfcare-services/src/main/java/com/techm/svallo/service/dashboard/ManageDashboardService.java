package com.techm.svallo.service.dashboard;

import com.techm.svallo.vo.dashboard.DashboardInfoVo;
import com.techm.svallo.vo.dashboard.UpdateSubscriptionSerialNoVo;
import com.techmahindra.online.svallo.service.common.WidgetManager;


public interface ManageDashboardService 
{
	
	public DashboardInfoVo getDashboardInfo(String subscriptionNumber,String areFlagCheck, String oldPayMSubscriptionNumber,String oldPayMTarrifCode);
	public void setWidgetManager(WidgetManager widgetMagr);
	public DashboardInfoVo getDashboardInfo(String accountNumber, String tariffCode, String mobileNumber, String subscriptionNumber, boolean controllerIdentifier,String areFlagCheck, String oldPayMSubscriptionNumber,String oldPayMTarrifCode);
	public String getAccount4Dashboard(long userId);
	public DashboardInfoVo getAjaxDonutsInfo(String a,String b, String c, String subscriptionNumber, DashboardInfoVo originalDashboardInfoVo,String areFlagCheck, String oldPayMSubscriptionNumber,String oldPayMTarrifCode);
	public void insertAreUser(long userId);
	public int getAreUserStatus(long userId);
	public UpdateSubscriptionSerialNoVo updateSubscriptionSerialNumber(UpdateSubscriptionSerialNoVo updateSubscriptionSerialNoVo);
	public DashboardInfoVo getFeatures(String onlyFeatures, String subscriptionNumber, DashboardInfoVo originalDashboardInfoVo);

}

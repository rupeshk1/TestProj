package com.techm.svallo.vo.billing;

public class BillingVO {
	private String tariffPlan;
	private String rental;
	private String usage;
	private String messagingCharges;
	private String roamingCharges;
	private String discounts;
	
	
	
	public String getTariffPlan() {
		return tariffPlan;
	}
	public void setTariffPlan(String tariffPlan) {
		this.tariffPlan = tariffPlan;
	}
	public String getRental() {
		return rental;
	}
	public void setRental(String rental) {
		this.rental = rental;
	}
	public String getUsage() {
		return usage;
	}
	public void setUsage(String usage) {
		this.usage = usage;
	}
	public String getMessagingCharges() {
		return messagingCharges;
	}
	public void setMessagingCharges(String messagingCharges) {
		this.messagingCharges = messagingCharges;
	}
	public String getRoamingCharges() {
		return roamingCharges;
	}
	public void setRoamingCharges(String roamingCharges) {
		this.roamingCharges = roamingCharges;
	}
	public String getDiscounts() {
		return discounts;
	}
	public void setDiscounts(String discounts) {
		this.discounts = discounts;
	}

	
}

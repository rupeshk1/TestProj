package com.techm.svallo.service.singlesignon;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.techm.svallo.vo.singlesignon.SingleSignOnAccountListVo;
import com.techm.svallo.vo.singlesignon.SingleSignOnVo;
import com.techmahindra.online.svallo.model.singlesignon._2014._09._30.SvalloSingleSignOnAccountList;
import com.techmahindra.online.svallo.model.singlesignon._2014._09._30.SvalloSingleSignOnDetailsRequest;
import com.techmahindra.online.svallo.model.singlesignon._2014._09._30.SvalloSingleSignOnDetailsResponse;
import com.techmahindra.online.svallo.service.singlesignon._2014._09._30.SvalloSingleSignOn;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import com.techm.portal.common.loggerwrapper.PortalLogger;

public class SingleSignOnServiceImpl implements SingleSignOnService{

	final static PortalLogger logger = PortalLogger.getLogger(SingleSignOnServiceImpl.class);
	
	@Autowired
	private SvalloSingleSignOn svalloSingleSignOn;

	public void setSvalloSingleSignOn(SvalloSingleSignOn svalloSingleSignOn) {
		this.svalloSingleSignOn = svalloSingleSignOn;
	}

	@Autowired
	private JdbcTemplate jdbcTemplate=null;
	
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	private static String GET_USER_PASSWORD = "select password_ from User_ where screenName=?;";
	
	private static String GET_USERNAME_SSO = "select screenName from User_ where openId=? order by userId desc;";

	@Override
	public SingleSignOnVo getSingleSignOnDetails(SingleSignOnVo singleSignOnVo) {
		SingleSignOnVo singleSignOnVoDetails = new SingleSignOnVo();
		List<SingleSignOnAccountListVo> singleSignOnListVo = new ArrayList();
		
		try{
		SvalloSingleSignOnDetailsRequest svalloSingleSignOnDetailsRequest = new SvalloSingleSignOnDetailsRequest();	
		
		svalloSingleSignOnDetailsRequest.setSessionToken(singleSignOnVo.getSessionToken());		
		
		SvalloSingleSignOnDetailsResponse svalloSingleSignOnDetailsResponse = svalloSingleSignOn.getSingleSignOnDetails(svalloSingleSignOnDetailsRequest);
		
		//System.out.println("Token Value "+svalloSingleSignOnDetailsResponse.getSessionToken());
		//System.out.println("username "+svalloSingleSignOnDetailsResponse.getUserName());
		//System.out.println("Size="+svalloSingleSignOnDetailsResponse.getSvalloSingleSignOnAccountList().size());
	
		//if(svalloSingleSignOnDetailsResponse.getSvalloSingleSignOnAccountList().size()<1){
		//	singleSignOnVoDetails.setSingleSignOnListEmpty(true);	
		//}
		
		singleSignOnVoDetails.setSessionToken(svalloSingleSignOnDetailsResponse.getSessionToken());
		singleSignOnVoDetails.setUserName(svalloSingleSignOnDetailsResponse.getUserName());
		
		for (int i = 0; i < svalloSingleSignOnDetailsResponse.getSvalloSingleSignOnAccountList().size(); i++)
		{
			SvalloSingleSignOnAccountList s1 = svalloSingleSignOnDetailsResponse.getSvalloSingleSignOnAccountList().get(i);
			//System.out.println("Attribute ID "+s1.getAttributeId());
			//System.out.println("Attribute Name "+s1.getAttributeValue());
			
			if(s1.getAttributeId()==null){
				singleSignOnVoDetails.setSingleSignOnListEmpty(true);
			}
			
			SingleSignOnAccountListVo singleSignOnAccountListVo = new SingleSignOnAccountListVo();
			singleSignOnAccountListVo.setAttributeId(s1.getAttributeId());
			singleSignOnAccountListVo.setAttributeValue(s1.getAttributeValue());
			singleSignOnListVo.add(singleSignOnAccountListVo);
		}
		singleSignOnVoDetails.setSingleSignOnAccountListVo(singleSignOnListVo);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return singleSignOnVoDetails;
	}


	@Override
	public String getUsersPassword(String username) {
		String password = "";		
		try{			
			//password = (String)jdbcTemplate.query(GET_USER_PASSWORD.replaceAll("\\?",username+""),new ManageGetPasswordMapper()).get(0);
			password = (String)jdbcTemplate.query(GET_USER_PASSWORD,new String[]{username},new ManageGetPasswordMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");
		}
		return password;	
	}
	
	 private static final class ManageGetPasswordMapper implements RowMapper<String> 
		{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
		    	return rs.getString("password_");
		    }
		}
	 
	 @Override
		public String getUserNameSSO(String accountNum) {
			String screenName="";		
			try{
				screenName = (String)jdbcTemplate.query(GET_USERNAME_SSO,new String[]{accountNum},new ManageGetUserNameSSOMapper()).get(0);
			} catch(ArrayIndexOutOfBoundsException ae){
				logger.error(ae,"Array Index out of bound exception");
				screenName="";
			}
			return screenName;	
		}
		
		 private static final class ManageGetUserNameSSOMapper implements RowMapper<String> 
			{
				public String mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
			    	return rs.getString("screenName");
			    }
			}

}

package com.techm.svallo.service.addon;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.Addon.SvalloAddOnServiceException;
import com.techm.svallo.util.SelfCareUtil;
import com.techm.svallo.vo.addon.AddonListVo;
import com.techm.svallo.vo.addon.AddonVo;
import com.techmahindra.online.svallo.model.vas.addon._2014._08._28.Addon;
import com.techmahindra.online.svallo.model.vas.addon._2014._08._28.QueryAddonRequest;
import com.techmahindra.online.svallo.model.vas.addon._2014._08._28.QueryAddonResponse;
import com.techmahindra.online.svallo.model.vas.addon._2014._08._28.Service;
import com.techmahindra.online.svallo.model.vas.addon._2014._08._28.UpdateAddonRequest;
import com.techmahindra.online.svallo.model.vas.addon._2014._08._28.UpdateAddonResponse;
import com.techmahindra.online.svallo.service.common.exception.addon.SvalloAddonIntegrationException;
import com.techmahindra.online.svallo.service.vas.addon._2014._08._28.AddonService;
import  com.techm.svallo.util.ExistingAddOnDateComparator;



import java.util.Comparator;
import java.util.Collections;

public class AddonServiceServiceImpl implements AddonServiceService
{
	final static PortalLogger logger = PortalLogger.getLogger(AddonServiceServiceImpl.class);

	@Autowired
	private AddonService addonService;

	private JdbcTemplate jdbcTemplate = null;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	@Value("${addon.updateAddon.add.error.message.detail}")
	private String ADDON_UPDATEADDON_ADD_ERROR_MESSAGE_DETAIL;

	@Value("${addon.updateAddon.remove.error.message.detail}")
	private String ADDON_UPDATEADDON_REMOVE_ERROR_MESSAGE_DETAIL;

	@Value("${addon.getAddon.error.message.detail}")
	private String ADDON_GETADDON_ERROR_MESSAGE_DETAIL;

	@Value("${addon.impl.updateaddon.error.code}")
	private String ADDON_IMPL_UPDATEADDON_ERROR_CODE;

	@Value("${addon.impl.updateaddon.error.message}")
	private String ADDON_IMPL_UPDATEADDON_ERROR_MESSAGE;

	@Value("${addon.impl.updateaddon.exception.code}")
	private String ADDON_IMPL_UPDATEADDON_EXCEPTION_CODE;

	@Value("${addon.impl.updateaddon.exception.message}")
	private String ADDON_IMPL_UPDATEADDON_EXCEPTION_MESSAGE;

	@Value("${addon.impl.getapplicableaddon.error.code}")
	private String ADDON_IMPL_GETAPPLICABLEADDON_ERROR_CODE;

	@Value("${addon.impl.getapplicableaddon.error.message}")
	private String ADDON_IMPL_GETAPPLICABLEADDON_ERROR_MESSAGE;

	@Value("${addon.impl.getapplicableaddon.exception.code}")
	private String ADDON_IMPL_GETAPPLICABLEADDON_EXCEPTION_CODE;

	@Value("${addon.impl.getapplicableaddon.exception.message}")
	private String ADDON_IMPL_GETAPPLICABLEADDON_EXCEPTION_MESSAGE;

	@Value("${addon.impl.getexistingaddon.error.code}")
	private String ADDON_IMPL_GETEXISTINGADDON_ERROR_CODE;

	@Value("${addon.impl.getexistingaddon.error.message}")
	private String ADDON_IMPL_GETEXISTINGADDON_ERROR_MESSAGE;

	@Value("${addon.impl.getexistingaddon.exception.code}")
	private String ADDON_IMPL_GETEXISTINGADDON_EXCEPTION_CODE;

	@Value("${addon.impl.getexistingaddon.exception.message}")
	private String ADDON_IMPL_GETEXISTINGADDON_EXCEPTION_MESSAGE;

	private static String GET_USER_PASSWORD = "select password_ from User_ where userId=?;";

	NumberFormat decimalformatter = new DecimalFormat("#0.00");
	
	private static String PPBILL = "PPBILL";
	private static String PPCRED = "PPCRED";
	private static String PREPAY = "PREPAY"; 

	public AddonListVo getAddon(String accountNumber, String subscriptionNum)
	{		
		return null;
	}

	public String getAddonMessage(String accountNumber, String subscriptionNum)
	{
		QueryAddonRequest queryAddonRequest = new QueryAddonRequest();
		queryAddonRequest.setAccountNumber(accountNumber);
		queryAddonRequest.setTodaysDate(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()));
		queryAddonRequest.setCustomerLevel(subscriptionNum);
		QueryAddonResponse queryAddonResponse = addonService.getAddon(queryAddonRequest);

		Service allAddons = queryAddonResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getAddons().get(0);
		List<Addon> existingAddons = allAddons.getExistingAddon().getAddon();

		LinkedHashSet<String> existingAddonTypes = new LinkedHashSet<String>();
		HashMap<String, Integer> existingAddonTypesAndSizes = new HashMap<String, Integer>();

		for (Addon existingAddon : existingAddons)
		{
			if (existingAddonTypes.add(existingAddon.getProductType()))
			{
				existingAddonTypesAndSizes.put(existingAddon.getProductType(), 1);
			}
			else
			{
				int addonSize = existingAddonTypesAndSizes.get(existingAddon.getProductType()) + 1;
				existingAddonTypesAndSizes.remove(existingAddon.getProductType());
				existingAddonTypesAndSizes.put(existingAddon.getProductType(), addonSize);
			}
		}

		boolean atLeastOneAddon = false;
		String addonMessage = "You have ";

		for (Map.Entry<String, Integer> existingAddonTypeAndSize : existingAddonTypesAndSizes.entrySet())
		{
			if (!atLeastOneAddon)
			{
				atLeastOneAddon = true;
				addonMessage += existingAddonTypeAndSize.getValue() + " " + existingAddonTypeAndSize.getKey();
			}
			else
				addonMessage += ", " + existingAddonTypeAndSize.getValue() + " " + existingAddonTypeAndSize.getKey();
		}

		if (!atLeastOneAddon)
			addonMessage += "not subscribed to any Bolton";
		else
			addonMessage += " Bolton(s)";

		return addonMessage;
	}

	public String updateAddon(String serviceCode, String operation, String subscriptionNum, String boltonTypeName, String servicePrice, String reloadMethod, String unformattedNextinvoiceDate, boolean isPhase2User)
	{
		UpdateAddonResponse updateAddonResponse = new UpdateAddonResponse();
		try
		{
			UpdateAddonRequest updateAddonRequest = new UpdateAddonRequest();
			updateAddonRequest.setServiceCode(serviceCode);
			updateAddonRequest.setOperation(operation);
			updateAddonRequest.setSubscriptionNumber(subscriptionNum);

			if ("remove".equalsIgnoreCase(operation))
			{
				if (!"".equalsIgnoreCase(unformattedNextinvoiceDate) && isPhase2User)
				{
					updateAddonRequest.setEffectiveDate(SelfCareUtil.getCMPPreviousDate(unformattedNextinvoiceDate));
				}
				else
				{
					updateAddonRequest.setEffectiveDate(new SimpleDateFormat("yyyy-MM-dd'Z'").format(Calendar.getInstance().getTime()));
				}
			}
			else
			{
				updateAddonRequest.setEffectiveDate(new SimpleDateFormat("yyyy-MM-dd'Z'").format(Calendar.getInstance().getTime()));
			}
			/*
			 * passing two more values in updateAddonRequest for realtime
			 * changes
			 */
			updateAddonRequest.setDescription(boltonTypeName);
			updateAddonRequest.setServicePrice(servicePrice);
			updateAddonRequest.setReloadMethod(reloadMethod);

			updateAddonResponse = addonService.updateAddon(updateAddonRequest);
		}
		catch (SvalloAddonIntegrationException saoie)
		{
			logger.error(saoie, "\n[ AddonServiceServiceImpl | updateAddon() ] SvalloAddOnServiceException Catch Block ");
			logger.error(saoie, "\n[ AddonServiceServiceImpl | updateAddon() ] SvalloAddOnServiceException Catch Block | Error Code =" + ADDON_IMPL_UPDATEADDON_ERROR_CODE);
			logger.error(saoie, "\n[ AddonServiceServiceImpl | updateAddon() ] SvalloAddOnServiceException Catch Block | Error Message =" + ADDON_IMPL_UPDATEADDON_ERROR_MESSAGE);
			SvalloAddOnServiceException svalloAddOnServiceException = new SvalloAddOnServiceException();
			svalloAddOnServiceException.setErrorCode(ADDON_IMPL_UPDATEADDON_ERROR_CODE);
			svalloAddOnServiceException.setErrorMessage(ADDON_IMPL_UPDATEADDON_ERROR_MESSAGE);
			svalloAddOnServiceException.setRootCause(saoie);
			// saoie.printStackTrace();
			if (operation.equalsIgnoreCase("add"))
			{
				updateAddonResponse.setResponseStatus(ADDON_UPDATEADDON_ADD_ERROR_MESSAGE_DETAIL);
			}
			else
			{
				updateAddonResponse.setResponseStatus(ADDON_UPDATEADDON_REMOVE_ERROR_MESSAGE_DETAIL);
			}
		}
		catch (Exception e)
		{
			logger.error(e, "\n[ AddonServiceServiceImpl | updateAddon() ] Exception Catch Block");
			logger.error(e, "\n[ AddonServiceServiceImpl | updateAddon() ] Exception Catch Block | Error Code =" + ADDON_IMPL_UPDATEADDON_EXCEPTION_CODE);
			logger.error(e, "\n[ AddonServiceServiceImpl | updateAddon() ] Exception Catch Block | Error Message =" + ADDON_IMPL_UPDATEADDON_EXCEPTION_MESSAGE);
			SvalloAddOnServiceException svalloAddOnServiceException = new SvalloAddOnServiceException();
			svalloAddOnServiceException.setErrorCode(ADDON_IMPL_UPDATEADDON_EXCEPTION_CODE);
			svalloAddOnServiceException.setErrorMessage(ADDON_IMPL_UPDATEADDON_EXCEPTION_MESSAGE);
			svalloAddOnServiceException.setRootCause(e);
			// e.printStackTrace();
			if (operation.equalsIgnoreCase("add"))
			{
				updateAddonResponse.setResponseStatus(ADDON_UPDATEADDON_ADD_ERROR_MESSAGE_DETAIL);
			}
			else
			{
				updateAddonResponse.setResponseStatus(ADDON_UPDATEADDON_REMOVE_ERROR_MESSAGE_DETAIL);
			}
		}
		return updateAddonResponse.getResponseStatus();
	}

	public AddonService getAddonService()
	{
		return addonService;
	}

	public void setAddonService(AddonService addonService)
	{
		this.addonService = addonService;
	}

	public AddonListVo getApplicableAddon(String accountNumber, String subscriptionNum)
	{
		AddonListVo addonListVo = new AddonListVo();
		List<AddonVo> applicableAddonVos = new ArrayList<AddonVo>();
		Set<String> addonTypes = new LinkedHashSet<String>();
		Set<String> uniqueAddonName = new HashSet<String>();
		Set<String> AddedAddonName = new HashSet<String>();
		HashMap uniqueMap = new HashMap();
		try
		{
			QueryAddonRequest queryAddonRequest = new QueryAddonRequest();
			queryAddonRequest.setAccountNumber(accountNumber);
			queryAddonRequest.setTodaysDate(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()));
			queryAddonRequest.setCustomerLevel(subscriptionNum);
			QueryAddonResponse queryAddonResponse = addonService.getAddon(queryAddonRequest);

			Service allAddons = queryAddonResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getAddons().get(0);
			List<Addon> applicableAddons = allAddons.getApplicableAddon().getAddon();

			for (Addon uniqueApplicabelAddonName : applicableAddons)
			{
				uniqueAddonName.add(uniqueApplicabelAddonName.getCrossSellCategoryName());
			}

			for (String s : uniqueAddonName)
			{
				logger.debug("iterate value =" + s);

				for (int j = 0; j < applicableAddons.size(); j++)
				{
					Addon tempD = (Addon) applicableAddons.get(j);

					if (s.equals(tempD.getCrossSellCategoryName()))
					{
						AddonVo tempB = (AddonVo) uniqueMap.get(tempD.getCrossSellCategoryName());
						if (tempB != null)
						{

							tempB.setCode(tempD.getRecurring(), tempD.getProductId());

						}
						else
						{
							AddonVo tempN = new AddonVo(tempD.getCrossSellCategoryName(), tempD.getRecurring(), tempD.getProductId());

							uniqueMap.put(tempD.getCrossSellCategoryName(), tempN);
						}
					}
				}

			}

			logger.debug(" Unique size : " + uniqueMap.size());

			Set setOfKeys = uniqueMap.keySet();
			Iterator iterator = setOfKeys.iterator();
			while (iterator.hasNext())
			{
				String key = (String) iterator.next();
				AddonVo value = (AddonVo) uniqueMap.get(key);
				logger.debug("Key: " + key + ", Value: " + value.getRecurringCode() + " " + value.getOneOffCode());
			}

			AddonVo addonVo;

			// for (String uniqAddonName : uniqueAddonName) {
			for (Addon applicableAddon : applicableAddons)
			{
				logger.debug("new changes done");
				// if(uniqAddonName.equalsIgnoreCase(applicableAddon.getCrossSellCategoryName())){
				if (!AddedAddonName.contains(applicableAddon.getCrossSellCategoryName()))
				{
					AddedAddonName.add(applicableAddon.getCrossSellCategoryName());

					addonVo = new AddonVo();
					// addonVo.setServiceCode(applicableAddon.getProductId());
					// addonVo.setAddonName(applicableAddon.getProductName());
					addonVo.setAddonName(applicableAddon.getCrossSellCategoryName());
					addonVo.setAddonDescription(applicableAddon.getProductDescription());
					addonVo.setAddonExtendedDescription(applicableAddon.getProductLongDescription());
					addonVo.setAddonType(applicableAddon.getProductType());
					addonVo.setAddonPrice(applicableAddon.getProductPrice());
					addonVo.setAddonServicePrice(decimalformatter.format(Double.valueOf(applicableAddon.getAddonServicePrice())));
					// using addon service price value in addbotons page
					
					// getting recurring value from service and setting in addon
					// vo for realtime changes
					addonVo.setAddonMinutes(applicableAddon.getMinutes());
					addonVo.setAddonTexts(applicableAddon.getTexts());
					addonVo.setAddonData(applicableAddon.getData());
					addonVo.setAddonDays(applicableAddon.getDays());

					Set setOfUniqueKeys = uniqueMap.keySet();
					Iterator uniqueIterator = setOfUniqueKeys.iterator();
					while (uniqueIterator.hasNext())
					{
						String key = (String) uniqueIterator.next();
						AddonVo value = (AddonVo) uniqueMap.get(key);
					
						// key+" : Value unique: "+ value.getRecurringCode() +
						// " "+ value.getOneOffCode());
						if (key.equalsIgnoreCase(applicableAddon.getCrossSellCategoryName()))
						{
							addonVo.setOneOffCode(value.getOneOffCode());
							addonVo.setRecurringCode(value.getRecurringCode());
						}
					}

					if (addonVo.getOneOffCode() != null && addonVo.getRecurringCode() != null)
					{
						addonVo.setAddonCodeType("both");
					}
					else if (addonVo.getRecurringCode() != null)
					{
						addonVo.setAddonCodeType("recurring");
					}
					else
					{
						addonVo.setAddonCodeType("oneOff");
					}
					addonVo.setAddonEndDate(SelfCareUtil.getFutureDateFromDays(applicableAddon.getDays()));

					applicableAddonVos.add(addonVo);
					addonTypes.add(applicableAddon.getProductType());
				}

				// }

			}
			// }			

			addonListVo.setApplicableAddons(applicableAddonVos);
			addonListVo.setAddonTypes(addonTypes);

		}
		catch (SvalloAddonIntegrationException saoie)
		{
			logger.error(saoie, "\n[ AddonServiceServiceImpl | getApplicableAddon() ] SvalloAddOnServiceException Catch Block");
			logger.error(saoie, "\n[ AddonServiceServiceImpl | getApplicableAddon() ] SvalloAddOnServiceException Catch Block | Error Code =" + ADDON_IMPL_GETAPPLICABLEADDON_ERROR_CODE);
			logger.error(saoie, "\n[ AddonServiceServiceImpl | getApplicableAddon() ] SvalloAddOnServiceException Catch Block | Error Message =" + ADDON_IMPL_GETAPPLICABLEADDON_ERROR_MESSAGE);
			SvalloAddOnServiceException svalloAddOnServiceException = new SvalloAddOnServiceException();
			svalloAddOnServiceException.setErrorCode(ADDON_IMPL_GETAPPLICABLEADDON_ERROR_CODE);
			svalloAddOnServiceException.setErrorMessage(ADDON_IMPL_GETAPPLICABLEADDON_ERROR_MESSAGE);
			svalloAddOnServiceException.setRootCause(saoie);
			// saoie.printStackTrace();
			addonListVo.setAddonError(ADDON_GETADDON_ERROR_MESSAGE_DETAIL);
		}
		catch (Exception e)
		{
			logger.error(e, "\n[ AddonServiceServiceImpl | getApplicableAddon() ] Exception Catch Block");
			logger.error(e, "\n[ AddonServiceServiceImpl | getApplicableAddon() ] Exception Catch Block | Error Code =" + ADDON_IMPL_GETAPPLICABLEADDON_EXCEPTION_CODE);
			logger.error(e, "\n[ AddonServiceServiceImpl | getApplicableAddon() ] Exception Catch Block | Error Message =" + ADDON_IMPL_GETAPPLICABLEADDON_EXCEPTION_MESSAGE);
			SvalloAddOnServiceException svalloAddOnServiceException = new SvalloAddOnServiceException();
			svalloAddOnServiceException.setErrorCode(ADDON_IMPL_GETAPPLICABLEADDON_EXCEPTION_CODE);
			svalloAddOnServiceException.setErrorMessage(ADDON_IMPL_GETAPPLICABLEADDON_EXCEPTION_MESSAGE);
			svalloAddOnServiceException.setRootCause(e);
			// e.printStackTrace();
			addonListVo.setAddonError(ADDON_GETADDON_ERROR_MESSAGE_DETAIL);
		}
		return addonListVo;
	}

	public AddonListVo getExistingAddon(String accountNumber, String subscriptionNum, String unformattedNextinvoiceDate, String unformattedLastinvoiceDate)
	{
		AddonListVo addonListVo = new AddonListVo();
		List<AddonVo> existingAddonVos = new ArrayList<AddonVo>();
		Set<String> addonTypes = new LinkedHashSet<String>();

		try
		{
			QueryAddonRequest queryAddonRequest = new QueryAddonRequest();
			queryAddonRequest.setAccountNumber(accountNumber);
			queryAddonRequest.setTodaysDate(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()));
			queryAddonRequest.setCustomerLevel(subscriptionNum);
			QueryAddonResponse queryAddonResponse = addonService.getAddon(queryAddonRequest);

			Service allAddons = queryAddonResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getAddons().get(0);
			List<Addon> existingAddons = allAddons.getExistingAddon().getAddon();
			
			
			
			AddonVo addonVo;
			String onlyDays = "";
			String firstDayActivation="";
			for (Addon existingAddon : existingAddons)
			{
				onlyDays = "";
				firstDayActivation="";
				addonVo = new AddonVo();
				addonVo.setServiceCode(existingAddon.getProductId());
				addonVo.setAddonName(existingAddon.getCrossSellCategoryName());
				addonVo.setAddonNameDescription(existingAddon.getProductName());
				addonVo.setAddonDescription(existingAddon.getProductDescription());
				addonVo.setAddonExtendedDescription(existingAddon.getProductLongDescription());
				addonVo.setAddonType(existingAddon.getProductType());
				addonVo.setAddonPrice(existingAddon.getProductPrice());
				addonVo.setAddonServicePrice(decimalformatter.format(Double.valueOf(existingAddon.getAddonServicePrice())));
				// addonVo.setAddonEffectiveDate(existingAddon.getStartDate());
				
				addonVo.setAddonEffectiveDate(SelfCareUtil.getBoltOnFormattedDate(existingAddon.getStartDate()));
				
				logger.info("addonVo.getAddonEffectiveDate()::before sort::"+addonVo.getAddonEffectiveDate());
				/*
				 * getting recurring value from service and setting in addon vo
				 * for realtime changes
				 */
				addonVo.setRecurring(existingAddon.getRecurring());

				/*
				 * Changes only for Phase2 Release 2 to get recurring boltons
				 * expiry value
				 */
				addonVo.setAddonExpired(existingAddon.getCancelbuttonValue());
				addonVo.setAddonExpiredDate(existingAddon.getExpiryDate());
				addonVo.setAddonAvaiableAmount(existingAddon.getAddonAvailableAmount());
				addonVo.setAddonRemainingValue(existingAddon.getAddonAvailableAmount());
				
				addonVo.setAddonAllowanceValue(existingAddon.getAddonLastGrantAmount());
				addonVo.setAddonLastGrantAmount(existingAddon.getAddonLastGrantAmount());
				addonVo.setAddonUsedValue(existingAddon.getAddonBalanceAmount());
				addonVo.setAddonTotalValue(existingAddon.getAddonLastGrantAmount());

				

				if ("true".equalsIgnoreCase(existingAddon.getRecurring())) {
				
					if ("".equalsIgnoreCase(existingAddon.getExpiryDate())) {
					
					  if("".equalsIgnoreCase(unformattedLastinvoiceDate)) {
					     firstDayActivation = SelfCareUtil.getFutureMonthDate();
					     addonVo.setAddonRenewsExpireValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(existingAddon.getStartDate(),firstDayActivation));
					}else{
						// addonVo.setAddonRenewsExpireValue(SelfCareUtil.getDatediffernce(unformattedNextinvoiceDate));
						// addonVo.setAddonRenewsExpireValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(unformattedLastinvoiceDate,unformattedNextinvoiceDate));
						addonVo.setAddonRenewsExpireValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(new SimpleDateFormat("yyyy-MM-dd'Z'").format(Calendar.getInstance().getTime()), unformattedNextinvoiceDate));
					  }
					}
					else {
						addonVo.setAddonRenewsExpireValue(SelfCareUtil.getDatediffernce(existingAddon.getExpiryDate()));
					}

					// addonVo.setAddonBarGraphTotalValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(existingAddon.getStartDate(),unformattedNextinvoiceDate));
					if ("".equalsIgnoreCase(unformattedLastinvoiceDate)) {
						//addonVo.setAddonBarGraphTotalValue("30");
						addonVo.setAddonBarGraphTotalValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(existingAddon.getStartDate(),firstDayActivation));
					}
					else {
						addonVo.setAddonBarGraphTotalValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(unformattedLastinvoiceDate, unformattedNextinvoiceDate));
					}
				}
				else {	
					
					addonVo.setAddonRenewsExpireValue(SelfCareUtil.getDatediffernce(existingAddon.getExpiryDate()));
					addonVo.setAddonBarGraphTotalValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(existingAddon.getStartDate(), existingAddon.getExpiryDate()));
					
				}

				addonVo.setAddonMinutes(existingAddon.getMinutes());
				addonVo.setAddonTexts(existingAddon.getTexts());
				addonVo.setAddonData(existingAddon.getData());
				addonVo.setAddonDays(existingAddon.getDays());
				addonVo.setAddonEndDate(SelfCareUtil.getFutureDateFromDays(existingAddon.getDays()));
				logger.debug("[ AddonServiceServiceImpl.java | getExistingAddon() ]  -- existingAddon.getReloadMethod() >> " + existingAddon.getReloadMethod());
				if(existingAddon.getReloadMethod().equalsIgnoreCase("A"))
				{
					addonVo.setReloadMethod(PPBILL);
				}
				if(existingAddon.getReloadMethod().equalsIgnoreCase("B"))
				{	
					addonVo.setReloadMethod(PPCRED);
				}
				if(existingAddon.getReloadMethod().equalsIgnoreCase("C"))
				{	
					addonVo.setReloadMethod(PREPAY);
				}
				logger.debug("[ AddonServiceServiceImpl.java | getExistingAddon() ]  -- addonVo.getReloadMethod() >> " + addonVo.getReloadMethod());

				
				existingAddonVos.add(addonVo);
				addonTypes.add(existingAddon.getProductType());
				
				/*Collections.sort(existingAddonVos, new Comparator<AddonVo>() {
				    @Override
				    public int compare(AddonVo addonVo1, AddonVo addonVo2) {
				        return addonVo1.getAddonEffectiveDate().compareTo(addonVo2.getAddonEffectiveDate());
				    }
				}); */
				
				/*logger.info("Before sorting::");
				Collections.sort(existingAddonVos, new ExistingAddOnDateComparator());
				
				for (int i=0; i<existingAddonVos.size();i++){
							
				AddonVo  addonVoSort= (AddonVo)existingAddonVos.get(i);
				logger.info("addonVo.getAddonEffectiveDate():: after sort::"+addonVoSort.getAddonEffectiveDate());
				}
				logger.info("Before sorting::");*/
			}

			// For getting rollover addons details start
			AddonVo dataRolloverAddonVo = new AddonVo();
			AddonVo textsRolloverAddonVo = new AddonVo();
			AddonVo minsRolloverAddonVo = new AddonVo();

			@SuppressWarnings("restriction")
			JAXBElement<Addon> dataRolloverAddon = allAddons.getRolloverAddon().getDataRolloverAddon();
			logger.debug("AddonServiceServiceImpl || data bolton || Rollover Applicable: " + dataRolloverAddon.getValue().getRolloverApplicable());
			dataRolloverAddonVo.setRolloverApplicable(dataRolloverAddon.getValue().getRolloverApplicable());
			
			@SuppressWarnings("restriction")
			JAXBElement<Addon> textsRolloverAddon = allAddons.getRolloverAddon().getTextsRolloverAddon();
			logger.debug("AddonServiceServiceImpl || texts bolton || Rollover Applicable: " + textsRolloverAddon.getValue().getRolloverApplicable());
			textsRolloverAddonVo.setRolloverApplicable(textsRolloverAddon.getValue().getRolloverApplicable());
			
			@SuppressWarnings("restriction")
			JAXBElement<Addon> minsRolloverAddon = allAddons.getRolloverAddon().getMinsRolloverAddon();
			logger.debug("AddonServiceServiceImpl || mins bolton || Rollover Applicable: " + minsRolloverAddon.getValue().getRolloverApplicable());
			minsRolloverAddonVo.setRolloverApplicable(minsRolloverAddon.getValue().getRolloverApplicable());
			
			addonListVo.setDataRolloverAddon(dataRolloverAddonVo);
			addonListVo.setTextsRolloverAddon(textsRolloverAddonVo);
			addonListVo.setMinsRolloverAddon(minsRolloverAddonVo);

			logger.debug("AddonServiceServiceImpl || data rollover package code: " + allAddons.getRolloverAddon().getDataRolloverPackageCode());
			logger.debug("AddonServiceServiceImpl || texts rollover package code: " + allAddons.getRolloverAddon().getTextsRolloverPackageCode());
			logger.debug("AddonServiceServiceImpl || mins rollover package code: " + allAddons.getRolloverAddon().getMinsRolloverPackageCode());
			addonListVo.setDataRolloverPackageCode(allAddons.getRolloverAddon().getDataRolloverPackageCode());
			addonListVo.setTextsRolloverPackageCode(allAddons.getRolloverAddon().getTextsRolloverPackageCode());
			addonListVo.setMinsRolloverPackageCode(allAddons.getRolloverAddon().getMinsRolloverPackageCode());
			// For getting rollover addons details end

			addonListVo.setExistingAddons(existingAddonVos);
			addonListVo.setAddonTypes(addonTypes);
		}
		catch (SvalloAddonIntegrationException saoie)
		{
			logger.error(saoie, "\n[ AddonServiceServiceImpl | getExistingAddon() ] SvalloAddOnServiceException Catch Block");
			logger.error(saoie, "\n[ AddonServiceServiceImpl | getExistingAddon() ] SvalloAddOnServiceException Catch Block | Error Code =" + ADDON_IMPL_GETEXISTINGADDON_ERROR_CODE);
			logger.error(saoie, "\n[ AddonServiceServiceImpl | getExistingAddon() ] SvalloAddOnServiceException Catch Block | Error Message =" + ADDON_IMPL_GETEXISTINGADDON_ERROR_MESSAGE);
			SvalloAddOnServiceException svalloAddOnServiceException = new SvalloAddOnServiceException();
			svalloAddOnServiceException.setErrorCode(ADDON_IMPL_GETEXISTINGADDON_ERROR_CODE);
			svalloAddOnServiceException.setErrorMessage(ADDON_IMPL_GETEXISTINGADDON_ERROR_MESSAGE);
			svalloAddOnServiceException.setRootCause(saoie);
			// saoie.printStackTrace();
			addonListVo.setAddonError(ADDON_GETADDON_ERROR_MESSAGE_DETAIL);
		}
		catch (Exception e)
		{
			logger.error(e, "\n[ AddonServiceServiceImpl | getExistingAddon() ] Exception Catch Block");
			logger.error(e, "\n[ AddonServiceServiceImpl | getExistingAddon() ] Exception Catch Block | Error Code =" + ADDON_IMPL_GETEXISTINGADDON_EXCEPTION_CODE);
			logger.error(e, "\n[ AddonServiceServiceImpl | getExistingAddon() ] Exception Catch Block | Error Message =" + ADDON_IMPL_GETEXISTINGADDON_EXCEPTION_MESSAGE);
			SvalloAddOnServiceException svalloAddOnServiceException = new SvalloAddOnServiceException();
			svalloAddOnServiceException.setErrorCode(ADDON_IMPL_GETEXISTINGADDON_EXCEPTION_CODE);
			svalloAddOnServiceException.setErrorMessage(ADDON_IMPL_GETEXISTINGADDON_EXCEPTION_MESSAGE);
			svalloAddOnServiceException.setRootCause(e);
			// e.printStackTrace();
			addonListVo.setAddonError(ADDON_GETADDON_ERROR_MESSAGE_DETAIL);
		}
		return addonListVo;
	}

	public String getUserPassword(long userId)
	{
		String userPassword = "";
		logger.debug("user Id =" + userId);
		// logger.debug("Query="+GET_USER_PASSWORD);
		try
		{
			// userPassword =
			// (String)jdbcTemplate.query(GET_USER_PASSWORD.replaceAll("\\?",userId+""),new
			// ManageGetPasswordMapper()).get(0);
			userPassword = (String) jdbcTemplate.query(GET_USER_PASSWORD, new Long[]
			{ userId }, new ManageGetPasswordMapper()).get(0);
		}
		catch (ArrayIndexOutOfBoundsException ae)
		{
			logger.error(ae, "Array Index out of bound exception");
		}
		finally
		{
			// logger.debug("password from DB="+userPassword);
			return userPassword;
		}
	}

	private static final class ManageGetPasswordMapper implements RowMapper<String>
	{
		public String mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			return rs.getString("password_");
		}
	}

	@SuppressWarnings("restriction")
	public AddonListVo getRolloverAddons(String accountNumber, String subscriptionNum)
	{
		// TODO Auto-generated method stub
		AddonListVo addonListVo = new AddonListVo();
		AddonVo dataRolloverAddonVo = new AddonVo();
		AddonVo textsRolloverAddonVo = new AddonVo();
		AddonVo minsRolloverAddonVo = new AddonVo();

		QueryAddonRequest queryAddonRequest = new QueryAddonRequest();
		queryAddonRequest.setAccountNumber(accountNumber);
		queryAddonRequest.setTodaysDate(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()));
		queryAddonRequest.setCustomerLevel(subscriptionNum);
		QueryAddonResponse queryAddonResponse = addonService.getAddon(queryAddonRequest);

		Service allAddons = queryAddonResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getAddons().get(0);

		JAXBElement<Addon> dataRolloverAddon = allAddons.getRolloverAddon().getDataRolloverAddon();
		logger.debug("AddonServiceServiceImpl || data bolton || Rollover Applicable: " + dataRolloverAddon.getValue().getRolloverApplicable());
		dataRolloverAddonVo.setRolloverApplicable(dataRolloverAddon.getValue().getRolloverApplicable());
		dataRolloverAddonVo.setServiceCode(dataRolloverAddon.getValue().getProductId());
		dataRolloverAddonVo.setAddonName(dataRolloverAddon.getValue().getProductName());
		dataRolloverAddonVo.setAddonDescription(dataRolloverAddon.getValue().getProductDescription());
		dataRolloverAddonVo.setAddonType(dataRolloverAddon.getValue().getProductType());
		dataRolloverAddonVo.setAddonPrice(dataRolloverAddon.getValue().getProductPrice());

		JAXBElement<Addon> textsRolloverAddon = allAddons.getRolloverAddon().getTextsRolloverAddon();
		logger.debug("AddonServiceServiceImpl || texts bolton || Rollover Applicable: " + textsRolloverAddon.getValue().getRolloverApplicable());
		textsRolloverAddonVo.setRolloverApplicable(textsRolloverAddon.getValue().getRolloverApplicable());
		textsRolloverAddonVo.setRolloverApplicable(textsRolloverAddon.getValue().getRolloverApplicable());
		textsRolloverAddonVo.setServiceCode(textsRolloverAddon.getValue().getProductId());
		textsRolloverAddonVo.setAddonName(textsRolloverAddon.getValue().getProductName());
		textsRolloverAddonVo.setAddonDescription(textsRolloverAddon.getValue().getProductDescription());
		textsRolloverAddonVo.setAddonType(textsRolloverAddon.getValue().getProductType());
		textsRolloverAddonVo.setAddonPrice(textsRolloverAddon.getValue().getProductPrice());

		JAXBElement<Addon> minsRolloverAddon = allAddons.getRolloverAddon().getMinsRolloverAddon();
		logger.debug("AddonServiceServiceImpl || mins bolton || Rollover Applicable: " + minsRolloverAddon.getValue().getRolloverApplicable());
		minsRolloverAddonVo.setRolloverApplicable(minsRolloverAddon.getValue().getRolloverApplicable());
		minsRolloverAddonVo.setServiceCode(minsRolloverAddon.getValue().getProductId());
		minsRolloverAddonVo.setAddonName(minsRolloverAddon.getValue().getProductName());
		minsRolloverAddonVo.setAddonDescription(minsRolloverAddon.getValue().getProductDescription());
		minsRolloverAddonVo.setAddonType(minsRolloverAddon.getValue().getProductType());
		minsRolloverAddonVo.setAddonPrice(minsRolloverAddon.getValue().getProductPrice());

		addonListVo.setDataRolloverAddon(dataRolloverAddonVo);
		addonListVo.setTextsRolloverAddon(textsRolloverAddonVo);
		addonListVo.setMinsRolloverAddon(minsRolloverAddonVo);

		return addonListVo;
	}
}
package com.techm.svallo.exception.service.forgotusername;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloForgotUsernamePasswordServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

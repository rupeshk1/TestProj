package com.techm.svallo.exception;

public class SvalloPortalException extends SvalloException
{
	private static final long serialVersionUID = 1L;
}

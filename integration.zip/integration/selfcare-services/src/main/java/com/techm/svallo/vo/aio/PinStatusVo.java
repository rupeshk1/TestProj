package com.techm.svallo.vo.aio;

public class PinStatusVo
{

	protected String pinMessage;
	protected String pinStatus;

	public String getPinMessage()
	{
		return pinMessage;
	}

	public void setPinMessage(String pinMessage)
	{
		this.pinMessage = pinMessage;
	}

	public String getPinStatus()
	{
		return pinStatus;
	}

	public void setPinStatus(String pinStatus)
	{
		this.pinStatus = pinStatus;
	}

}

package com.techm.svallo.service.topups;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.topup.SvalloTopUpServiceException;
import com.techm.svallo.util.SelfCareUtil;
import com.techm.svallo.vo.topups.HistoryListVo;
import com.techm.svallo.vo.topups.HistoryVo;
import com.techm.svallo.vo.topups.PaymentDetailsVo;
import com.techm.svallo.vo.topups.TopUpListVo;
import com.techmahindra.online.svallo.model.topups._2015._04._07.Histories;
import com.techmahindra.online.svallo.model.topups._2015._04._07.History;
import com.techmahindra.online.svallo.model.topups._2015._04._07.PaymentDetails;
import com.techmahindra.online.svallo.model.topups._2015._04._07.PurchaseOffer;
import com.techmahindra.online.svallo.model.topups._2015._04._07.PurchaseProductRequest;
import com.techmahindra.online.svallo.model.topups._2015._04._07.TopUp;
import com.techmahindra.online.svallo.model.topups._2015._04._07.TopUps;
import com.techmahindra.online.svallo.model.topups._2015._04._07.TopUpsRequest;
import com.techmahindra.online.svallo.service.common.exception.topup.SvalloTopUpIntegrationException;
import com.techmahindra.online.svallo.service.topups._2015._04._07.TopUpsService;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class GetTopUpsSelfcareServiceImpl implements GetTopUpsSelfcareService
{

	final static PortalLogger logger = PortalLogger.getLogger(GetTopUpsSelfcareServiceImpl.class);

	@Autowired
	private TopUpsService topUpsService;

	@Value("${topupService.queryPurchaseProduct.error.code}")
	private String TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_ERROR_CODE;

	@Value("${topupService.queryPurchaseProduct.error.message}")
	private String TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_ERROR_MESSAGE;

	@Value("${topupService.queryPurchaseProduct.exception.code}")
	private String TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_EXCEPTION_CODE;

	@Value("${topupService.queryPurchaseProduct.exception.message}")
	private String TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_EXCEPTION_MESSAGE;

	@Value("${topupService.getTopUps.error.code}")
	private String TOPUP_SERVICE_GET_TOPUPS_ERROR_CODE;

	@Value("${topupService.getTopUps.error.message}")
	private String TOPUP_SERVICE_GET_TOPUPS_ERROR_MESSAGE;

	@Value("${topupService.getTopUps.exception.code}")
	private String TOPUP_SERVICE_GET_TOPUPS_EXCEPTION_CODE;

	@Value("${topupService.getTopUps.exception.message}")
	private String TOPUP_SERVICE_GET_TOPUPS_EXCEPTION_MESSAGE;

	@Value("${topupService.getHistory.error.code}")
	private String TOPUP_SERVICE_HISTORY_ERROR_CODE;

	@Value("${topupService.getHistory.error.message}")
	private String TOPUP_SERVICE_HISTORY_ERROR_MESSAGE;

	@Value("${topupService.getHistory.exception.code}")
	private String TOPUP_SERVICE_HISTORY_EXCEPTION_CODE;

	@Value("${topupService.getHistory.exception.message}")
	private String TOPUP_SERVICE_HISTORY_EXCEPTION_MESSAGE;

	
	public HistoryListVo getReloadHistory(String subscriptionNumber, String dataset1, String dataset2, String includeBasketData, String reloadStatusFilter, String date) throws SvalloTopUpServiceException
	{
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  --START");
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  subscriptionNumber >> " + subscriptionNumber);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  dataset1 >> " + dataset1);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  dataset2 >> " + dataset2);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  includeBasketData >> " + includeBasketData);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  reloadStatusFilter >> " + reloadStatusFilter);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  date >> " + date);

		HistoryListVo reloadHistoryListVo = new HistoryListVo();
		try
		{
			logger.debug("######### inside selfcare getReloadHistory begining of try block ##########");

			Histories histories = topUpsService.getHistory(subscriptionNumber, dataset1, dataset2, includeBasketData, reloadStatusFilter, date);
			logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories >>> " + histories);

			if (histories != null)
			{
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getTopupHistories() >>> " + histories.getTopupHistories());
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getBundleHistories() >>> " + histories.getBundleHistories());
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getAddonHistories() >>> " + histories.getAddonHistories());
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getGeneralHistories() >>> " + histories.getGeneralHistories());

				if (histories.getTopupHistories() != null && histories.getTopupHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getTopupHistories().getHistory() >>> " + histories.getTopupHistories().getHistory());
					List<History> topupHistoryLists = histories.getTopupHistories().getHistory();
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  topupHistoryLists >>> " + topupHistoryLists);
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================topupHistoryLists mapping=========================START");
					if (topupHistoryLists != null && topupHistoryLists.size() > 0)
					{
						List<HistoryVo> topupHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(topupHistoryLists,topupHistories);
						reloadHistoryListVo.setTopupHistories(topupHistories);
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  TopupHistories priceTotal >>> " + priceTotal);
						reloadHistoryListVo.setTotalTopupPrice(SelfCareUtil.roundToTwoDight(priceTotal));
					}
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================topupHistoryLists mapping=========================END");
				}

				if (histories.getBundleHistories() != null && histories.getBundleHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getBundleHistories().getHistory() >>> " + histories.getBundleHistories().getHistory());
					List<History> bundleHistoryLists = histories.getBundleHistories().getHistory();
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================bundleHistoryLists mapping=========================START");
					if (bundleHistoryLists != null && bundleHistoryLists.size() > 0)
					{
						List<HistoryVo> bundleHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(bundleHistoryLists,bundleHistories);
						reloadHistoryListVo.setBundleHistories(bundleHistories);
						reloadHistoryListVo.setTotalBundlePrice(SelfCareUtil.roundToTwoDight(priceTotal));
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  BundleHistories priceTotal >>> " + priceTotal);
					}
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================bundleHistoryLists mapping=========================END");
				}

				if (histories.getAddonHistories() != null && histories.getAddonHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getAddonHistories().getHistory() >>> " + histories.getAddonHistories().getHistory());
					List<History> addonHistoryLists = histories.getAddonHistories().getHistory();
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================addonHistoryLists mapping=========================START");
					if (addonHistoryLists != null && addonHistoryLists.size() > 0)
					{
						List<HistoryVo> addonHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(addonHistoryLists,addonHistories);
						reloadHistoryListVo.setAddonHistories(addonHistories);
						reloadHistoryListVo.setTotalAddonPrice(SelfCareUtil.roundToTwoDight(priceTotal));
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  AddonHistories priceTotal >>> " + priceTotal);
					}
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================addonHistoryLists mapping=========================END");
				}
				if (histories.getGeneralHistories() != null && histories.getGeneralHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  histories.getGeneralHistories().getHistory() >>> " + histories.getGeneralHistories().getHistory());
					List<History> generalHistoryLists = histories.getGeneralHistories().getHistory();
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================generalHistoryLists mapping=========================START");
					if (generalHistoryLists != null && generalHistoryLists.size() > 0)
					{
						List<HistoryVo> generalHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(generalHistoryLists,generalHistories);
						reloadHistoryListVo.setGeneralHistories(generalHistories);
						reloadHistoryListVo.setTotalPrice(SelfCareUtil.roundToTwoDight(priceTotal));
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  GeneralHistories priceTotal >>> " + priceTotal);
					}
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | \n\n=================================generalHistoryLists mapping=========================END");
				}
			}
			logger.debug("######### inside selfcare getReloadHistory ending of try block ##########");
		}
		catch (SvalloTopUpIntegrationException svalloTopUpIntegrationException)
		{
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getReloadHistory() ] SvalloServiceException Catch Block ");
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getReloadHistory() ] SvalloServiceException Catch Block | Error Code =  " + TOPUP_SERVICE_HISTORY_ERROR_CODE);
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getReloadHistory() ] SvalloServiceException Catch Block | Error Message  =  " + TOPUP_SERVICE_HISTORY_ERROR_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_HISTORY_ERROR_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_HISTORY_ERROR_MESSAGE);
			svalloTopUpServiceException.setRootCause(svalloTopUpIntegrationException);
			throw svalloTopUpServiceException;
		}
		catch (Exception exception)
		{
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getReloadHistory() ] Exception Catch Block ");
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getReloadHistory() ] Exception Catch Block | Error Code =  " + TOPUP_SERVICE_HISTORY_EXCEPTION_CODE);
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getReloadHistory() ] Exception Catch Block | Error Message  =  " + TOPUP_SERVICE_HISTORY_EXCEPTION_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_HISTORY_EXCEPTION_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_HISTORY_EXCEPTION_MESSAGE);
			svalloTopUpServiceException.setRootCause(exception);
			throw svalloTopUpServiceException;
		}
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  Finally before return statment, reloadHistoryListVo = " + reloadHistoryListVo);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getReloadHistory() ]  --END");

		return reloadHistoryListVo;

	}
	
	public HistoryListVo getGReloadHistory(String subscriptionNumber, String dataset1, String dataset2, String includeBasketData, String reloadStatusFilter, String date)
	{
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  --START");
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  subscriptionNumber >> " + subscriptionNumber);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  dataset1 >> " + dataset1);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  dataset2 >> " + dataset2);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  includeBasketData >> " + includeBasketData);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  reloadStatusFilter >> " + reloadStatusFilter);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  date >> " + date);

		HistoryListVo reloadHistoryListVo = new HistoryListVo();
		try
		{
			logger.debug("######### inside selfcare getReloadHistory begining of try block ##########");

			Histories histories = topUpsService.getGHistory(subscriptionNumber, dataset1, dataset2, includeBasketData, reloadStatusFilter, date);
			logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories >>> " + histories);

			if (histories != null)
			{
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getTopupHistories() >>> " + histories.getTopupHistories());
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getBundleHistories() >>> " + histories.getBundleHistories());
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getAddonHistories() >>> " + histories.getAddonHistories());
				logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getGeneralHistories() >>> " + histories.getGeneralHistories());

				if (histories.getTopupHistories() != null && histories.getTopupHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getTopupHistories().getHistory() >>> " + histories.getTopupHistories().getHistory());
					List<History> topupHistoryLists = histories.getTopupHistories().getHistory();
					
					
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  topupHistoryLists >>> " + topupHistoryLists);
					if (topupHistoryLists != null && topupHistoryLists.size() > 0)
					{
						List<HistoryVo> topupHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(topupHistoryLists,topupHistories);
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  reloadHistoryListVo >>> " + reloadHistoryListVo);
						reloadHistoryListVo.setTopupHistories(topupHistories);
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  TopupHistories priceTotal >>> " + priceTotal);
						reloadHistoryListVo.setTotalTopupPrice(SelfCareUtil.roundToTwoDight(priceTotal));
					}
				}

				if (histories.getBundleHistories() != null && histories.getBundleHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getBundleHistories().getHistory() >>> " + histories.getBundleHistories().getHistory());
					List<History> bundleHistoryLists = histories.getBundleHistories().getHistory();

					if (bundleHistoryLists != null && bundleHistoryLists.size() > 0)
					{
						List<HistoryVo> bundleHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(bundleHistoryLists,bundleHistories);
						reloadHistoryListVo.setBundleHistories(bundleHistories);
						reloadHistoryListVo.setTotalBundlePrice(SelfCareUtil.roundToTwoDight(priceTotal));
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  BundleHistories priceTotal >>> " + priceTotal);
					}
				}

				if (histories.getAddonHistories() != null && histories.getAddonHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getAddonHistories().getHistory() >>> " + histories.getAddonHistories().getHistory());
					List<History> addonHistoryLists = histories.getAddonHistories().getHistory();

					if (addonHistoryLists != null && addonHistoryLists.size() > 0)
					{
						List<HistoryVo> addonHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(addonHistoryLists,addonHistories);
						reloadHistoryListVo.setAddonHistories(addonHistories);
						reloadHistoryListVo.setTotalAddonPrice(SelfCareUtil.roundToTwoDight(priceTotal));
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  AddonHistories priceTotal >>> " + priceTotal);
					}
				}
				if (histories.getGeneralHistories() != null && histories.getGeneralHistories().getHistory() != null)
				{
					logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  histories.getGeneralHistories().getHistory() >>> " + histories.getGeneralHistories().getHistory());
					List<History> generalHistoryLists = histories.getGeneralHistories().getHistory();
					if (generalHistoryLists != null && generalHistoryLists.size() > 0)
					{
						List<HistoryVo> generalHistories = new ArrayList<HistoryVo>();
						float priceTotal = setHistories(generalHistoryLists,generalHistories);
						reloadHistoryListVo.setGeneralHistories(generalHistories);
						reloadHistoryListVo.setTotalPrice(SelfCareUtil.roundToTwoDight(priceTotal));
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  GeneralHistories priceTotal >>> " + priceTotal);

					}
				}
			}
			logger.debug("######### inside selfcare getReloadHistory ending of try block ##########");
		}
		catch (SvalloTopUpIntegrationException svalloTopUpIntegrationException)
		{
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getGReloadHistory() ] SvalloServiceException Catch Block ");
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getGReloadHistory() ] SvalloServiceException Catch Block | Error Code =  " + TOPUP_SERVICE_HISTORY_ERROR_CODE);
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getGReloadHistory() ] SvalloServiceException Catch Block | Error Message  =  " + TOPUP_SERVICE_HISTORY_ERROR_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_HISTORY_ERROR_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_HISTORY_ERROR_MESSAGE);
			svalloTopUpServiceException.setRootCause(svalloTopUpIntegrationException);
			throw svalloTopUpServiceException;
		}
		catch (Exception exception)
		{
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getGReloadHistory() ] Exception Catch Block ");
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getGReloadHistory() ] Exception Catch Block | Error Code =  " + TOPUP_SERVICE_HISTORY_EXCEPTION_CODE);
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getGReloadHistory() ] Exception Catch Block | Error Message  =  " + TOPUP_SERVICE_HISTORY_EXCEPTION_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_HISTORY_EXCEPTION_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_HISTORY_EXCEPTION_MESSAGE);
			svalloTopUpServiceException.setRootCause(exception);
			throw svalloTopUpServiceException;
		}
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  Finally before return statment, reloadHistoryListVo = " + reloadHistoryListVo);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getGReloadHistory() ]  --END");

		return reloadHistoryListVo;

	}

	private static float setHistories(List<History> historyList,List<HistoryVo> histories) throws Exception
	{
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  --START");
		HistoryVo historyVo;
		float priceTotal = 0.00f;
		try
		{
			if(historyList!=null && historyList.size()>0 &&  histories!=null)
			{
				for (History history : historyList)
				{
					if (history != null)
					{
						historyVo = new HistoryVo();
						String dateCreated = null;
						String reloadExpiryDate = null;
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  history.getDateCreated() >>> " + history.getDateCreated());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  history.getReloadExpiryDate() >>> " + history.getReloadExpiryDate());
						
						if (history.getDateCreated() != null && history.getDateCreated().trim().length() > 0)
						{
							dateCreated = SelfCareUtil.getFormatedDate(history.getDateCreated());
							logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  dateCreated >>> " + dateCreated);
						}
						
						if (history.getReloadExpiryDate() != null && history.getReloadExpiryDate().trim().length() > 0)
						{
							reloadExpiryDate = SelfCareUtil.getFormatedDate(history.getReloadExpiryDate());
							logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  expiryDate >>> " +reloadExpiryDate);
						}
						
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadPrice() >>> " + history.getReloadPrice());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getDateCreated() >>> " + history.getDateCreated());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | dateCreated >>> " + dateCreated);
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadOption() >>> " + history.getReloadOption());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadOptionDescription() >>> " + history.getReloadOptionDescription());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadMethod() >>> " + history.getReloadMethod());
						
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadMethodDescription() >>> " + history.getReloadMethodDescription());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getPaymentReference() >>> " + history.getPaymentReference());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadMethodDescription() >>> " + history.getReloadMethodDescription());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getTimeCreated() >>> " + history.getTimeCreated());
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadExpiryDate() >>> " + reloadExpiryDate);
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  | history.getReloadExpiryTime() >>> " + history.getReloadExpiryTime());
						
						historyVo.setDateCreated(dateCreated);
						historyVo.setReloadOption(history.getReloadOption());
						historyVo.setReloadOptionDescription(history.getReloadOptionDescription());
						historyVo.setReloadMethod(history.getReloadMethod());
						historyVo.setReloadMethodDescription(history.getReloadMethodDescription());
						historyVo.setPaymentReference(history.getPaymentReference());
						historyVo.setTimeCreated(history.getTimeCreated());
						historyVo.setReloadExpiryDate(reloadExpiryDate);
						historyVo.setReloadExpiryTime(history.getReloadExpiryTime());
						
						logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  history.getReloadPrice() >>> " + history.getReloadPrice());
						if ((history.getReloadPrice()) != null && (!history.getReloadPrice().equalsIgnoreCase("")))
						{
							float reloadPrice = Float.parseFloat(history.getReloadPrice());
							historyVo.setReloadPrice(SelfCareUtil.roundToTwoDight(reloadPrice));
							priceTotal = priceTotal + reloadPrice;
						}
						histories.add(historyVo);
					}
				}
			}
		}
		catch (Exception exception)
		{
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | setHistories() ] Exception Catch Block ");
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | setHistories() ] Exception Catch Block | Error Code =  " + "GH001");
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | setHistories() ] Exception Catch Block | Error Message  =  " + "Exception in setHistories()");
			throw exception;
		}
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  priceTotal >> "+priceTotal);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | setHistories() ]  --END");
		
		return priceTotal;
	}

	public List<TopUpListVo> getTopUps(String accountNumber) throws SvalloTopUpServiceException
	{
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getTopUps() ]  --START");
		TopUpsRequest topUpsRequest = new TopUpsRequest();

		topUpsRequest.setAccountNumber(accountNumber);

		List<TopUpListVo> topUpList = new ArrayList<TopUpListVo>();
		TopUpListVo topUpListVo = new TopUpListVo();

		NumberFormat decimalformatter = new DecimalFormat("#0.00");
		
		try
		{

			logger.debug("######### inside selfcare getTopUps begining of try block ##########");

			TopUps receiveTopUp = topUpsService.getTopUps(topUpsRequest);

			if (receiveTopUp != null)
			{
				List<TopUp> topUps = receiveTopUp.getTopUp();

				if (topUps != null && topUps.size() > 0)
				{
					for (int i = 0; i < topUps.size(); i++)
					{

						TopUp singleTopUp = topUps.get(i);
						TopUpListVo singleTopUpListVo = new TopUpListVo();
						if (singleTopUp != null && singleTopUpListVo != null)
						{
							singleTopUpListVo.setTopUpAmount(decimalformatter.format(Double.valueOf(singleTopUp.getTopUpAmount())));

							singleTopUpListVo.setTopUpDescription(singleTopUp.getTopUpDescription());
							singleTopUpListVo.setTopUpId(singleTopUp.getTopUpId());
							singleTopUpListVo.setTopUpName(singleTopUp.getTopUpName());
							singleTopUpListVo.setTopUpType(singleTopUp.getTopUpType());

						}
						topUpList.add(singleTopUpListVo);
					}
				}
				else
				{

					topUpList.add(topUpListVo);
				}
			}
			logger.debug("######### inside selfcare getTopUps ending of try block ##########");
		}
		catch (SvalloTopUpIntegrationException svalloTopUpIntegrationException)
		{
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getTopUps() ] SvalloServiceException Catch Block ");
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getTopUps() ] SvalloServiceException Catch Block | Error Code =  " + TOPUP_SERVICE_GET_TOPUPS_ERROR_CODE);
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | getTopUps() ] SvalloServiceException Catch Block | Error Message  =  " + TOPUP_SERVICE_GET_TOPUPS_ERROR_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_GET_TOPUPS_ERROR_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_GET_TOPUPS_ERROR_MESSAGE);
			svalloTopUpServiceException.setRootCause(svalloTopUpIntegrationException);
			throw svalloTopUpServiceException;
		}
		catch (Exception exception)
		{
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getTopUps() ] Exception Catch Block ");
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getTopUps() ] Exception Catch Block | Error Code =  " + TOPUP_SERVICE_GET_TOPUPS_EXCEPTION_CODE);
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | getTopUps() ] Exception Catch Block | Error Message  =  " + TOPUP_SERVICE_GET_TOPUPS_EXCEPTION_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_GET_TOPUPS_EXCEPTION_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_GET_TOPUPS_EXCEPTION_MESSAGE);
			svalloTopUpServiceException.setRootCause(exception);
			throw svalloTopUpServiceException;
		}
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | getTopUps() ]  --END");
		return topUpList;
	}

	public String queryPurchaseProduct(PaymentDetailsVo paymentDetailsVo, String subscriptionNumber, String serviceCode, String servicePrice, String txnRef, String productType)
	{
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | queryPurchaseProduct() ]  --START");
		String responseFromPurchaseProductService = "";
		try
		{
			PurchaseProductRequest purchaseProductRequest = new PurchaseProductRequest();
			PaymentDetails paymentDetails = new PaymentDetails();

			PurchaseOffer purchaseOffer = new PurchaseOffer();

			purchaseOffer.setPrice(servicePrice);
			purchaseOffer.setReloadOption(serviceCode);

			paymentDetails.setAuthorisationCode(paymentDetailsVo.getAuthorisationCode());
			paymentDetails.setCardNumber(paymentDetailsVo.getCardNumber());
			paymentDetails.setCardReference(paymentDetailsVo.getCardReference());
			paymentDetails.setPaymentReference(paymentDetailsVo.getPaymentReference());
			paymentDetails.setNameOnCard(paymentDetailsVo.getNameOnCard());
			paymentDetails.setPaymentType(paymentDetailsVo.getPaymentType());
			paymentDetails.setPostCode(paymentDetailsVo.getPostCode());
			paymentDetails.setTransactionReference(paymentDetailsVo.getTransactionReference());
			paymentDetails.setTransactionDateTime(paymentDetailsVo.getTransactionDateTime());

			purchaseProductRequest.setPaymentDetails(paymentDetails);
			purchaseProductRequest.setSubscriptionNumber(subscriptionNumber);
			purchaseProductRequest.setTransactionReference(txnRef);
			purchaseProductRequest.setPurchaseOffers(purchaseOffer);
			purchaseProductRequest.setProductType(productType);

			logger.info("######### inside selfcare queryPurchaseProduct begining of try block ##########");

			responseFromPurchaseProductService = topUpsService.queryPurchaseProduct(purchaseProductRequest);

			logger.info("######### inside selfcare queryPurchaseProduct ending of try block ##########");

		}
		catch (SvalloTopUpIntegrationException svalloTopUpIntegrationException)
		{
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | queryPurchaseProduct() ] SvalloServiceException Catch Block ");
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | queryPurchaseProduct() ] SvalloServiceException Catch Block | Error Code =  " + TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_ERROR_CODE);
			logger.error(svalloTopUpIntegrationException, "\n[ GetTopUpsSelfcareServiceImpl | queryPurchaseProduct() ] SvalloServiceException Catch Block | Error Message  =  " + TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_ERROR_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_ERROR_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_ERROR_MESSAGE);
			svalloTopUpServiceException.setRootCause(svalloTopUpIntegrationException);
		}
		catch (Exception exception)
		{
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | queryPurchaseProduct() ] Exception Catch Block ");
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | queryPurchaseProduct() ] Exception Catch Block | Error Code =  " + TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_EXCEPTION_CODE);
			logger.error(exception, "\n[ GetTopUpsSelfcareServiceImpl | queryPurchaseProduct() ] Exception Catch Block | Error Message  =  " + TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_EXCEPTION_MESSAGE);
			SvalloTopUpServiceException svalloTopUpServiceException = new SvalloTopUpServiceException();
			svalloTopUpServiceException.setErrorCode(TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_EXCEPTION_CODE);
			svalloTopUpServiceException.setErrorMessage(TOPUP_SERVICE_QUERY_PURCHASE_PRODUCT_EXCEPTION_MESSAGE);
			svalloTopUpServiceException.setRootCause(exception);
		}

		logger.info("response value=" + responseFromPurchaseProductService);
		logger.debug("[ GetTopUpsSelfcareServiceImpl.java | queryPurchaseProduct() ]  --END");
		return responseFromPurchaseProductService;

	}
}
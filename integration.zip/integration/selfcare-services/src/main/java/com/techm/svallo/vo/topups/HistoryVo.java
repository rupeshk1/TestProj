package com.techm.svallo.vo.topups;

public class HistoryVo
{

	private String reloadOption;
	private String dateCreated;
	private String reloadOptionDescription;
	private String reloadPrice;
	private String reloadMethod;
	private String reloadMethodDescription;
	private String paymentReference;
	private String timeCreated;
	private String reloadExpiryDate;
	private String reloadExpiryTime;
	
	public String getReloadOption()
	{
		return reloadOption;
	}
	public void setReloadOption(String reloadOption)
	{
		this.reloadOption = reloadOption;
	}
	public String getDateCreated()
	{
		return dateCreated;
	}
	public void setDateCreated(String dateCreated)
	{
		this.dateCreated = dateCreated;
	}
	public String getReloadOptionDescription()
	{
		return reloadOptionDescription;
	}
	public void setReloadOptionDescription(String reloadOptionDescription)
	{
		this.reloadOptionDescription = reloadOptionDescription;
	}
	public String getReloadPrice()
	{
		return reloadPrice;
	}
	public void setReloadPrice(String reloadPrice)
	{
		this.reloadPrice = reloadPrice;
	}
	public String getReloadMethod()
	{
		return reloadMethod;
	}
	public void setReloadMethod(String reloadMethod)
	{
		this.reloadMethod = reloadMethod;
	}
	public String getReloadMethodDescription()
	{
		return reloadMethodDescription;
	}
	public void setReloadMethodDescription(String reloadMethodDescription)
	{
		this.reloadMethodDescription = reloadMethodDescription;
	}
	public String getPaymentReference()
	{
		return paymentReference;
	}
	public void setPaymentReference(String paymentReference)
	{
		this.paymentReference = paymentReference;
	}
	public String getTimeCreated()
	{
		return timeCreated;
	}
	public void setTimeCreated(String timeCreated)
	{
		this.timeCreated = timeCreated;
	}
	public String getReloadExpiryDate()
	{
		return reloadExpiryDate;
	}
	public void setReloadExpiryDate(String reloadExpiryDate)
	{
		this.reloadExpiryDate = reloadExpiryDate;
	}
	public String getReloadExpiryTime()
	{
		return reloadExpiryTime;
	}
	public void setReloadExpiryTime(String reloadExpiryTime)
	{
		this.reloadExpiryTime = reloadExpiryTime;
	}
	
	 

}

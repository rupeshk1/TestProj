package com.techm.svallo.vo.registration;

public class RegistrationVo
{
	private String workFlowId;
	private String accountNumber;
	private String pin;
	private String isAction;
	private String otpPin;
	private String mobileNumber;
	private String title;
	private String firstName;
	private String lastName;
	private String email;
	private String dob;
	private String userName;
	private String subscriptionNumber;
	private String termsAndCondition;
	private String eventCode;
	private String eventTypeCode;
	private String serviceDOB;
	private String smsMessage;
	private String traiffCode;
	private String accountName;
	private String currentDate;
	private String emailMessage;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String addressLine5;	
	private String mins;
	private String secs;
	private String resetFlag;
	private String accountType;
	private int isFromRegisterButton = 0;
	private String serviceDownError;
	private String disconnectedDate;
	private boolean isAccountDisconnected;
	private String isMyAccont;
	private String subscriptionStatus;
	private String eventNumber;
	private String pinEntered;
	private String validationStatus;
	private String areFlag;
	private String middleName;
	
	/* added fileds for PAYG Anonymisation CR */ 
	private String agreementNum;
	private String billingType;
	private String subscriptionLastAmendedDate;
	private String customerLastAmendedDate;
	private String aioUserValue;
	
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getAreFlag() {
		return areFlag;
	}
	public void setAreFlag(String areFlag) {
		this.areFlag = areFlag;
	}
	public String getEventNumber() {
		return eventNumber;
	}
	public void setEventNumber(String eventNumber) {
		this.eventNumber = eventNumber;
	}
	public String getPinEntered() {
		return pinEntered;
	}
	public void setPinEntered(String pinEntered) {
		this.pinEntered = pinEntered;
	}
	public String getValidationStatus() {
		return validationStatus;
	}
	public void setValidationStatus(String validationStatus) {
		this.validationStatus = validationStatus;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getAddressLine4() {
		return addressLine4;
	}
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}
	public String getAddressLine5() {
		return addressLine5;
	}
	public void setAddressLine5(String addressLine5) {
		this.addressLine5 = addressLine5;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	private String postalCode;
	/*
	private String town;
	private String country;
	*/
	
		
	public String getEmailMessage() {
		return emailMessage;
	}
	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}
	public String getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}
	public String getTraiffCode() {
		return traiffCode;
	}
	public void setTraiffCode(String traiffCode) {
		this.traiffCode = traiffCode;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getServiceDOB() {
		return serviceDOB;
	}
	public void setServiceDOB(String serviceDOB) {
		this.serviceDOB = serviceDOB;
	}
	public String getSmsMessage() {
		return smsMessage;
	}
	public void setSmsMessage(String smsMessage) {
		this.smsMessage = smsMessage;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}	
	public String getEventTypeCode() {
		return eventTypeCode;
	}
	public void setEventTypeCode(String eventTypeCode) {
		this.eventTypeCode = eventTypeCode;
	}
	public String getTermsAndCondition() {
		return termsAndCondition;
	}
	public void setTermsAndCondition(String termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}
	public String getSubscriptionNumber() {
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber) {
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOtpPin() {
		return otpPin;
	}
	public void setOtpPin(String otpPin) {
		this.otpPin = otpPin;
	}
	public String getWorkFlowId() {
		return workFlowId;
	}
	public void setWorkFlowId(String workFlowId) {
		this.workFlowId = workFlowId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getIsAction() {
		return isAction;
	}
	public void setIsAction(String isAction) {
		this.isAction = isAction;
	}
	public String getMins() {
		return mins;
	}
	public void setMins(String mins) {
		this.mins = mins;
	}
	public String getSecs() {
		return secs;
	}
	public void setSecs(String secs) {
		this.secs = secs;
	}
	public String getResetFlag() {
		return resetFlag;
	}
	public void setResetFlag(String resetFlag) {
		this.resetFlag = resetFlag;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getIsFromRegisterButton() {
		return isFromRegisterButton;
	}
	public void setIsFromRegisterButton(int isFromRegisterButton) {
		this.isFromRegisterButton = isFromRegisterButton;
	}
	public String getServiceDownError() {
		return serviceDownError;
	}
	public void setServiceDownError(String serviceDownError) {
		this.serviceDownError = serviceDownError;
	}
	public String getDisconnectedDate() {
		return disconnectedDate;
	}
	public void setDisconnectedDate(String disconnectedDate) {
		this.disconnectedDate = disconnectedDate;
	}
	public boolean isAccountDisconnected() {
		return isAccountDisconnected;
	}
	public void setAccountDisconnected(boolean isAccountDisconnected) {
		this.isAccountDisconnected = isAccountDisconnected;
	}
	public String getIsMyAccont() {
		return isMyAccont;
	}
	public void setIsMyAccont(String isMyAccont) {
		this.isMyAccont = isMyAccont;
	}
	public String getSubscriptionStatus() {
		return subscriptionStatus;
	}
	public void setSubscriptionStatus(String subscriptionStatus) {
		this.subscriptionStatus = subscriptionStatus;
	}	
	public String getAgreementNum() {
		return agreementNum;
	}
	public void setAgreementNum(String agreementNum) {
		this.agreementNum = agreementNum;
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getSubscriptionLastAmendedDate() {
		return subscriptionLastAmendedDate;
	}
	public void setSubscriptionLastAmendedDate(String subscriptionLastAmendedDate) {
		this.subscriptionLastAmendedDate = subscriptionLastAmendedDate;
	}
	public String getCustomerLastAmendedDate() {
		return customerLastAmendedDate;
	}
	public void setCustomerLastAmendedDate(String customerLastAmendedDate) {
		this.customerLastAmendedDate = customerLastAmendedDate;
	}
	public String getAioUserValue() {
		return aioUserValue;
	}
	public void setAioUserValue(String aioUserValue) {
		this.aioUserValue = aioUserValue;
	} 		
}

package com.techm.svallo.exception.integration.Addon;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloAddonIntegrationException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

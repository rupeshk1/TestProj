package com.techm.svallo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.vo.addon.AddonVo;

public class ExistingAddOnDateComparator implements Comparator<AddonVo>
{

	final static PortalLogger logger = PortalLogger.getLogger(ExistingAddOnDateComparator.class);

	@Override
	public int compare(AddonVo addonVo1, AddonVo addonVo2) 
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		
		String dateStr1 =addonVo1.getAddonEffectiveDate();
		String dateStr2 = addonVo2.getAddonEffectiveDate();
		
		try 
		{
			if (dateStr1 == null ||(dateStr1 != null && dateStr1.length() > 8 )|| dateStr2 == null ||(dateStr2 != null && dateStr2.length() > 8 )  )
			{	
			      return 0;
			}      
			
			Date date1 = sdf.parse(dateStr1);
			Date date2 = sdf.parse(dateStr2);
			
			
			logger.debug("date1::"+date1);
			
			logger.debug("date2::"+date2);
			
			logger.debug("date2.compareTo(date1)::"+date2.compareTo(date1));
			//return date1.compareTo(date2);
			return date2.compareTo(date1);
		} 
		catch (ParseException e) 
		{
			logger.error(e,"[ ExistingAddOnDateComparator.java| compare() ] Exception Catch Block ");
		}	
		
		return 0;
	}

}

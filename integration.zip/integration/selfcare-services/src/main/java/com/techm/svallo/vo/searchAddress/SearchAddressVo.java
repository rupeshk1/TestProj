package com.techm.svallo.vo.searchAddress;


public class SearchAddressVo
{
	protected String buildingName;
    protected String subBuildingName;
    protected String buildingNumber;
    protected String thoroughfare;
    protected String dependentThoroughfare;
    protected String locality;
    protected String town;
    protected String county;
    protected String postcode;
    protected String country;
    protected String threeCharacterISOCountryCode;
    protected String errorMessage;
    protected String status;
    protected String component;
    protected String service;
    protected String code;
    protected String message;
    protected String recoverable;
    protected String category;
    protected String originator;
    protected String originatorCode;
    protected String originatorMessage;
    
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getSubBuildingName() {
		return subBuildingName;
	}
	public void setSubBuildingName(String subBuildingName) {
		this.subBuildingName = subBuildingName;
	}
	public String getBuildingNumber() {
		return buildingNumber;
	}
	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}
	public String getThoroughfare() {
		return thoroughfare;
	}
	public void setThoroughfare(String thoroughfare) {
		this.thoroughfare = thoroughfare;
	}
	public String getDependentThoroughfare() {
		return dependentThoroughfare;
	}
	public void setDependentThoroughfare(String dependentThoroughfare) {
		this.dependentThoroughfare = dependentThoroughfare;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getThreeCharacterISOCountryCode() {
		return threeCharacterISOCountryCode;
	}
	public void setThreeCharacterISOCountryCode(String threeCharacterISOCountryCode) {
		this.threeCharacterISOCountryCode = threeCharacterISOCountryCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getRecoverable() {
		return recoverable;
	}
	public void setRecoverable(String recoverable) {
		this.recoverable = recoverable;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getOriginator() {
		return originator;
	}
	public void setOriginator(String originator) {
		this.originator = originator;
	}
	public String getOriginatorCode() {
		return originatorCode;
	}
	public void setOriginatorCode(String originatorCode) {
		this.originatorCode = originatorCode;
	}
	public String getOriginatorMessage() {
		return originatorMessage;
	}
	public void setOriginatorMessage(String originatorMessage) {
		this.originatorMessage = originatorMessage;
	}
    
    
}

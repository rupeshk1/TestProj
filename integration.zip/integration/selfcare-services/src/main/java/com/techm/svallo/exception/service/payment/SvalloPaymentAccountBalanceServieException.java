package com.techm.svallo.exception.service.payment;


import com.techm.svallo.exception.integration.SvalloIntegrationException;

public class SvalloPaymentAccountBalanceServieException extends SvalloIntegrationException
{
	private static final long serialVersionUID = 1L;
}

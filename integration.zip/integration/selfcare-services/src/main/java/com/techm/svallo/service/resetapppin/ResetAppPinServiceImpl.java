package com.techm.svallo.service.resetapppin;

import com.techm.portal.common.loggerwrapper.PortalLogger;

import com.techm.svallo.exception.service.resetapppin.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;

import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.comviva.encryptor.CryptoEngine;

@Service("resetAppPinService")
public class ResetAppPinServiceImpl implements ResetAppPinService
{

	// @Autowired
	// private RechargeBalance rechargeBalance;
	
	
	private JdbcTemplate jdbcTemplateMobPin = null;
	
	//private JdbcTemplate jdbcTemplate = null;
	
	@Value("${resetapppin.savepin.error.code}")
	private String RESETAPPPIN_SAVEPIN_ERROR_CODE;

	@Value("${resetapppin.savepin.error.message}")
	private String RESETAPPPIN_SAVEPIN_ERROR_MESSAGE;

	@Value("${resetapppin.savepin.error.message.detail}")
	private String RESETAPPPIN_SAVEPIN_ERROR_MESSAGE_DETAIL;
	
	@Value("${resetapppin.enryptpin.error.code}")
	private String RESETAPPPIN_ENCRYPTPIN_ERROR_CODE;
	@Value("${resetapppin.enryptpin.error.message}")
	private String RESETAPPPIN_ENCRYPTPIN_ERROR_MESSAGE;
	@Value("${resetapppin.enryptpin.error.message.detail}")
	private String RESETAPPPIN_ENCRYPTPIN_ERROR_MESSAGE_DETAIL;

	private static String SAVE_APPPIN_DETAILS = "update CPWPINDETAILS set LOGINPIN=? where ACCOUNTNUMBER=?";
	final static PortalLogger logger = PortalLogger.getLogger(ResetAppPinServiceImpl.class);
	 
	@Override
	public boolean savePin(String accountNumber, String pin)
	{
		logger.info("[ ResetAppPinServiceImpl.java |  savePin() ]  ");
		String encryptedPin = encryptPin(accountNumber, pin);
		boolean insertStatus = false;
		int intinsert =0;
		if (encryptedPin != null && encryptedPin.trim().length() > 0)
		{
			try
			{
			   
				intinsert = jdbcTemplateMobPin.update(SAVE_APPPIN_DETAILS,encryptedPin,accountNumber);
				
				if (intinsert != 0)
				{	
				insertStatus = true;
				}
			
				
			}
			catch (InvalidResultSetAccessException invalidResultSetAccessException)
			{
				logger.error(invalidResultSetAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] InvalidResultSetAccessException Catch Block ");
				logger.error(invalidResultSetAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] InvalidResultSetAccessException Catch Block | Error Code =  " + RESETAPPPIN_SAVEPIN_ERROR_CODE);
				logger.error(invalidResultSetAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] InvalidResultSetAccessException Catch Block | Error Message  =  " + RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
				SvalloResetAppPinServiceException SvalloResetAppPinServiceException = new SvalloResetAppPinServiceException();
                SvalloResetAppPinServiceException.setErrorCode(RESETAPPPIN_SAVEPIN_ERROR_CODE);
                SvalloResetAppPinServiceException.setErrorMessage(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
                SvalloResetAppPinServiceException.setErrorMessageDetail(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE_DETAIL);
                SvalloResetAppPinServiceException.setRootCause(invalidResultSetAccessException);
                throw SvalloResetAppPinServiceException;

			}
			catch (EmptyResultDataAccessException emptyResultDataAccessException)
			{
				logger.error(emptyResultDataAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] EmptyResultDataAccessException Catch Block ");
				logger.error(emptyResultDataAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] EmptyResultDataAccessException Catch Block | Error Code =  " + RESETAPPPIN_SAVEPIN_ERROR_CODE);
				logger.error(emptyResultDataAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] EmptyResultDataAccessException Catch Block | Error Message  =  " + RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
				SvalloResetAppPinServiceException SvalloResetAppPinServiceException = new SvalloResetAppPinServiceException();
                SvalloResetAppPinServiceException.setErrorCode(RESETAPPPIN_SAVEPIN_ERROR_CODE);
                SvalloResetAppPinServiceException.setErrorMessage(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
                SvalloResetAppPinServiceException.setErrorMessageDetail(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE_DETAIL);
                SvalloResetAppPinServiceException.setRootCause(emptyResultDataAccessException);
                throw SvalloResetAppPinServiceException;
			}
			catch (DataAccessException dataAccessException)
			{
				logger.error(dataAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] DataAccessException Catch Block ");
				logger.error(dataAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] DataAccessException Catch Block | Error Code =  " + RESETAPPPIN_SAVEPIN_ERROR_CODE);
				logger.error(dataAccessException,"\n[ ResetAppPinServiceImpl | savePin() ] DataAccessException Catch Block | Error Message  =  " + RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
				SvalloResetAppPinServiceException SvalloResetAppPinServiceException = new SvalloResetAppPinServiceException();
                SvalloResetAppPinServiceException.setErrorCode(RESETAPPPIN_SAVEPIN_ERROR_CODE);
                SvalloResetAppPinServiceException.setErrorMessage(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
                SvalloResetAppPinServiceException.setErrorMessageDetail(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE_DETAIL);
                SvalloResetAppPinServiceException.setRootCause(dataAccessException);
                throw SvalloResetAppPinServiceException;
			}
			
			catch (Exception exception)
			{
				logger.error(exception,"\n[ ResetAppPinServiceImpl | savePin() ] Exception   catch block ");
				logger.error(exception,"\n[ ResetAppPinServiceImpl | savePin() ] Exception   catch bloc | Error Code =  " + RESETAPPPIN_SAVEPIN_ERROR_CODE);
				logger.error(exception,"\n[ ResetAppPinServiceImpl | savePin() ] Exception   catch bloc | Error Message  =  " + RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
				SvalloResetAppPinServiceException SvalloResetAppPinServiceException = new SvalloResetAppPinServiceException();
                SvalloResetAppPinServiceException.setErrorCode(RESETAPPPIN_SAVEPIN_ERROR_CODE);
                SvalloResetAppPinServiceException.setErrorMessage(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE);
                SvalloResetAppPinServiceException.setErrorMessageDetail(RESETAPPPIN_SAVEPIN_ERROR_MESSAGE_DETAIL);
                SvalloResetAppPinServiceException.setRootCause(exception);
                throw SvalloResetAppPinServiceException;
			}
		}
		logger.info("[ ResetAppPinServiceImpl.java |  savePin() ]   insertStatus >>> " +insertStatus );
		return insertStatus;
	}

	private String encryptPin(String accountNumber, String pin)
	{
		String encryptedPin = null;
		if (accountNumber != null && accountNumber.trim().length() > 0 && pin != null && pin.trim().length() > 0)
		{
			try
			{
				//ResetAppPinsVo ResetAppPinsVo = new ResetAppPinsVo();
				
				CryptoEngine ceObj = new CryptoEngine(accountNumber);
				encryptedPin = ceObj.encrypt(pin);
				
			}
			catch (Exception exception)
			{
				logger.error(exception,"\n[ ResetAppPinServiceImpl | encryptPin() ] Exception   catch block ");
				logger.error(exception,"\n[ ResetAppPinServiceImpl | encryptPin() ] Exception   catch bloc | Error Code =  " + RESETAPPPIN_ENCRYPTPIN_ERROR_CODE);
				logger.error(exception,"\n[ ResetAppPinServiceImpl | encryptPin() ] Exception   catch bloc | Error Message  =  " + RESETAPPPIN_ENCRYPTPIN_ERROR_MESSAGE);
			}
		}
		return encryptedPin;
	}
	public void setJdbcTemplateMobPin(JdbcTemplate jdbcTemplateMobPin)
	{
		this.jdbcTemplateMobPin = jdbcTemplateMobPin;
	}

}

package com.techm.svallo.service.aio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.vo.aio.QueryAccountVo;
import com.techm.svallo.vo.aio.SubscriptionDetailVo;
import com.techmahindra.online.svallo.model.aio._2015._09._18.QueryAccount;
import com.techmahindra.online.svallo.model.aio._2015._09._18.SubscriptionDetail;
import com.techmahindra.online.svallo.service.aio._2015._09._18.AllInOne;
import com.techmahindra.online.svallo.service.common.exception.aio.SvalloAioActivateSimIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.aio.SvalloAioGetSubscriptionIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.aio.SvalloUpdateAddressAccountSubscriptionlevelIntegrationException;
import com.techm.svallo.exception.service.aio.SvalloActivateSimServiceException;
import com.techm.svallo.exception.service.aio.SvalloGetSubscriptionServiceException;
import com.techm.svallo.exception.service.aio.SvalloUpdateAddressAccountSubscriptionLevelServiceException;




//import org.springframework.beans.factory.annotation.Autowired;
//@Service("aioService")
public class AioServiceImpl implements AioService
{

	final static PortalLogger logger = PortalLogger.getLogger(AioServiceImpl.class);

	@Value("${aio.activatesim.service.error.code}")
	private String AIO_ACTIVATESIM_ERROR_CODE;
	
	@Value("${aio.activatesim.error.message}")
	private String AIO_ACTIVATESIM_ERROR_MESSAGE;
	
		
	@Value("${aio.updateaddressaccountsubscriptionlevel.service.error.code}")
	private String  AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_CODE; 
	
	@Value("${aio.updateaddressaccountsubscriptionlevel.error.message}")
	private String  AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_MESSAGE; 
	
	
	@Value("${aio.getsubscription.service.error.code}")
	private String  AIO_GETSUBSCRIPTION_ERROR_CODE;  
	
	@Value("${aio.getsubscription.error.message}")
	private String  AIO_GETSUBSCRIPTION_ERROR_MESSAGE;  
	
	@Autowired
	private AllInOne allInOne;
	


	public AllInOne getAllInOne()
	{
		return allInOne;
	}

	public void setAllInOne(AllInOne allInOne)
	{
		this.allInOne = allInOne;
	}

	@Override
	public SubscriptionDetailVo getSubscription(QueryAccountVo queryAccountVo) throws SvalloGetSubscriptionServiceException
	{
		logger.debug("[ getSubscription() ] - START");
		SubscriptionDetail subscriptionDetail = null;
		QueryAccount queryAccount = null;
		SubscriptionDetailVo subscriptionDetailVo = null;
		try
		{
			if (queryAccountVo != null && queryAccountVo.getSimNumber()!=null && !queryAccountVo.getSimNumber().equals(""))
			{
				queryAccount = new QueryAccount();
				queryAccount.setSimNumber(queryAccountVo.getSimNumber());
				queryAccount.setAccountIdentifier(queryAccountVo.getAccountIdentifier());
				queryAccount.setSubscriptionNumber(queryAccountVo.getSubscriptionNumber());
				subscriptionDetail = allInOne.getSubscription(queryAccount);
				logger.debug("[ getSubscription() ] Got response from camel service,  subscriptionDetail > " + subscriptionDetail);
				if(subscriptionDetail!=null)
				{
					subscriptionDetailVo = new SubscriptionDetailVo();
					logger.debug("[ getSubscription() ] subscriptionDetail.getSubscriptionNumber() > " + subscriptionDetail.getSubscriptionNumber());
					subscriptionDetailVo.setSubscriptionNumber(subscriptionDetail.getSubscriptionNumber());
					subscriptionDetailVo.setAgreementNumber(subscriptionDetail.getAgreementNumber());
					subscriptionDetailVo.setAccountNumber(subscriptionDetail.getAccountNumber());
					subscriptionDetailVo.setCustomerLastAmendedDate(subscriptionDetail.getCustomerLastAmendedDate());
					subscriptionDetailVo.setMobileNumber(subscriptionDetail.getMobileNumber());
					subscriptionDetailVo.setSubscriptionLastAmendedDate(subscriptionDetail.getSubscriptionLastAmendedDate());
					
					
					//subscriptionDetailVo.setNetworkSerialNumber(subscriptionDetail.getNetworkSerialNumber());
					subscriptionDetailVo.setNetworkSerialNumber("1234567890111111");	
				}
			}
			logger.debug("[ getSubscription() ] - END");
		}
		catch(SvalloAioGetSubscriptionIntegrationException svalloAioGetSubscriptionIntegrationException)
		{
			logger.error(svalloAioGetSubscriptionIntegrationException,"[ getSubscription() ] svalloAioGetSubscriptionIntegrationException Catch Block ");
			logger.error(svalloAioGetSubscriptionIntegrationException,"[ getSubscription() ] svalloAioGetSubscriptionIntegrationException Catch Block | Error Code =  "+AIO_GETSUBSCRIPTION_ERROR_CODE);
			logger.error(svalloAioGetSubscriptionIntegrationException,"[ getSubscription() ] svalloAioGetSubscriptionIntegrationException Catch Block | Error Message  =  "+AIO_GETSUBSCRIPTION_ERROR_MESSAGE);
			SvalloGetSubscriptionServiceException svalloGetSubscriptionServiceException = new SvalloGetSubscriptionServiceException();
			svalloGetSubscriptionServiceException.setErrorCode(AIO_GETSUBSCRIPTION_ERROR_CODE);
			svalloGetSubscriptionServiceException.setErrorMessage(AIO_GETSUBSCRIPTION_ERROR_MESSAGE);
			svalloGetSubscriptionServiceException.setRootCause(svalloAioGetSubscriptionIntegrationException);
			throw svalloGetSubscriptionServiceException;
		} 
		catch(Exception exception)
		{
			logger.error(exception,"[ getSubscription() ] Exception catch block ");
			logger.error(exception,"[ getSubscription() ] Exception catch block | Error Code =  "+AIO_GETSUBSCRIPTION_ERROR_CODE);
			logger.error(exception,"[ getSubscription() ] Exception catch block | Error Message  =  "+AIO_GETSUBSCRIPTION_ERROR_MESSAGE);
			SvalloGetSubscriptionServiceException svalloGetSubscriptionServiceException = new SvalloGetSubscriptionServiceException();
			svalloGetSubscriptionServiceException.setErrorCode(AIO_GETSUBSCRIPTION_ERROR_CODE);
			svalloGetSubscriptionServiceException.setErrorMessage(AIO_GETSUBSCRIPTION_ERROR_MESSAGE);
			svalloGetSubscriptionServiceException.setRootCause(exception);
			throw svalloGetSubscriptionServiceException;
		}
		logger.debug("[ getSubscription() ] END");
		return subscriptionDetailVo;
	}


	@Override
	public SubscriptionDetailVo updateAddressAccountSubscriptionlevel(QueryAccountVo queryAccountVo) throws SvalloUpdateAddressAccountSubscriptionLevelServiceException
	{
		logger.debug("[ updateAddressAccountSubscriptionlevel() ] - START");
		SubscriptionDetail subscriptionDetail = null;
		QueryAccount queryAccount = null;
		SubscriptionDetailVo subscriptionDetailVo = null;
		try
		{
			if (queryAccountVo != null && queryAccountVo.getSubscriptionNumber()!=null && !queryAccountVo.getSubscriptionNumber().equals(""))
			{
				queryAccount = new QueryAccount();
				queryAccount.setSubscriptionNumber(queryAccountVo.getSubscriptionNumber()); //asSubscriptionIdentifier
				queryAccount.setSurname(queryAccountVo.getSurname());
				queryAccount.setFirstname(queryAccountVo.getFirstname());
				queryAccount.setDateofbirth(queryAccountVo.getDateofbirth());
				
				
				
				queryAccount.setTitle(queryAccountVo.getTitle());
				queryAccount.setAdressLine1(queryAccountVo.getAdressLine1());
				queryAccount.setAdressLine2(queryAccountVo.getAdressLine2());
				queryAccount.setAdressLine3(queryAccountVo.getAdressLine3());
				queryAccount.setAdressLine4(queryAccountVo.getAdressLine4());
				queryAccount.setAdressLine5(queryAccountVo.getAdressLine5());
				queryAccount.setPostCode(queryAccountVo.getPostCode());
				
				
				queryAccount.setAccountNumber(queryAccountVo.getAccountNumber());
				queryAccount.setAgreementNumber(queryAccountVo.getAgreementNumber());
				queryAccount.setCustLastAmendedDate(queryAccountVo.getCustLastAmendedDate());
				queryAccount.setSubLastAmendDate(queryAccountVo.getSubLastAmendDate());
				queryAccount.setUserName(queryAccountVo.getUserName());
				queryAccount.setSubPassword(queryAccountVo.getSubPassword());
				                
						
				subscriptionDetail = allInOne.updateAddressAccountSubscriptionlevel(queryAccount);
				logger.debug("[ updateAddressAccountSubscriptionlevel() ] Got response from camel service,  subscriptionDetail > " + subscriptionDetail);
				if(subscriptionDetail!=null)
				{
					subscriptionDetailVo = new SubscriptionDetailVo();
					logger.debug("[ updateAddressAccountSubscriptionlevel() ] subscriptionDetail.getUpdateAddressAccountLevelMessage() > " + subscriptionDetail.getUpdateAddressAccountLevelMessage());
				
					
					subscriptionDetailVo.setUpdateAddressAccountLevelMessage(subscriptionDetail.getUpdateAddressAccountLevelMessage());
					subscriptionDetailVo.setUpdateAddressSubscriptionLevelMessage(subscriptionDetail.getUpdateAddressSubscriptionLevelMessage());
				}
			}
			
			
		}catch(SvalloUpdateAddressAccountSubscriptionlevelIntegrationException svalloAioUpdateAddressAccountlevelIntegrationException)
		{
			logger.error(svalloAioUpdateAddressAccountlevelIntegrationException,"[ getSubscriptionDetails() ] svalloAioUpdateAddressAccountlevelIntegrationException Catch Block ");
			logger.error(svalloAioUpdateAddressAccountlevelIntegrationException,"[ getSubscriptionDetails() ] svalloAioUpdateAddressAccountlevelIntegrationException Catch Block | Error Code =  "+AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_CODE);
			logger.error(svalloAioUpdateAddressAccountlevelIntegrationException,"[ getSubscriptionDetails() ] svalloAioUpdateAddressAccountlevelIntegrationException Catch Block | Error Message  =  "+AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_MESSAGE);
			SvalloUpdateAddressAccountSubscriptionLevelServiceException svalloupdateAddressAccountSubscriptionlevelServiceException = new SvalloUpdateAddressAccountSubscriptionLevelServiceException();
			svalloupdateAddressAccountSubscriptionlevelServiceException.setErrorCode(AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_CODE);
			svalloupdateAddressAccountSubscriptionlevelServiceException.setErrorMessage(AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_MESSAGE);
			svalloupdateAddressAccountSubscriptionlevelServiceException.setRootCause(svalloAioUpdateAddressAccountlevelIntegrationException);
			throw svalloupdateAddressAccountSubscriptionlevelServiceException;
		}
		catch(Exception exception)
		{
			logger.error(exception,"[ updateAddressAccountSubscriptionlevel() ] Exception catch block ");
			logger.error(exception,"[ updateAddressAccountSubscriptionlevel() ] Exception catch block | Error Code =  "+AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_CODE);
			logger.error(exception,"[ updateAddressAccountSubscriptionlevel() ] Exception catch block | Error Message  =  "+AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_MESSAGE);
			SvalloUpdateAddressAccountSubscriptionLevelServiceException svalloupdateAddressAccountSubscriptionlevelServiceException = new SvalloUpdateAddressAccountSubscriptionLevelServiceException();
			svalloupdateAddressAccountSubscriptionlevelServiceException.setErrorCode(AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_CODE);
			svalloupdateAddressAccountSubscriptionlevelServiceException.setErrorMessage(AIO_UPDATEADDRESSACCOUNTSUBSCRIPTIONLEVEL_ERROR_MESSAGE);
			svalloupdateAddressAccountSubscriptionlevelServiceException.setRootCause(exception);
			throw svalloupdateAddressAccountSubscriptionlevelServiceException;
		}
		logger.debug("[ updateAddressAccountSubscriptionlevel() ] - END");
		return subscriptionDetailVo;
	}
	

	@Override
	public SubscriptionDetailVo activateSim(QueryAccountVo queryAccountVo) throws SvalloActivateSimServiceException
	{
		logger.debug("[ activateSim() ] - START");
		SubscriptionDetail subscriptionDetail = null;
		QueryAccount queryAccount = null;
		SubscriptionDetailVo subscriptionDetailVo = null;
		try
		{
			if (queryAccountVo != null && queryAccountVo.getSubscriptionNumber()!=null && !queryAccountVo.getSubscriptionNumber().equals(""))
			{
				queryAccount = new QueryAccount();
				queryAccount.setSubscriptionNumber(queryAccountVo.getSubscriptionNumber());
				queryAccount.setAccountNumber(queryAccountVo.getAccountNumber());
				queryAccount.setEventCode(queryAccountVo.getEventCode());
				queryAccount.setEventTypeCode(queryAccountVo.getEventTypeCode());
				
				queryAccount.setTAndC(queryAccountVo.gettAndC());
					
				
				subscriptionDetail = allInOne.activateSim(queryAccount);
				logger.debug("[ activateSim() ] Got response from camel service,  activateSim > " + subscriptionDetail);
				if(subscriptionDetail!=null)
				{
					subscriptionDetailVo = new SubscriptionDetailVo();
					logger.debug("[ activateSim() ] subscriptionDetail.getUpdateAddressMessage() > " + subscriptionDetail.getUpdateAddressMessage());
				
					subscriptionDetailVo.setUpdateAddressMessage(subscriptionDetail.getUpdateAddressMessage());
					
				}
			}
			
		}catch(SvalloAioActivateSimIntegrationException svalloAioActivateSimIntegrationException)
		{
			logger.error(svalloAioActivateSimIntegrationException,"[ activateSim() ] svalloAioActivateSimIntegrationException Catch Block ");
			logger.error(svalloAioActivateSimIntegrationException,"[ activateSim() ] svalloAioActivateSimIntegrationException Catch Block | Error Code =  "+AIO_ACTIVATESIM_ERROR_CODE);
			logger.error(svalloAioActivateSimIntegrationException,"[ activateSim() ] svalloAioActivateSimIntegrationException Catch Block | Error Message  =  "+AIO_ACTIVATESIM_ERROR_MESSAGE);
			SvalloActivateSimServiceException svalloActivateSimServiceException = new SvalloActivateSimServiceException();
			svalloActivateSimServiceException.setErrorCode(AIO_ACTIVATESIM_ERROR_CODE);
			svalloActivateSimServiceException.setErrorMessage(AIO_ACTIVATESIM_ERROR_MESSAGE);
			svalloActivateSimServiceException.setRootCause(svalloAioActivateSimIntegrationException);
			throw svalloActivateSimServiceException;
		}
		catch(Exception exception)
		{
			logger.error(exception,"[ activateSim() ] Exception catch block ");
			logger.error(exception,"[ activateSim() ] Exception catch block | Error Code =  "+AIO_ACTIVATESIM_ERROR_CODE);
			logger.error(exception,"[ activateSim() ] Exception catch block | Error Message  =  "+AIO_ACTIVATESIM_ERROR_MESSAGE);
			SvalloActivateSimServiceException svalloActivateSimServiceException = new SvalloActivateSimServiceException();
			svalloActivateSimServiceException.setErrorCode(AIO_ACTIVATESIM_ERROR_CODE);
			svalloActivateSimServiceException.setErrorMessage(AIO_ACTIVATESIM_ERROR_MESSAGE);
			svalloActivateSimServiceException.setRootCause(exception);
			throw svalloActivateSimServiceException;
		}
		
		logger.debug("[ activateSim() ] - END");
		return subscriptionDetailVo;
	}
	
	



}

package com.techm.svallo.exception.service.oneofpayment;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloOneOfPaymentServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

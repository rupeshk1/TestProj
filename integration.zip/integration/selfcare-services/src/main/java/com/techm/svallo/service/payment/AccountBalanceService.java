package com.techm.svallo.service.payment;

import com.techmahindra.online.svallo.model.payment._2014._09._01.BalanceDetails;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;

public interface AccountBalanceService
{
	public BalanceDetails getAccountBallance(QueryAccount queryAccount);
}

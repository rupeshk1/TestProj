package com.techm.svallo.service;

import java.util.List;

import com.techm.svallo.vo.CustomerAccount;

public interface PortalProfileService {
	
	public List<CustomerAccount> getUserAccount(String userId);
	
	public void createUserAccount(CustomerAccount custAccount);

}

package com.techm.svallo.exception.service.payment;

import com.techm.svallo.exception.service.SvalloDatabaseException;

public class SvalloServiceBillingException extends SvalloDatabaseException
{
	private static final long serialVersionUID = 1L;
}

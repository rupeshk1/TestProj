package com.techm.svallo.vo.aio;

import java.util.ArrayList;
import java.util.List;

public class SubscriptionDetailVo
{
	private String activationcode=null;
	private String accountNumber=null;
	private String mobileNumber=null;
	private String addressNumberAccountlevel=null;
	private String subscriptionNumber=null;
	private String agreementNumber=null;
	private String subscriptionLastAmendedDate=null;
	private String customerLastAmendedDate=null;
	
	private String networkSerialNumber=null;
	private String networkSerialStatus=null;
	
	private String updateAddressAccountLevelMessage;
	private String updateAddressMessage;
	private String updateAddressSubscriptionLevelMessage;
	public String getActivationcode()
	{
		return activationcode;
	}
	public void setActivationcode(String activationcode)
	{
		this.activationcode = activationcode;
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getMobileNumber()
	{
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber)
	{
		this.mobileNumber = mobileNumber;
	}
	public String getAddressNumberAccountlevel()
	{
		return addressNumberAccountlevel;
	}
	public void setAddressNumberAccountlevel(String addressNumberAccountlevel)
	{
		this.addressNumberAccountlevel = addressNumberAccountlevel;
	}
	public String getSubscriptionNumber()
	{
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber)
	{
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getAgreementNumber()
	{
		return agreementNumber;
	}
	public void setAgreementNumber(String agreementNumber)
	{
		this.agreementNumber = agreementNumber;
	}
	public String getSubscriptionLastAmendedDate()
	{
		return subscriptionLastAmendedDate;
	}
	public void setSubscriptionLastAmendedDate(String subscriptionLastAmendedDate)
	{
		this.subscriptionLastAmendedDate = subscriptionLastAmendedDate;
	}
	public String getCustomerLastAmendedDate()
	{
		return customerLastAmendedDate;
	}
	public void setCustomerLastAmendedDate(String customerLastAmendedDate)
	{
		this.customerLastAmendedDate = customerLastAmendedDate;
	}
	public String getNetworkSerialNumber()
	{
		return networkSerialNumber;
	}
	public void setNetworkSerialNumber(String networkSerialNumber)
	{
		this.networkSerialNumber = networkSerialNumber;
	}
	public String getNetworkSerialStatus()
	{
		return networkSerialStatus;
	}
	public void setNetworkSerialStatus(String networkSerialStatus)
	{
		this.networkSerialStatus = networkSerialStatus;
	}
	public String getUpdateAddressAccountLevelMessage()
	{
		return updateAddressAccountLevelMessage;
	}
	public void setUpdateAddressAccountLevelMessage(String updateAddressAccountLevelMessage)
	{
		this.updateAddressAccountLevelMessage = updateAddressAccountLevelMessage;
	}
	public String getUpdateAddressMessage()
	{
		return updateAddressMessage;
	}
	public void setUpdateAddressMessage(String updateAddressMessage)
	{
		this.updateAddressMessage = updateAddressMessage;
	}
	public String getUpdateAddressSubscriptionLevelMessage()
	{
		return updateAddressSubscriptionLevelMessage;
	}
	public void setUpdateAddressSubscriptionLevelMessage(String updateAddressSubscriptionLevelMessage)
	{
		this.updateAddressSubscriptionLevelMessage = updateAddressSubscriptionLevelMessage;
	}
	
	

	
}

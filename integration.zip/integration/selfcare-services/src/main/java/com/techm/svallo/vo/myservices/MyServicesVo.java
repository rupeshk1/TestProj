package com.techm.svallo.vo.myservices;

import java.util.ArrayList;
import java.util.List;


public class MyServicesVo
{

	/*
private CallingFeaturesVo callingFeaturesVo=null;

public CallingFeaturesVo getCallingFeaturesVo() {
	return callingFeaturesVo;
}

public void setCallingFeaturesVo(CallingFeaturesVo callingFeaturesVo) {
	this.callingFeaturesVo = callingFeaturesVo;
}
*/

private List<CallingFeaturesVo> callingFeaturesVoList = new ArrayList<CallingFeaturesVo>();
private String accountNumber;
private String effectiveDate;
private String subscriptionNumber;
private String message;
private String serviceCode; //not a right way to do
private String accountType;
private String myServicesError;

public String getServiceCode() {
	return serviceCode;
}

public void setServiceCode(String serviceCode) {
	this.serviceCode = serviceCode;
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

public String getAccountNumber() {
	return accountNumber;
}

public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}

public String getEffectiveDate() {
	return effectiveDate;
}

public void setEffectiveDate(String effectiveDate) {
	this.effectiveDate = effectiveDate;
}

public String getSubscriptionNumber() {
	return subscriptionNumber;
}

public void setSubscriptionNumber(String subscriptionNumber) {
	this.subscriptionNumber = subscriptionNumber;
}

public List<CallingFeaturesVo> getCallingFeaturesVoList() {
	return callingFeaturesVoList;
}

public void setCallingFeaturesVoList(List<CallingFeaturesVo> callingFeaturesVoList) {
	this.callingFeaturesVoList = callingFeaturesVoList;
}

public String getAccountType() {
	return accountType;
}

public void setAccountType(String accountType) {
	this.accountType = accountType;
}

public String getMyServicesError() {
	return myServicesError;
}

public void setMyServicesError(String myServicesError) {
	this.myServicesError = myServicesError;
}


}

package com.techm.svallo.vo.billingandpayment;

import java.util.List;
import java.util.Map;

import com.techm.svallo.vo.subscriptioncap.SubscriptionCapVo;
import com.techm.svallo.vo.topups.BasketListVo;
import com.techm.svallo.vo.topups.HistoryListVo;
import com.techmahindra.online.svallo.model.payment._2014._09._01.BalanceDetails;
import com.techmahindra.online.svallo.model.payment._2014._09._01.Bill;
import com.techmahindra.online.svallo.model.payment._2014._09._01.DirectDebitDetail;
import com.techmahindra.online.svallo.model.payment._2014._09._01.Payment;

public class BillingAndPaymentVo
{
	private DirectDebitDetailVo directDebitDetailVo=null;
	private List<PaymentNBillingVo> paymentList=null; //"paymentList"
	private List<PaymentNBillingVo> invoiceList=null; //"invoiceList"
	private List<BillVo> billHistoryList = null; //"billHistoryList"
	
	private BillVo lastBillHistoryVo=null; //"lastBillHistoryVo"
	private PaymentNBillingVo lastPaymentNBillingVo = null;
	private BalanceDetails balanceDetails = null; //"balanceDetails"
	private DirectDebitDetail directDebitDetail = null; //"directDebitDetail";
	private List validationMessageList = null; //"validationMessageList"
	//private String directDebitUpdateStatus = "" ; //directDebitUpdateStatus
	private BillVo billHistory = null; //"billHistory"
	private List<BillPeriodVo> billingPeriod = null; //"billingPeriod"
	private Map<String,BillVo> billPeriodMap = null;
	
	private String bankaccountNumber="";
    private String banksortCode="";
    private String nameOfPayer="";
    private boolean termsAndConditions=false;
    private String directDebitUpdateStatus=null;
    private String billHistoryPeriod="";
    
    private String accountNumber="";
    
	private String paymentType;
    private String paymentTerms;
    
    private String lastAmendedDate;
    
    
    private PaymentNBillingVo lastInvoicePaymentNBillingVo = null;
    
    private String currentMonthEstimatedBill;
    private String currentMonth;
    private String currentMonthDueOn;
    private String currentMonthExtraCharges;
    private String currentMonthTarrif;
    private String nextInvoiceDate;
    
    private String directDebitRecordFound="false";
    private String billHistoryRecordFound="false";
    private String paymentHistoryRecordFound="false";
    
    private String directDebitExceptionMessage="error while populating direct debit details";
    private String billHistoryExceptionMessage="error while populating bill history";
    private String paymentHistoryExceptionMessage="error while populating payment history";
    
    private String directDebitExceptionPresent="false";
    private String billHistoryExceptionPresent="false";
    private String paymentHistoryExceptionPresent="false";
    
    private String amountOverdue=null;
    
    private String unbilledAmount=null;
    
    private String banksortCode1="";
    private String banksortCode2="";
    private String banksortCode3="";
    
    private String directDebitMessage="";
    private String directDebitDayMessage="";
    private String directDebitDay="";
    
    private String dueDate="";
    private String myCurrentMonthBillExceptionPresent="false";
    List<BasketListVo> basketList=null;
    
    private String myTopHistoryExceptionPresent="false";
    
    private String currentMonthTopUpAndAddOnTotalAmount="";
    private String totalAddonPrice="";
    private String totalOfActiveAddons="";
    
    private String lastBillTopUpAndAddOnTotalAmount="";
    
    private String outStandingBillAmount="";
    
    private String billingType="";
    
    private SubscriptionCapVo subscriptionCapVo=null;
    
    HistoryListVo historyListVo = null;
    
    private String myAccountContractStartDate=null;
    
	public String getMyAccountContractStartDate()
	{
		return myAccountContractStartDate;
	}
	public void setMyAccountContractStartDate(String myAccountContractStartDate)
	{
		this.myAccountContractStartDate = myAccountContractStartDate;
	}
	public HistoryListVo getHistoryListVo()
	{
		return historyListVo;
	}
	public void setHistoryListVo(HistoryListVo historyListVo)
	{
		this.historyListVo = historyListVo;
	}
	public SubscriptionCapVo getSubscriptionCapVo()
	{
		return subscriptionCapVo;
	}
	public void setSubscriptionCapVo(SubscriptionCapVo subscriptionCapVo)
	{
		this.subscriptionCapVo = subscriptionCapVo;
	}
	public String getOutStandingBillAmount()
	{
		return outStandingBillAmount;
	}
	public void setOutStandingBillAmount(String outStandingBillAmount)
	{
		this.outStandingBillAmount = outStandingBillAmount;
	}
	public String getCurrentMonthTopUpAndAddOnTotalAmount()
	{
		return currentMonthTopUpAndAddOnTotalAmount;
	}
	public void setCurrentMonthTopUpAndAddOnTotalAmount(String currentMonthTopUpAndAddOnTotalAmount)
	{
		this.currentMonthTopUpAndAddOnTotalAmount = currentMonthTopUpAndAddOnTotalAmount;
	}
	public String getLastBillTopUpAndAddOnTotalAmount()
	{
		return lastBillTopUpAndAddOnTotalAmount;
	}
	public void setLastBillTopUpAndAddOnTotalAmount(String lastBillTopUpAndAddOnTotalAmount)
	{
		this.lastBillTopUpAndAddOnTotalAmount = lastBillTopUpAndAddOnTotalAmount;
	}
	public List<BasketListVo> getBasketList()
	{
		return basketList;
	}
	public void setBasketList(List<BasketListVo> basketList)
	{
		this.basketList = basketList;
	}
	public String getMyTopHistoryExceptionPresent()
	{
		return myTopHistoryExceptionPresent;
	}
	public void setMyTopHistoryExceptionPresent(String myTopHistoryExceptionPresent)
	{
		this.myTopHistoryExceptionPresent = myTopHistoryExceptionPresent;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getDirectDebitMessage() {
		return directDebitMessage;
	}
	public void setDirectDebitMessage(String directDebitMessage) {
		this.directDebitMessage = directDebitMessage;
	}
	public String getBanksortCode1()
	{
		return banksortCode1;
	}
	public void setBanksortCode1(String banksortCode1)
	{
		this.banksortCode1 = banksortCode1;
	}
	public String getBanksortCode2()
	{
		return banksortCode2;
	}
	public void setBanksortCode2(String banksortCode2)
	{
		this.banksortCode2 = banksortCode2;
	}
	public String getBanksortCode3()
	{
		return banksortCode3;
	}
	public void setBanksortCode3(String banksortCode3)
	{
		this.banksortCode3 = banksortCode3;
	}
	public String getUnbilledAmount()
	{
		return unbilledAmount;
	}
	public void setUnbilledAmount(String unbilledAmount)
	{
		this.unbilledAmount = unbilledAmount;
	}
	public String getDirectDebitExceptionPresent()
	{
		return directDebitExceptionPresent;
	}
	public void setDirectDebitExceptionPresent(String directDebitExceptionPresent)
	{
		this.directDebitExceptionPresent = directDebitExceptionPresent;
	}
	public String getBillHistoryExceptionPresent()
	{
		return billHistoryExceptionPresent;
	}
	public void setBillHistoryExceptionPresent(String billHistoryExceptionPresent)
	{
		this.billHistoryExceptionPresent = billHistoryExceptionPresent;
	}
	public String getPaymentHistoryExceptionPresent()
	{
		return paymentHistoryExceptionPresent;
	}
	public void setPaymentHistoryExceptionPresent(String paymentHistoryExceptionPresent)
	{
		this.paymentHistoryExceptionPresent = paymentHistoryExceptionPresent;
	}
	public String getDirectDebitExceptionMessage()
	{
		return directDebitExceptionMessage;
	}
	public void setDirectDebitExceptionMessage(String directDebitExceptionMessage)
	{
		this.directDebitExceptionMessage = directDebitExceptionMessage;
	}
	public String getBillHistoryExceptionMessage()
	{
		return billHistoryExceptionMessage;
	}
	public void setBillHistoryExceptionMessage(String billHistoryExceptionMessage)
	{
		this.billHistoryExceptionMessage = billHistoryExceptionMessage;
	}
	public String getPaymentHistoryExceptionMessage()
	{
		return paymentHistoryExceptionMessage;
	}
	public void setPaymentHistoryExceptionMessage(String paymentHistoryExceptionMessage)
	{
		this.paymentHistoryExceptionMessage = paymentHistoryExceptionMessage;
	}
	public String getPaymentHistoryRecordFound()
	{
		return paymentHistoryRecordFound;
	}
	public void setPaymentHistoryRecordFound(String paymentHistoryRecordFound)
	{
		this.paymentHistoryRecordFound = paymentHistoryRecordFound;
	}
	public String getBillHistoryRecordFound()
	{
		return billHistoryRecordFound;
	}
	public void setBillHistoryRecordFound(String billHistoryRecordFound)
	{
		this.billHistoryRecordFound = billHistoryRecordFound;
	}
	public String getDirectDebitRecordFound()
	{
		return directDebitRecordFound;
	}
	public void setDirectDebitRecordFound(String directDebitRecordFound)
	{
		this.directDebitRecordFound = directDebitRecordFound;
	}
	public String getCurrentMonthEstimatedBill()
	{
		return currentMonthEstimatedBill;
	}
	public void setCurrentMonthEstimatedBill(String currentMonthEstimatedBill)
	{
		this.currentMonthEstimatedBill = currentMonthEstimatedBill;
	}
	public List<PaymentNBillingVo> getInvoiceList()
	{
		return invoiceList;
	}
	public void setInvoiceList(List<PaymentNBillingVo> invoiceList)
	{
		this.invoiceList = invoiceList;
	}
	public String getCurrentMonth()
	{
		return currentMonth;
	}
	public void setCurrentMonth(String currentMonth)
	{
		this.currentMonth = currentMonth;
	}
	public String getCurrentMonthDueOn()
	{
		return currentMonthDueOn;
	}
	public void setCurrentMonthDueOn(String currentMonthDueOn)
	{
		this.currentMonthDueOn = currentMonthDueOn;
	}
	public String getCurrentMonthExtraCharges()
	{
		return currentMonthExtraCharges;
	}
	public void setCurrentMonthExtraCharges(String currentMonthExtraCharges)
	{
		this.currentMonthExtraCharges = currentMonthExtraCharges;
	}
	public String getCurrentMonthTarrif()
	{
		return currentMonthTarrif;
	}
	public void setCurrentMonthTarrif(String currentMonthTarrif)
	{
		this.currentMonthTarrif = currentMonthTarrif;
	}
	public String getNextInvoiceDate()
	{
		return nextInvoiceDate;
	}
	public void setNextInvoiceDate(String nextInvoiceDate)
	{
		this.nextInvoiceDate = nextInvoiceDate;
	}
	public PaymentNBillingVo getLastInvoicePaymentNBillingVo()
	{
		return lastInvoicePaymentNBillingVo;
	}
	public void setLastInvoicePaymentNBillingVo(PaymentNBillingVo lastInvoicePaymentNBillingVo)
	{
		this.lastInvoicePaymentNBillingVo = lastInvoicePaymentNBillingVo;
	}
	public String getLastAmendedDate()
	{
		return lastAmendedDate;
	}
	public void setLastAmendedDate(String lastAmendedDate)
	{
		this.lastAmendedDate = lastAmendedDate;
	}
    
    public String getPaymentType()
	{
		return paymentType;
	}

	public void setPaymentType(String paymentType)
	{
		this.paymentType = paymentType;
	}

	public String getPaymentTerms()
	{
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms)
	{
		this.paymentTerms = paymentTerms;
	}

	public DirectDebitDetailVo getDirectDebitDetailVo()
	{
		return directDebitDetailVo;
	}

	public void setDirectDebitDetailVo(DirectDebitDetailVo directDebitDetailVo)
	{
		this.directDebitDetailVo = directDebitDetailVo;
	}

	public List<PaymentNBillingVo> getPaymentList()
	{
		return paymentList;
	}

	public void setPaymentList(List<PaymentNBillingVo> paymentList)
	{
		this.paymentList = paymentList;
	}

	public List<BillVo> getBillHistoryList()
	{
		return billHistoryList;
	}

	public void setBillHistoryList(List<BillVo> billHistoryList)
	{
		this.billHistoryList = billHistoryList;
	}

	public BillVo getLastBillHistoryVo()
	{
		return lastBillHistoryVo;
	}

	public void setLastBillHistoryVo(BillVo lastBillHistoryVo)
	{
		this.lastBillHistoryVo = lastBillHistoryVo;
	}

	public PaymentNBillingVo getLastPaymentNBillingVo()
	{
		return lastPaymentNBillingVo;
	}

	public void setLastPaymentNBillingVo(PaymentNBillingVo lastPaymentNBillingVo)
	{
		this.lastPaymentNBillingVo = lastPaymentNBillingVo;
	}

	public BalanceDetails getBalanceDetails()
	{
		return balanceDetails;
	}

	public void setBalanceDetails(BalanceDetails balanceDetails)
	{
		this.balanceDetails = balanceDetails;
	}

	public DirectDebitDetail getDirectDebitDetail()
	{
		return directDebitDetail;
	}

	public void setDirectDebitDetail(DirectDebitDetail directDebitDetail)
	{
		this.directDebitDetail = directDebitDetail;
	}

	public List getValidationMessageList()
	{
		return validationMessageList;
	}

	public void setValidationMessageList(List validationMessageList)
	{
		this.validationMessageList = validationMessageList;
	}

	public BillVo getBillHistory()
	{
		return billHistory;
	}

	public void setBillHistory(BillVo billHistory)
	{
		this.billHistory = billHistory;
	}

	public List<BillPeriodVo> getBillingPeriod()
	{
		return billingPeriod;
	}

	public void setBillingPeriod(List<BillPeriodVo> billingPeriod)
	{
		this.billingPeriod = billingPeriod;
	}

	public Map<String, BillVo> getBillPeriodMap()
	{
		return billPeriodMap;
	}

	public void setBillPeriodMap(Map<String, BillVo> billPeriodMap)
	{
		this.billPeriodMap = billPeriodMap;
	}

	public String getBankaccountNumber()
	{
		return bankaccountNumber;
	}

	public void setBankaccountNumber(String bankaccountNumber)
	{
		this.bankaccountNumber = bankaccountNumber;
	}

	public String getBanksortCode()
	{
		return banksortCode;
	}

	public void setBanksortCode(String banksortCode)
	{
		this.banksortCode = banksortCode;
	}

	public String getNameOfPayer()
	{
		return nameOfPayer;
	}

	public void setNameOfPayer(String nameOfPayer)
	{
		this.nameOfPayer = nameOfPayer;
	}

	public boolean isTermsAndConditions()
	{
		return termsAndConditions;
	}

	public void setTermsAndConditions(boolean termsAndConditions)
	{
		this.termsAndConditions = termsAndConditions;
	}

	public String getDirectDebitUpdateStatus()
	{
		return directDebitUpdateStatus;
	}

	public void setDirectDebitUpdateStatus(String directDebitUpdateStatus)
	{
		this.directDebitUpdateStatus = directDebitUpdateStatus;
	}

	public String getBillHistoryPeriod()
	{
		return billHistoryPeriod;
	}

	public void setBillHistoryPeriod(String billHistoryPeriod)
	{
		this.billHistoryPeriod = billHistoryPeriod;
	}

	public String getAccountNumber()
	{
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getAmountOverdue()
	{
		return amountOverdue;
	}
	public void setAmountOverdue(String amountOverdue)
	{
		this.amountOverdue = amountOverdue;
	}
	public String getMyCurrentMonthBillExceptionPresent() {
		return myCurrentMonthBillExceptionPresent;
	}
	public void setMyCurrentMonthBillExceptionPresent(
			String myCurrentMonthBillExceptionPresent) {
		this.myCurrentMonthBillExceptionPresent = myCurrentMonthBillExceptionPresent;
	}
	public String getDirectDebitDayMessage()
	{
		return directDebitDayMessage;
	}
	public void setDirectDebitDayMessage(String directDebitDayMessage)
	{
		this.directDebitDayMessage = directDebitDayMessage;
	}
	public String getDirectDebitDay()
	{
		return directDebitDay;
	}
	public void setDirectDebitDay(String directDebitDay)
	{
		this.directDebitDay = directDebitDay;
	}
	public String getTotalAddonPrice()
	{
		return totalAddonPrice;
	}
	public void setTotalAddonPrice(String totalAddonPrice)
	{
		this.totalAddonPrice = totalAddonPrice;
	}
	public String getTotalOfActiveAddons()
	{
		return totalOfActiveAddons;
	}
	public void setTotalOfActiveAddons(String totalOfActiveAddons)
	{
		this.totalOfActiveAddons = totalOfActiveAddons;
	}
	public String getBillingType()
	{
		return billingType;
	}
	public void setBillingType(String billingType)
	{
		this.billingType = billingType;
	}
	
    
}

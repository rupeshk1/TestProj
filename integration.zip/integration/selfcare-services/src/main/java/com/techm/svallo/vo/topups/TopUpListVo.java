package com.techm.svallo.vo.topups;

public class TopUpListVo {
	
		private String topUpAmount;
	    private String topUpDescription;
	    private String topUpId;
	    private String topUpName;
	    private String topUpType;
	    
		public String getTopUpAmount() {
			return topUpAmount;
		}
		public void setTopUpAmount(String topUpAmount) {
			this.topUpAmount = topUpAmount;
		}
		public String getTopUpDescription() {
			return topUpDescription;
		}
		public void setTopUpDescription(String topUpDescription) {
			this.topUpDescription = topUpDescription;
		}
		public String getTopUpId() {
			return topUpId;
		}
		public void setTopUpId(String topUpId) {
			this.topUpId = topUpId;
		}
		public String getTopUpName() {
			return topUpName;
		}
		public void setTopUpName(String topUpName) {
			this.topUpName = topUpName;
		}
		public String getTopUpType() {
			return topUpType;
		}
		public void setTopUpType(String topUpType) {
			this.topUpType = topUpType;
		}

}

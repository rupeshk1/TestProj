package com.techm.svallo.service.addressval;

import java.util.List;

import com.techm.svallo.vo.searchAddress.SearchAddressVo;

public interface AddressValSelfcareService {
	public List<SearchAddressVo> validateAddress(String adressLine1,String adressLine2,String postCode,String adressLine4,String country);
	
}
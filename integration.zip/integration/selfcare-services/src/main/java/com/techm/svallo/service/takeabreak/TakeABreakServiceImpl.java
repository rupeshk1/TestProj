package com.techm.svallo.service.takeabreak;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.payment.SvalloDirectDebitServiceException;
import com.techm.svallo.exception.service.takeabreak.SvalloTakeABreakServiceException;
import com.techm.svallo.vo.myprofile.TakeABreakQueryVo;
import com.techm.svallo.vo.takeabreak.QueryAccount;
import com.techm.svallo.vo.takeabreak.SubscriptionInfoVo;
import com.techm.svallo.vo.takeabreak.TakeABreakServiceStatusVo;
import com.techmahindra.online.svallo.model.takeabreak._2014._09._01.SubscriptionInfo;
import com.techmahindra.online.svallo.model.takeabreak._2014._09._01.TakeABreakQuery;
import com.techmahindra.online.svallo.model.takeabreak._2014._09._01.TakeABreakServiceStatus;
import com.techmahindra.online.svallo.service.common.exception.SvalloServiceException;
import com.techmahindra.online.svallo.service.common.exception.payment.SvalloPaymentDirectDebitIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.takeabreak.SvalloTakeABreakIntegrationException;
import com.techmahindra.online.svallo.service.payment._2014._09._01.ManagePayment;
import com.techmahindra.online.svallo.service.takeabreak._2014._09._01.TakeABreakService;

@Service("takeABreakService")
public class TakeABreakServiceImpl implements com.techm.svallo.service.takeabreak.TakeABreakService
{
	
	final static PortalLogger logger = PortalLogger.getLogger(TakeABreakServiceImpl.class);

	@Autowired
	private TakeABreakService takeABreakService;
	
	@Autowired
	private ManagePayment  managePayment;
	
	@Value("${myextras.takeabreak.check.takeabreak.error.code}")
	private String MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_CODE;
	
	@Value("${myextras.takeabreak.create.takeabreak.error.code}")
	private String MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_CODE;
	
	@Value("${myextras.takeabreak.check.takeabreak.error.message}")
	private String MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_MESSAGE;
	
	@Value("${myextras.takeabreak.create.takeabreak.error.message}")
	private String MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_MESSAGE;

	
	@Override
	public TakeABreakServiceStatusVo checkTakeABreakService(QueryAccount queryAccount)
	{
		logger.info("[selfcare-services/ TakeABreakServiceImpl | checkTakeABreakService() ]-- START");
		TakeABreakServiceStatusVo takeABreakServiceStatusVo = null;
		try
		{
			com.techmahindra.online.svallo.model.takeabreak._2014._09._01.QueryAccount queryAccount1 = new com.techmahindra.online.svallo.model.takeabreak._2014._09._01.QueryAccount();
			queryAccount1.setAccountNumber(queryAccount.getAccountNumber());
			queryAccount1.setSubscriptionNumber(queryAccount.getSubscriptionNumber());
			queryAccount1.setTariffCode(queryAccount.getTariffCode());
			TakeABreakServiceStatus takeABreakServiceStatus = takeABreakService.checkTakeABreakService(queryAccount1);
			logger.info(" [selfcare-services/ TakeABreakServiceImpl | checkTakeABreakService() ] takeABreakServiceStatus >> "+takeABreakServiceStatus);
			takeABreakServiceStatusVo  = new TakeABreakServiceStatusVo();
			if(takeABreakServiceStatus!=null)
			{
				logger.info(" [selfcare-services/ TakeABreakServiceImpl | checkTakeABreakService() ] takeABreakServiceStatus.getTabServiceStatus() >> "+takeABreakServiceStatus.getTabServiceStatus());
			}	
			takeABreakServiceStatusVo.setExternalReference(takeABreakServiceStatus.getExternalReference());
			takeABreakServiceStatusVo.setTabServiceStatus(takeABreakServiceStatus.getTabServiceStatus());
			takeABreakServiceStatusVo.setMrcServiceSum(takeABreakServiceStatus.getMrcServiceSum());
			takeABreakServiceStatusVo.setServiceCode(takeABreakServiceStatus.getServiceCode());
			takeABreakServiceStatusVo.setTakeABreakCounter(takeABreakServiceStatus.getTakeABreakCounter());
			logger.info("[selfcare-services/ TakeABreakServiceImpl | checkTakeABreakService() ]-- END");
		}
		catch (SvalloTakeABreakIntegrationException svalloTakeABreakIntegrationException)
		{
			logger.error(svalloTakeABreakIntegrationException,"[ selfcare-services/TakeABreakServiceImpl | checkTakeABreakService() ] SvalloServiceException Catch Block ");
			logger.error(svalloTakeABreakIntegrationException,"[ selfcare-services/TakeABreakServiceImpl | checkTakeABreakService() ] SvalloServiceException Catch Block | Error Code =  "+MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_CODE);
			logger.error(svalloTakeABreakIntegrationException,"[ selfcare-services/TakeABreakServiceImpl | checkTakeABreakService() ] SvalloServiceException Catch Block | Error Message  =  "+MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_MESSAGE);
			SvalloTakeABreakServiceException svalloTakeABreakServiceException = new SvalloTakeABreakServiceException();
			svalloTakeABreakServiceException.setErrorCode(MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_CODE);
			svalloTakeABreakServiceException.setErrorMessage(MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_MESSAGE);
			svalloTakeABreakServiceException.setRootCause(svalloTakeABreakIntegrationException);
			throw svalloTakeABreakServiceException;
		}
		catch (Exception exception)
		{
			logger.error(exception,"[ selfcare-services/TakeABreakServiceImpl | checkTakeABreakService() ] Exception Catch Block ");
			logger.error(exception,"[ selfcare-services/TakeABreakServiceImpl | checkTakeABreakService() ] Exception Catch Block | Error Code =  "+MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_CODE);
			logger.error(exception,"[ selfcare-services/TakeABreakServiceImpl | checkTakeABreakService() ] Exception Catch Block | Error Message  =  "+MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_MESSAGE);
			SvalloTakeABreakServiceException svalloTakeABreakServiceException = new SvalloTakeABreakServiceException();
			svalloTakeABreakServiceException.setErrorCode(MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_CODE);
			svalloTakeABreakServiceException.setErrorMessage(MYEXTRAS_TAKEABREAK_CHECK_TAKEABREAK_ERROR_MESSAGE);
			svalloTakeABreakServiceException.setRootCause(exception);
			throw svalloTakeABreakServiceException;
		}
		return takeABreakServiceStatusVo;
	}

	@Override
	public TakeABreakServiceStatusVo createTakeABreakService(TakeABreakQueryVo takeABreakQueryVo,SubscriptionInfoVo subscriptionInfoVo)
	{
		logger.info("[selfcare-services/ TakeABreakServiceImpl | createTakeABreakService() ]-- START");
		TakeABreakServiceStatusVo takeABreakServiceStatusVo=null;
		try
		{
			TakeABreakQuery takeABreakQuery = new TakeABreakQuery();
			takeABreakQuery.setAttributeGroupId(takeABreakQueryVo.getAttributeGroupId());
			takeABreakQuery.setDate(takeABreakQueryVo.getDate());
			takeABreakQuery.setServiceCode(takeABreakQueryVo.getServiceCode());
			takeABreakQuery.setSubscriptionNumber(takeABreakQueryVo.getSubscriptionNumber());
			takeABreakQuery.setTotalPrice(takeABreakQueryVo.getTotalPrice());
			takeABreakQuery.setTakeABreakCounter(takeABreakQueryVo.getTakeABreakCounter());
			
			SubscriptionInfo subscriptionInfo = new SubscriptionInfo();
			subscriptionInfo.setDate(subscriptionInfoVo.getDate());
			subscriptionInfo.setSubscriptionNumber(subscriptionInfoVo.getSubscriptionNumber());
			
			TakeABreakServiceStatus takeABreakServiceStatus = takeABreakService.createTakeABreakService(takeABreakQuery,subscriptionInfo);
			logger.info(" [selfcare-services/ TakeABreakServiceImpl | checkTakeABreakService() ] takeABreakServiceStatus >> "+takeABreakServiceStatus);
			takeABreakServiceStatusVo  = new TakeABreakServiceStatusVo();
			takeABreakServiceStatusVo.setExternalReference(takeABreakServiceStatus.getExternalReference());
			if(takeABreakServiceStatus!=null)
			{
				logger.info(" [selfcare-services/ TakeABreakServiceImpl | createTakeABreakService() ] takeABreakServiceStatus.getExternalReference() >> "+takeABreakServiceStatus.getExternalReference());
			}
			logger.info("[selfcare-services/ TakeABreakServiceImpl | createTakeABreakService() ]-- END");
		}
		catch (SvalloTakeABreakIntegrationException svalloTakeABreakIntegrationException)
		{
			logger.error(svalloTakeABreakIntegrationException,"[ selfcare-services/TakeABreakServiceImpl | createTakeABreakService() ] SvalloServiceException Catch Block ");
			logger.error(svalloTakeABreakIntegrationException,"[ selfcare-services/TakeABreakServiceImpl | createTakeABreakService() ] SvalloServiceException Catch Block | Error Code =  "+MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_CODE);
			logger.error(svalloTakeABreakIntegrationException,"[ selfcare-services/TakeABreakServiceImpl | createTakeABreakService() ] SvalloServiceException Catch Block | Error Message  =  "+MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_MESSAGE);
			SvalloTakeABreakServiceException svalloTakeABreakServiceException = new SvalloTakeABreakServiceException();
			svalloTakeABreakServiceException.setErrorCode(MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_CODE);
			svalloTakeABreakServiceException.setErrorMessage(MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_MESSAGE);
			svalloTakeABreakServiceException.setRootCause(svalloTakeABreakIntegrationException);
			throw svalloTakeABreakServiceException;
		}
		catch (Exception exception)
		{
			logger.error(exception,"[ selfcare-services/TakeABreakServiceImpl | createTakeABreakService() ] Exception Catch Block ");
			logger.error(exception,"[ selfcare-services/TakeABreakServiceImpl | createTakeABreakService() ] Exception Catch Block | Error Code =  "+MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_CODE);
			logger.error(exception,"[ selfcare-services/TakeABreakServiceImpl | createTakeABreakService() ] Exception Catch Block | Error Message  =  "+MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_MESSAGE);
			SvalloTakeABreakServiceException svalloTakeABreakServiceException = new SvalloTakeABreakServiceException();
			svalloTakeABreakServiceException.setErrorCode(MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_CODE);
			svalloTakeABreakServiceException.setErrorMessage(MYEXTRAS_TAKEABREAK_CREATE_TAKEABREAK_ERROR_MESSAGE);
			svalloTakeABreakServiceException.setRootCause(exception);
			throw svalloTakeABreakServiceException;
		}
		return takeABreakServiceStatusVo;
	}
	
}

package com.techm.svallo.exception.service.aio;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloSendSecurityPinServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

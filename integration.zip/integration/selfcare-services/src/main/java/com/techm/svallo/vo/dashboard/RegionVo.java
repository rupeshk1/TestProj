package com.techm.svallo.vo.dashboard;

public class RegionVo {

   
    private UsageVo available;

    private UsageVo used;

   
    public UsageVo getAvailable() {
        return available;
    }

    
    public void setAvailable(UsageVo value) {
        this.available = value;
    }

   
    public UsageVo getUsed() {
        return used;
    }

    public void setUsed(UsageVo value) {
        this.used = value;
    }

}

package com.techm.svallo.service.addressval;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.vo.searchAddress.SearchAddressVo;
import com.techmahindra.online.svallo.service.addressval._2014._12._09.AddressValService;
import com.techmahindra.online.svallo.model.addressval._2014._12._09.AddressValidateRequest;
import com.techmahindra.online.svallo.model.addressval._2014._12._09.AddressValidateResponse;
import com.techmahindra.online.svallo.model.addressval._2014._12._09.AddressDetail;
import com.techmahindra.online.svallo.model.addressval._2014._12._09.ReplyStatus;
import com.techmahindra.online.svallo.service.common.exception.addressval.SvalloSearchPostalAddressIntegrationException;
import com.techm.svallo.exception.service.searchaddress.SvalloSearchPostalAddressServiceException;




public class AddressValSelfcareServiceImpl implements AddressValSelfcareService
{
	final static PortalLogger logger = PortalLogger.getLogger(AddressValSelfcareServiceImpl.class);
	
	@Autowired
	private AddressValService addressValService;
	
	@Value("${addressval.searchPostalAddress.error}")
	private String ADDRESSVAL_SEARCH_POSTAL_ADDRESS_ERROR;
	
	@Value("${addressval.service.searchPostalAddress.error.code}")
	private String ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_ERROR_CODE;
	
	@Value("${addressval.service.searchPostalAddress.error.message}")
	private String ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_ERROR_MESSAGE;
	
	@Value("${addressval.service.searchPostalAddress.exception.code}")
	private String ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_EXCEPTION_CODE;
	
	@Value("${addressval.service.searchPostalAddress.exception.message}")
	private String ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_EXCEPTION_MESSAGE;
	
	public List<SearchAddressVo> validateAddress(String adressLine1,String adressLine2,String postCode,String adressLine4,String country) throws SvalloSearchPostalAddressServiceException {
		
		AddressValidateRequest addressValidateRequest = new AddressValidateRequest();
		
		addressValidateRequest.setAddressLine1(adressLine1);
		addressValidateRequest.setAddressLine2(adressLine2);
		addressValidateRequest.setCountry(country);
		addressValidateRequest.setPostalCode(postCode);
		addressValidateRequest.setTown(adressLine4);
		
		List<SearchAddressVo> searchAddress = new ArrayList<SearchAddressVo>(); 
		SearchAddressVo  searchAddressVo = new SearchAddressVo();
			
		try 
		{ 
			AddressValidateResponse addressValidateResponse = addressValService.validateAddress(addressValidateRequest);
			List<AddressDetail> addressList = addressValidateResponse.getAddressList();
			List<ReplyStatus> replyStatus = addressValidateResponse.getReplyStatus();
			
			if(addressList!=null && addressList.size()>0)
			{ 
				for (int i = 0; i < addressList.size(); i++)
				{
					AddressDetail addressDetail = addressList.get(i);
					SearchAddressVo  singleSearchAddressVo = new SearchAddressVo();
					mapSearchAddressVo(addressDetail, singleSearchAddressVo);
					searchAddress.add(singleSearchAddressVo);
					
				}
			}else if(replyStatus!=null && replyStatus.size()>0){
			
				searchAddressVo.setStatus(replyStatus.get(0).getStatus());
				searchAddressVo.setComponent(replyStatus.get(0).getComponent());
				searchAddressVo.setService(replyStatus.get(0).getService());
				searchAddressVo.setCode(replyStatus.get(0).getCode());
				searchAddressVo.setMessage(replyStatus.get(0).getMessage());
				searchAddressVo.setRecoverable(replyStatus.get(0).getRecoverable());
				searchAddressVo.setCategory(replyStatus.get(0).getCategory());
				searchAddressVo.setOriginator(replyStatus.get(0).getOriginator());
				searchAddressVo.setOriginatorCode(replyStatus.get(0).getOriginatorCode());
				searchAddressVo.setOriginatorMessage(replyStatus.get(0).getOriginatorMessage());
				searchAddress.add(searchAddressVo);
			
			}else{
				searchAddress.add(searchAddressVo);
			}
		}
		catch(SvalloSearchPostalAddressIntegrationException svalloSearchPostalAddressIntegrationException)
		{
			//Replace System.out with Logger Statement
		//Error Code and Error Message in this(SvalloServiceException) block will be according to your business			
		logger.error(svalloSearchPostalAddressIntegrationException,"\n[ AddressValSelfcareServiceImpl | searchPostalAddress() ] SvalloServiceException Catch Block ");
		logger.error(svalloSearchPostalAddressIntegrationException,"\n[ AddressValSelfcareServiceImpl | searchPostalAddress() ] SvalloServiceException Catch Block | Error Code =  "+ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_ERROR_CODE);
		logger.error(svalloSearchPostalAddressIntegrationException,"\n[ AddressValSelfcareServiceImpl | searchPostalAddress() ] SvalloServiceException Catch Block | Error Message  =  "+ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_ERROR_MESSAGE);
		SvalloSearchPostalAddressServiceException svalloSearchPostalAddressServiceException = new SvalloSearchPostalAddressServiceException();
		svalloSearchPostalAddressServiceException.setErrorCode(ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_ERROR_CODE);
		svalloSearchPostalAddressServiceException.setErrorMessage(ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_ERROR_MESSAGE);
		svalloSearchPostalAddressServiceException.setRootCause(svalloSearchPostalAddressIntegrationException);
		searchAddressVo.setErrorMessage(ADDRESSVAL_SEARCH_POSTAL_ADDRESS_ERROR);
		searchAddress.add(searchAddressVo);
		throw svalloSearchPostalAddressServiceException;
		}
		catch(Exception exception)
		{
			//Replace System.out with Logger Statement
		//Error Code and Error Message in this(SvalloServiceException) block will be according to your business			
		logger.error(exception,"\n[ AddressValSelfcareServiceImpl | searchPostalAddress() ] Exception Catch Block ");
		logger.error(exception,"\n[ AddressValSelfcareServiceImpl | searchPostalAddress() ] Exception Catch Block | Error Code =  "+ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_EXCEPTION_CODE);
		logger.error(exception,"\n[ AddressValSelfcareServiceImpl | searchPostalAddress() ] Exception Catch Block | Error Message  =  "+ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_EXCEPTION_MESSAGE);
		SvalloSearchPostalAddressServiceException svalloSearchPostalAddressServiceException = new SvalloSearchPostalAddressServiceException();
		svalloSearchPostalAddressServiceException.setErrorCode(ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_EXCEPTION_CODE);
		svalloSearchPostalAddressServiceException.setErrorMessage(ADDRESSVAL_SERVICE_SEARCH_POSTAL_ADDRESS_EXCEPTION_MESSAGE);
		svalloSearchPostalAddressServiceException.setRootCause(exception);
		throw svalloSearchPostalAddressServiceException;
		}
		
		return searchAddress;
		
	}
	
	private void mapSearchAddressVo(AddressDetail addressDetail, SearchAddressVo searchAddressVo)
	{
		if(addressDetail!=null && searchAddressVo!=null)
		{	
			
			searchAddressVo.setBuildingName(addressDetail.getBuildingName());
			searchAddressVo.setBuildingNumber(addressDetail.getBuildingNumber());
			searchAddressVo.setCountry(addressDetail.getCountry());
			searchAddressVo.setCounty(addressDetail.getCounty());
			searchAddressVo.setDependentThoroughfare(addressDetail.getDependentThoroughfare());
			searchAddressVo.setLocality(addressDetail.getLocality());
			searchAddressVo.setPostcode(addressDetail.getPostcode());
			searchAddressVo.setSubBuildingName(addressDetail.getSubBuildingName());
			searchAddressVo.setThreeCharacterISOCountryCode(addressDetail.getThreeCharacterISOCountryCode());
			searchAddressVo.setTown(addressDetail.getTown());
			searchAddressVo.setThoroughfare(addressDetail.getThoroughfare());
			
		}	
	}
}
package com.techm.svallo.vo.myprofile;

public class PersonalDetailsVo
{
	private String name;
	private String mahindraTelecomNumber;
	private String residentialAddress;
	private String pin;
	private String alternateContactNumber;
	private String emailId;
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getMahindraTelecomNumber()
	{
		return mahindraTelecomNumber;
	}
	public void setMahindraTelecomNumber(String mahindraTelecomNumber)
	{
		this.mahindraTelecomNumber = mahindraTelecomNumber;
	}
	public String getResidentialAddress()
	{
		return residentialAddress;
	}
	public void setResidentialAddress(String residentialAddress)
	{
		this.residentialAddress = residentialAddress;
	}
	public String getPin()
	{
		return pin;
	}
	public void setPin(String pin)
	{
		this.pin = pin;
	}
	public String getAlternateContactNumber()
	{
		return alternateContactNumber;
	}
	public void setAlternateContactNumber(String alternateContactNumber)
	{
		this.alternateContactNumber = alternateContactNumber;
	}
	public String getEmailId()
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	
}

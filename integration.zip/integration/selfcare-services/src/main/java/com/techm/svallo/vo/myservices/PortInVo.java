package com.techm.svallo.vo.myservices;

public class PortInVo
{
	
 private String pacCode;
 private String portDate;
 private String numberToPort;
 private String portInMessage;
 private String subScriptionNumber;
 private String accountNumber;
 private String portedDate;
	
 public String getSubScriptionNumber() {
	return subScriptionNumber;
}
public void setSubScriptionNumber(String subScriptionNumber) {
	this.subScriptionNumber = subScriptionNumber;
}
public String getPortInMessage() {
	return portInMessage;
}
public void setPortInMessage(String portInMessage) {
	this.portInMessage = portInMessage;
}
public String getPacCode() {
		return pacCode;
	}
	public void setPacCode(String pacCode) {
		this.pacCode = pacCode;
	}
	public String getPortDate() {
		return portDate;
	}
	public void setPortDate(String portDate) {
		this.portDate = portDate;
	}
	public String getNumberToPort() {
		return numberToPort;
	}
	public void setNumberToPort(String numberToPort) {
		this.numberToPort = numberToPort;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getPortedDate() {
		return portedDate;
	}
	public void setPortedDate(String portedDate) {
		this.portedDate = portedDate;
	}
  
}

package com.techm.svallo.exception.integration.payment;

import com.techm.svallo.exception.integration.SvalloIntegrationException;

public class SvalloPaymentDirectDebitIntegrationException extends SvalloIntegrationException
{
	private static final long serialVersionUID = 1L;
}

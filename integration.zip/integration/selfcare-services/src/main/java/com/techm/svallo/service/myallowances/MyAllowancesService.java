package com.techm.svallo.service.myallowances;

import com.techm.svallo.vo.dashboard.DashboardInfoVo;
import com.techm.svallo.vo.subscriptioncap.SubscriptionCapVo;

public interface MyAllowancesService
{	
	public DashboardInfoVo getMyAllowancesSum(String subscriptionNumber);
	public SubscriptionCapVo getSubscriptionCap(String subscriptionNumber);
	public SubscriptionCapVo updateSubscriptionCap(SubscriptionCapVo subscriptionCapVo);
}

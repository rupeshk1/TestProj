package com.techm.svallo.service.forgotusernamepassword;

import com.techm.svallo.vo.forgotusernamepassword.ForgotUsernamePasswordVo;

public interface ForgotUsernamePasswordService
{
	public ForgotUsernamePasswordVo getUsernameAccountDetails(ForgotUsernamePasswordVo forgotUsernamePasswordVo);
	public ForgotUsernamePasswordVo getUsernamePinDetails(ForgotUsernamePasswordVo forgotUsernamePasswordVo);
	public String getUsernameFromDB(ForgotUsernamePasswordVo forgotUsernamePasswordVo);
	public  String getAccountNumberFromUserID(long userId);
	public String getUsernameExits(ForgotUsernamePasswordVo forgotUsernamePasswordVo);
	public ForgotUsernamePasswordVo getPasswordAccountDetails(ForgotUsernamePasswordVo forgotUsernamePasswordVo);
	public ForgotUsernamePasswordVo getPasswordPinDetails(ForgotUsernamePasswordVo forgotUsernamePasswordVo);
	public void updatePasswordDetails(long userId);
	public String getScreenName(String accountNumber);
}


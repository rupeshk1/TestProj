package com.techm.svallo.vo.dashboard;

public class DashboardInfoVo
{
	private String accountNumber;
	private String accountName;
	private String amountOverdue;
	private String outstandingBillAmount;
	private String billDate;
	private String unbilledAmount;
	private String domesticCallPrice;
	private String internationalCallPrice;
	private String roamedCallPrice;
	private String planName;
	private String contractUpgradeDate;
	private AllowancesVo allowances;
	private AllowancesVo extraAllowances;
	private AllowancesVo inclusiveAllowances;
	private AllowancesVo rolloverAllowances;
	private AllowancesVo recurringAllowances;
	
	private String screenName;
	private String boltonCount;
	private String lengthOfContract;
	private String tariff;
	
	private String contractRenewalDate;
	private String contractStartDate;
	private String firstInvoiceDate;
	private String lastInvoiceDate;
    private String nextInvoiceDate;
    
    private String mobileNumber;
    private String noOfDays;    
    private int    monthMaxDays;
    private String noOffMonths;
    private String noOffMonthsAIO;
       
	private String noOffDaysDiff;
    
	private String firstName;
    private String donutRecordFound;
    private String donutExceptionPresent;
    private String billingRecordFound;
    private String billingExceptionPresent;
    private String mycontractRecordFound;
    private String mycontractExceptionPresent;
    private String networkCode;    
    private String nanIssue;
	private String billingType;
	private String terminationInvoiceProduced;
	private String currentMrcSum;
    private String futureMrcSum;
    private String discountedCurrentMrcSum;
    private String discountedFutureMrcSum;
    private String boltonsSum;
    private String connectedDate;
    private String nonManagedSerialNumberValue;
    private String dataRolloverEligible;
    private String minsRolloverEligible;
    private String textsRolloverEligible;
    private String middleName;
    private String myAccountContractRenewalDate;
	private String myAccountContractStartDate;
	private String topupCredit;
	private String sumOfAllReloads;
	
	private String  proposition;
	private String sumOfActiveOneoffBoltOns;	
	private String  aioPlanStartDate;
	private String  aioPlanEndDate;
	private String noOffDaysAIO;
	
	
	public String getSumOfActiveOneoffBoltOns() {
		return sumOfActiveOneoffBoltOns;
	}
	public void setSumOfActiveOneoffBoltOns(String sumOfActiveOneoffBoltOns) {
		this.sumOfActiveOneoffBoltOns = sumOfActiveOneoffBoltOns;
	}
	/* Added for phase2 AIO user login */
	 public String getProposition()
	{
		return proposition;
	}
	public void setProposition(String proposition)
	{
		this.proposition = proposition;
	}
	/* Added for phase2 user remove bolton */
    private String unformattedNextInvoiceDate;
	private String unformattedLastInvoiceDate;

	
	public String getSumOfAllReloads()
	{
		return sumOfAllReloads;
	}
	public void setSumOfAllReloads(String sumOfAllReloads)
	{
		this.sumOfAllReloads = sumOfAllReloads;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getDataRolloverEligible() {
		return dataRolloverEligible;
	}
	public void setDataRolloverEligible(String dataRolloverEligible) {
		this.dataRolloverEligible = dataRolloverEligible;
	}
	public String getMinsRolloverEligible() {
		return minsRolloverEligible;
	}
	public void setMinsRolloverEligible(String minsRolloverEligible) {
		this.minsRolloverEligible = minsRolloverEligible;
	}
	public String getTextsRolloverEligible() {
		return textsRolloverEligible;
	}
	public void setTextsRolloverEligible(String textsRolloverEligible) {
		this.textsRolloverEligible = textsRolloverEligible;
	}
	public String getConnectedDate() {
		return connectedDate;
	}
	public void setConnectedDate(String connectedDate) {
		this.connectedDate = connectedDate;
	}
	public String getNonManagedSerialNumberValue()
	{
		return nonManagedSerialNumberValue;
	}
	public void setNonManagedSerialNumberValue(String nonManagedSerialNumberValue)
	{
		this.nonManagedSerialNumberValue = nonManagedSerialNumberValue;
	}
	public String getCurrentMrcSum() {
		return currentMrcSum;
	}
	public void setCurrentMrcSum(String currentMrcSum) {
		this.currentMrcSum = currentMrcSum;
	}
	public String getFutureMrcSum() {
		return futureMrcSum;
	}
	public void setFutureMrcSum(String futureMrcSum) {
		this.futureMrcSum = futureMrcSum;
	}
	public String getDiscountedCurrentMrcSum() {
		return discountedCurrentMrcSum;
	}
	public void setDiscountedCurrentMrcSum(String discountedCurrentMrcSum) {
		this.discountedCurrentMrcSum = discountedCurrentMrcSum;
	}
	public String getDiscountedFutureMrcSum() {
		return discountedFutureMrcSum;
	}
	public void setDiscountedFutureMrcSum(String discountedFutureMrcSum) {
		this.discountedFutureMrcSum = discountedFutureMrcSum;
	}
	public String getBoltonsSum() {
		return boltonsSum;
	}
	public void setBoltonsSum(String boltonsSum) {
		this.boltonsSum = boltonsSum;
	}
	public String getNanIssue() {
		return nanIssue;
	}
	public void setNanIssue(String nanIssue) {
		this.nanIssue = nanIssue;
	}
	public AllowancesVo getRecurringAllowances() {
		return recurringAllowances;
	}
	public void setRecurringAllowances(AllowancesVo recurringAllowances) {
		this.recurringAllowances = recurringAllowances;
	}
	public AllowancesVo getRolloverAllowances() {
		return rolloverAllowances;
	}
	public void setRolloverAllowances(AllowancesVo rolloverAllowances) {
		this.rolloverAllowances = rolloverAllowances;
	}
	public String getNetworkCode() {
		return networkCode;
	}
	public void setNetworkCode(String networkCode) {
		this.networkCode = networkCode;
	}
	public String getDonutRecordFound() {
		return donutRecordFound;
	}
	public void setDonutRecordFound(String donutRecordFound) {
		this.donutRecordFound = donutRecordFound;
	}
	public String getDonutExceptionPresent() {
		return donutExceptionPresent;
	}
	public void setDonutExceptionPresent(String donutExceptionPresent) {
		this.donutExceptionPresent = donutExceptionPresent;
	}
	public String getBillingRecordFound() {
		return billingRecordFound;
	}
	public void setBillingRecordFound(String billingRecordFound) {
		this.billingRecordFound = billingRecordFound;
	}
	public String getBillingExceptionPresent() {
		return billingExceptionPresent;
	}
	public void setBillingExceptionPresent(String billingExceptionPresent) {
		this.billingExceptionPresent = billingExceptionPresent;
	}
	public String getMycontractRecordFound() {
		return mycontractRecordFound;
	}
	public void setMycontractRecordFound(String mycontractRecordFound) {
		this.mycontractRecordFound = mycontractRecordFound;
	}
	public String getMycontractExceptionPresent() {
		return mycontractExceptionPresent;
	}
	public void setMycontractExceptionPresent(String mycontractExceptionPresent) {
		this.mycontractExceptionPresent = mycontractExceptionPresent;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public int getMonthMaxDays() {
		return monthMaxDays;
	}
	public void setMonthMaxDays(int monthMaxDays) {
		this.monthMaxDays = monthMaxDays;
	}	
	public String getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getContractRenewalDate() {
		return contractRenewalDate;
	}
	public void setContractRenewalDate(String contractRenewalDate) {
		this.contractRenewalDate = contractRenewalDate;
	}
	

	public String getContractStartDate() {
		return contractStartDate;
	}
	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;
	}
	
	
	public String getFirstInvoiceDate() {
		return firstInvoiceDate;
	}
	public void setFirstInvoiceDate(String firstInvoiceDate) {
		this.firstInvoiceDate = firstInvoiceDate;
	}
	
	

	public String getNextInvoiceDate() {
		return nextInvoiceDate;
	}
	public void setNextInvoiceDate(String nextInvoiceDate) {
		this.nextInvoiceDate = nextInvoiceDate;
	}
	
	

	public String getLastInvoiceDate() {
		return lastInvoiceDate;
	}
	public void setLastInvoiceDate(String lastInvoiceDate) {
		this.lastInvoiceDate = lastInvoiceDate;
	}
	
	public String getLengthOfContract() {
		return lengthOfContract;
	}
	public void setLengthOfContract(String lengthOfContract) {
		this.lengthOfContract = lengthOfContract;
	}
	public String getTariff() {
		return tariff;
	}
	public void setTariff(String tariff) {
		this.tariff = tariff;
	}
	public String getBoltonCount() {
		return boltonCount;
	}
	public void setBoltonCount(String boltonCount) {
		this.boltonCount = boltonCount;
	}
	
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAmountOverdue() {
		return amountOverdue;
	}
	public void setAmountOverdue(String amountOverdue) {
		this.amountOverdue = amountOverdue;
	}
	public String getOutstandingBillAmount() {
		return outstandingBillAmount;
	}
	public void setOutstandingBillAmount(String outstandingBillAmount) {
		this.outstandingBillAmount = outstandingBillAmount;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	public String getUnbilledAmount() {
		return unbilledAmount;
	}
	public void setUnbilledAmount(String unbilledAmount) {
		this.unbilledAmount = unbilledAmount;
	}
	
	public String getDomesticCallPrice() {
		return domesticCallPrice;
	}
	public void setDomesticCallPrice(String domesticCallPrice) {
		this.domesticCallPrice = domesticCallPrice;
	}
	
	public String getInternationalCallPrice() {
		return internationalCallPrice;
	}
	public void setInternationalCallPrice(String internationalCallPrice) {
		this.internationalCallPrice = internationalCallPrice;
	}
	
	public String getRoamedCallPrice() {
		return roamedCallPrice;
	}
	public void setRoamedCallPrice(String roamedCallPrice) {
		this.roamedCallPrice = roamedCallPrice;
	}
	
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
	public String getContractUpgradeDate() {
		return contractUpgradeDate;
	}
	public void setContractUpgradeDate(String contractUpgradeDate) {
		this.contractUpgradeDate = contractUpgradeDate;
	}
	
	
	public AllowancesVo getAllowances() {
		return allowances;
	}
	public void setAllowances(AllowancesVo allowances) {
		this.allowances = allowances;
	}
	
	public AllowancesVo getExtraAllowances() {
		return extraAllowances;
	}
	public void setExtraAllowances(AllowancesVo extraAllowances) {
		this.extraAllowances = extraAllowances;
	}
	
	public AllowancesVo getInclusiveAllowances() {
		return inclusiveAllowances;
	}
	public void setInclusiveAllowances(AllowancesVo inclusiveAllowances) {
		this.inclusiveAllowances = inclusiveAllowances;
	}
	
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
      	
	public String getTerminationInvoiceProduced() {
		return terminationInvoiceProduced;
	}
	public void setTerminationInvoiceProduced(String terminationInvoiceProduced) {
		this.terminationInvoiceProduced = terminationInvoiceProduced;
	}

	public String getMyAccountContractRenewalDate() {
		return myAccountContractRenewalDate;
	}
	public void setMyAccountContractRenewalDate(String myAccountContractRenewalDate) {
		this.myAccountContractRenewalDate = myAccountContractRenewalDate;
	}
	public String getMyAccountContractStartDate() {
		return myAccountContractStartDate;
	}
	public void setMyAccountContractStartDate(String myAccountContractStartDate) {
		this.myAccountContractStartDate = myAccountContractStartDate;
	}

	public String getTopupCredit() {
		return topupCredit;
	}
	public void setTopupCredit(String topupCredit) {
		this.topupCredit = topupCredit;
	}
	
	public String getUnformattedNextInvoiceDate() {
		return unformattedNextInvoiceDate;
	}
	public void setUnformattedNextInvoiceDate(String unformattedNextInvoiceDate) {
		this.unformattedNextInvoiceDate = unformattedNextInvoiceDate;
	}
		
		
	public String getUnformattedLastInvoiceDate() {
		return unformattedLastInvoiceDate;
	}
	public void setUnformattedLastInvoiceDate(String unformattedLastInvoiceDate) {
		this.unformattedLastInvoiceDate = unformattedLastInvoiceDate;
	}
			
	public String getNoOffMonths()
	{
		return noOffMonths;
	}
	public void setNoOffMonths(String noOffMonths)
	{
		this.noOffMonths = noOffMonths;
	}

	public String getNoOffDaysDiff()
	{
		return noOffDaysDiff;
	}
	public void setNoOffDaysDiff(String noOffDaysDiff)
	{
		this.noOffDaysDiff = noOffDaysDiff;
	}
	
	public String getAioPlanStartDate()
	{
		return aioPlanStartDate;
	}
	public void setAioPlanStartDate(String aioPlanStartDate)
	{
		this.aioPlanStartDate = aioPlanStartDate;
	}
	public String getAioPlanEndDate()
	{
		return aioPlanEndDate;
	}
	public void setAioPlanEndDate(String aioPlanEndDate)
	{
		this.aioPlanEndDate = aioPlanEndDate;
	}
	
	public String getNoOffMonthsAIO()
	{
		return noOffMonthsAIO;
	}
	public void setNoOffMonthsAIO(String noOffMonthsAIO)
	{
		this.noOffMonthsAIO = noOffMonthsAIO;
	}
	public String getNoOffDaysAIO() {
		return noOffDaysAIO;
	}
	public void setNoOffDaysAIO(String noOffDaysAIO) {
		this.noOffDaysAIO = noOffDaysAIO;
	}

	
}


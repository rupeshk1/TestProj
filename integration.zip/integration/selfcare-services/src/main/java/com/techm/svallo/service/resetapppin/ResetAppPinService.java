package com.techm.svallo.service.resetapppin;


public interface ResetAppPinService
{
	public boolean savePin(String accountNumber, String pin);
}

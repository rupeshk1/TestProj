package com.techm.svallo.vo.billingandpayment;

import com.techm.svallo.vo.topups.HistoryListVo;


public class MyCurrentMonthBillVo
{
	private String currentMonthTarrif;
	private String currentMonthDueOn;
	private String myCurrentBillExceptionPresent="false";
	private String bankaccountNumber;
	private String currentMonth;
	private String unbilledAmount=null;
	private String currentMonthEstimatedBill;
	private String currentMonthExtraCharges;
	private String nextInvoiceDate;
	private String accountNumber="";
	private String currentMonthTopUpAndAddOnTotalAmount="";
    private HistoryListVo historyListVo = null;
    private String totalOfActiveAddons="";
    private String myAccountContractStartDate="";
    
    
	public String getCurrentMonthTarrif()
	{
		return currentMonthTarrif;
	}
	public void setCurrentMonthTarrif(String currentMonthTarrif)
	{
		this.currentMonthTarrif = currentMonthTarrif;
	}
	public String getCurrentMonthDueOn()
	{
		return currentMonthDueOn;
	}
	public void setCurrentMonthDueOn(String currentMonthDueOn)
	{
		this.currentMonthDueOn = currentMonthDueOn;
	}
	public String getMyCurrentBillExceptionPresent()
	{
		return myCurrentBillExceptionPresent;
	}
	public void setMyCurrentBillExceptionPresent(String myCurrentBillExceptionPresent)
	{
		this.myCurrentBillExceptionPresent = myCurrentBillExceptionPresent;
	}
	public String getBankaccountNumber()
	{
		return bankaccountNumber;
	}
	public void setBankaccountNumber(String bankaccountNumber)
	{
		this.bankaccountNumber = bankaccountNumber;
	}
	public String getCurrentMonth()
	{
		return currentMonth;
	}
	public void setCurrentMonth(String currentMonth)
	{
		this.currentMonth = currentMonth;
	}
	public String getUnbilledAmount()
	{
		return unbilledAmount;
	}
	public void setUnbilledAmount(String unbilledAmount)
	{
		this.unbilledAmount = unbilledAmount;
	}
	public String getCurrentMonthEstimatedBill()
	{
		return currentMonthEstimatedBill;
	}
	public void setCurrentMonthEstimatedBill(String currentMonthEstimatedBill)
	{
		this.currentMonthEstimatedBill = currentMonthEstimatedBill;
	}
	public String getCurrentMonthExtraCharges()
	{
		return currentMonthExtraCharges;
	}
	public void setCurrentMonthExtraCharges(String currentMonthExtraCharges)
	{
		this.currentMonthExtraCharges = currentMonthExtraCharges;
	}
	public String getNextInvoiceDate()
	{
		return nextInvoiceDate;
	}
	public void setNextInvoiceDate(String nextInvoiceDate)
	{
		this.nextInvoiceDate = nextInvoiceDate;
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getCurrentMonthTopUpAndAddOnTotalAmount()
	{
		return currentMonthTopUpAndAddOnTotalAmount;
	}
	public void setCurrentMonthTopUpAndAddOnTotalAmount(String currentMonthTopUpAndAddOnTotalAmount)
	{
		this.currentMonthTopUpAndAddOnTotalAmount = currentMonthTopUpAndAddOnTotalAmount;
	}
	public HistoryListVo getHistoryListVo()
	{
		return historyListVo;
	}
	public void setHistoryListVo(HistoryListVo historyListVo)
	{
		this.historyListVo = historyListVo;
	}
	public String getTotalOfActiveAddons()
	{
		return totalOfActiveAddons;
	}
	public void setTotalOfActiveAddons(String totalOfActiveAddons)
	{
		this.totalOfActiveAddons = totalOfActiveAddons;
	}
	public String getMyAccountContractStartDate()
	{
		return myAccountContractStartDate;
	}
	public void setMyAccountContractStartDate(String myAccountContractStartDate)
	{
		this.myAccountContractStartDate = myAccountContractStartDate;
	}
	
}

package com.techm.svallo.service.payment;

import java.util.List;

import com.techm.svallo.vo.billingandpayment.PaymentNBillingVo;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;


public interface PaymentHistoryService
{
	public List<PaymentNBillingVo> getPaymentHistory(QueryAccount queryAccount);
}

package com.techm.svallo.vo.plansAndServices;

import java.io.Serializable;

public class PlanVo implements Serializable
{
	
	private static final long serialVersionUID = 5856795914423544920L;
	
	private String planId="";
	private String planName="";
	private String planDescription="";
	private int planQuantity=0;
	float planCharges=0.0F;
	private String planImagePath="";
	
	
	public String getPlanId()
	{
		return planId;
	}
	public void setPlanId(String planId)
	{
		this.planId = planId;
	}
	public String getPlanName()
	{
		return planName;
	}
	public void setPlanName(String planName)
	{
		this.planName = planName;
	}
	public String getPlanDescription()
	{
		return planDescription;
	}
	public void setPlanDescription(String planDescription)
	{
		this.planDescription = planDescription;
	}
	public int getPlanQuantity()
	{
		return planQuantity;
	}
	public void setPlanQuantity(int planQuantity)
	{
		this.planQuantity = planQuantity;
	}
	public float getPlanCharges()
	{
		return planCharges;
	}
	public void setPlanCharges(float planCharges)
	{
		this.planCharges = planCharges;
	}
	public String getPlanImagePath()
	{
		return planImagePath;
	}
	public void setPlanImagePath(String planImagePath)
	{
		this.planImagePath = planImagePath;
	}
	
	
	
	
}

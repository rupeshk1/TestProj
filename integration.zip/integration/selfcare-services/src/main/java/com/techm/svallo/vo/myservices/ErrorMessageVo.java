package com.techm.svallo.vo.myservices;

public class ErrorMessageVo
{
	
 private int isSuccessful; //1 if successful and 0 if unsuccessful
 private String message="";
 private String operation="";
 private String serviceName="";
 private String errorAddonType="";
 private String serviceCode="";
	
	public int getIsSuccessful() {
		return isSuccessful;
	}
	public void setIsSuccessful(int isSuccessful) {
		this.isSuccessful = isSuccessful;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getErrorAddonType() {
		return errorAddonType;
	}
	public void setErrorAddonType(String errorAddonType) {
		this.errorAddonType = errorAddonType;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
}

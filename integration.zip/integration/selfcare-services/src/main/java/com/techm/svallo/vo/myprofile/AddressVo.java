package com.techm.svallo.vo.myprofile;

public class AddressVo
{

}

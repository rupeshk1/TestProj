package com.techm.svallo.vo.takeabreak;

public class SubscriptionInfoVo
{
	private String subscriptionNumber;
	private String date;
	
	public String getSubscriptionNumber()
	{
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber)
	{
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date = date;
	}
	
}

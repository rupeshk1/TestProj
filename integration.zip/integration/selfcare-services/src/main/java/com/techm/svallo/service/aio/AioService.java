package com.techm.svallo.service.aio;

import com.techmahindra.online.svallo.model.aio._2015._09._18.SubscriptionDetail;
import com.techmahindra.online.svallo.model.aio._2015._09._18.QueryAccount;
import com.techmahindra.online.svallo.model.aio._2015._09._18.PinStatus;


import com.techm.svallo.vo.aio.QueryAccountVo;
import com.techm.svallo.vo.aio.SubscriptionDetailVo;


public interface AioService
{
	public SubscriptionDetailVo getSubscription(QueryAccountVo queryAccountVo);
	public SubscriptionDetailVo updateAddressAccountSubscriptionlevel(QueryAccountVo queryAccountVo);
	public SubscriptionDetailVo activateSim(QueryAccountVo queryAccountVo);
	
}


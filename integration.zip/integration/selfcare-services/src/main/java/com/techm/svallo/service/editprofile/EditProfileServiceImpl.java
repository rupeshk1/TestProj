package com.techm.svallo.service.editprofile;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ArrayList;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.dao.DataAccessException;
import com.techm.svallo.util.SelfCareUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

import com.techm.svallo.vo.editprofile.ReasonCodeListVo;
import com.techm.svallo.vo.editprofile.IsEligibleForUpgradeVo;
import com.techm.svallo.vo.editprofile.MyCommunicationPreferencesVo;
import com.techmahindra.online.svallo.service.myprofile._2014._09._29.MyProfileService;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.AddressUpdateRequest;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.AddressUpdateResponse;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.EmailAddrUpdateRequest;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.EmailAddrUpdateResponse;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.Address;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.NameValuePair;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.PasswordUpdateResponse;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.PasswordUpdateRequest;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.QueryCommunicationPreferencesRequest;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.QueryCommunicationPreferencesResponse;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.QueryEligibleForUpgradeRequest;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.QueryEligibleForUpgradeResponse;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.ReasonCodeList;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.SetCommunicationPreferencesRequest;
import com.techmahindra.online.svallo.model.myprofile._2014._09._29.SetCommunicationPreferencesResponse;
import com.techmahindra.online.svallo.service.common.exception.myprofile.SvalloMyProfileIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.myprofile.SvalloMyProfileUpdateAddressIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.myprofile.SvalloMyProfileUpdateEmailAddressIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.myprofile.SvalloMyProfileUpdatePasswordIntegrationException;
//antima start for upgrade	
import com.techm.svallo.exception.service.myprofile.SvalloIsEligibleForUpgradeServiceException;
import com.techmahindra.online.svallo.service.common.exception.myprofile.SvalloMyProfileEligibleUpgradeIntegrationException;
//antima end for upgrade

import com.techm.svallo.exception.service.myprofile.SvalloEditProfileServiceException;
import com.techm.svallo.exception.service.myprofile.SvalloMarketingPreferencesServiceException;

public class EditProfileServiceImpl implements EditProfileService {

	final static PortalLogger logger = PortalLogger.getLogger(EditProfileServiceImpl.class);

	@Autowired
	private MyProfileService myProfileService;
	
	@Autowired
	private JdbcTemplate jdbcTemplateLR = null;
	
	@Value("${editprofile.duplicate.email.address.error}")
	private String EDITPROFILE_DUPLICATE_EMAIL_ADDRESS_ERROR;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplateLR) {
		this.jdbcTemplateLR = jdbcTemplateLR;
	}

	private final String UPDATE_NEW_EMAIL = "update User_ set emailAddress=? " + "where userId=?;";
	private final String GET_USER_PASSWORD = "select password_ from User_ " + "where userId=?;";
	private final String GET_USER_ID_FROM_EMAIL = "select userId from User_ " + "where emailAddress=?;";
	
	@Value("${changepassword.success.message}")
	private String PASSWORD_SUCCESS_MESSAGE;

	@Value("${changepassword.serverside.not.current.password.error.message}")
	private String PASSWORD_NOT_SAME_AS_CURRENT_PASSWORD_ERROR_MESSAGE;

	@Value("${editprofile.updateAddress.error.code}")
	private String EDIT_PROFILE_UPDATE_ADDRESS_ERROR_CODE;

	@Value("${editprofile.updateAddress.exception.code}")
	private String EDIT_PROFILE_UPDATE_ADDRESS_EXCEPTION_CODE;

	@Value("${editprofile.updateEmailAddress.error.code}")
	private String EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_ERROR_CODE;

	@Value("${editprofile.updateEmailAddress.exception.code}")
	private String EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_CODE;

	@Value("${editprofile.updatePassword.error.code}")
	private String EDIT_PROFILE_UPDATE_PASSWORD_ERROR_CODE;

	@Value("${editprofile.updatePassword.exception.code}")
	private String EDIT_PROFILE_UPDATE_PASSWORD_EXCEPTION_CODE;

	@Value("${editprofile.updateAddress.error.message}")
	private String EDIT_PROFILE_UPDATE_ADDRESS_ERROR_MESSAGE;

	@Value("${editprofile.updateAddress.exception.emessage}")
	private String EDIT_PROFILE_UPDATE_ADDRESS_EXCEPTION_MESSAGE;

	@Value("${editprofile.updateEmailAddress.error.message}")
	private String EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_ERROR_MESSAGE;

	@Value("${editprofile.updateEmailAddress.exception.message}")
	private String EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_MESSAGE;

	@Value("${editprofile.updatePassword.error.message}")
	private String EDIT_PROFILE_UPDATE_PASSWORD_ERROR_MESSAGE;

	@Value("${editprofile.updatePassword.exception.message}")
	private String EDIT_PROFILE_UPDATE_PASSWORD_EXCEPTION_MESSAGE;
	
	@Value("${editprofile.updateEmailInDb.exception.code}")
	private String EDIT_PROFILE_UPDATE_EMAIL_IN_DB_EXCEPTION_CODE;
	
	@Value("${editprofile.validateCurrentPassword.exception.code}")
	private String EDIT_PROFILE_VALIDATE_CURRENT_PASSWORD_EXCEPTION_CODE;
	
	@Value("${editprofile.updateEmailInDb.exception.message}")
	private String EDIT_PROFILE_UPDATE_EMAIL_IN_DB_EXCEPTION_MESSAGE;
	
	@Value("${editprofile.validateCurrentPassword.exception.message}")
	private String EDIT_PROFILE_VALIDATE_CURRENT_PASSWORD_EXCEPTION_MESSAGE;
	
	@Value("${editprofile.get.communicationpreferences.error.code}")
	private String EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_ERROR_CODE;

	@Value("${editprofile.get.communicationpreferences.error.message}")
	private String EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_ERROR_MESSAGE;
	
	@Value("${editprofile.update.communicationpreferences.error.code}")
	private String EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_ERROR_CODE;

	@Value("${editprofile.update.communicationpreferences.error.message}")
	private String EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_ERROR_MESSAGE;
	
	@Value("${editprofile.get.communicationpreferences.exception.code}")
	private String EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_EXCEPTION_CODE;

	@Value("${editprofile.get.communicationpreferences.exception.message}")
	private String EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_EXCEPTION_MESSAGE;
	
	@Value("${editprofile.update.communicationpreferences.exception.code}")
	private String EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_EXCEPTION_CODE;

	@Value("${editprofile.update.communicationpreferences.exception.message}")
	private String EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_EXCEPTION_MESSAGE;
	
	@Value("${data.not.available}")
	private String DATA_NOT_AVAILABLE;	
		//start by antima for upgrade 
	@Value("${editprofile.isEligibleForUpgrade.error.code}") 
	private String EDIT_PROFILE_ISELIGIBLEFORUPGRADE_ERROR_CODE;
	
	@Value("${editprofile.isEligibleForUpgrade.error.message}") 
	private String EDIT_PROFILE_ISELIGIBLEFORUPGRADE_ERROR_MESSAGE;
	
	@Value("${editprofile.isEligibleForUpgrade.exception.code}")
	private	String EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_CODE;
	
	@Value("${editprofile.isEligibleForUpgrade.exception.message}")
	private String EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_MESSAGE;
	@Value("${data.not.available.upgrade}")
	private String DATA_NOT_AVAILABLE_UPGRADE;	

	//end by antima for upgrade 


	public String updateAddress(String adressLine1, String adressLine2,
			String adressLine3, String adressLine4, String adressLine5,
			String postCode, String accountNumber, String mobileNumber,
			String subscriptionNumber, String title, String surname)
			throws SvalloEditProfileServiceException {
		AddressUpdateRequest addressUpdateRequest = new AddressUpdateRequest();
		Address address = new Address();
		address.setAddressLine1(adressLine1);
		address.setAddressLine2(adressLine2);
		address.setAddressLine3(adressLine3);
		address.setAddressLine4(adressLine4);
		address.setAddressLine5(adressLine5);
		address.setPostCode(postCode);
		
		addressUpdateRequest.setPersonalAddress(address);
		addressUpdateRequest.setAccountNumber(accountNumber);
		addressUpdateRequest.setMobileNumber(mobileNumber);
		addressUpdateRequest.setSubscriptionNumber(subscriptionNumber);
		addressUpdateRequest.setTitle(title);
		addressUpdateRequest.setSurname(surname);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(new Date());
		try {
			
			XMLGregorianCalendar currentDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
			addressUpdateRequest.setCurrentDate(currentDate);
			
			AddressUpdateResponse addressUpdateResponse = myProfileService.updateAddress(addressUpdateRequest);
			return addressUpdateResponse.getExternalReference();
		} catch (SvalloMyProfileUpdateAddressIntegrationException svalloMyProfileUpdateAddressIntegrationException) {
			logger.error(svalloMyProfileUpdateAddressIntegrationException,"\n[ EditProfileServiceImpl | updateAddress() ] SvalloEditProfileServiceException Catch Block ");
			logger.error(svalloMyProfileUpdateAddressIntegrationException,"\n[ EditProfileServiceImpl | updateAddress() ] SvalloEditProfileServiceException Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_ADDRESS_ERROR_CODE);
			logger.error(svalloMyProfileUpdateAddressIntegrationException,"\n[ EditProfileServiceImpl | updateAddress() ] SvalloEditProfileServiceException Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_ADDRESS_ERROR_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_UPDATE_ADDRESS_ERROR_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_ADDRESS_ERROR_MESSAGE);
			svalloEditProfileServiceException.setRootCause(svalloMyProfileUpdateAddressIntegrationException);
			throw svalloEditProfileServiceException;
			
		} catch (Exception exception) {
			logger.error(exception,"\n[ EditProfileServiceImpl | updateAddress() ] Exception Catch Block ");
			logger.error(exception,"\n[ EditProfileServiceImpl | updateAddress() ] Exception Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_CODE);
			logger.error(exception,"\n[ EditProfileServiceImpl | updateAddress() ] Exception Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_ADDRESS_EXCEPTION_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_ADDRESS_EXCEPTION_MESSAGE);
			svalloEditProfileServiceException.setRootCause(exception);
			throw svalloEditProfileServiceException;
			
		}
		
	}
	
	public String updateEmail(String emailAddr, String accountNumber,
			String mobileNumber, String subscriptionNumber)
			throws SvalloEditProfileServiceException {

		EmailAddrUpdateRequest emailAddrUpdateRequest = new EmailAddrUpdateRequest();
		emailAddrUpdateRequest.setEmailAddr(emailAddr);
		emailAddrUpdateRequest.setAccountNumber(accountNumber);
		emailAddrUpdateRequest.setMobileNumber(mobileNumber);
		emailAddrUpdateRequest.setSubscriptionNumber(subscriptionNumber);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(new Date());
		
		
		try {
		
				XMLGregorianCalendar currentDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
				emailAddrUpdateRequest.setCurrentDate(currentDate);
				
				EmailAddrUpdateResponse emailAddrUpdateResponse = myProfileService.updateEmailAddr(emailAddrUpdateRequest);
				return emailAddrUpdateResponse.getExternalReference();
			
		} catch (SvalloMyProfileUpdateEmailAddressIntegrationException svalloMyProfileUpdateEmailAddressIntegrationException) {

			logger.error(svalloMyProfileUpdateEmailAddressIntegrationException,"\n[ EditProfileServiceImpl | updateEmail() ] SvalloEditProfileServiceException Catch Block ");
			logger.error(svalloMyProfileUpdateEmailAddressIntegrationException,"\n[ EditProfileServiceImpl | updateEmail() ] SvalloEditProfileServiceException Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_ERROR_CODE);
			logger.error(svalloMyProfileUpdateEmailAddressIntegrationException,"\n[ EditProfileServiceImpl | updateEmail() ] SvalloEditProfileServiceException Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_ERROR_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_ERROR_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_ERROR_MESSAGE);
			svalloEditProfileServiceException.setRootCause(svalloMyProfileUpdateEmailAddressIntegrationException);
			throw svalloEditProfileServiceException;
			
		} catch (Exception exception) {
		
			logger.error(exception,"\n[ EditProfileServiceImpl | updateEmail() ] Exception Catch Block ");
			logger.error(exception,"\n[ EditProfileServiceImpl | updateEmail() ] Exception Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_CODE);
			logger.error(exception,"\n[ EditProfileServiceImpl | updateEmail() ] Exception Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_EMAIL_ADDRESS_EXCEPTION_MESSAGE);
			svalloEditProfileServiceException.setRootCause(exception);
			throw svalloEditProfileServiceException;

		}
	}
	
	public String updatePassword(String accountNumber, String mobileNumber,
			String subscriptionNumber)
			throws SvalloEditProfileServiceException {
		PasswordUpdateRequest passwordUpdateRequest = new PasswordUpdateRequest();
		passwordUpdateRequest.setAccountNumber(accountNumber);
		passwordUpdateRequest.setMobileNumber(mobileNumber);
		passwordUpdateRequest.setSubscriptionNumber(subscriptionNumber);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(new Date());

		try {
			XMLGregorianCalendar currentDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
			passwordUpdateRequest.setCurrentDate(currentDate);
			
			PasswordUpdateResponse passwordUpdateResponse = myProfileService.updatePassword(passwordUpdateRequest);
			return passwordUpdateResponse.getExternalReference();
			
		} catch (SvalloMyProfileUpdatePasswordIntegrationException svalloMyProfileUpdatePasswordIntegrationException) {

			logger.error(svalloMyProfileUpdatePasswordIntegrationException,"\n[ EditProfileServiceImpl | updatePassword() ] SvalloEditProfileServiceException Catch Block ");
			logger.error(svalloMyProfileUpdatePasswordIntegrationException,"\n[ EditProfileServiceImpl | updatePassword() ] SvalloEditProfileServiceException Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_PASSWORD_ERROR_CODE);
			logger.error(svalloMyProfileUpdatePasswordIntegrationException,"\n[ EditProfileServiceImpl | updatePassword() ] SvalloEditProfileServiceException Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_PASSWORD_ERROR_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_UPDATE_PASSWORD_ERROR_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_PASSWORD_ERROR_MESSAGE);
			svalloEditProfileServiceException.setRootCause(svalloMyProfileUpdatePasswordIntegrationException);
			throw svalloEditProfileServiceException;

		} catch (Exception exception) {

			logger.error(exception,"\n[ EditProfileServiceImpl | updatePassword() ] Exception Catch Block ");
			logger.error(exception,"\n[ EditProfileServiceImpl | updatePassword() ] Exception Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_PASSWORD_ERROR_CODE);
			logger.error(exception,"\n[ EditProfileServiceImpl | updatePassword() ] Exception Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_PASSWORD_EXCEPTION_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_UPDATE_PASSWORD_EXCEPTION_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_PASSWORD_EXCEPTION_MESSAGE);
			svalloEditProfileServiceException.setRootCause(exception);
			throw svalloEditProfileServiceException;
		}
		
	}
	
	public MyCommunicationPreferencesVo getCommunicationPreferences(
			MyCommunicationPreferencesVo myCommunicationPreferencesVo){
		
		logger.debug("Hello getCommunicationPreferences---------------");
		MyCommunicationPreferencesVo myCommunicationPreferencesVo1 = new MyCommunicationPreferencesVo();		
		try
		{
		QueryCommunicationPreferencesRequest queryCommunicationPreferencesRequest = new QueryCommunicationPreferencesRequest();
		queryCommunicationPreferencesRequest.setAccountNumber(myCommunicationPreferencesVo.getAccountNumber());		
		logger.debug("Account Number: " +queryCommunicationPreferencesRequest.getAccountNumber());
		logger.debug("External Reference: " +queryCommunicationPreferencesRequest.getExternalReference());
		
		QueryCommunicationPreferencesResponse queryCommunicationPreferencesResponse = myProfileService.getCommunicationPreferences(queryCommunicationPreferencesRequest);
		logger.debug("Size: " +queryCommunicationPreferencesResponse.getName().size());
		String byLetter = getFlatData("marketingByLetter", queryCommunicationPreferencesResponse.getName());
		String byEmail = getFlatData("marketingByEmail", queryCommunicationPreferencesResponse.getName());
		String byTelephone = getFlatData("marketingByTelephone", queryCommunicationPreferencesResponse.getName());
		String bySMS= getFlatData("marketingBySMS", queryCommunicationPreferencesResponse.getName());
		
		logger.debug("byLetter: " +byLetter);
		logger.debug("byEmail: " +byEmail);
		logger.debug("byTelephone: " +byTelephone);
		logger.debug("bySMS: "+bySMS);		
		
		myCommunicationPreferencesVo1.setMarketingByLetter(byLetter);
		myCommunicationPreferencesVo1.setMarketingByEmail(byEmail);
		myCommunicationPreferencesVo1.setMarketingByTelephone(byTelephone);
		myCommunicationPreferencesVo1.setMarketingBySMS(bySMS);
		myCommunicationPreferencesVo1.setSize(queryCommunicationPreferencesResponse.getName().size());
		}catch(SvalloMyProfileIntegrationException svalloMyProfileIntegrationException) {

			logger.error(svalloMyProfileIntegrationException,"\n[ EditProfileServiceImpl | getCommunicationPreferences() ] SvalloMarketingPreferencesServiceException Catch Block ");
			logger.error(svalloMyProfileIntegrationException,"\n[ EditProfileServiceImpl | getCommunicationPreferences() ] SvalloMarketingPreferencesServiceException Catch Block | Error Code =  "+ EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_ERROR_CODE);
			logger.error(svalloMyProfileIntegrationException,"\n[ EditProfileServiceImpl | getCommunicationPreferences() ] SvalloMarketingPreferencesServiceException Catch Block | Error Message  =  "+ EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_ERROR_MESSAGE);
			SvalloMarketingPreferencesServiceException svalloMarketingPreferencesServiceException = new SvalloMarketingPreferencesServiceException();
			svalloMarketingPreferencesServiceException.setErrorCode(EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_ERROR_CODE);
			svalloMarketingPreferencesServiceException.setErrorMessage(EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_ERROR_MESSAGE);
			svalloMarketingPreferencesServiceException.setRootCause(svalloMyProfileIntegrationException);
			
			myCommunicationPreferencesVo1.setMarketingByLetter(DATA_NOT_AVAILABLE);
			myCommunicationPreferencesVo1.setMarketingByEmail(DATA_NOT_AVAILABLE);
			myCommunicationPreferencesVo1.setMarketingByTelephone(DATA_NOT_AVAILABLE);
			myCommunicationPreferencesVo1.setMarketingBySMS(DATA_NOT_AVAILABLE);

		} catch (Exception exception) {

			logger.error(exception,"\n[ EditProfileServiceImpl | getCommunicationPreferences() ] Exception Catch Block ");
			logger.error(exception,"\n[ EditProfileServiceImpl | getCommunicationPreferences() ] Exception Catch Block | Error Code =  "+ EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_EXCEPTION_CODE);
			logger.error(exception,"\n[ EditProfileServiceImpl | getCommunicationPreferences() ] Exception Catch Block | Error Message  =  "+ EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_EXCEPTION_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_EXCEPTION_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_GET_COMMUNICATIONPREFERENCES_EXCEPTION_MESSAGE);
			svalloEditProfileServiceException.setRootCause(exception);
			
			myCommunicationPreferencesVo1.setMarketingByLetter(DATA_NOT_AVAILABLE);
			myCommunicationPreferencesVo1.setMarketingByEmail(DATA_NOT_AVAILABLE);
			myCommunicationPreferencesVo1.setMarketingByTelephone(DATA_NOT_AVAILABLE);
			myCommunicationPreferencesVo1.setMarketingBySMS(DATA_NOT_AVAILABLE);
		}
		
		return myCommunicationPreferencesVo1;
	}

	public String updateCommunicationPreferences(MyCommunicationPreferencesVo myCommunicationPreferencesVo) {		
		
		logger.debug("Hello updateCommunicationPreferences---------------");
		
		String status = "";			
		SetCommunicationPreferencesRequest setCommunicationPreferencesRequest = new SetCommunicationPreferencesRequest();
		try
		{		
		String letter = myCommunicationPreferencesVo.getLetter();
		String email = myCommunicationPreferencesVo.getEmail();
		String telephone = myCommunicationPreferencesVo.getTelephone();
		String sms = myCommunicationPreferencesVo.getSms();		
		logger.debug("letter: " +letter);
		logger.debug("email: " +email);
		logger.debug("telephone: " +telephone);
		logger.debug("sms: " +sms);
		logger.debug("ooooooooooooooooooooooooooooooooooo");
		
		setCommunicationPreferencesRequest.setAccountNumber(myCommunicationPreferencesVo.getAccountNumber());		
		setCommunicationPreferencesRequest.setCommunicationMethod(myCommunicationPreferencesVo.getCommunicationMethod());
		setCommunicationPreferencesRequest.setLanguage(myCommunicationPreferencesVo.getLanguage());
		setCommunicationPreferencesRequest.setParticularRequirement(myCommunicationPreferencesVo.getParticularRequirement());
		
		NameValuePair name = new NameValuePair();
		name.setKey("marketingByLetter");
		name.setValue(letter);
		//logger.debug("11111111" +name.getValue());
		setCommunicationPreferencesRequest.getName().add(name);
		
		NameValuePair name1 = new NameValuePair();
		name1.setKey("marketingByEmail");
		name1.setValue(email);
		//logger.debug("22222222" +name.getValue());
		setCommunicationPreferencesRequest.getName().add(name1);
		
		NameValuePair name2 = new NameValuePair();
		name2.setKey("marketingByTelephone");
		name2.setValue(telephone);
		//logger.debug("333333333333" +name.getValue());
		setCommunicationPreferencesRequest.getName().add(name2);
		
		NameValuePair name3 = new NameValuePair();
		name3.setKey("marketingBySMS");
		name3.setValue(sms);
		//logger.debug("4444444444" +name.getValue());
		setCommunicationPreferencesRequest.getName().add(name3);			
	
		SetCommunicationPreferencesResponse setCommunicationPreferencesResponse = myProfileService.updateCommunicationPreferences(setCommunicationPreferencesRequest);
		logger.debug("Status message: " +setCommunicationPreferencesResponse.getStatusMessage());
		status = setCommunicationPreferencesResponse.getStatusMessage();		
		
		}catch(SvalloMyProfileIntegrationException svalloMyProfileIntegrationException) {

			logger.error(svalloMyProfileIntegrationException,"\n[ EditProfileServiceImpl | updateCommunicationPreferences() ] SvalloMarketingPreferencesServiceException Catch Block ");
			logger.error(svalloMyProfileIntegrationException,"\n[ EditProfileServiceImpl | updateCommunicationPreferences() ] SvalloMarketingPreferencesServiceException Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_ERROR_CODE);
			logger.error(svalloMyProfileIntegrationException,"\n[ EditProfileServiceImpl | updateCommunicationPreferences() ] SvalloMarketingPreferencesServiceException Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_ERROR_MESSAGE);
			SvalloMarketingPreferencesServiceException svalloMarketingPreferencesServiceException = new SvalloMarketingPreferencesServiceException();
			svalloMarketingPreferencesServiceException.setErrorCode(EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_ERROR_CODE);
			svalloMarketingPreferencesServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_ERROR_MESSAGE);
			svalloMarketingPreferencesServiceException.setRootCause(svalloMyProfileIntegrationException);
			
			status = DATA_NOT_AVAILABLE;

		} catch (Exception exception) {

			logger.error(exception,"\n[ EditProfileServiceImpl | updateCommunicationPreferences() ] Exception Catch Block ");
			logger.error(exception,"\n[ EditProfileServiceImpl | updateCommunicationPreferences() ] Exception Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_EXCEPTION_CODE);
			logger.error(exception,"\n[ EditProfileServiceImpl | updateCommunicationPreferences() ] Exception Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_EXCEPTION_MESSAGE);
			SvalloEditProfileServiceException svalloEditProfileServiceException = new SvalloEditProfileServiceException();
			svalloEditProfileServiceException.setErrorCode(EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_EXCEPTION_CODE);
			svalloEditProfileServiceException.setErrorMessage(EDIT_PROFILE_UPDATE_COMMUNICATIONPREFERENCES_EXCEPTION_MESSAGE);
			svalloEditProfileServiceException.setRootCause(exception);
			
			status = DATA_NOT_AVAILABLE;
		}
		
		return status;
	}

//start by antima for upgrade eligibility checker
	public IsEligibleForUpgradeVo isEligibleForUpgrade(IsEligibleForUpgradeVo isEligibleForUpgradeVo)
	{
		logger.debug("************************inside selfCare Services isEligibleForUpgrade start**************");
		IsEligibleForUpgradeVo isEligibleForUpgradeVo1 = new IsEligibleForUpgradeVo();
		//logger.debug("******not workimng *********");
		//ReasonCodeListVo reasonCodeListVo= new ReasonCodeListVo();
		List<ReasonCodeListVo> ReasonCodeList1 = new ArrayList<ReasonCodeListVo>();
		QueryEligibleForUpgradeRequest queryEligibleForUpgradeRequest =new QueryEligibleForUpgradeRequest();
		try{
		queryEligibleForUpgradeRequest.setSubscriptionNumber(isEligibleForUpgradeVo.getSubscriptionNumber());
		queryEligibleForUpgradeRequest.setExternalReference(isEligibleForUpgradeVo.getExternalReference());
		logger.debug("External Reference: " +queryEligibleForUpgradeRequest.getExternalReference());
		logger.debug("Subscription Number: " +queryEligibleForUpgradeRequest.getSubscriptionNumber());
		QueryEligibleForUpgradeResponse queryEligibleForUpgradeResponse=myProfileService.isEligibleForUpgrade(queryEligibleForUpgradeRequest);
		logger.debug("ReasonCodeList Size: " +queryEligibleForUpgradeResponse.getReasonCode().size());
		logger.debug("EligbleFlag: " +queryEligibleForUpgradeResponse.getEligibleFlag());
		//logger.debug("Upgrade Date: " +queryEligibleForUpgradeResponse.getUpgradeDate());
		
		if (queryEligibleForUpgradeResponse.getUpgradeDate()!=null &&  !queryEligibleForUpgradeResponse.getUpgradeDate().trim().isEmpty() )
		{
		logger.debug("Upgrade Date: " +SelfCareUtil.getFormatedDate(queryEligibleForUpgradeResponse.getUpgradeDate()));
		isEligibleForUpgradeVo1.setUpgradeDate(SelfCareUtil.getFormatedDate(queryEligibleForUpgradeResponse.getUpgradeDate()));
		}else {
			
			isEligibleForUpgradeVo1.setUpgradeDate("date is not available");
			
			logger.debug("Upgrade Date: is nulll");
		}
		
		logger.debug("Upgrade Date: " +SelfCareUtil.getFormatedDate(queryEligibleForUpgradeResponse.getUpgradeDate()));
		logger.debug("Upgrade Charge: " +queryEligibleForUpgradeResponse.getEarlyUpgradeCharge());
		logger.debug("Hello---------------");
		logger.debug("Size:_reasoncode" +queryEligibleForUpgradeResponse.getReasonCode());
		logger.debug("Size: " +queryEligibleForUpgradeResponse.getReasonCode().size());
		 
		int no = queryEligibleForUpgradeResponse.getReasonCode().size() ;
		  
//		  ReasonCodeList L1=null;
//		  List k=null;
		  //ReasonCodeListVo ReasonCodeList = new ReasonCodeListVo();
		  //List<ReasonCodeListVo> ReasonCodeList1 = new ArrayList<ReasonCodeListVo>();
		 
			for(int i=0;i<no;i++)
			{	
				ReasonCodeList L1  = (ReasonCodeList) queryEligibleForUpgradeResponse.getReasonCode().get(i); 
				//isEligibleForUpgradeVo1.setReasonCodeNo(L1.getReasonCodeNo());			
				ReasonCodeListVo reasonCodeListVo = new ReasonCodeListVo();
				reasonCodeListVo.setReasonCodeNo(L1.getReasonCodeNo());	
				ReasonCodeList1.add(reasonCodeListVo);
	//			 k=(List) L1;
				//List<ReasonCodes> L1  = queryEligibleForUpgradeResponse.getReasonCode().get(i);
				  logger.debug("getReasonCodeNo :" +L1.getReasonCodeNo());
	//			  reasonCodeListVo.setReasonCodeNo(L1.getReasonCodeNo());		
			}	
			isEligibleForUpgradeVo1.setReasonCode(ReasonCodeList1);	
		
		
//		isEligibleForUpgradeVo1.setUpgradeDate(SelfCareUtil.getFormatedDate(queryEligibleForUpgradeResponse.getUpgradeDate()));
		isEligibleForUpgradeVo1.setEligibleFlag(queryEligibleForUpgradeResponse.getEligibleFlag());
		isEligibleForUpgradeVo1.setEarlyUpgradeCharge(queryEligibleForUpgradeResponse.getEarlyUpgradeCharge());	
		isEligibleForUpgradeVo1.setSize(no);
	}
	catch (SvalloMyProfileEligibleUpgradeIntegrationException svalloMyProfileEligibleUpgradeIntegrationException)
		{
			
			//Error Code and Error Message in this(SvalloPaymentDirectDebitIntegrationException) block will be according to your business
						//es.printStackTrace();
			logger.error(svalloMyProfileEligibleUpgradeIntegrationException,"\n[ MyProfileServiceImpl | isEligibleForUpgrade() ] SvalloMyProfileEligibleUpgradeIntegrationException Catch Block ");
			logger.error(svalloMyProfileEligibleUpgradeIntegrationException,"\n[ MyProfileServiceImpl | isEligibleForUpgrade() ] SvalloMyProfileEligibleUpgradeIntegrationException Catch Block | Error Code =  "+EDIT_PROFILE_ISELIGIBLEFORUPGRADE_ERROR_CODE);
			logger.error(svalloMyProfileEligibleUpgradeIntegrationException,"\n[ MyProfileServiceImpl | isEligibleForUpgrade() ] SvalloMyProfileEligibleUpgradeIntegrationException Catch Block | Error Message  =  "+EDIT_PROFILE_ISELIGIBLEFORUPGRADE_ERROR_MESSAGE);
			SvalloIsEligibleForUpgradeServiceException svalloIsEligibleForUpgradeServiceException = new SvalloIsEligibleForUpgradeServiceException();
			svalloIsEligibleForUpgradeServiceException.setErrorCode(EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_CODE);
			svalloIsEligibleForUpgradeServiceException.setErrorMessage(EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_MESSAGE);
			svalloIsEligibleForUpgradeServiceException.setRootCause(svalloMyProfileEligibleUpgradeIntegrationException);
			isEligibleForUpgradeVo1.setReasonCode(ReasonCodeList1);	
			isEligibleForUpgradeVo1.setUpgradeDate(DATA_NOT_AVAILABLE_UPGRADE);
			isEligibleForUpgradeVo1.setEligibleFlag(DATA_NOT_AVAILABLE_UPGRADE);
			isEligibleForUpgradeVo1.setEarlyUpgradeCharge(DATA_NOT_AVAILABLE_UPGRADE);	
//			throw svalloIsEligibleForUpgradeServiceException;
		
		}
		catch (Exception exception)
		{
			
			//Error Code and Error Message in this(Exception) block will be according to your business		
			logger.error(exception,"\n[ MyProfileServiceImpl | isEligibleForUpgrade() ] Exception Catch Block ");
			logger.error(exception,"\n[ MyProfileServiceImpl | isEligibleForUpgrade() ] Exception Catch Block | Error Code =  "+EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_CODE);
			logger.error(exception,"\n[ MyProfileServiceImpl | isEligibleForUpgrade() ] Exception Catch Block | Error Message  =  "+EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_MESSAGE);
			SvalloIsEligibleForUpgradeServiceException svalloIsEligibleForUpgradeServiceException = new SvalloIsEligibleForUpgradeServiceException();
			svalloIsEligibleForUpgradeServiceException.setErrorCode(EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_CODE);
			svalloIsEligibleForUpgradeServiceException.setErrorMessage(EDIT_PROFILE_ISELIGIBLEFORUPGRADE_EXCEPTION_MESSAGE);
			svalloIsEligibleForUpgradeServiceException.setRootCause(exception);
			isEligibleForUpgradeVo1.setReasonCode(ReasonCodeList1);	
			isEligibleForUpgradeVo1.setUpgradeDate(DATA_NOT_AVAILABLE_UPGRADE);
			isEligibleForUpgradeVo1.setEligibleFlag(DATA_NOT_AVAILABLE_UPGRADE);
			isEligibleForUpgradeVo1.setEarlyUpgradeCharge(DATA_NOT_AVAILABLE_UPGRADE);	
			//throw svalloIsEligibleForUpgradeServiceException;
		}
		return isEligibleForUpgradeVo1;
	}
	
	//end by antima for upgrade eligibility checker
	public String getFlatData(String name, List<NameValuePair> names){
		
		for ( int i =0; i<names.size();i++){
			
			if(name.equals(names.get(i).getKey())){
				return names.get(i).getValue();
			}
		}
			return name + " Not found";
		}
		
	public String updateEmailAddressInDb(String emailAddr, Long userId) {
		
			try{
				
				String actualUserId = getUserIdBasedOnEmail(emailAddr);
			
				if(!(actualUserId.isEmpty())){
				
					if (actualUserId.equalsIgnoreCase(userId.toString())){
						
						jdbcTemplateLR.update(UPDATE_NEW_EMAIL, emailAddr,
								String.valueOf(userId));

						return "success";
					}else{
						return EDITPROFILE_DUPLICATE_EMAIL_ADDRESS_ERROR;
					}
				}else{
					jdbcTemplateLR.update(UPDATE_NEW_EMAIL, emailAddr,
							String.valueOf(userId));
					return "success";
				}
			}catch(ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException){
			
			logger.error(arrayIndexOutOfBoundsException,"\n[ EditProfileServiceImpl | updateEmailAddressInDb() ] SqlException Catch Block ");
			logger.error(arrayIndexOutOfBoundsException,"\n[ EditProfileServiceImpl | updateEmailAddressInDb() ] SqlException Catch Block | Error Code =  "+ EDIT_PROFILE_UPDATE_EMAIL_IN_DB_EXCEPTION_CODE);
			logger.error(arrayIndexOutOfBoundsException,"\n[ EditProfileServiceImpl | updateEmailAddressInDb() ] SqlException Catch Block | Error Message  =  "+ EDIT_PROFILE_UPDATE_EMAIL_IN_DB_EXCEPTION_MESSAGE);
			//arrayIndexOutOfBoundsException.printStackTrace();
			return "failure";
			}
			catch(Exception exception){
			logger.error(exception," Exception occured while updating email address in DB ");
			//exception.printStackTrace();
			return "failure";
			}
	}
	
	public String getUserIdBasedOnEmail (String emailAddr){
		
		String actualUserId="";
		try{
			 actualUserId = (String) jdbcTemplateLR.query(
					GET_USER_ID_FROM_EMAIL, new String[] { emailAddr },
						new ManageGetUserIdMapper()).get(0);
			
		}catch(ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException){
		
			logger.error(arrayIndexOutOfBoundsException,"Array Index out of bound exception while getting userId based on emailId");
			//arrayIndexOutOfBoundsException.printStackTrace();
			
		}catch(Exception exception){
			logger.error(exception," Exception occured while while getting userId based on emailId");
			//exception.printStackTrace();
		}
		finally{
			return actualUserId;
		}
		
		
	}
	
	public String validateCurrentPassword(String currentPassword,Long userId) {
	
			try{
			 byte[] actualCurrentPassword = jdbcTemplateLR.query(
				GET_USER_PASSWORD, new Long[] { userId },
				new ManageGetPasswordMapper()).get(0).getBytes();

			byte[] encodedCurrentPassword = Base64.encodeBase64(DigestUtils.sha(currentPassword.getBytes()));
			//String encryptedCurrentPassword = new String(encodedCurrentPassword);
			
			if (Arrays.equals(actualCurrentPassword, encodedCurrentPassword)) {
			
				logger.debug("[ EditProfileServiceImpl | validateCurrentPassword() ] passwords matched ");
				actualCurrentPassword = null;
				encodedCurrentPassword = null;
				return (PASSWORD_SUCCESS_MESSAGE);
			} else {
				logger.debug("[ EditProfileServiceImpl | validateCurrentPassword() ] passwords didn't match ");
				actualCurrentPassword = null;
				encodedCurrentPassword = null;
				return (PASSWORD_NOT_SAME_AS_CURRENT_PASSWORD_ERROR_MESSAGE);
			}
		}catch(ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException){
			
			logger.error(arrayIndexOutOfBoundsException,"\n[ EditProfileServiceImpl | validateCurrentPassword() ] SqlException Catch Block ");
			logger.error(arrayIndexOutOfBoundsException,"\n[ EditProfileServiceImpl | validateCurrentPassword() ] SqlException Catch Block | Error Code =  "+ EDIT_PROFILE_VALIDATE_CURRENT_PASSWORD_EXCEPTION_CODE);
			logger.error(arrayIndexOutOfBoundsException,"\n[ EditProfileServiceImpl | validateCurrentPassword() ] SqlException Catch Block | Error Message  =  "+ EDIT_PROFILE_VALIDATE_CURRENT_PASSWORD_EXCEPTION_MESSAGE);
			//arrayIndexOutOfBoundsException.printStackTrace();
			return "failure";
			}
			catch(Exception exception){
			logger.error(exception," Exception occured while while validating password");
			//exception.printStackTrace();
			return "failure";
			}
	}
	
	private static final class ManageGetPasswordMapper implements
			RowMapper<String> {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			return rs.getString("password_");
		}
	}
	private static final class ManageGetUserIdMapper implements
			RowMapper<String> {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			return rs.getString("userId");
		}
	}
}
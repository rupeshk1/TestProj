package com.techm.svallo.vo.dashboard;

public class TotalAllowancesVo {

   
    private AllowancesVo inclusive;
    private AllowancesVo free;
    private AllowancesVo extra;
	
	public AllowancesVo getInclusive(){
		return inclusive;
	}
   
    public AllowancesVo getFree(){
		return free;
	}
	
	public AllowancesVo getExtra(){
		return extra;
	}
	
	public void setInclusive( AllowancesVo inclusive){
	 this.inclusive = inclusive;
	}
	
	public void setFree( AllowancesVo free){
	 this.free = free;
	}
	
	public void setExtra( AllowancesVo extra){
	 this.extra = extra;
	}
}

package com.techm.svallo.vo.editprofile;

import java.util.ArrayList;
import java.util.List;

public class MyCommunicationPreferencesVo {
	
	private String externalReference;
	private String accountNumber;
	//private PreferencesVo preferencesVo;	
	private String message;
	private String communicationMethod;
	private String language;
	private String particularRequirement;	
	private String marketingByLetter;
	private String marketingByEmail;
	private String marketingByTelephone;
	private String marketingBySMS;
	private String optout;
	private String letter;
	private String email;
	private String telephone;
	private String sms;
	private int size;		
	
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getOptout() {
		return optout;
	}
	public void setOptout(String optout) {
		this.optout = optout;
	}
	public String getLetter() {
		return letter;
	}
	public void setLetter(String letter) {
		this.letter = letter;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getSms() {
		return sms;
	}
	public void setSms(String sms) {
		this.sms = sms;
	}
	public String getMarketingByLetter() {
		return marketingByLetter;
	}
	public void setMarketingByLetter(String marketingByLetter) {
		this.marketingByLetter = marketingByLetter;
	}
	public String getMarketingByEmail() {
		return marketingByEmail;
	}
	public void setMarketingByEmail(String marketingByEmail) {
		this.marketingByEmail = marketingByEmail;
	}
	public String getMarketingByTelephone() {
		return marketingByTelephone;
	}
	public void setMarketingByTelephone(String marketingByTelephone) {
		this.marketingByTelephone = marketingByTelephone;
	}
	public String getMarketingBySMS() {
		return marketingBySMS;
	}
	public void setMarketingBySMS(String marketingBySMS) {
		this.marketingBySMS = marketingBySMS;
	}
	/*public PreferencesVo getPreferencesVo() {
		return preferencesVo;
	}
	public void setPreferencesVo(PreferencesVo preferencesVo) {
		this.preferencesVo = preferencesVo;
	}*/
	public String getExternalReference() {
		return externalReference;
	}
	public void setExternalReference(String externalReference) {
		this.externalReference = externalReference;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCommunicationMethod() {
		return communicationMethod;
	}
	public void setCommunicationMethod(String communicationMethod) {
		this.communicationMethod = communicationMethod;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getParticularRequirement() {
		return particularRequirement;
	}
	public void setParticularRequirement(String particularRequirement) {
		this.particularRequirement = particularRequirement;
	}
}

package com.techm.svallo.service.bundle;

import com.techm.svallo.vo.bundle.BundleListVo;

public interface BundleServiceService {
	public BundleListVo getBundle(String accountNumber, String subscriptionNum);
	/* added bundleTypeName and servicePrice parameter in updateBundle for realtime changes */
	public String updateBundle(String serviceCode, String operation, String subscriptionNum, String bundleTypeName, String servicePrice,String reloadMethod);
	public String getBundleMessage(String accountNumber, String subscriptionNum);
	public BundleListVo getApplicableBundle(String accountNumber, String subscriptionNum);
	public BundleListVo getExistingBundle(String accountNumber, String subscriptionNum);
	public String getUserPassword(long userId);
}

package com.techm.svallo.vo.takeabreak;


public class QueryAccount 
{
	private String externalReference;
	private String accountNumber;
	private String subscriptionNumber;
	private String tariffCode;
	private String responseFilter;
	private String date;
	private String serviceCode;
	private String mrcServiceSum;
	
	public String getExternalReference()
	{
		return externalReference;
	}
	public void setExternalReference(String externalReference)
	{
		this.externalReference = externalReference;
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getSubscriptionNumber()
	{
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber)
	{
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getTariffCode()
	{
		return tariffCode;
	}
	public void setTariffCode(String tariffCode)
	{
		this.tariffCode = tariffCode;
	}
	public String getResponseFilter()
	{
		return responseFilter;
	}
	public void setResponseFilter(String responseFilter)
	{
		this.responseFilter = responseFilter;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date = date;
	}
	public String getServiceCode()
	{
		return serviceCode;
	}
	public void setServiceCode(String serviceCode)
	{
		this.serviceCode = serviceCode;
	}
	public String getMrcServiceSum()
	{
		return mrcServiceSum;
	}
	public void setMrcServiceSum(String mrcServiceSum)
	{
		this.mrcServiceSum = mrcServiceSum;
	}
    
}

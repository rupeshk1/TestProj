package com.techm.svallo.service.accountlockout;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import com.techm.portal.common.loggerwrapper.PortalLogger;

public class AccountLockoutServiceImpl implements AccountLockoutService{

    final static PortalLogger logger = PortalLogger.getLogger(AccountLockoutServiceImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate=null;
	
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/*
	private static String GET_USER_ACCOUNTNUMBER="select data_ from ExpandoValue where companyId = (select companyId "+
                         "from User_ where screenName = '?') and columnId = "+
						 "(select columnId from ExpandoColumn "+
						 "where companyId in (select companyId from User_ where screenName = '?') "+
						 "and name='accountNum') "+
						 "and classPk= "+
					   	 "(select userId from User_ where screenName = '?'); ";

  */
	/*
	private static String GET_USER_ACCOUNTNUMBER="select ev.data_ as data_ from ExpandoValue ev "+
            "join User_ u on u.userId = ev.classPk "+
			"join ExpandoRow er on u.userId = er.classPk and ev.rowid_ = er.rowId_ "+
			"join ExpandoColumn ec on u.companyId=ec.companyId and ev.columnId=ec.columnId "+
		    "where ec.name='accountNum' and u.screenName='?'; ";	
		    */
	
	private static String GET_USER_ACCOUNTNUMBER="select openId as accountNum from User_ where screenName=?; ";	
	
	public String getAccountnumber(String userName) {
		String accountNumber = "";
		//logger.debug("Username passed="+userName);		
		//logger.debug( " GET_USER_ACCOUNTNUMBER : "+ GET_USER_ACCOUNTNUMBER.replaceAll("\\?",userName+"")); 
		try{			
			//accountNumber = (String)jdbcTemplate.query(GET_USER_ACCOUNTNUMBER.replaceAll("\\?",userName+""),new ManageGetAccountNumberMapper()).get(0);
			accountNumber = (String)jdbcTemplate.query(GET_USER_ACCOUNTNUMBER,new String[]{userName},new ManageGetAccountNumberMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){			
			logger.error(ae,"Array Index out of bound exception");
		}
		return accountNumber;		
	}
	
	
	private static final class ManageGetAccountNumberMapper implements RowMapper<String> {
	    public String mapRow(ResultSet rs, int rowNum) throws SQLException {	    
	    	return rs.getString("accountNum");  
	    }
	}
	
	

}

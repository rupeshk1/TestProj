package com.techm.svallo.vo.billingandpayment;

public class BillPeriodVo
{
	String billPeriodDate="";

	public String getBillPeriodDate()
	{
		return billPeriodDate;
	}

	public void setBillPeriodDate(String billPeriodDate)
	{
		this.billPeriodDate = billPeriodDate;
	}
	
	
}

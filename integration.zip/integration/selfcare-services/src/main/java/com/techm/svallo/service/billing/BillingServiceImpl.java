package com.techm.svallo.service.billing;

import java.util.List;

import com.techm.svallo.vo.billing.BillingVO;
import com.techm.svallo.vo.billing.PaymentVO;
import com.techm.svallo.vo.billing.UsageVO;


//import org.springframework.beans.factory.annotation.Autowired;

public class BillingServiceImpl implements BillingService {

	
	//@Autowired
    //private WebServiceTemplate wsTemplate;
	
	
	public BillingServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	public List<BillingVO> getBillHistory(int months) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PaymentVO> getPaymentHistory(int months) {
		// TODO Auto-generated method stub
		return null;
	}

	public BillingVO viewBill(int month) {

		/*CustomerBill billData = new BillData();
            //(BillData) wsTemplate.marshalSendAndReceive(month);
		    BillingVO billingVO = new BillingVO();
		    billingVO.setMessagingCharges(billData.getMessagingCharges());
		    billingVO.setRental(billData.getMonthlyCharges());
		    billingVO.setRoamingCharges(billData.getRoamingCharges());
		    billingVO.setUsage(billData.getUsageCharges());
		    billingVO.setDiscounts(billData.getDiscountCharges());*/
		return null;
	}

	public UsageVO viewUsage() {
		// TODO Auto-generated method stub
		return null;
	}

}

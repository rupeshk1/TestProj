package com.techm.svallo.vo.billingandpayment;

import java.util.List;
import java.util.Map;

public class MyLastBillVo
{

	private String accountNumber = null;
	private String billHistoryRecordFound = "false";
	private List<BillVo> billHistoryList = null; // "billHistoryList"
	private BillVo lastBillHistoryVo = null; // "lastBillHistoryVo"
	private String billHistoryExceptionPresent = "false";
	private List<BillPeriodVo> billingPeriod = null; // "billingPeriod"
	private Map<String, BillVo> billPeriodMap = null;
	private String currentMonth;
	private String unbilledAmount = null;
	private String currentMonthEstimatedBill;
	private String currentMonthExtraCharges;
	private String nextInvoiceDate;
	private String currentMonthTarrif;
	private PaymentNBillingVo lastInvoicePaymentNBillingVo = null;
	private String currentMonthDueOn;
	
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getBillHistoryRecordFound()
	{
		return billHistoryRecordFound;
	}
	public void setBillHistoryRecordFound(String billHistoryRecordFound)
	{
		this.billHistoryRecordFound = billHistoryRecordFound;
	}
	public List<BillVo> getBillHistoryList()
	{
		return billHistoryList;
	}
	public void setBillHistoryList(List<BillVo> billHistoryList)
	{
		this.billHistoryList = billHistoryList;
	}
	public BillVo getLastBillHistoryVo()
	{
		return lastBillHistoryVo;
	}
	public void setLastBillHistoryVo(BillVo lastBillHistoryVo)
	{
		this.lastBillHistoryVo = lastBillHistoryVo;
	}
	public String getBillHistoryExceptionPresent()
	{
		return billHistoryExceptionPresent;
	}
	public void setBillHistoryExceptionPresent(String billHistoryExceptionPresent)
	{
		this.billHistoryExceptionPresent = billHistoryExceptionPresent;
	}
	public List<BillPeriodVo> getBillingPeriod()
	{
		return billingPeriod;
	}
	public void setBillingPeriod(List<BillPeriodVo> billingPeriod)
	{
		this.billingPeriod = billingPeriod;
	}
	public Map<String, BillVo> getBillPeriodMap()
	{
		return billPeriodMap;
	}
	public void setBillPeriodMap(Map<String, BillVo> billPeriodMap)
	{
		this.billPeriodMap = billPeriodMap;
	}
	public String getCurrentMonth()
	{
		return currentMonth;
	}
	public void setCurrentMonth(String currentMonth)
	{
		this.currentMonth = currentMonth;
	}
	public String getUnbilledAmount()
	{
		return unbilledAmount;
	}
	public void setUnbilledAmount(String unbilledAmount)
	{
		this.unbilledAmount = unbilledAmount;
	}
	public String getCurrentMonthEstimatedBill()
	{
		return currentMonthEstimatedBill;
	}
	public void setCurrentMonthEstimatedBill(String currentMonthEstimatedBill)
	{
		this.currentMonthEstimatedBill = currentMonthEstimatedBill;
	}
	public String getCurrentMonthExtraCharges()
	{
		return currentMonthExtraCharges;
	}
	public void setCurrentMonthExtraCharges(String currentMonthExtraCharges)
	{
		this.currentMonthExtraCharges = currentMonthExtraCharges;
	}
	public String getNextInvoiceDate()
	{
		return nextInvoiceDate;
	}
	public void setNextInvoiceDate(String nextInvoiceDate)
	{
		this.nextInvoiceDate = nextInvoiceDate;
	}
	public String getCurrentMonthTarrif()
	{
		return currentMonthTarrif;
	}
	public void setCurrentMonthTarrif(String currentMonthTarrif)
	{
		this.currentMonthTarrif = currentMonthTarrif;
	}
	public PaymentNBillingVo getLastInvoicePaymentNBillingVo()
	{
		return lastInvoicePaymentNBillingVo;
	}
	public void setLastInvoicePaymentNBillingVo(PaymentNBillingVo lastInvoicePaymentNBillingVo)
	{
		this.lastInvoicePaymentNBillingVo = lastInvoicePaymentNBillingVo;
	}
	public String getCurrentMonthDueOn()
	{
		return currentMonthDueOn;
	}
	public void setCurrentMonthDueOn(String currentMonthDueOn)
	{
		this.currentMonthDueOn = currentMonthDueOn;
	}
	
	

}

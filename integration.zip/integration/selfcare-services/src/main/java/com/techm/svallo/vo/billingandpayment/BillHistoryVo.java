package com.techm.svallo.vo.billingandpayment;

public class BillHistoryVo
{
	private String billHistoryPeriod="";

	public String getBillHistoryPeriod()
	{
		return billHistoryPeriod;
	}

	public void setBillHistoryPeriod(String billHistoryPeriod)
	{
		this.billHistoryPeriod = billHistoryPeriod;
	}
	
	
}

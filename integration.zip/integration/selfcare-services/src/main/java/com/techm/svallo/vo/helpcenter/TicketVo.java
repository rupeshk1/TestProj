package com.techm.svallo.vo.helpcenter;

public class TicketVo
{
	private String ticketId;
	private String ticketType;
	private String ticketShortDescription;
	private String ticketLongDescription;
	
	public String getTicketId()
	{
		return ticketId;
	}
	public void setTicketId(String ticketId)
	{
		this.ticketId = ticketId;
	}
	public String getTicketType()
	{
		return ticketType;
	}
	public void setTicketType(String ticketType)
	{
		this.ticketType = ticketType;
	}
	public String getTicketShortDescription()
	{
		return ticketShortDescription;
	}
	public void setTicketShortDescription(String ticketShortDescription)
	{
		this.ticketShortDescription = ticketShortDescription;
	}
	public String getTicketLongDescription()
	{
		return ticketLongDescription;
	}
	public void setTicketLongDescription(String ticketLongDescription)
	{
		this.ticketLongDescription = ticketLongDescription;
	}
	
}

package com.techm.svallo.service.oneofpayment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.oneofpayment.SvalloOneOfPaymentServiceException;
import com.techm.svallo.util.SelfCareUtil;
import com.techm.svallo.vo.oneofpayment.OneOfPaymentVo;
import com.techmahindra.online.svallo.model.oneofpayment._2014._10._16.SvalloOneOfPaymentDetailsRequest;
import com.techmahindra.online.svallo.model.oneofpayment._2014._10._16.SvalloOneOfPaymentDetailsResponse;
import com.techmahindra.online.svallo.service.common.exception.oneofpayment.SvalloOneOfPaymentIntegrationException;
import com.techmahindra.online.svallo.service.oneofpayment._2014._10._16.SvalloOneOfPayment;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

public class OneOfPaymentServiceImpl implements OneOfPaymentService
{
	final static PortalLogger logger = PortalLogger.getLogger(OneOfPaymentServiceImpl.class);
	
	@Autowired	
	private SvalloOneOfPayment svalloOneOfPayment;	

	private JdbcTemplate jdbcTemplate=null;	

	private JdbcTemplate jdbcSelfcareTemplate=null;
	
	public void setSvalloOneOfPayment(SvalloOneOfPayment svalloOneOfPayment) {
		this.svalloOneOfPayment = svalloOneOfPayment;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void setJdbcSelfcareTemplate(JdbcTemplate jdbcSelfcareTemplate) {
		this.jdbcSelfcareTemplate = jdbcSelfcareTemplate;
	}

	@Value("${oneofpayment.data.not.available}")
	private String ONEOFPAYMENT_DATA_NOT_AVAILABLE;
	
	
	@Value("${oneofpayment.impl.getOneOfPaymentDetails.error.code}")
	private String ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_ERROR_CODE;
	
	@Value("${oneofpayment.impl.getOneOfPaymentDetails.error.message}")
	private String ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_ERROR_MESSAGE;
	
	@Value("${oneofpayment.impl.getOneOfPaymentDetails.exception.code}")
	private String ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_EXCEPTION_CODE;
	
	@Value("${oneofpayment.impl.getOneOfPaymentDetails.exception.message}")
	private String ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_EXCEPTION_MESSAGE;
	
	/*	
	private static String GET_USER_USERNAME_FROM_ACCOUNT="select screenName from User_ "+
            "where userId IN (select classPk from ExpandoValue where data_ = '?') "+
                     "order by userId desc limit 1; ";
	*/
	
	private static String GET_USER_USERNAME_FROM_ACCOUNT="select screenName from User_ where openId=? order by createDate desc,userId desc;";
	
	private static String GET_USER_PASSWORD = "select password_ from User_ where userId=?;";

	private static String GET_SHORT_PAYMENT_TYPE = "select payment_type from verifone_payment_types where payment_type_desc=?;";
	
		
	@Override
	public OneOfPaymentVo getOneOfPaymentDetails(OneOfPaymentVo oneOfPaymentVo) {
		OneOfPaymentVo OneOfPaymentServiceVo = new OneOfPaymentVo();
		
		try{
			SvalloOneOfPaymentDetailsRequest svalloOneOfPaymentDetailsRequest = new SvalloOneOfPaymentDetailsRequest();
			svalloOneOfPaymentDetailsRequest.setAccountNumber(oneOfPaymentVo.getAccountNumber());
			svalloOneOfPaymentDetailsRequest.setAmount(oneOfPaymentVo.getAmount());
			svalloOneOfPaymentDetailsRequest.setAuditRecordProgram(oneOfPaymentVo.getAuditRecordProgram());
			svalloOneOfPaymentDetailsRequest.setCardNumber(oneOfPaymentVo.getCardNumber());
			svalloOneOfPaymentDetailsRequest.setCardReference(oneOfPaymentVo.getCardReference());
			svalloOneOfPaymentDetailsRequest.setCurrencyCode(oneOfPaymentVo.getCurrencyCode());
			svalloOneOfPaymentDetailsRequest.setExternalReference(oneOfPaymentVo.getExternalReference());
			svalloOneOfPaymentDetailsRequest.setPaymentReference(oneOfPaymentVo.getPaymentReference());
			svalloOneOfPaymentDetailsRequest.setPaymentType(oneOfPaymentVo.getPaymentType());
			svalloOneOfPaymentDetailsRequest.setSuccessfulpaymentStatus(oneOfPaymentVo.getSuccessfulpaymentStatus());
			svalloOneOfPaymentDetailsRequest.setTransactionDateTime(oneOfPaymentVo.getTransactionDateTime());
			svalloOneOfPaymentDetailsRequest.setTransactionReference(oneOfPaymentVo.getTransactionReference());
			svalloOneOfPaymentDetailsRequest.setUserID(oneOfPaymentVo.getUserID());
			svalloOneOfPaymentDetailsRequest.setPaymentFailedErrorCode(oneOfPaymentVo.getMerchantErrorCode());
			svalloOneOfPaymentDetailsRequest.setPaymentFailedErrorDescription(oneOfPaymentVo.getMerchantErrorDesc());
			svalloOneOfPaymentDetailsRequest.setMessage(oneOfPaymentVo.getMessage());
			svalloOneOfPaymentDetailsRequest.setExpiryMonth(oneOfPaymentVo.getExpiryMonth());
			svalloOneOfPaymentDetailsRequest.setExpiryYear(oneOfPaymentVo.getExpiryYear());
			svalloOneOfPaymentDetailsRequest.setAuthCode(oneOfPaymentVo.getAuthCode());
			SvalloOneOfPaymentDetailsResponse getOneOfPaymentResponse = svalloOneOfPayment.getOneOfPaymentDetails(svalloOneOfPaymentDetailsRequest);

			OneOfPaymentServiceVo.setExternalReference(getOneOfPaymentResponse.getExternalReference());
			OneOfPaymentServiceVo.setTransactionReference(getOneOfPaymentResponse.getTransactionReference());
			
		}catch (SvalloOneOfPaymentIntegrationException sopie) {
			// TODO Auto-generated catch block
			logger.error(sopie,"\n[ OneOfPaymentServiceImpl | getOneOfPaymentDetails() ] SvalloOneOfPaymentServiceException Catch Block ");
			logger.error(sopie,"\n[ OneOfPaymentServiceImpl | getOneOfPaymentDetails() ] SvalloOneOfPaymentServiceException Catch Block | Error Code =  "+ ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_ERROR_CODE);
			logger.error(sopie,"\n[ OneOfPaymentServiceImpl | getOneOfPaymentDetails() ] SvalloOneOfPaymentServiceException Catch Block | Error Message  =  "+ ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_ERROR_MESSAGE);			
			SvalloOneOfPaymentServiceException svalloOneOfPaymentServiceException = new SvalloOneOfPaymentServiceException();
			svalloOneOfPaymentServiceException.setErrorCode(ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_ERROR_CODE);
			svalloOneOfPaymentServiceException.setErrorMessage(ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_ERROR_MESSAGE);
			svalloOneOfPaymentServiceException.setRootCause(sopie);
			//sopie.printStackTrace();
			OneOfPaymentServiceVo.setExternalReference(ONEOFPAYMENT_DATA_NOT_AVAILABLE);
			OneOfPaymentServiceVo.setTransactionReference(ONEOFPAYMENT_DATA_NOT_AVAILABLE);			
		}	
		catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e,"\n[ OneOfPaymentServiceImpl | getOneOfPaymentDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ OneOfPaymentServiceImpl | getOneOfPaymentDetails() ] Exception Catch Block | Error Code =  "+ ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ OneOfPaymentServiceImpl | getOneOfPaymentDetails() ] Exception Catch Block | Error Message  =  "+ ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_EXCEPTION_MESSAGE);			
			SvalloOneOfPaymentServiceException svalloOneOfPaymentServiceException = new SvalloOneOfPaymentServiceException();
			svalloOneOfPaymentServiceException.setErrorCode(ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_EXCEPTION_CODE);
			svalloOneOfPaymentServiceException.setErrorMessage(ONEOFPAYMENT_IMPL_GETONEOFPAYMENTDETAILS_EXCEPTION_MESSAGE);
			svalloOneOfPaymentServiceException.setRootCause(e);
			//e.printStackTrace();
			OneOfPaymentServiceVo.setExternalReference(ONEOFPAYMENT_DATA_NOT_AVAILABLE);
			OneOfPaymentServiceVo.setTransactionReference(ONEOFPAYMENT_DATA_NOT_AVAILABLE);			
		}	
		return OneOfPaymentServiceVo;
	}
	
	@Override
	public String getScreenName(String accountNumber) {
		String screenName = "";		
		logger.debug("Account Number ="+accountNumber);
		//logger.debug("Query="+GET_USER_USERNAME_FROM_ACCOUNT);
		try{
			//screenName = (String)jdbcTemplate.query(GET_USER_USERNAME_FROM_ACCOUNT.replaceAll("\\?",accountNumber+""),new ManageGetScreenNameMapper()).get(0);
			screenName = (String)jdbcTemplate.query(GET_USER_USERNAME_FROM_ACCOUNT,new String[]{accountNumber},new ManageGetScreenNameMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");		
		}
		finally{		
			//logger.debug("Screen name from DB="+screenName);
		return screenName;
		}
	}

	
	private static final class ManageGetScreenNameMapper implements RowMapper<String> {
		 public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		    	return rs.getString("screenName");	    
		    }
	}


	@Override
	public String getUserPassword(long userId) {
		String userPassword = "";		
		logger.debug("user Id ="+userId);	
		try{
			//userPassword = (String)jdbcTemplate.query(GET_USER_PASSWORD.replaceAll("\\?",userId+""),new ManageGetPasswordMapper()).get(0);
			userPassword = (String)jdbcTemplate.query(GET_USER_PASSWORD,new Long[]{userId},new ManageGetPasswordMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");
		}
		finally{		
			//logger.debug("password from DB="+userPassword);
		return userPassword;
		}
	}
	
	
	private static final class ManageGetPasswordMapper implements RowMapper<String> 
	{
		public String mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
	    	return rs.getString("password_");
	    }
	}
	
	@Override
	public String getPaymentType(String paymentType) {
		String shortPaymentType = "";
		try{
			//shortPaymentType = (String)jdbcSelfcareTemplate.query(GET_SHORT_PAYMENT_TYPE.replaceAll("\\?",paymentType+""),new ManageGetPaymentTypeMapper()).get(0);	
			shortPaymentType = (String)jdbcSelfcareTemplate.query(GET_SHORT_PAYMENT_TYPE,new String[]{paymentType},new ManageGetPaymentTypeMapper()).get(0);
			
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");
		}
		finally{	
			logger.debug("Short Payment Type from DB="+shortPaymentType);		
		return shortPaymentType;
		}
	}
	
	private static final class ManageGetPaymentTypeMapper implements RowMapper<String> 
	{
		public String mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
	    	return rs.getString("payment_type");
	    }
	}
	
	/*
	@Override
	public void insertPaymentDetails(OneOfPaymentVo oneOfPaymentVo) {
		// TODO Auto-generated method stub
		try{
			jdbcTemplate.update(INSERT_USER_PAYMNET_DETAILS,oneOfPaymentVo.getAccountNumber(),oneOfPaymentVo.getAmount(),oneOfPaymentVo.getTransactionDateTime(),oneOfPaymentVo.getCardNumber(),oneOfPaymentVo.getCardReference(),oneOfPaymentVo.getCurrencyCode(),oneOfPaymentVo.getPaymentReference(),oneOfPaymentVo.getPaymentType(),oneOfPaymentVo.getTransactionReference());			
		} catch(ArrayIndexOutOfBoundsException ae){
			ae.printStackTrace();
		}
	}

	@Override
	public OneOfPaymentVo getUserPaymentDetails(OneOfPaymentVo oneOfPaymentVo) {
		// TODO Auto-generated method stub
		OneOfPaymentVo oneOfPaymentResponse = new OneOfPaymentVo();		
		try{					
		oneOfPaymentResponse = jdbcTemplate.queryForObject(GET_USER_PAYMNET_DETAILS,  new ManageGetPaymentDetailsMapper(), oneOfPaymentVo.getAccountNumber());
		if(oneOfPaymentResponse != null){
			jdbcTemplate.update(UPDATE_USER_PAYMENT_DETAILS,oneOfPaymentVo.getAccountNumber(),oneOfPaymentResponse.getTransactionReference());
		}
		} catch(ArrayIndexOutOfBoundsException ae){
			ae.printStackTrace();
		}		
		finally{
			return oneOfPaymentResponse;
		}		
	}

	private static final class ManageGetPaymentDetailsMapper implements RowMapper<OneOfPaymentVo> {

	    public OneOfPaymentVo mapRow(ResultSet rs, int rowNum) throws SQLException {
	    
	    	OneOfPaymentVo oneOfPaymentVo = new OneOfPaymentVo();
	    	oneOfPaymentVo.setAccountNumber(rs.getString("account_number"));
	    	oneOfPaymentVo.setAmount(rs.getString("amount"));
	    	oneOfPaymentVo.setTransactionDateTime(rs.getString("transaction_datetime"));
	    	oneOfPaymentVo.setCardNumber(rs.getString("card_number"));
	    	oneOfPaymentVo.setCardReference(rs.getString("card_reference"));
	    	oneOfPaymentVo.setCurrencyCode(rs.getString("currency_code"));
	    	oneOfPaymentVo.setPaymentReference(rs.getString("payment_reference"));
	    	oneOfPaymentVo.setPaymentType(rs.getString("payment_type"));
	    	oneOfPaymentVo.setTransactionReference(rs.getString("transaction_reference"));
	        return oneOfPaymentVo;
	    }
	}
	*/

}


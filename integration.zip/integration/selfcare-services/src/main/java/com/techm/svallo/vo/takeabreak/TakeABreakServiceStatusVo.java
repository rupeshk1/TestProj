package com.techm.svallo.vo.takeabreak;

public class TakeABreakServiceStatusVo
{
	private String externalReference;
	private String tabServiceStatus;
	private String mrcServiceSum;
	private String takeABreakCounter;
	private String serviceCode;
    private String serviceCodes;
    
	public String getExternalReference()
	{
		return externalReference;
	}
	public void setExternalReference(String externalReference)
	{
		this.externalReference = externalReference;
	}
	public String getTabServiceStatus()
	{
		return tabServiceStatus;
	}
	public void setTabServiceStatus(String tabServiceStatus)
	{
		this.tabServiceStatus = tabServiceStatus;
	}
	public String getMrcServiceSum()
	{
		return mrcServiceSum;
	}
	public void setMrcServiceSum(String mrcServiceSum)
	{
		this.mrcServiceSum = mrcServiceSum;
	}
	public String getTakeABreakCounter()
	{
		return takeABreakCounter;
	}
	public void setTakeABreakCounter(String takeABreakCounter)
	{
		this.takeABreakCounter = takeABreakCounter;
	}
	public String getServiceCode()
	{
		return serviceCode;
	}
	public void setServiceCode(String serviceCode)
	{
		this.serviceCode = serviceCode;
	}
	public String getServiceCodes()
	{
		return serviceCodes;
	}
	public void setServiceCodes(String serviceCodes)
	{
		this.serviceCodes = serviceCodes;
	}
	
    
	
}

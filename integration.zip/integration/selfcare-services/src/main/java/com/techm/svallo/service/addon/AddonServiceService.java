package com.techm.svallo.service.addon;

import com.techm.svallo.vo.addon.AddonListVo;

public interface AddonServiceService {
	public AddonListVo getAddon(String accountNumber, String subscriptionNum);
	/* added boltonTypeName and servicePrice parameter in updateAddon for realtime changes */
	public String updateAddon(String serviceCode, String operation, String subscriptionNum, String boltonTypeName, String servicePrice, String reloadMethod, String unformattedNextinvoiceDate, boolean isPhase2User);
	public String getAddonMessage(String accountNumber, String subscriptionNum);
	public AddonListVo getApplicableAddon(String accountNumber, String subscriptionNum);
	public AddonListVo getExistingAddon(String accountNumber, String subscriptionNum, String unformattedNextinvoiceDate, String unformattedLastinvoiceDate);
	public String getUserPassword(long userId);
	public AddonListVo getRolloverAddons(String accountNumber, String subscriptionNum);
}

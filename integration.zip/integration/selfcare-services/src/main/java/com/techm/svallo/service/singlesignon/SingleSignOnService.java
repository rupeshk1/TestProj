package com.techm.svallo.service.singlesignon;

import com.techm.svallo.vo.singlesignon.SingleSignOnVo;

public interface SingleSignOnService {
	public SingleSignOnVo getSingleSignOnDetails(SingleSignOnVo singleSignOnVo);	
	public String getUsersPassword(String username);
	public String getUserNameSSO(String accountNum);
}

package com.techm.svallo.vo.dashboard;

public class UsageVo {

    private String data;
    private String mins;
    private String text;

    public String getData() {
        return data;
    }

    public void setData(String value) {
        this.data = value;
    }

    public String getMins() {
        return mins;
    }


    public void setMins(String value) {
        this.mins = value;
    }

 
    public String getText() {
        return text;
    }

    public void setText(String value) {
        this.text = value;
    }

}

package com.techm.svallo.vo.dashboard;

public class UpdateSubscriptionSerialNoVo {

    public String getExternalReference()
	{
		return externalReference;
	}
	public void setExternalReference(String externalReference)
	{
		this.externalReference = externalReference;
	}
	public String getManagedSerialNumber()
	{
		return managedSerialNumber;
	}
	public void setManagedSerialNumber(String managedSerialNumber)
	{
		this.managedSerialNumber = managedSerialNumber;
	}
	public String getManagedSerialNumberid()
	{
		return managedSerialNumberid;
	}
	public void setManagedSerialNumberid(String managedSerialNumberid)
	{
		this.managedSerialNumberid = managedSerialNumberid;
	}
	public String getNonManagedSerialNumber()
	{
		return nonManagedSerialNumber;
	}
	public void setNonManagedSerialNumber(String nonManagedSerialNumber)
	{
		this.nonManagedSerialNumber = nonManagedSerialNumber;
	}
	public String getNonManagedSerialNumberid()
	{
		return nonManagedSerialNumberid;
	}
	public void setNonManagedSerialNumberid(String nonManagedSerialNumberid)
	{
		this.nonManagedSerialNumberid = nonManagedSerialNumberid;
	}
	public String getSubscriptionNumber()
	{
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber)
	{
		this.subscriptionNumber = subscriptionNumber;
	}
	private String externalReference;
    private String managedSerialNumber;
    private String managedSerialNumberid;
    private String nonManagedSerialNumber;
    private String nonManagedSerialNumberid;
    private String subscriptionNumber;
	public String getExternalReferenceNo()
	{
		return externalReferenceNo;
	}
	public void setExternalReferenceNo(String externalReferenceNo)
	{
		this.externalReferenceNo = externalReferenceNo;
	}
	private String externalReferenceNo;


    

}

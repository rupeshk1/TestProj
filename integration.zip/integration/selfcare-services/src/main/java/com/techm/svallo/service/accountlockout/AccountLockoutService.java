package com.techm.svallo.service.accountlockout;

public interface AccountLockoutService {

	public String getAccountnumber(String userName);
	
}

package com.techm.svallo.vo.resetapppin;




public class ResetAppPinsVo 
{
	private String resetAppPinException="false";
	

	public String getResetAppPinException()
	{
		return resetAppPinException;
	}

	public void setResetAppPinException(String resetAppPinException)
	{
		resetAppPinException = resetAppPinException;
	}
	
	
		
	
}

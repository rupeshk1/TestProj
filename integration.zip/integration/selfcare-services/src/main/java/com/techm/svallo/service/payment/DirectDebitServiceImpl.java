package com.techm.svallo.service.payment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.payment.SvalloDirectDebitServiceException;
import com.techmahindra.online.svallo.model.payment._2014._09._01.AccountDetail;
import com.techmahindra.online.svallo.model.payment._2014._09._01.AccountServiceUpdateStatus;
import com.techmahindra.online.svallo.model.payment._2014._09._01.BankAccountValidatonStatus;
import com.techmahindra.online.svallo.model.payment._2014._09._01.DirectDebitDetail;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryValidateBankAccount;
import com.techmahindra.online.svallo.service.common.exception.payment.SvalloPaymentDirectDebitIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.payment.SvalloPaymentValidateDirectDebitIntegrationException;
import com.techmahindra.online.svallo.service.payment._2014._09._01.ManagePayment;

@Service("directDebitService")
public class DirectDebitServiceImpl implements DirectDebitService
{

	final static PortalLogger logger = PortalLogger.getLogger(DirectDebitServiceImpl.class);
	
	@Autowired
	private ManagePayment managePayment;
	
	@Value("${payment.directdebit.error.code}")
	private String PAYMENT_DIRECTDEBIT_ERROR_CODE;
	
	@Value("${payment.directdebit.error.message}")
	private String PAYMENT_DIRECTDEBIT_ERROR_MESSAGE;
	
	@Value("${billingandpayment.directdebit.update.error.code}")
	private String BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_CODE;
	
	@Value("${billingandpayment.directdebit.update.error.message}")
	private String BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_MESSAGE;
	
	@Value("${payment.directdebit.validation.error.code}")
	private String PAYMENT_DIRECTDEBIT_VALIDATION_ERROR_CODE;
	
	@Value("${payment.directdebit.validation.error.message}")
	private String PAYMENT_DIRECTDEBIT_VALIDATION_ERROR_MESSAGE;
	
	@Value("${billingandpayment.directdebit.validate.bank.account.error.code}")
	private String BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_CODE;
	
	@Value("${billingandpayment.directdebit.validate.bank.account.error.message}")
	private String BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_MESSAGE;
	
	private String DIRECT_DEBIT_DATASET="PAYMENT_DETAIL";
	
	

	@Override
	public AccountDetail getDirectDebit(QueryAccount queryAccount) throws SvalloDirectDebitServiceException
	{
		logger.debug("[ getDirectDebit() ] - START");
		AccountDetail accountDetail = null;
		try
		{
			if (queryAccount != null)
			{
				queryAccount.setResponseFilter(DIRECT_DEBIT_DATASET);
				accountDetail = managePayment.getDirectDebit(queryAccount);
				logger.debug("[ getDirectDebit() ] Got response from camel service,  accountDetail > " + accountDetail);
				logger.debug("[ getDirectDebit() ] Got response from camel service,  accountDetail > " + accountDetail);
			}
			logger.debug("[ getDirectDebit() ] - END");
		}
		catch(SvalloPaymentDirectDebitIntegrationException svalloPaymentDirectDebitIntegrationException)
		{
			logger.error(svalloPaymentDirectDebitIntegrationException,"[ getDirectDebit() ] SvalloPaymentDirectDebitIntegrationException Catch Block ");
			logger.error(svalloPaymentDirectDebitIntegrationException,"[ getDirectDebit() ] SvalloPaymentDirectDebitIntegrationException Catch Block | Error Code =  "+PAYMENT_DIRECTDEBIT_ERROR_CODE);
			logger.error(svalloPaymentDirectDebitIntegrationException,"[ getDirectDebit() ] SvalloPaymentDirectDebitIntegrationException Catch Block | Error Message  =  "+PAYMENT_DIRECTDEBIT_ERROR_MESSAGE);
			SvalloDirectDebitServiceException svalloDirectDebitServiceException = new SvalloDirectDebitServiceException();
			svalloDirectDebitServiceException.setErrorCode(PAYMENT_DIRECTDEBIT_ERROR_CODE);
			svalloDirectDebitServiceException.setErrorMessage(PAYMENT_DIRECTDEBIT_ERROR_MESSAGE);
			svalloDirectDebitServiceException.setRootCause(svalloPaymentDirectDebitIntegrationException);
			throw svalloDirectDebitServiceException;
		}
		catch(Exception exception)
		{
			logger.error(exception,"[ getDirectDebit() ] Exception catch block ");
			logger.error(exception,"[ getDirectDebit() ] Exception catch block | Error Code =  "+PAYMENT_DIRECTDEBIT_ERROR_CODE);
			logger.error(exception,"[ getDirectDebit() ] Exception catch block | Error Message  =  "+PAYMENT_DIRECTDEBIT_ERROR_MESSAGE);
			SvalloDirectDebitServiceException svalloDirectDebitServiceException = new SvalloDirectDebitServiceException();
			svalloDirectDebitServiceException.setErrorCode(PAYMENT_DIRECTDEBIT_ERROR_CODE);
			svalloDirectDebitServiceException.setErrorMessage(PAYMENT_DIRECTDEBIT_ERROR_MESSAGE);
			svalloDirectDebitServiceException.setRootCause(exception);
			throw svalloDirectDebitServiceException;
		}
		logger.debug("[ getDirectDebit() ] END");
		return accountDetail;
	}

	@Override
	public AccountServiceUpdateStatus updateDirectDebit(DirectDebitDetail directDebitDetail)
	{
		AccountServiceUpdateStatus accountServiceUpdateStatus = null;
		try
		{
			logger.debug("[ updateDirectDebit() ]- START");
			String nameOfPayer = directDebitDetail.getNameOfPayer();
			String bankAccountNumber = directDebitDetail.getBankAccountNumber();
			String bankSortCode = directDebitDetail.getBankSortCode();
			logger.debug("[ updateDirectDebit() ] directDebitDetail.nameOfPayer > " + nameOfPayer);
			logger.debug("[ updateDirectDebit() ] directDebitDetail.bankAccountNumber > " + bankAccountNumber);
			logger.debug("[ updateDirectDebit() ] directDebitDetail.bankSortCode > " + bankSortCode);
	
			logger.debug("[ updateDirectDebit() ] Calling service now....");
	
			accountServiceUpdateStatus = managePayment.updateDirectDebit(directDebitDetail);
			logger.debug("[ updateDirectDebit() ] Got Response from Camel service");
			String externalReference = accountServiceUpdateStatus.getExternalReference();
			logger.debug("[ updateDirectDebit() ] accountServiceUpdateStatus > " + accountServiceUpdateStatus);
			logger.debug("[ updateDirectDebit() ] externalReference > " + externalReference);
			logger.debug("[ updateDirectDebit() ]- END");
		}
		catch(SvalloPaymentDirectDebitIntegrationException svalloPaymentDirectDebitIntegrationException)
		{
			logger.error(svalloPaymentDirectDebitIntegrationException,"[ updateDirectDebit() ] SvalloPaymentDirectDebitIntegrationException Catch Block ");
			logger.error(svalloPaymentDirectDebitIntegrationException,"[ updateDirectDebit() ] SvalloPaymentDirectDebitIntegrationException Catch Block | Error Code =  "+BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_CODE);
			logger.error(svalloPaymentDirectDebitIntegrationException,"[ updateDirectDebit() ] SvalloPaymentDirectDebitIntegrationException Catch Block | Error Message  =  "+BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_MESSAGE);
			SvalloDirectDebitServiceException svalloDirectDebitServiceException = new SvalloDirectDebitServiceException();
			svalloDirectDebitServiceException.setErrorCode(BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_CODE);
			svalloDirectDebitServiceException.setErrorMessage(BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_MESSAGE);
			svalloDirectDebitServiceException.setRootCause(svalloPaymentDirectDebitIntegrationException);
			throw svalloDirectDebitServiceException;
		}
		catch(Exception exception)
		{
			logger.error(exception,"[ updateDirectDebit() ] Exception catch block ");
			logger.error(exception,"[ updateDirectDebit() ] Exception catch block | Error Code =  "+BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_CODE);
			logger.error(exception,"[ updateDirectDebit() ] Exception catch block | Error Message  =  "+BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_MESSAGE);
			SvalloDirectDebitServiceException svalloDirectDebitServiceException = new SvalloDirectDebitServiceException();
			svalloDirectDebitServiceException.setErrorCode(BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_CODE);
			svalloDirectDebitServiceException.setErrorMessage(BILLINGANDPAYMENT_DIRECTDEBIT_UPDATE_ERROR_MESSAGE);
			svalloDirectDebitServiceException.setRootCause(exception);
			throw svalloDirectDebitServiceException;
		}
		return accountServiceUpdateStatus;
	}

	@Override
	public BankAccountValidatonStatus validateBankAccount(QueryValidateBankAccount queryValidateBankAccount)
	{
		BankAccountValidatonStatus bankAccountValidatonStatus = null;
		try
		{
			logger.debug("[ validateBankAccount() ]- START");
			if (queryValidateBankAccount != null)
			{
				bankAccountValidatonStatus = managePayment.validateBankAccount(queryValidateBankAccount);
				logger.debug("[ validateBankAccount() ]   bankAccountValidatonStatus > " + bankAccountValidatonStatus);
			}
			logger.debug("[ validateBankAccount() ]   bankAccountValidatonStatus > " + bankAccountValidatonStatus);
			logger.debug("[ validateBankAccount() ]- END");
		}
		
		catch(SvalloPaymentValidateDirectDebitIntegrationException svalloPaymentValidateDirectDebitIntegrationException)
		{
			logger.error(svalloPaymentValidateDirectDebitIntegrationException,"[ validateBankAccount() ] SvalloPaymentValidateDirectDebitIntegrationException Catch Block ");
			logger.error(svalloPaymentValidateDirectDebitIntegrationException,"[ validateBankAccount() ] SvalloPaymentValidateDirectDebitIntegrationException Catch Block | Error Code =  "+BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_CODE);
			logger.error(svalloPaymentValidateDirectDebitIntegrationException,"[ validateBankAccount() ] SvalloPaymentValidateDirectDebitIntegrationException Catch Block | Error Message  =  "+BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_MESSAGE);
			SvalloDirectDebitServiceException svalloDirectDebitServiceException = new SvalloDirectDebitServiceException();
			svalloDirectDebitServiceException.setErrorCode(BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_CODE);
			svalloDirectDebitServiceException.setErrorMessage(BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_MESSAGE);
			svalloDirectDebitServiceException.setRootCause(svalloPaymentValidateDirectDebitIntegrationException);
			throw svalloDirectDebitServiceException;
		}
		catch(Exception exception)
		{
			logger.error(exception,"[ validateBankAccount() ] Exception catch block ");
			logger.error(exception,"[ validateBankAccount() ] Exception catch block | Error Code =  "+BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_CODE);
			logger.error(exception,"[ validateBankAccount() ] Exception catch block | Error Message  =  "+BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_MESSAGE);
			SvalloDirectDebitServiceException svalloDirectDebitServiceException = new SvalloDirectDebitServiceException();
			svalloDirectDebitServiceException.setErrorCode(BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_CODE);
			svalloDirectDebitServiceException.setErrorMessage(BILLINGANDPAYMENT_DIRECTDEBIT_VALIDATE_BANK_ACCOUNT_ERROR_MESSAGE);
			svalloDirectDebitServiceException.setRootCause(exception);
			throw svalloDirectDebitServiceException;
		}
		return bankAccountValidatonStatus;
	}

	public ManagePayment getManagePayment()
	{
		return managePayment;
	}

	public void setManagePayment(ManagePayment managePayment)
	{
		this.managePayment = managePayment;
	}

}

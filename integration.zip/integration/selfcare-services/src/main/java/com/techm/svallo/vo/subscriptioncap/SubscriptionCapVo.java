package com.techm.svallo.vo.subscriptioncap;

public class SubscriptionCapVo {
	
	private String subscriptionNumber;
	private String amount;
	private String unit;
	private String capCode;
	private String effectiveDate;
	private String value;
	private String externalReference;
	private String userDefinedCredit;
	private boolean cappedFlag;
	private String expiryDate;
	private String operation;
	private String unbar;
	private String topupCredit;
	
	//Phase2 Capping/Call Limit start
	/*private ContentVo contentVo;
	
	public ContentVo getContentVo() {
		return contentVo;
	}
	public void setContentVo(ContentVo contentVo) {
		this.contentVo = contentVo;
	}*/
	private String dataInternationalCap;
	private String dataRoamingCap;
	private String dataPremiumCap;
	private String textInternationalCap;
	private String textRoamingCap;
	private String textPremiumCap;
	private String voiceInternationalCap;
	private String voiceRoamingCap;
	private String voicePremiumCap;
	
	private String dataInternationalEffectiveDate;
	private String dataRoamingEffectiveDate;
	private String dataPremiumEffectiveDate;
	private String textInternationalEffectiveDate;
	private String textRoamingEffectiveDate;
	private String textPremiumEffectiveDate;
	private String voiceInternationalEffectiveDate;
	private String voiceRoamingEffectiveDate;
	private String voicePremiumEffectiveDate;
	
	public String getDataInternationalCap() {
		return dataInternationalCap;
	}
	public void setDataInternationalCap(String dataInternationalCap) {
		this.dataInternationalCap = dataInternationalCap;
	}
	public String getDataRoamingCap() {
		return dataRoamingCap;
	}
	public void setDataRoamingCap(String dataRoamingCap) {
		this.dataRoamingCap = dataRoamingCap;
	}
	public String getDataPremiumCap() {
		return dataPremiumCap;
	}
	public void setDataPremiumCap(String dataPremiumCap) {
		this.dataPremiumCap = dataPremiumCap;
	}
	public String getTextInternationalCap() {
		return textInternationalCap;
	}
	public void setTextInternationalCap(String textInternationalCap) {
		this.textInternationalCap = textInternationalCap;
	}
	public String getTextRoamingCap() {
		return textRoamingCap;
	}
	public void setTextRoamingCap(String textRoamingCap) {
		this.textRoamingCap = textRoamingCap;
	}
	public String getTextPremiumCap() {
		return textPremiumCap;
	}
	public void setTextPremiumCap(String textPremiumCap) {
		this.textPremiumCap = textPremiumCap;
	}
	public String getVoiceInternationalCap() {
		return voiceInternationalCap;
	}
	public void setVoiceInternationalCap(String voiceInternationalCap) {
		this.voiceInternationalCap = voiceInternationalCap;
	}
	public String getVoiceRoamingCap() {
		return voiceRoamingCap;
	}
	public void setVoiceRoamingCap(String voiceRoamingCap) {
		this.voiceRoamingCap = voiceRoamingCap;
	}
	public String getVoicePremiumCap() {
		return voicePremiumCap;
	}
	public void setVoicePremiumCap(String voicePremiumCap) {
		this.voicePremiumCap = voicePremiumCap;
	}	
	public String getDataInternationalEffectiveDate() {
		return dataInternationalEffectiveDate;
	}
	public void setDataInternationalEffectiveDate(
			String dataInternationalEffectiveDate) {
		this.dataInternationalEffectiveDate = dataInternationalEffectiveDate;
	}
	public String getDataRoamingEffectiveDate() {
		return dataRoamingEffectiveDate;
	}
	public void setDataRoamingEffectiveDate(String dataRoamingEffectiveDate) {
		this.dataRoamingEffectiveDate = dataRoamingEffectiveDate;
	}
	public String getDataPremiumEffectiveDate() {
		return dataPremiumEffectiveDate;
	}
	public void setDataPremiumEffectiveDate(String dataPremiumEffectiveDate) {
		this.dataPremiumEffectiveDate = dataPremiumEffectiveDate;
	}
	public String getTextInternationalEffectiveDate() {
		return textInternationalEffectiveDate;
	}
	public void setTextInternationalEffectiveDate(
			String textInternationalEffectiveDate) {
		this.textInternationalEffectiveDate = textInternationalEffectiveDate;
	}
	public String getTextRoamingEffectiveDate() {
		return textRoamingEffectiveDate;
	}
	public void setTextRoamingEffectiveDate(String textRoamingEffectiveDate) {
		this.textRoamingEffectiveDate = textRoamingEffectiveDate;
	}
	public String getTextPremiumEffectiveDate() {
		return textPremiumEffectiveDate;
	}
	public void setTextPremiumEffectiveDate(String textPremiumEffectiveDate) {
		this.textPremiumEffectiveDate = textPremiumEffectiveDate;
	}
	public String getVoiceInternationalEffectiveDate() {
		return voiceInternationalEffectiveDate;
	}
	public void setVoiceInternationalEffectiveDate(
			String voiceInternationalEffectiveDate) {
		this.voiceInternationalEffectiveDate = voiceInternationalEffectiveDate;
	}
	public String getVoiceRoamingEffectiveDate() {
		return voiceRoamingEffectiveDate;
	}
	public void setVoiceRoamingEffectiveDate(String voiceRoamingEffectiveDate) {
		this.voiceRoamingEffectiveDate = voiceRoamingEffectiveDate;
	}
	public String getVoicePremiumEffectiveDate() {
		return voicePremiumEffectiveDate;
	}
	public void setVoicePremiumEffectiveDate(String voicePremiumEffectiveDate) {
		this.voicePremiumEffectiveDate = voicePremiumEffectiveDate;
	}
	//Phase2 Capping/Call Limit end
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public boolean isCappedFlag() {
		return cappedFlag;
	}
	public void setCappedFlag(boolean cappedFlag) {
		this.cappedFlag = cappedFlag;
	}
	public String getUserDefinedCredit() {
		return userDefinedCredit;
	}
	public void setUserDefinedCredit(String userDefinedCredit) {
		this.userDefinedCredit = userDefinedCredit;
	}
	public String getSubscriptionNumber() {
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber) {
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getCapCode() {
		return capCode;
	}
	public void setCapCode(String capCode) {
		this.capCode = capCode;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getExternalReference() {
		return externalReference;
	}
	public void setExternalReference(String externalReference) {
		this.externalReference = externalReference;
	}
	public String getUnbar() {
		return unbar;
	}
	public void setUnbar(String unbar) {
		this.unbar = unbar;
	}
	public String getTopupCredit() {
		return topupCredit;
	}
	public void setTopupCredit(String topupCredit) {
		this.topupCredit = topupCredit;
	}
}

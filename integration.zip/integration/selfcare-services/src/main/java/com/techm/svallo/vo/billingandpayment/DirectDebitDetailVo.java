package com.techm.svallo.vo.billingandpayment;


public class DirectDebitDetailVo
{
	private String accountNumber="";
	private String bankaccountNumber="";
    private String banksortCode="";
    private String nameOfPayer="";
    private boolean termsAndConditions=false;
    private String directDebitUpdateStatus=null;
    private String billHistoryPeriod="";
    private String searchedBillFileCompletePath="";
    private String latestBillFileCompletePath="";
    private String paymentType;
    private String paymentTerms;
    private String lastAmendedDate;
    private String banksortCode1="";
    private String banksortCode2="";
    private String banksortCode3="";
    private String directDebitRecordFound="";
    
    
    
	public String getBanksortCode1()
	{
		return banksortCode1;
	}
	public void setBanksortCode1(String banksortCode1)
	{
		this.banksortCode1 = banksortCode1;
	}
	public String getBanksortCode2()
	{
		return banksortCode2;
	}
	public void setBanksortCode2(String banksortCode2)
	{
		this.banksortCode2 = banksortCode2;
	}
	public String getBanksortCode3()
	{
		return banksortCode3;
	}
	public void setBanksortCode3(String banksortCode3)
	{
		this.banksortCode3 = banksortCode3;
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getBankaccountNumber()
	{
		return bankaccountNumber;
	}
	public void setBankaccountNumber(String bankaccountNumber)
	{
		this.bankaccountNumber = bankaccountNumber;
	}
	public String getBanksortCode()
	{
		return banksortCode;
	}
	public void setBanksortCode(String banksortCode)
	{
		this.banksortCode = banksortCode;
	}
	public String getNameOfPayer()
	{
		return nameOfPayer;
	}
	public void setNameOfPayer(String nameOfPayer)
	{
		this.nameOfPayer = nameOfPayer;
	}
	public boolean isTermsAndConditions()
	{
		return termsAndConditions;
	}
	public void setTermsAndConditions(boolean termsAndConditions)
	{
		this.termsAndConditions = termsAndConditions;
	}
	public String getDirectDebitUpdateStatus()
	{
		return directDebitUpdateStatus;
	}
	public void setDirectDebitUpdateStatus(String directDebitUpdateStatus)
	{
		this.directDebitUpdateStatus = directDebitUpdateStatus;
	}
	public String getBillHistoryPeriod()
	{
		return billHistoryPeriod;
	}
	public void setBillHistoryPeriod(String billHistoryPeriod)
	{
		this.billHistoryPeriod = billHistoryPeriod;
	}
	public String getSearchedBillFileCompletePath()
	{
		return searchedBillFileCompletePath;
	}
	public void setSearchedBillFileCompletePath(String searchedBillFileCompletePath)
	{
		this.searchedBillFileCompletePath = searchedBillFileCompletePath;
	}
	public String getLatestBillFileCompletePath()
	{
		return latestBillFileCompletePath;
	}
	public void setLatestBillFileCompletePath(String latestBillFileCompletePath)
	{
		this.latestBillFileCompletePath = latestBillFileCompletePath;
	}
	public String getPaymentType()
	{
		return paymentType;
	}
	public void setPaymentType(String paymentType)
	{
		this.paymentType = paymentType;
	}
	public String getPaymentTerms()
	{
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms)
	{
		this.paymentTerms = paymentTerms;
	}
	public String getLastAmendedDate()
	{
		return lastAmendedDate;
	}
	public void setLastAmendedDate(String lastAmendedDate)
	{
		this.lastAmendedDate = lastAmendedDate;
	}
	public String getDirectDebitRecordFound() {
		return directDebitRecordFound;
	}
	public void setDirectDebitRecordFound(String directDebitRecordFound) {
		this.directDebitRecordFound = directDebitRecordFound;
	}
    
	
	
}

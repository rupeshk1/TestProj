package com.techm.svallo.service.payment;

import com.techmahindra.online.svallo.model.payment._2014._09._01.AccountDetail;
import com.techmahindra.online.svallo.model.payment._2014._09._01.AccountServiceUpdateStatus;
import com.techmahindra.online.svallo.model.payment._2014._09._01.BankAccountValidatonStatus;
import com.techmahindra.online.svallo.model.payment._2014._09._01.DirectDebitDetail;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryValidateBankAccount;

public interface DirectDebitService 
{
	public AccountDetail getDirectDebit(QueryAccount queryAccount);
	public AccountServiceUpdateStatus updateDirectDebit(DirectDebitDetail directDebitDetail);
	public BankAccountValidatonStatus validateBankAccount(QueryValidateBankAccount queryValidateBankAccount);
}

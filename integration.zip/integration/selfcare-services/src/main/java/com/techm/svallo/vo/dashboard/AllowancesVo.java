package com.techm.svallo.vo.dashboard;

public class AllowancesVo {

    private boolean bolton;
	private int boltonCount;
	
    private UsageVo available;
	private UsageVo used;
	private UsageVo rollover;
	private UsageVo recurring;
		
	public UsageVo getRecurring() {
		return recurring;
	}

	public void setRecurring(UsageVo recurring) {
		this.recurring = recurring;
	}

	public UsageVo getRollover() {
		return rollover;
	}

	public void setRollover(UsageVo rollover) {
		this.rollover = rollover;
	}

	public void setAvailable(UsageVo available){
		this.available = available;
	}
	
	public void setUsed(UsageVo used){
		this.used = used;
	}
 
	public UsageVo getAvailable(){
	return available;
	}
	
	public UsageVo getUsed(){
		return used;
	}
	
	public void setBolton(boolean flag){
	 this.bolton = flag;
	}
	
	public void setBoltonCount(int count){
		this.boltonCount = count;
	}
	
	public boolean isBolton(){
	 return bolton;
	}
	
	public int getBoltonCount(){
		return boltonCount;
	}
	
	
}

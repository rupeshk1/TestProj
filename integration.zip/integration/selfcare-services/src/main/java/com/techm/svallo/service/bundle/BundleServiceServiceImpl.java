package com.techm.svallo.service.bundle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.Bundle.SvalloBundleServiceException;
import com.techm.svallo.util.SelfCareUtil;
import com.techm.svallo.vo.bundle.BundleListVo;
import com.techm.svallo.vo.bundle.BundleVo;
import com.techmahindra.online.svallo.service.common.exception.bundle.SvalloBundleIntegrationException;
import com.techmahindra.online.svallo.service.vas.bundle._2015._09._14.BundleService;
import com.techmahindra.online.svallo.model.vas.bundle._2015._09._14.Service;
import com.techmahindra.online.svallo.model.vas.bundle._2015._09._14.Bundle;
import com.techmahindra.online.svallo.model.vas.bundle._2015._09._14.QueryBundleResponse;
import com.techmahindra.online.svallo.model.vas.bundle._2015._09._14.QueryBundleRequest;
import com.techmahindra.online.svallo.model.vas.bundle._2015._09._14.UpdateBundleRequest;
import com.techmahindra.online.svallo.model.vas.bundle._2015._09._14.UpdateBundleResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class BundleServiceServiceImpl implements BundleServiceService 
{
	final static PortalLogger logger = PortalLogger.getLogger(BundleServiceServiceImpl.class);
	
	@Autowired
	private BundleService bundleService;
	
	private JdbcTemplate jdbcTemplate=null;		
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Value("${bundle.updateBundle.add.error.message.detail}")
	private String BUNDLE_UPDATEBUNDLE_ADD_ERROR_MESSAGE_DETAIL;
	
	@Value("${bundle.updateBundle.remove.error.message.detail}")
	private String BUNDLE_UPDATEBUNDLE_REMOVE_ERROR_MESSAGE_DETAIL;
	
	@Value("${bundle.getBundle.error.message.detail}")
	private String BUNDLE_GETBUNDLE_ERROR_MESSAGE_DETAIL;
	
	
	@Value("${bundle.impl.updatebundle.error.code}")
	private String BUNDLE_IMPL_UPDATEBUNDLE_ERROR_CODE;
	
	@Value("${bundle.impl.updatebundle.error.message}")
	private String BUNDLE_IMPL_UPDATEBUNDLE_ERROR_MESSAGE;
	
	@Value("${bundle.impl.updatebundle.exception.code}")
	private String BUNDLE_IMPL_UPDATEBUNDLE_EXCEPTION_CODE;
	
	@Value("${bundle.impl.updatebundle.exception.message}")
	private String BUNDLE_IMPL_UPDATEBUNDLE_EXCEPTION_MESSAGE;   
		
	
	@Value("${bundle.impl.getapplicablebundle.error.code}")
	private String BUNDLE_IMPL_GETAPPLICABLEBUNDLE_ERROR_CODE;
	
	@Value("${bundle.impl.getapplicablebundle.error.message}")
	private String BUNDLE_IMPL_GETAPPLICABLEBUNDLE_ERROR_MESSAGE;
	
	@Value("${bundle.impl.getapplicablebundle.exception.code}")
	private String BUNDLE_IMPL_GETAPPLICABLEBUNDLE_EXCEPTION_CODE;
	
	@Value("${bundle.impl.getapplicablebundle.exception.message}")
	private String BUNDLE_IMPL_GETAPPLICABLEBUNDLE_EXCEPTION_MESSAGE;
		
	
	@Value("${bundle.impl.getexistingbundle.error.code}")
	private String BUNDLE_IMPL_GETEXISTINGBUNDLE_ERROR_CODE;
	
	@Value("${bundle.impl.getexistingbundle.error.message}")
	private String BUNDLE_IMPL_GETEXISTINGBUNDLE_ERROR_MESSAGE;
	
	@Value("${bundle.impl.getexistingbundle.exception.code}")
	private String BUNDLE_IMPL_GETEXISTINGBUNDLE_EXCEPTION_CODE;
	
	@Value("${bundle.impl.getexistingbundle.exception.message}")
	private String BUNDLE_IMPL_GETEXISTINGBUNDLE_EXCEPTION_MESSAGE;
	
	
	private static String GET_USER_PASSWORD = "select password_ from User_ where userId=?;";
	
	NumberFormat decimalformatter = new DecimalFormat("#0.00"); 
	
	public BundleListVo getBundle(String accountNumber, String subscriptionNum)
    {
		/*BundleListVo bundleListVo = new BundleListVo();
		List<BundleVo> existingBundleVos = new ArrayList<BundleVo>();
		List<BundleVo> applicableBundleVos = new ArrayList<BundleVo>();
		List<BundleVo> pendingBundleVos = new ArrayList<BundleVo>();
		Set<String> bundleTypes = new HashSet<String>();
		Set<String> applicableBundleTypes = new HashSet<String>();
		
		QueryBundleRequest queryBundleRequest = new QueryBundleRequest();
		queryBundleRequest.setAccountNumber(accountNumber);
		QueryBundleResponse queryBundleResponse = bundleService.getBundle(queryBundleRequest);
		
		Service allBundles = queryBundleResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getBundles().get(0);
		List<Bundle> existingBundles = allBundles.getExistingBundle().getBundle();
		List<Bundle> applicableBundles = allBundles.getApplicableBundle().getBundle();
		List<Bundle> pendingBundles = allBundles.getPendingBundle().getBundle();
		
		BundleVo bundleVo;
		
		for(Bundle existingBundle : existingBundles)
		{
			bundleVo = new BundleVo();
			bundleVo.setServiceCode(existingBundle.getProductId());
			bundleVo.setBundleName(existingBundle.getProductName());
			bundleVo.setBundleDescription(existingBundle.getProductDescription());
			bundleVo.setBundleExtendedDescription(existingBundle.getProductLongDescription());
			bundleVo.setBundleType(existingBundle.getProductType());
			bundleVo.setBundlePrice(existingBundle.getProductPrice());
			existingBundleVos.add(bundleVo);
			bundleTypes.add(existingBundle.getProductType());
		}
		
		for(Bundle applicableBundle : applicableBundles)
		{
			bundleVo = new BundleVo();
			bundleVo.setServiceCode(applicableBundle.getProductId());
			bundleVo.setBundleName(applicableBundle.getProductName());
			bundleVo.setBundleDescription(applicableBundle.getProductDescription());
			bundleVo.setBundleExtendedDescription(applicableBundle.getProductLongDescription());
			bundleVo.setBundleType(applicableBundle.getProductType());
			bundleVo.setBundlePrice(applicableBundle.getProductPrice());
			applicableBundleVos.add(bundleVo);
			bundleTypes.add(applicableBundle.getProductType());
			applicableBundleTypes.add(applicableBundle.getProductType());
		}
		
		for(Bundle pendingBundle : pendingBundles)
		{
			bundleVo = new BundleVo();
			bundleVo.setServiceCode(pendingBundle.getProductId());
			bundleVo.setBundleName(pendingBundle.getProductName());
			bundleVo.setBundleDescription(pendingBundle.getProductDescription());
			bundleVo.setBundleExtendedDescription(pendingBundle.getProductLongDescription());
			bundleVo.setBundleType(pendingBundle.getProductType());
			bundleVo.setBundlePrice(pendingBundle.getProductPrice());
			pendingBundleVos.add(bundleVo);
			bundleTypes.add(pendingBundle.getProductType());
		}
		
		bundleListVo.setExistingBundles(existingBundleVos);
		bundleListVo.setApplicableBundles(applicableBundleVos);
		bundleListVo.setPendingBundles(pendingBundleVos);
		bundleListVo.setBundleTypes(bundleTypes);
		bundleListVo.setApplicableBundleTypes(applicableBundleTypes);
		
		return bundleListVo;*/
		return null;
	}
	
	public String getBundleMessage(String accountNumber, String subscriptionNum)
    {
		QueryBundleRequest queryBundleRequest = new QueryBundleRequest();
		queryBundleRequest.setAccountNumber(accountNumber);
		queryBundleRequest.setTodaysDate(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()));
		queryBundleRequest.setCustomerLevel(subscriptionNum);
		QueryBundleResponse queryBundleResponse = bundleService.getBundle(queryBundleRequest);
		
		boolean atLeastOneBundle = false;
		String bundleMessage = "You have ";
		
		if(queryBundleResponse != null){
			Service allBundles = queryBundleResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getBundles().get(0);
			List<Bundle> existingBundles = allBundles.getExistingBundle().getBundle();
			
			HashSet<String> existingBundleTypes = new HashSet<String>();
			HashMap<String, Integer> existingBundleTypesAndSizes = new HashMap<String, Integer>();
			
			for(Bundle existingBundle : existingBundles)
			{
				if(existingBundleTypes.add(existingBundle.getProductType()))
				{
					existingBundleTypesAndSizes.put(existingBundle.getProductType(), 1);
				}
				else
				{
					int bundleSize = existingBundleTypesAndSizes.get(existingBundle.getProductType()) + 1;
					existingBundleTypesAndSizes.remove(existingBundle.getProductType());
					existingBundleTypesAndSizes.put(existingBundle.getProductType(), bundleSize);
				}
			}
			
		
			
			for(Map.Entry<String, Integer> existingBundleTypeAndSize : existingBundleTypesAndSizes.entrySet())
			{
				if(!atLeastOneBundle)
				{
					atLeastOneBundle = true;
					bundleMessage += existingBundleTypeAndSize.getValue() + " " + existingBundleTypeAndSize.getKey();
				}
				else
					bundleMessage += ", " + existingBundleTypeAndSize.getValue() + " " + existingBundleTypeAndSize.getKey();
			}
		}
		if(!atLeastOneBundle)
			bundleMessage += "not subscribed to any Bundle";
		else
			bundleMessage += " Bundle(s)";
			
		return bundleMessage;
	}
	
	public String updateBundle(String serviceCode, String operation, String subscriptionNum, String bundleTypeName, String servicePrice, String reloadMethod)
	{
		UpdateBundleResponse updateBundleResponse = new UpdateBundleResponse();
	  try 
	   {
		UpdateBundleRequest updateBundleRequest = new UpdateBundleRequest();
		updateBundleRequest.setServiceCode(serviceCode);
		updateBundleRequest.setOperation(operation);
		updateBundleRequest.setSubscriptionNumber(subscriptionNum);
		updateBundleRequest.setEffectiveDate(new SimpleDateFormat("yyyy-MM-dd'Z'").format(Calendar.getInstance().getTime()));
		/* passing two more values in updateBundleRequest for realtime changes */ 
		updateBundleRequest.setDescription(bundleTypeName);
		updateBundleRequest.setServicePrice(servicePrice);
		updateBundleRequest.setReloadMethod(reloadMethod);
		
		updateBundleResponse = bundleService.updateBundle(updateBundleRequest);
	   } 
	   catch (SvalloBundleIntegrationException saoie) {		  
		  logger.error(saoie,"\n[ BundleServiceServiceImpl | updateBundle() ] SvalloBundleServiceException Catch Block ");
		  logger.error(saoie,"\n[ BundleServiceServiceImpl | updateBundle() ] SvalloBundleServiceException Catch Block | Error Code ="+ BUNDLE_IMPL_UPDATEBUNDLE_ERROR_CODE);
		  logger.error(saoie,"\n[ BundleServiceServiceImpl | updateBundle() ] SvalloBundleServiceException Catch Block | Error Message ="+ BUNDLE_IMPL_UPDATEBUNDLE_ERROR_MESSAGE);
		  SvalloBundleServiceException svalloBundleServiceException = new SvalloBundleServiceException();
		  svalloBundleServiceException.setErrorCode(BUNDLE_IMPL_UPDATEBUNDLE_ERROR_CODE);
		  svalloBundleServiceException.setErrorMessage(BUNDLE_IMPL_UPDATEBUNDLE_ERROR_MESSAGE);
		  svalloBundleServiceException.setRootCause(saoie);
		  //saoie.printStackTrace();
		  if(operation.equalsIgnoreCase("add")){
		     updateBundleResponse.setResponseStatus(BUNDLE_UPDATEBUNDLE_ADD_ERROR_MESSAGE_DETAIL);
		  }else{
			  updateBundleResponse.setResponseStatus(BUNDLE_UPDATEBUNDLE_REMOVE_ERROR_MESSAGE_DETAIL); 
		  }
	  }
	  catch (Exception e) {		  
		  logger.error(e,"\n[ BundleServiceServiceImpl | updateBundle() ] Exception Catch Block");
		  logger.error(e,"\n[ BundleServiceServiceImpl | updateBundle() ] Exception Catch Block | Error Code ="+ BUNDLE_IMPL_UPDATEBUNDLE_EXCEPTION_CODE);
		  logger.error(e,"\n[ BundleServiceServiceImpl | updateBundle() ] Exception Catch Block | Error Message ="+ BUNDLE_IMPL_UPDATEBUNDLE_EXCEPTION_MESSAGE);
		  SvalloBundleServiceException svalloBundleServiceException = new SvalloBundleServiceException();
		  svalloBundleServiceException.setErrorCode(BUNDLE_IMPL_UPDATEBUNDLE_EXCEPTION_CODE);
		  svalloBundleServiceException.setErrorMessage(BUNDLE_IMPL_UPDATEBUNDLE_EXCEPTION_MESSAGE);
		  svalloBundleServiceException.setRootCause(e);
		  //e.printStackTrace();
		  if(operation.equalsIgnoreCase("add")){
		     updateBundleResponse.setResponseStatus(BUNDLE_UPDATEBUNDLE_ADD_ERROR_MESSAGE_DETAIL);
		  }else{
			  updateBundleResponse.setResponseStatus(BUNDLE_UPDATEBUNDLE_REMOVE_ERROR_MESSAGE_DETAIL); 
		  }
	  }
		return updateBundleResponse.getResponseStatus();
	}
	
	public BundleService getBundleService()
	{
		return bundleService;
	}

	public void setBundleService(BundleService bundleService)
	{
		this.bundleService = bundleService;
	}


	public BundleListVo getApplicableBundle(String accountNumber, String subscriptionNum)
	
	{
		BundleListVo bundleListVo = new BundleListVo();	
		List<BundleVo> applicableBundleVos = new ArrayList<BundleVo>();		
		Set<String> bundleTypes = new HashSet<String>();
		try{
		QueryBundleRequest queryBundleRequest = new QueryBundleRequest();
		queryBundleRequest.setAccountNumber(accountNumber);
		queryBundleRequest.setTodaysDate(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()));
		queryBundleRequest.setCustomerLevel(subscriptionNum);
		QueryBundleResponse queryBundleResponse = bundleService.getBundle(queryBundleRequest);
		
		if(queryBundleResponse != null){
		Service allBundles = queryBundleResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getBundles().get(0);		
		List<Bundle> applicableBundles = allBundles.getApplicableBundle().getBundle();		
		

	
		BundleVo bundleVo;

		for(Bundle applicableBundle : applicableBundles)
		{
			bundleVo = new BundleVo();
			bundleVo.setServiceCode(applicableBundle.getProductId());
			bundleVo.setBundleName(applicableBundle.getProductName());
			bundleVo.setBundleDescription(applicableBundle.getProductDescription());
			bundleVo.setBundleExtendedDescription(applicableBundle.getProductLongDescription());
			bundleVo.setBundleType(applicableBundle.getProductType());
			bundleVo.setBundlePrice(applicableBundle.getProductPrice());			
			bundleVo.setBundleServicePrice(decimalformatter.format(Double.valueOf(applicableBundle.getBundleServicePrice())));	
			//using bundle service price value in addbotons page
			
			// getting recurring value from service and setting in bundle vo for realtime changes  
			bundleVo.setRecurring(applicableBundle.getRecurring());
			bundleVo.setBundleMinutes(applicableBundle.getMinutes());
			bundleVo.setBundleTexts(applicableBundle.getTexts());
			bundleVo.setBundleData(applicableBundle.getData());
			bundleVo.setBundleDays(applicableBundle.getDays());
			bundleVo.setBundleEndDate(SelfCareUtil.getFutureDateFromDays(bundleVo.getBundleDays()));
			applicableBundleVos.add(bundleVo);
			bundleTypes.add(applicableBundle.getProductType());			
		}		
		
		bundleListVo.setApplicableBundles(applicableBundleVos);		
		bundleListVo.setBundleTypes(bundleTypes);
			}
		}
		catch(SvalloBundleIntegrationException saoie){			
			logger.error(saoie,"\n[ BundleServiceServiceImpl | getApplicableBundle() ] SvalloBundleServiceException Catch Block");
			logger.error(saoie,"\n[ BundleServiceServiceImpl | getApplicableBundle() ] SvalloBundleServiceException Catch Block | Error Code ="+ BUNDLE_IMPL_GETAPPLICABLEBUNDLE_ERROR_CODE);
			logger.error(saoie,"\n[ BundleServiceServiceImpl | getApplicableBundle() ] SvalloBundleServiceException Catch Block | Error Message ="+ BUNDLE_IMPL_GETAPPLICABLEBUNDLE_ERROR_MESSAGE);
			SvalloBundleServiceException svalloBundleServiceException = new SvalloBundleServiceException();
			svalloBundleServiceException.setErrorCode(BUNDLE_IMPL_GETAPPLICABLEBUNDLE_ERROR_CODE);
			svalloBundleServiceException.setErrorMessage(BUNDLE_IMPL_GETAPPLICABLEBUNDLE_ERROR_MESSAGE);
			svalloBundleServiceException.setRootCause(saoie);
			//saoie.printStackTrace();
		    bundleListVo.setBundleError(BUNDLE_GETBUNDLE_ERROR_MESSAGE_DETAIL);
		}
		catch(Exception e){			
			logger.error(e,"\n[ BundleServiceServiceImpl | getApplicableBundle() ] Exception Catch Block");
			logger.error(e,"\n[ BundleServiceServiceImpl | getApplicableBundle() ] Exception Catch Block | Error Code ="+ BUNDLE_IMPL_GETAPPLICABLEBUNDLE_EXCEPTION_CODE);
			logger.error(e,"\n[ BundleServiceServiceImpl | getApplicableBundle() ] Exception Catch Block | Error Message ="+ BUNDLE_IMPL_GETAPPLICABLEBUNDLE_EXCEPTION_MESSAGE);
			SvalloBundleServiceException svalloBundleServiceException = new SvalloBundleServiceException();
			svalloBundleServiceException.setErrorCode(BUNDLE_IMPL_GETAPPLICABLEBUNDLE_EXCEPTION_CODE);
			svalloBundleServiceException.setErrorMessage(BUNDLE_IMPL_GETAPPLICABLEBUNDLE_EXCEPTION_MESSAGE);
			svalloBundleServiceException.setRootCause(e);
			//e.printStackTrace();
		    bundleListVo.setBundleError(BUNDLE_GETBUNDLE_ERROR_MESSAGE_DETAIL);
		}
		return bundleListVo;
	}


	public BundleListVo getExistingBundle(String accountNumber, String subscriptionNum)
	{
		BundleListVo bundleListVo = new BundleListVo();
		List<BundleVo> existingBundleVos = new ArrayList<BundleVo>();		
		Set<String> bundleTypes = new HashSet<String>();		
		
		try{
		QueryBundleRequest queryBundleRequest = new QueryBundleRequest();
		queryBundleRequest.setAccountNumber(accountNumber);
		queryBundleRequest.setTodaysDate(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()));
		queryBundleRequest.setCustomerLevel(subscriptionNum);
		QueryBundleResponse queryBundleResponse = bundleService.getBundle(queryBundleRequest);
		
		if(queryBundleResponse != null){
			Service allBundles = queryBundleResponse.getCustomerSubscriptionInfo().getAccount().get(0).getSubscriptions().get(0).getBundles().get(0);
			List<Bundle> existingBundles = allBundles.getExistingBundle().getBundle();
			
			BundleVo bundleVo;
			String onlyDays = "";
				for(Bundle existingBundle : existingBundles)
				{
					onlyDays = "";
					bundleVo = new BundleVo();			
					bundleVo.setServiceCode(existingBundle.getProductId());
					bundleVo.setBundleName(existingBundle.getProductName());
					bundleVo.setBundleDescription(existingBundle.getProductDescription());
					bundleVo.setBundleExtendedDescription(existingBundle.getProductLongDescription());
					bundleVo.setBundleType(existingBundle.getProductType());
					bundleVo.setBundlePrice(existingBundle.getProductPrice());			
					bundleVo.setBundleServicePrice(existingBundle.getBundleServicePrice());			
					//bundleVo.setBundleEffectiveDate(existingBundle.getStartDate());			
					bundleVo.setBundleEffectiveDate(SelfCareUtil.getBoltOnFormattedDate(existingBundle.getStartDate()));
					/* getting recurring value from service and setting in bundle vo for realtime changes  */
					bundleVo.setRecurring(existingBundle.getRecurring());
					bundleVo.setBundleData(existingBundle.getData());
					
					/*
					int indexOfDash = existingBundle.getDays().indexOf(' ');
				     onlyDays = existingBundle.getDays().substring(0, indexOfDash);
				     if("Unlimited".equalsIgnoreCase(onlyDays)){
				    	 bundleVo.setBundleRenewsExpireValue("Unltd");
				     }else{
				    	 bundleVo.setBundleRenewsExpireValue(String.valueOf(Integer.parseInt(onlyDays)-Integer.parseInt(SelfCareUtil.getDatediffernce(existingBundle.getStartDate()))));
				     }
				     
				     */					
					bundleVo.setBundleRenewsExpireValue(SelfCareUtil.getDatediffernce(existingBundle.getExpiryDate()));
					bundleVo.setBundlebarGraphTotalValue(SelfCareUtil.getdaysdiffernceBetnTwoDates(existingBundle.getStartDate(), existingBundle.getExpiryDate()));
					
					bundleVo.setBundleMinutes(existingBundle.getMinutes());
					bundleVo.setBundleTexts(existingBundle.getTexts());
					bundleVo.setBundleDays(existingBundle.getDays());
					bundleVo.setBundleEndDate(SelfCareUtil.getFutureDateFromDays(bundleVo.getBundleDays()));
					
					bundleVo.setBundleDataAvailableAmount(existingBundle.getBundleDataAvailableAmount());
					bundleVo.setBundleDataLastGrantAmount(existingBundle.getBundleDataLastGrantAmount());
					bundleVo.setBundleDataBalanceAmount(existingBundle.getBundleDataBalanceAmount());
					
					bundleVo.setBundleMinutesAvailableAmount(existingBundle.getBundleMinutesAvailableAmount());
					bundleVo.setBundleMinutesLastGrantAmount(existingBundle.getBundleMinutesLastGrantAmount());
					bundleVo.setBundleMinutesBalanceAmount(existingBundle.getBundleMinutesBalanceAmount());
					
					bundleVo.setBundleTextAvailableAmount(existingBundle.getBundleTextAvailableAmount());
					bundleVo.setBundleTextLastGrantAmount(existingBundle.getBundleTextLastGrantAmount());
					bundleVo.setBundleTextBalanceAmount(existingBundle.getBundleTextBalanceAmount());
					
					/*bundleVo.setBundleTotalAvailableAmount();
					bundleVo.setBundleTotalLastGrantAmount();
					bundleVo.setBundleTotalBalanceAmount();*/
					
					
					
					/*bundleVo.setBundleAvaiableAmount(existingBundle.getBundleAvailableAmount());
					bundleVo.setBundleRemainingValue(existingBundle.getBundleAvailableAmount());
					bundleVo.setBundleAllowanceValue(existingBundle.getBundleAvailableAmount());
					bundleVo.setBundleLastGrantAmount(existingBundle.getBundleLastGrantAmount());		
					bundleVo.setBundleUsedValue(String.valueOf(!"".equals(existingBundle.getBundleAvailableAmount()) ? Double.parseDouble(existingBundle.getBundleLastGrantAmount()) - Double.parseDouble(existingBundle.getBundleAvailableAmount()) : ""));			
					
					bundleVo.setBundleTotalValue(String.valueOf(!"".equals(existingBundle.getBundleAvailableAmount()) ? Double.parseDouble(bundleVo.getBundleRemainingValue()) + Double.parseDouble(bundleVo.getBundleUsedValue()) : ""));*/
					
					existingBundleVos.add(bundleVo);
					bundleTypes.add(existingBundle.getProductType());
				}
	
			  bundleListVo.setExistingBundles(existingBundleVos);		
			  bundleListVo.setBundleTypes(bundleTypes);	
			}
		}
		catch(SvalloBundleIntegrationException saoie){		 
		 logger.error(saoie,"\n[ BundleServiceServiceImpl | getExistingBundle() ] SvalloBundleServiceException Catch Block");
		 logger.error(saoie,"\n[ BundleServiceServiceImpl | getExistingBundle() ] SvalloBundleServiceException Catch Block | Error Code ="+ BUNDLE_IMPL_GETEXISTINGBUNDLE_ERROR_CODE);
		 logger.error(saoie,"\n[ BundleServiceServiceImpl | getExistingBundle() ] SvalloBundleServiceException Catch Block | Error Message ="+ BUNDLE_IMPL_GETEXISTINGBUNDLE_ERROR_MESSAGE);
		 SvalloBundleServiceException svalloBundleServiceException = new SvalloBundleServiceException();
		 svalloBundleServiceException.setErrorCode(BUNDLE_IMPL_GETEXISTINGBUNDLE_ERROR_CODE);
		 svalloBundleServiceException.setErrorMessage(BUNDLE_IMPL_GETEXISTINGBUNDLE_ERROR_MESSAGE);
		 svalloBundleServiceException.setRootCause(saoie);
		 //saoie.printStackTrace();		
		 bundleListVo.setBundleError(BUNDLE_GETBUNDLE_ERROR_MESSAGE_DETAIL);
		}
		catch(Exception e){		
		 logger.error(e,"\n[ BundleServiceServiceImpl | getExistingBundle() ] Exception Catch Block");
		 logger.error(e,"\n[ BundleServiceServiceImpl | getExistingBundle() ] Exception Catch Block | Error Code ="+ BUNDLE_IMPL_GETEXISTINGBUNDLE_EXCEPTION_CODE);
		 logger.error(e,"\n[ BundleServiceServiceImpl | getExistingBundle() ] Exception Catch Block | Error Message ="+ BUNDLE_IMPL_GETEXISTINGBUNDLE_EXCEPTION_MESSAGE);
		 SvalloBundleServiceException svalloBundleServiceException = new SvalloBundleServiceException();
		 svalloBundleServiceException.setErrorCode(BUNDLE_IMPL_GETEXISTINGBUNDLE_EXCEPTION_CODE);
		 svalloBundleServiceException.setErrorMessage(BUNDLE_IMPL_GETEXISTINGBUNDLE_EXCEPTION_MESSAGE);
		 svalloBundleServiceException.setRootCause(e);
		 //e.printStackTrace();		
		 bundleListVo.setBundleError(BUNDLE_GETBUNDLE_ERROR_MESSAGE_DETAIL);
		}
		return bundleListVo;
	}
	
	public String getUserPassword(long userId) {
		String userPassword = "";		
		logger.debug("user Id ="+userId);
		//logger.debug("Query="+GET_USER_PASSWORD);
		try{
			//userPassword = (String)jdbcTemplate.query(GET_USER_PASSWORD.replaceAll("\\?",userId+""),new ManageGetPasswordMapper()).get(0);			
			userPassword = (String)jdbcTemplate.query(GET_USER_PASSWORD,new Long[]{userId},new ManageGetPasswordMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){			
			logger.error(ae,"Array Index out of bound exception");
		}
		finally{			
			//logger.debug("password from DB="+userPassword);
		return userPassword;
		}
	}
	
	private static final class ManageGetPasswordMapper implements RowMapper<String> 
	{
		public String mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
	    	return rs.getString("password_");
	    }
	}
}
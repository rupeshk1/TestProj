package com.techm.svallo.service.registration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.vo.registration.RegistrationVo;
import com.techmahindra.online.svallo.model.registration_login._2014._08._22.Account;
import com.techmahindra.online.svallo.model.registration_login._2014._08._22.Resend;
import com.techmahindra.online.svallo.service.common.exception.registration.SvalloRegistrationIntegrationException;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.ResendEmailResponse;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloDisconnectedAccountRequest;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloDisconnectedAccountResponse;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloPreRegistrationRequest;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloPreRegistrationResponse;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloRegistrationLogin;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloRegistrationRequest;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloRegistrationResponse;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloResendPreRegistrationEmailRequest;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloResendPreRegistrationEmailResponse;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloResendPreRegistrationPINRequest;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloResendPreRegistrationPINResponse;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloSaveRegistrationDetailsRequest;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloSaveRegistrationDetailsResponse;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloValidatePINRequest;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloValidatePINResponse;

import com.techm.svallo.exception.service.registration.SvalloRegistrationServiceException;
import com.techm.svallo.util.SelfCareUtil;

public class RegistrationServiceImpl implements RegistrationService
{
	final static PortalLogger logger = PortalLogger.getLogger(RegistrationServiceImpl.class);	
	
	@Autowired
	private SvalloRegistrationLogin  svalloRegistrationLogin;
	
	public void setSvalloRegistrationLogin(SvalloRegistrationLogin svalloRegistrationLogin) {
		this.svalloRegistrationLogin = svalloRegistrationLogin;
	}

	@Value("${registration.data.not.available}")
	private String REGISTRATION_DATA_NOT_AVAILABLE;
	
	
	@Value("${registration.impl.getPreRegistrationDetails.error.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_ERROR_CODE;
	
	@Value("${registration.impl.getPreRegistrationDetails.error.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_ERROR_MESSAGE;
	
	@Value("${registration.impl.getPreRegistrationDetails.exception.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_EXCEPTION_CODE;
	
	@Value("${registration.impl.getPreRegistrationDetails.exception.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${registration.impl.getRegistrationDetails.error.code}")
	private String REGISTRATION_IMPL_GETREGISTRATIONDETAILS_ERROR_CODE;
	
	@Value("${registration.impl.getRegistrationDetails.error.message}")
	private String REGISTRATION_IMPL_GETREGISTRATIONDETAILS_ERROR_MESSAGE;
	
	@Value("${registration.impl.getRegistrationDetails.exception.code}")
	private String REGISTRATION_IMPL_GETREGISTRATIONDETAILS_EXCEPTION_CODE;
	
	@Value("${registration.impl.getRegistrationDetails.exception.message}")
	private String REGISTRATION_IMPL_GETREGISTRATIONDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${registration.impl.getSaveRegistrationDetails.error.code}")
	private String REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_ERROR_CODE;
	
	@Value("${registration.impl.getSaveRegistrationDetails.error.message}")
	private String REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_ERROR_MESSAGE;
	
	@Value("${registration.impl.getSaveRegistrationDetails.exception.code}")
	private String REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_EXCEPTION_CODE;
	
	@Value("${registration.impl.getSaveRegistrationDetails.exception.message}")
	private String REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${registration.impl.getPreRegistrationResendPinDetails.error.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_ERROR_CODE;
	
	@Value("${registration.impl.getPreRegistrationResendPinDetails.error.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_ERROR_MESSAGE;
	
	@Value("${registration.impl.getPreRegistrationResendPinDetails.exception.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_EXCEPTION_CODE;
	
	@Value("${registration.impl.getPreRegistrationResendPinDetails.exception.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_EXCEPTION_MESSAGE;	
	
	
	@Value("${registration.impl.getPreRegistrationResendEmailDetails.error.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_ERROR_CODE;
	
	@Value("${registration.impl.getPreRegistrationResendEmailDetails.error.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_ERROR_MESSAGE;
	
	@Value("${registration.impl.getPreRegistrationResendEmailDetails.exception.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_EXCEPTION_CODE;
	
	@Value("${registration.impl.getPreRegistrationResendEmailDetails.exception.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${registration.impl.getPreRegistrationResendEmail.error.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_ERROR_CODE;
	
	@Value("${registration.impl.getPreRegistrationResendEmail.error.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_ERROR_MESSAGE;
	
	@Value("${registration.impl.getPreRegistrationResendEmail.exception.code}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_EXCEPTION_CODE;
	
	@Value("${registration.impl.getPreRegistrationResendEmail.exception.message}")
	private String REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_EXCEPTION_MESSAGE;
	
	
	@Value("${registration.impl.getDisconnectedAccountDetails.error.code}")
	private String REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_ERROR_CODE;
	
	@Value("${registration.impl.getDisconnectedAccountDetails.error.message}")
	private String REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_ERROR_MESSAGE;
	
	@Value("${registration.impl.getDisconnectedAccountDetails.exception.code}")
	private String REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_EXCEPTION_CODE;
	
	@Value("${registration.impl.getDisconnectedAccountDetails.exception.message}")
	private String REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_EXCEPTION_MESSAGE;
	
	@Value("${registration.impl.getValidatePIN.error.code}")
	private String REGISTRATION_IMPL_GETVALIDATEPIN_ERROR_CODE;
	
	@Value("${registration.impl.getValidatePIN.error.message}")
	private String REGISTRATION_IMPL_GETVALIDATEPIN_ERROR_MESSAGE;
	
	@Value("${registration.impl.getValidatePIN.exception.code}")
	private String REGISTRATION_IMPL_GETVALIDATEPIN_EXCEPTION_CODE;
	
	@Value("${registration.impl.getValidatePIN.exception.message}")
	private String REGISTRATION_IMPL_GETVALIDATEPIN_EXCEPTION_MESSAGE;
	
	
	public RegistrationVo getPreRegistrationDetails(RegistrationVo registrationVo)
	{
		
		RegistrationVo preRegistrationServiceVo = new RegistrationVo();
		try {
			SvalloPreRegistrationRequest preRegistrationRequest = new SvalloPreRegistrationRequest();
			preRegistrationRequest.setWorkFlowId(registrationVo.getWorkFlowId());			
			SvalloPreRegistrationResponse preRegistrationResponse = svalloRegistrationLogin.getPreRegistrationInfo(preRegistrationRequest);		
			
			preRegistrationServiceVo.setAccountNumber(preRegistrationResponse.getAccountNumber());
			preRegistrationServiceVo.setOtpPin(preRegistrationResponse.getOTPPin());
			preRegistrationServiceVo.setEventCode(preRegistrationResponse.getEventCode());
			preRegistrationServiceVo.setEventTypeCode(preRegistrationResponse.getEventType());
			preRegistrationServiceVo.setServiceDOB(SelfCareUtil.getNewFormatedDate(preRegistrationResponse.getDateOfBirth()));
			//System.out.println("DDDDDDDDDDDDDDDate: " +SelfCareUtil.getFormatedDate(preRegistrationResponse.getDateOfBirth()));		
		
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationDetails() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationDetails() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationDetails() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			//srie.printStackTrace();			
			preRegistrationServiceVo.setAccountNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setOtpPin(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setEventCode(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setEventTypeCode(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setServiceDOB(REGISTRATION_DATA_NOT_AVAILABLE);			
		}	
		  catch (Exception e) {			
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationDetails() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationDetails() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONDETAILS_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			//e.printStackTrace();
			preRegistrationServiceVo.setAccountNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setOtpPin(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setEventCode(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setEventTypeCode(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationServiceVo.setServiceDOB(REGISTRATION_DATA_NOT_AVAILABLE);					
		}		
		return preRegistrationServiceVo;
	}

	public RegistrationVo getRegistrationDetails(RegistrationVo registrationVo) 
	  {
		
	       RegistrationVo registrationServiceVo = new RegistrationVo();
		try {
			SvalloRegistrationRequest registrationRequest = new SvalloRegistrationRequest();			
			Account account=new Account();
			account.setAccountNumber(registrationVo.getAccountNumber());
			registrationRequest.setAccount(account);		
			SvalloRegistrationResponse registrationResponse = svalloRegistrationLogin.getRegistrationInfo(registrationRequest);	
		
			registrationServiceVo.setAccountNumber(registrationResponse.getAccountDetails().getAccountNumber());
			registrationServiceVo.setMobileNumber(registrationResponse.getSubscriptionDetails().getMobileNumber());
			registrationServiceVo.setEmail(registrationResponse.getCustomerDetails().getCustomerEmail());
			registrationServiceVo.setFirstName(registrationResponse.getCustomerDetails().getCustomerName());
			registrationServiceVo.setLastName(registrationResponse.getCustomerDetails().getCustomerlastName());
			registrationServiceVo.setTitle(registrationResponse.getCustomerDetails().getTitle());
			registrationServiceVo.setSubscriptionNumber(registrationResponse.getSubscriptionDetails().getSubscriptionNumber());
			registrationServiceVo.setAccountName(registrationResponse.getAccountDetails().getAccountName());
			registrationServiceVo.setTraiffCode(registrationResponse.getSubscriptionDetails().getTariffCode());			
			registrationServiceVo.setAddressLine1(registrationResponse.getCustomerDetails().getAddressLine1());
			registrationServiceVo.setAddressLine2(registrationResponse.getCustomerDetails().getAddressLine2());
			registrationServiceVo.setAddressLine3(registrationResponse.getCustomerDetails().getAddressLine3());
			registrationServiceVo.setAddressLine4(registrationResponse.getCustomerDetails().getAddressLine4());
			registrationServiceVo.setAddressLine5(registrationResponse.getCustomerDetails().getAddressLine5());
			registrationServiceVo.setPostalCode(registrationResponse.getCustomerDetails().getPostCode());
			registrationServiceVo.setAccountType(registrationResponse.getAccountDetails().getAccountType());
			registrationServiceVo.setAreFlag(registrationResponse.getAREFlag());
			registrationServiceVo.setMiddleName(registrationResponse.getCustomerDetails().getMiddleName());
			/*
			registrationServiceVo.setTown("Mumbai");
			registrationServiceVo.setCountry("India");
			*/
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ RegistrationServiceImpl | getRegistrationDetails() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getRegistrationDetails() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETREGISTRATIONDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getRegistrationDetails() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETREGISTRATIONDETAILS_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETREGISTRATIONDETAILS_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETREGISTRATIONDETAILS_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			//srie.printStackTrace();			
			registrationServiceVo.setAccountNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setMobileNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setEmail(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setFirstName(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setLastName(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setTitle(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setSubscriptionNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAccountName(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setTraiffCode(REGISTRATION_DATA_NOT_AVAILABLE);			
			registrationServiceVo.setAddressLine1(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine2(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine3(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine4(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine5(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setPostalCode(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAccountType(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setMiddleName(REGISTRATION_DATA_NOT_AVAILABLE);
		}		
		  catch (Exception e) {			
			logger.error(e,"\n[ RegistrationServiceImpl | getRegistrationDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getRegistrationDetails() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETREGISTRATIONDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getRegistrationDetails() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETREGISTRATIONDETAILS_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETREGISTRATIONDETAILS_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETREGISTRATIONDETAILS_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			//e.printStackTrace();
			registrationServiceVo.setAccountNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setMobileNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setEmail(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setFirstName(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setLastName(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setTitle(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setSubscriptionNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAccountName(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setTraiffCode(REGISTRATION_DATA_NOT_AVAILABLE);			
			registrationServiceVo.setAddressLine1(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine2(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine3(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine4(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAddressLine5(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setPostalCode(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setAccountType(REGISTRATION_DATA_NOT_AVAILABLE);
			registrationServiceVo.setMiddleName(REGISTRATION_DATA_NOT_AVAILABLE);
		}		
		return registrationServiceVo;
	}


	public RegistrationVo getSaveRegistrationDetails(RegistrationVo registrationVo) {
		
		RegistrationVo saveRegistrationServiceVo = new RegistrationVo();
		try {
			SvalloSaveRegistrationDetailsRequest saveRegistrationRequest = new SvalloSaveRegistrationDetailsRequest();
			
			saveRegistrationRequest.setAccountNumber(registrationVo.getAccountNumber());
			saveRegistrationRequest.setUserName(registrationVo.getUserName());
			saveRegistrationRequest.setSubscriptionNumber(registrationVo.getSubscriptionNumber());
			saveRegistrationRequest.setTAndC(registrationVo.getTermsAndCondition());
			SvalloSaveRegistrationDetailsResponse saveRegistrationDetailsResponse = svalloRegistrationLogin.saveRegistrationDetails(saveRegistrationRequest);
		
			saveRegistrationServiceVo.setEmailMessage(saveRegistrationDetailsResponse.getMessage());
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ RegistrationServiceImpl | getSaveRegistrationDetails() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getSaveRegistrationDetails() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getSaveRegistrationDetails() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			//srie.printStackTrace();			
			saveRegistrationServiceVo.setEmailMessage(REGISTRATION_DATA_NOT_AVAILABLE);		
		}	
		catch (Exception e) {			
			logger.error(e,"\n[ RegistrationServiceImpl | getSaveRegistrationDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getSaveRegistrationDetails() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getSaveRegistrationDetails() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETSAVEREGISTRATIONDETAILS_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			//e.printStackTrace();
			saveRegistrationServiceVo.setEmailMessage(REGISTRATION_DATA_NOT_AVAILABLE);					
		}		
		return saveRegistrationServiceVo;		
	}


	public RegistrationVo getPreRegistrationResendPinDetails(RegistrationVo registrationVo) {
		
		RegistrationVo preRegistrationResendPinServiceVo = new RegistrationVo();
		try {
			SvalloResendPreRegistrationPINRequest resendPreRegistrationPinRequest = new SvalloResendPreRegistrationPINRequest();
			
			Resend resendpin = new Resend();
			resendpin.setAccountNumber(registrationVo.getAccountNumber());
			resendPreRegistrationPinRequest.setResendDetails(resendpin);			
			SvalloResendPreRegistrationPINResponse preRegistrationResendPinResponse = svalloRegistrationLogin.resendPreRegistrationPIN(resendPreRegistrationPinRequest);
					
			preRegistrationResendPinServiceVo.setSmsMessage(preRegistrationResendPinResponse.getSmsMessage());
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendPinDetails() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendPinDetails() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendPinDetails() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			//srie.printStackTrace();		
			preRegistrationResendPinServiceVo.setSmsMessage(REGISTRATION_DATA_NOT_AVAILABLE);			
		}	
		  catch (Exception e) {			
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendPinDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendPinDetails() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendPinDetails() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDPINDETAILS_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			//e.printStackTrace();
			preRegistrationResendPinServiceVo.setSmsMessage(REGISTRATION_DATA_NOT_AVAILABLE);				
		}	
		return preRegistrationResendPinServiceVo;
	}


	public RegistrationVo getPreRegistrationResendEmailDetails(RegistrationVo registrationVo) {
		
		RegistrationVo preRegistrationResendEmailDetailsServiceVo = new RegistrationVo();
		try {
			SvalloResendPreRegistrationEmailRequest resendPreRegistrationEmailDetailsRequest = new SvalloResendPreRegistrationEmailRequest();
			
			Resend resendpin = new Resend();
			resendpin.setMobileNumber(registrationVo.getMobileNumber());
			resendPreRegistrationEmailDetailsRequest.setResendDetails(resendpin);
			
			ResendEmailResponse resendEmailResponse = svalloRegistrationLogin.resendPreRegistrationEmailDetails(resendPreRegistrationEmailDetailsRequest);
			
			preRegistrationResendEmailDetailsServiceVo.setAccountNumber(resendEmailResponse.getAccountNumber());
			preRegistrationResendEmailDetailsServiceVo.setLastName(resendEmailResponse.getLastName());
			preRegistrationResendEmailDetailsServiceVo.setDob((SelfCareUtil.getNewFormatedDate(resendEmailResponse.getDateOfBirth())));
			preRegistrationResendEmailDetailsServiceVo.setBillingType(resendEmailResponse.getBillingType());
			preRegistrationResendEmailDetailsServiceVo.setSubscriptionNumber(resendEmailResponse.getSubscriptionNumber());			
			preRegistrationResendEmailDetailsServiceVo.setSubscriptionLastAmendedDate(resendEmailResponse.getSubscriptionLastAmendedDate());
			preRegistrationResendEmailDetailsServiceVo.setCustomerLastAmendedDate(resendEmailResponse.getCustomerLastAmendedDate());			
			preRegistrationResendEmailDetailsServiceVo.setAgreementNum(resendEmailResponse.getSubscriptionAgreementNumber());
			preRegistrationResendEmailDetailsServiceVo.setAioUserValue(resendEmailResponse.getAioUser());
			preRegistrationResendEmailDetailsServiceVo.setMobileNumber(registrationVo.getMobileNumber());
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmailDetails() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmailDetails() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmailDetails() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			//srie.printStackTrace();		
			preRegistrationResendEmailDetailsServiceVo.setAccountNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setLastName(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setDob(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setBillingType(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setSubscriptionNumber(REGISTRATION_DATA_NOT_AVAILABLE);			
			preRegistrationResendEmailDetailsServiceVo.setSubscriptionLastAmendedDate(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setCustomerLastAmendedDate(REGISTRATION_DATA_NOT_AVAILABLE);			
			preRegistrationResendEmailDetailsServiceVo.setAgreementNum(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setAioUserValue(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setMobileNumber(REGISTRATION_DATA_NOT_AVAILABLE);
		}	
		 catch (Exception e) {			
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmailDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmailDetails() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmailDetails() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAILDETAILS_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			//e.printStackTrace();
			preRegistrationResendEmailDetailsServiceVo.setAccountNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setLastName(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setDob(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setBillingType(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setSubscriptionNumber(REGISTRATION_DATA_NOT_AVAILABLE);			
			preRegistrationResendEmailDetailsServiceVo.setSubscriptionLastAmendedDate(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setCustomerLastAmendedDate(REGISTRATION_DATA_NOT_AVAILABLE);			
			preRegistrationResendEmailDetailsServiceVo.setAgreementNum(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setAioUserValue(REGISTRATION_DATA_NOT_AVAILABLE);
			preRegistrationResendEmailDetailsServiceVo.setMobileNumber(REGISTRATION_DATA_NOT_AVAILABLE);
			}	
		return preRegistrationResendEmailDetailsServiceVo;		
	}


	public RegistrationVo getPreRegistrationResendEmail(RegistrationVo registrationVo) {
		
		RegistrationVo preRegistrationResendEmailServiceVo = new RegistrationVo();
		try {
			SvalloResendPreRegistrationEmailRequest resendPreRegistrationEmailRequest = new SvalloResendPreRegistrationEmailRequest();
			
			Resend resendpin = new Resend();
			resendpin.setAccountNumber(registrationVo.getAccountNumber());
			resendpin.setEventCode(registrationVo.getEventCode());
			resendPreRegistrationEmailRequest.setResendDetails(resendpin);
			
			SvalloResendPreRegistrationEmailResponse resendPreRegistrationEmailResponse = svalloRegistrationLogin.resendPreRegistrationEmail(resendPreRegistrationEmailRequest);
			
			preRegistrationResendEmailServiceVo.setEmailMessage(resendPreRegistrationEmailResponse.getEmailmessage());
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmail() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmail() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmail() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			//srie.printStackTrace();		
			preRegistrationResendEmailServiceVo.setEmailMessage(REGISTRATION_DATA_NOT_AVAILABLE);			
		}	
		 catch (Exception e) {			
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmail() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmail() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getPreRegistrationResendEmail() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETPREREGISTRATIONRESENDEMAIL_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			//e.printStackTrace();
			preRegistrationResendEmailServiceVo.setEmailMessage(REGISTRATION_DATA_NOT_AVAILABLE);				
		}	
		return preRegistrationResendEmailServiceVo;		
	}
	
	public RegistrationVo getDisconnectedAccountDetails(RegistrationVo registrationVo) {
		RegistrationVo disconnectedAccount = new RegistrationVo();
		try {
			SvalloDisconnectedAccountRequest disconnectedAccountRequest = new SvalloDisconnectedAccountRequest();
			disconnectedAccountRequest.setMobileNumber(registrationVo.getMobileNumber());			
			SvalloDisconnectedAccountResponse disconnectedAccountResponse = svalloRegistrationLogin.getDisconnectedAccountInfo(disconnectedAccountRequest);
			
			disconnectedAccount.setDisconnectedDate(disconnectedAccountResponse.getDisconnectedDate());
			disconnectedAccount.setAccountDisconnected(SelfCareUtil.checkAccountDisconnected(disconnectedAccountResponse.getDisconnectedDate()));
			disconnectedAccount.setSubscriptionStatus(disconnectedAccountResponse.getSubscriptionStatus());
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ RegistrationServiceImpl | getDisconnectedAccountDetails() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getDisconnectedAccountDetails() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getDisconnectedAccountDetails() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			//srie.printStackTrace();	
			disconnectedAccount.setDisconnectedDate(REGISTRATION_DATA_NOT_AVAILABLE);	
			disconnectedAccount.setAccountDisconnected(false);
			disconnectedAccount.setSubscriptionStatus(REGISTRATION_DATA_NOT_AVAILABLE);
		}	
		  catch (Exception e) {			
			logger.error(e,"\n[ RegistrationServiceImpl | getDisconnectedAccountDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getDisconnectedAccountDetails() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getDisconnectedAccountDetails() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETDISCONNECTEDACCOUNTDETAILS_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			//e.printStackTrace();
			disconnectedAccount.setDisconnectedDate(REGISTRATION_DATA_NOT_AVAILABLE);
			disconnectedAccount.setAccountDisconnected(false);
			disconnectedAccount.setSubscriptionStatus(REGISTRATION_DATA_NOT_AVAILABLE);
		}		
		return disconnectedAccount;
	}

	//This method is used for Randomised pin validation with MDS
	public boolean getValidatePIN(String eventNo, String eventNoAlias) { 
		// TODO Auto-generated method stub
		logger.debug("RegistrationServiceImpl || event no. :" +eventNo);
		logger.debug("RegistrationServiceImpl || pin no. entered by user: " +eventNoAlias);
		boolean pinValidationStatus = false;
		try{
			SvalloValidatePINRequest validatePINRequest = new SvalloValidatePINRequest();
			validatePINRequest.setEventNumber(eventNo);
			validatePINRequest.setPinEnteredByUser(eventNoAlias);
			
			SvalloValidatePINResponse validatePINResponse = svalloRegistrationLogin.validatePIN(validatePINRequest);
			logger.debug("RegistrationServiceImpl | getvalidatePIN | Validation Status: " +validatePINResponse.getValidationStatus());
			if((validatePINResponse.getValidationStatus() != null) && (validatePINResponse.getValidationStatus().trim().length() != 0) && (!validatePINResponse.getValidationStatus().equals("?"))){
				pinValidationStatus = true;
			}			
		}catch(SvalloRegistrationIntegrationException srie)
		{			
			logger.error(srie,"\n[ RegistrationServiceImpl | getvalidatePIN() ] SvalloRegistrationServiceException Catch Block ");
			logger.error(srie,"\n[ RegistrationServiceImpl | getvalidatePIN() ] SvalloRegistrationServiceException Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETVALIDATEPIN_ERROR_CODE);
			logger.error(srie,"\n[ RegistrationServiceImpl | getvalidatePIN() ] SvalloRegistrationServiceException Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETVALIDATEPIN_ERROR_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETVALIDATEPIN_ERROR_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETVALIDATEPIN_ERROR_MESSAGE);
			svalloRegistrationServiceException.setRootCause(srie);
			pinValidationStatus = false;
		}catch(Exception e)
		{
			logger.error(e,"\n[ RegistrationServiceImpl | getvalidatePIN() ] Exception Catch Block ");
			logger.error(e,"\n[ RegistrationServiceImpl | getvalidatePIN() ] Exception Catch Block | Error Code =  "+ REGISTRATION_IMPL_GETVALIDATEPIN_EXCEPTION_CODE);
			logger.error(e,"\n[ RegistrationServiceImpl | getvalidatePIN() ] Exception Catch Block | Error Message  =  "+ REGISTRATION_IMPL_GETVALIDATEPIN_EXCEPTION_MESSAGE);
			SvalloRegistrationServiceException svalloRegistrationServiceException = new SvalloRegistrationServiceException();
			svalloRegistrationServiceException.setErrorCode(REGISTRATION_IMPL_GETVALIDATEPIN_EXCEPTION_CODE);
			svalloRegistrationServiceException.setErrorMessage(REGISTRATION_IMPL_GETVALIDATEPIN_EXCEPTION_MESSAGE);
			svalloRegistrationServiceException.setRootCause(e);
			pinValidationStatus = false;
		}
		
		return pinValidationStatus;
	}
	
}


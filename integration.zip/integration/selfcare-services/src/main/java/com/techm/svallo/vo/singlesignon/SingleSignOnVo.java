package com.techm.svallo.vo.singlesignon;

import java.util.List;


public class SingleSignOnVo {
	
	private String sessionToken;
	private String userName;
	private String companyNumber;
	private List <SingleSignOnAccountListVo> singleSignOnAccountListVo;
	private boolean isSingleSignOnListEmpty;
	
	public boolean isSingleSignOnListEmpty() {
		return isSingleSignOnListEmpty;
	}
	public void setSingleSignOnListEmpty(boolean isSingleSignOnListEmpty) {
		this.isSingleSignOnListEmpty = isSingleSignOnListEmpty;
	}
	public String getSessionToken() {
		return sessionToken;
	}
	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCompanyNumber() {
		return companyNumber;
	}
	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}
	public List<SingleSignOnAccountListVo> getSingleSignOnAccountListVo() {
		return singleSignOnAccountListVo;
	}
	public void setSingleSignOnAccountListVo(
			List<SingleSignOnAccountListVo> singleSignOnAccountListVo) {
		this.singleSignOnAccountListVo = singleSignOnAccountListVo;
	}	

}

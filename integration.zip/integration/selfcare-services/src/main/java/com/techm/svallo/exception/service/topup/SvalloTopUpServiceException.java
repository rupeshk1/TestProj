package com.techm.svallo.exception.service.topup;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloTopUpServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}
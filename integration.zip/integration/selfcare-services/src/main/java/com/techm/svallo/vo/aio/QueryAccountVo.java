package com.techm.svallo.vo.aio;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

public class QueryAccountVo
{

	private String simNumber;
	private String accountNumber;
	private String subscriptionNumber;
	private String eventCode;
	private String accountIdentifier;
	private String eventNumberAlias;
	private String externalReference;

	private String adressLine1;
	private String adressLine2;
	private String adressLine3;
	private String adressLine4;
	private String adressLine5;
	private String postCode;
	private String mobileNumber;
	private String title;
	private String surname;
	private String firstname;
	private String dateofbirth;
	private String lastAmendedDate;
	
	
	private String  userName;
	private String  subPassword;
	private String  tAndC;
	private String   attributeId;
	private String   eventTypeCode;
	private String  custLastAmendedDate;
	private String  subLastAmendDate;
	private String  agreementNumber;
	
	
	public String getSimNumber()
	{
		return simNumber;
	}
	public void setSimNumber(String simNumber)
	{
		this.simNumber = simNumber;
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getSubscriptionNumber()
	{
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber)
	{
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getEventCode()
	{
		return eventCode;
	}
	public void setEventCode(String eventCode)
	{
		this.eventCode = eventCode;
	}
	public String getAccountIdentifier()
	{
		return accountIdentifier;
	}
	public void setAccountIdentifier(String accountIdentifier)
	{
		this.accountIdentifier = accountIdentifier;
	}
	public String getEventNumberAlias()
	{
		return eventNumberAlias;
	}
	public void setEventNumberAlias(String eventNumberAlias)
	{
		this.eventNumberAlias = eventNumberAlias;
	}
	public String getExternalReference()
	{
		return externalReference;
	}
	public void setExternalReference(String externalReference)
	{
		this.externalReference = externalReference;
	}
	public String getAdressLine1()
	{
		return adressLine1;
	}
	public void setAdressLine1(String adressLine1)
	{
		this.adressLine1 = adressLine1;
	}
	public String getAdressLine2()
	{
		return adressLine2;
	}
	public void setAdressLine2(String adressLine2)
	{
		this.adressLine2 = adressLine2;
	}
	public String getAdressLine3()
	{
		return adressLine3;
	}
	public void setAdressLine3(String adressLine3)
	{
		this.adressLine3 = adressLine3;
	}
	public String getAdressLine4()
	{
		return adressLine4;
	}
	public void setAdressLine4(String adressLine4)
	{
		this.adressLine4 = adressLine4;
	}
	public String getAdressLine5()
	{
		return adressLine5;
	}
	public void setAdressLine5(String adressLine5)
	{
		this.adressLine5 = adressLine5;
	}
	public String getPostCode()
	{
		return postCode;
	}
	public void setPostCode(String postCode)
	{
		this.postCode = postCode;
	}
	public String getMobileNumber()
	{
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber)
	{
		this.mobileNumber = mobileNumber;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	public String getSurname()
	{
		return surname;
	}
	public void setSurname(String surname)
	{
		this.surname = surname;
	}
	public String getUserName()
	{
		return userName;
	}
	public void setUserName(String userName)
	{
		this.userName = userName;
	}
	public String getSubPassword()
	{
		return subPassword;
	}
	public void setSubPassword(String subPassword)
	{
		this.subPassword = subPassword;
	}
	public String gettAndC()
	{
		return tAndC;
	}
	public void settAndC(String tAndC)
	{
		this.tAndC = tAndC;
	}
	public String getAttributeId()
	{
		return attributeId;
	}
	public void setAttributeId(String attributeId)
	{
		this.attributeId = attributeId;
	}
	public String getEventTypeCode()
	{
		return eventTypeCode;
	}
	public void setEventTypeCode(String eventTypeCode)
	{
		this.eventTypeCode = eventTypeCode;
	}
	public String getCustLastAmendedDate()
	{
		return custLastAmendedDate;
	}
	public void setCustLastAmendedDate(String custLastAmendedDate)
	{
		this.custLastAmendedDate = custLastAmendedDate;
	}
	public String getSubLastAmendDate()
	{
		return subLastAmendDate;
	}
	public void setSubLastAmendDate(String subLastAmendDate)
	{
		this.subLastAmendDate = subLastAmendDate;
	}
	public String getAgreementNumber()
	{
		return agreementNumber;
	}
	public void setAgreementNumber(String agreementNumber)
	{
		this.agreementNumber = agreementNumber;
	}
	
	public String getFirstname()
	{
		return firstname;
	}
	public void setFirstname(String firstname)
	{
		this.firstname = firstname;
	}
	public String getDateofbirth()
	{
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth)
	{
		this.dateofbirth = dateofbirth;
	}
	public String getLastAmendedDate()
	{
		return lastAmendedDate;
	}
	public void setLastAmendedDate(String lastAmendedDate)
	{
		this.lastAmendedDate = lastAmendedDate;
	}


}
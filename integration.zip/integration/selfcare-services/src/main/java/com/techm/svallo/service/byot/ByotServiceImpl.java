package com.techm.svallo.service.byot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.byot.SvalloByotServiceException;
import com.techm.svallo.vo.byot.ByotInfoVo;
import com.techmahindra.online.svallo.model.byot._2015._03._12.ByotRequest;
import com.techmahindra.online.svallo.model.byot._2015._03._12.ByotResponse;
import com.techmahindra.online.svallo.model.byot._2015._03._12.QuerySubscriptionRequest;
import com.techmahindra.online.svallo.model.byot._2015._03._12.QuerySubscriptionResponse;
import com.techmahindra.online.svallo.model.byot._2015._03._12.SearchForPriceListsRequest;
import com.techmahindra.online.svallo.model.byot._2015._03._12.SearchForPriceListsResponse;
import com.techmahindra.online.svallo.service.byot._2015._03._12.Byot;
import com.techmahindra.online.svallo.service.common.exception.SvalloServiceException;
import com.techmahindra.online.svallo.service.common.exception.byot.SvalloByotIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.myallowances.SvalloMyAllowancesIntegrationException;



public class ByotServiceImpl implements ByotService {
	
	@Autowired
	private Byot byot;
	
	final static PortalLogger logger = PortalLogger.getLogger(ByotServiceImpl.class);
	
	@Value("${byot.getMrcAllowanceDetails.error.code}")
	private String BYOT_GETMRCALLOWANCEDETAILS_ERROR_CODE;

	@Value("${byot.getMrcAllowanceDetails.error.message}")
	private String BYOT_GETMRCALLOWANCEDETAILS_ERROR_MESSAGE;
	
	@Value("${byot.getCostAllowanceDetails.error.code}")
	private String BYOT_GETCOSTALLOWANCEDETAILS_ERROR_CODE;

	@Value("${byot.getCostAllowanceDetails.error.message}")
	private String BYOT_GETCOSTALLOWANCEDETAILS_ERROR_MESSAGE;
	
	@Value("${byot.updateByotDetails.error.message.error.code}")
	private String BYOT_UPDATEBYOTDETAILS_ERROR_CODE;

	@Value("${byot.updateByotDetails.error.message.error.message}")
	private String BYOT_UPDATEBYOTDETAILS_ERROR_MESSAGE;
	
	
	
	public ByotInfoVo getMrcAllowanceDetails(String dataSet, String externalReference, String primarySerialNumber,String subscriptionNumber){
		
		logger.debug("==in getMrcAllowanceDetails==");
		ByotInfoVo byotInfoVo = new ByotInfoVo();
		try{
		QuerySubscriptionRequest querySubscriptionRequest = new QuerySubscriptionRequest();
		querySubscriptionRequest.setDataSet(dataSet);
		querySubscriptionRequest.setExternalReference(externalReference);
		querySubscriptionRequest.setPrimarySerialNumber(primarySerialNumber);
		querySubscriptionRequest.setSubscriptionNumber(subscriptionNumber);
		logger.debug("==befor calling getMrcAllowanceDetails==");
		QuerySubscriptionResponse querySubscriptionResponse =byot.getMrcAllowanceDetails(querySubscriptionRequest);
		byotInfoVo.setBasketCode(querySubscriptionResponse.getBasketCode());
		byotInfoVo.setBalanceAmount(querySubscriptionResponse.getBalanceAmount());
		byotInfoVo.setAvailableAmount(querySubscriptionResponse.getAvailableAmount());
		}catch (SvalloByotIntegrationException SvalloByotIntegrationException) {
			
			//e.printStackTrace();
			System.out.println("\n[ ByotServiceImpl | getMrcAllowanceDetails() ] SvalloServiceException Catch Block ");
			System.out.println("\n[ ByotServiceImpl | getMrcAllowanceDetails() ] SvalloServiceException Catch Block | Error Code =  "+BYOT_GETMRCALLOWANCEDETAILS_ERROR_CODE);
			System.out.println("\n[ ByotServiceImpl | getMrcAllowanceDetails() ] SvalloServiceException Catch Block | Error Message  =  "+BYOT_GETMRCALLOWANCEDETAILS_ERROR_MESSAGE);
			SvalloByotServiceException svalloByotServiceException = new SvalloByotServiceException();
			svalloByotServiceException.setErrorCode(BYOT_GETMRCALLOWANCEDETAILS_ERROR_CODE);
			svalloByotServiceException.setErrorMessage(BYOT_GETMRCALLOWANCEDETAILS_ERROR_MESSAGE);
			svalloByotServiceException.setRootCause(SvalloByotIntegrationException);
			throw svalloByotServiceException;
		}
		catch(Exception exception)
		{
			//es.printStackTrace();
			System.out.println("\n[ ByotServiceImpl | getMrcAllowanceDetails() ] SvalloServiceException Catch Block ");
			System.out.println("\n[ ByotServiceImpl | getMrcAllowanceDetails() ] SvalloServiceException Catch Block | Error Code =  "+BYOT_GETMRCALLOWANCEDETAILS_ERROR_CODE);
			System.out.println("\n[ ByotServiceImpl | getMrcAllowanceDetails() ] SvalloServiceException Catch Block | Error Message  =  "+BYOT_GETMRCALLOWANCEDETAILS_ERROR_MESSAGE);
			SvalloByotServiceException svalloByotServiceException = new SvalloByotServiceException();
			svalloByotServiceException.setErrorCode(BYOT_GETMRCALLOWANCEDETAILS_ERROR_CODE);
			svalloByotServiceException.setErrorMessage(BYOT_GETMRCALLOWANCEDETAILS_ERROR_MESSAGE);
			svalloByotServiceException.setRootCause(exception);
			throw svalloByotServiceException;
		}
		
		return byotInfoVo;
	}
	
	
	//public String getCostAllowanceDetails (String key,String name,String value){
	public String getCostAllowanceDetails (String tariffCode){
		
		SearchForPriceListsResponse searchForPriceListsResponse=null;
		try{
		SearchForPriceListsRequest searchForPriceListsRequest = new SearchForPriceListsRequest();
		//searchForPriceListsRequest.setKey(key);
		//searchForPriceListsRequest.setName(name);
		//searchForPriceListsRequest.setValue(value);
		searchForPriceListsRequest.setTariffCode(tariffCode);
		searchForPriceListsResponse= byot.getCostAllowanceDetails(searchForPriceListsRequest);
		}catch (SvalloByotIntegrationException SvalloByotIntegrationException) {
			
			//e.printStackTrace();
			System.out.println("\n[ ByotServiceImpl | getCostAllowanceDetails() ] SvalloServiceException Catch Block ");
			System.out.println("\n[ ByotServiceImpl | getCostAllowanceDetails() ] SvalloServiceException Catch Block | Error Code =  "+BYOT_GETCOSTALLOWANCEDETAILS_ERROR_CODE);
			System.out.println("\n[ ByotServiceImpl | getCostAllowanceDetails() ] SvalloServiceException Catch Block | Error Message  =  "+BYOT_GETCOSTALLOWANCEDETAILS_ERROR_MESSAGE);
			SvalloByotServiceException svalloByotServiceException = new SvalloByotServiceException();
			svalloByotServiceException.setErrorCode(BYOT_GETCOSTALLOWANCEDETAILS_ERROR_CODE);
			svalloByotServiceException.setErrorMessage(BYOT_GETCOSTALLOWANCEDETAILS_ERROR_MESSAGE);
			svalloByotServiceException.setRootCause(SvalloByotIntegrationException);
			throw svalloByotServiceException;
		}
		catch(Exception exception)
		{
			//es.printStackTrace();
			System.out.println("\n[ ByotServiceImpl | getCostAllowanceDetails() ] SvalloServiceException Catch Block ");
			System.out.println("\n[ ByotServiceImpl | getCostAllowanceDetails() ] SvalloServiceException Catch Block | Error Code =  "+BYOT_GETCOSTALLOWANCEDETAILS_ERROR_CODE);
			System.out.println("\n[ ByotServiceImpl | getCostAllowanceDetails() ] SvalloServiceException Catch Block | Error Message  =  "+BYOT_GETCOSTALLOWANCEDETAILS_ERROR_MESSAGE);
			SvalloByotServiceException svalloByotServiceException = new SvalloByotServiceException();
			svalloByotServiceException.setErrorCode(BYOT_GETCOSTALLOWANCEDETAILS_ERROR_CODE);
			svalloByotServiceException.setErrorMessage(BYOT_GETCOSTALLOWANCEDETAILS_ERROR_MESSAGE);
			svalloByotServiceException.setRootCause(exception);
			throw svalloByotServiceException;
		}
		
		return searchForPriceListsResponse.getPrice();
	}
	
	public String updateByotDetails(String externalReference,String subscriptionNumber,String packageCode,String tariffCode,String mins,String data,String text) {
		
		ByotRequest  byotRequest = new ByotRequest();
		ByotResponse byotResponse=null;
		try{
		byotRequest.setExternalReference(externalReference);
		byotRequest.setSubscriptionNumber(subscriptionNumber);
		byotRequest.setPackageCode(packageCode);
		byotRequest.setTariffCode(tariffCode);
		byotRequest.setMins(mins);
		byotRequest.setData(data);		
		byotRequest.setText(text);
		
		byotResponse= byot.updateByotDetails(byotRequest);
		}catch (SvalloByotIntegrationException SvalloByotIntegrationException) {
			
			//e.printStackTrace();
			System.out.println("\n[ ByotServiceImpl | updateByotDetails() ] SvalloServiceException Catch Block ");
			System.out.println("\n[ ByotServiceImpl | updateByotDetails() ] SvalloServiceException Catch Block | Error Code =  "+BYOT_UPDATEBYOTDETAILS_ERROR_CODE);
			System.out.println("\n[ ByotServiceImpl | updateByotDetails() ] SvalloServiceException Catch Block | Error Message  =  "+BYOT_UPDATEBYOTDETAILS_ERROR_MESSAGE);
			SvalloByotServiceException svalloByotServiceException = new SvalloByotServiceException();
			svalloByotServiceException.setErrorCode(BYOT_UPDATEBYOTDETAILS_ERROR_CODE);
			svalloByotServiceException.setErrorMessage(BYOT_UPDATEBYOTDETAILS_ERROR_MESSAGE);
			svalloByotServiceException.setRootCause(SvalloByotIntegrationException);
			throw svalloByotServiceException;
		}
		catch(Exception exception)
		{
			//es.printStackTrace();
			System.out.println("\n[ ByotServiceImpl | updateByotDetails() ] SvalloServiceException Catch Block ");
			System.out.println("\n[ ByotServiceImpl | updateByotDetails() ] SvalloServiceException Catch Block | Error Code =  "+BYOT_UPDATEBYOTDETAILS_ERROR_CODE);
			System.out.println("\n[ ByotServiceImpl | updateByotDetails() ] SvalloServiceException Catch Block | Error Message  =  "+BYOT_UPDATEBYOTDETAILS_ERROR_MESSAGE);
			SvalloByotServiceException svalloByotServiceException = new SvalloByotServiceException();
			svalloByotServiceException.setErrorCode(BYOT_UPDATEBYOTDETAILS_ERROR_CODE);
			svalloByotServiceException.setErrorMessage(BYOT_UPDATEBYOTDETAILS_ERROR_MESSAGE);
			svalloByotServiceException.setRootCause(exception);
			throw svalloByotServiceException;
		}
		
		return byotResponse.getExternalReference();
	
		
		 
	}

}

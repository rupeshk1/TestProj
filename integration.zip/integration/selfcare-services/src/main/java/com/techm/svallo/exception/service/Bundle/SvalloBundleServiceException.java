package com.techm.svallo.exception.service.Bundle;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloBundleServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

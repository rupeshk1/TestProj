package com.techm.svallo.service.dashboard;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.dashboard.DashBoardServiceException;
import com.techm.svallo.exception.service.dashboard.DashboardPostUpgradeServiceException;
import com.techm.svallo.exception.service.payment.SvalloPaymentAccountBalanceServieException;
import com.techm.svallo.exception.service.payment.SvalloPaymentUnBilledValueServiceException;
import com.techm.svallo.service.payment.BillHistoryService;
import com.techm.svallo.util.SelfCareUtil;
import com.techm.svallo.vo.dashboard.AllowancesVo;
import com.techm.svallo.vo.dashboard.DashboardInfoVo;
import com.techm.svallo.vo.dashboard.UsageVo;
import com.techm.svallo.vo.dashboard.UpdateSubscriptionSerialNoVo;
import com.techmahindra.online.svallo.model.dashboard._2014._09._05.DashboardInfo;
import com.techmahindra.online.svallo.model.dashboard._2014._09._05.NameValuePair;
import com.techmahindra.online.svallo.model.payment._2014._09._01.BalanceDetails;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;
import com.techmahindra.online.svallo.model.payment._2014._09._01.UnbilledUnitSummary;
import com.techmahindra.online.svallo.service.common.WidgetManager;
import com.techmahindra.online.svallo.service.common.exception.dashboard.SvalloDashboardIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.dashboard.SvalloDashboardPostUpgradeIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.payment.SvalloPaymentAccountBalanceIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.payment.SvalloPaymentUnbilledValueIntegrationException;
import com.techmahindra.online.svallo.service.dashboard._2014._09._05.DashboardService;
import com.techmahindra.online.svallo.service.payment._2014._09._01.ManagePayment;
import com.techmahindra.online.svallo.service.dashboard._2014._09._05.UpdateSubscriptionSerialNumbersDetails;
import com.techmahindra.online.svallo.service.dashboard._2014._09._05.UpdateSubscriptionSerialNumbersDetailsResponse;
import com.techmahindra.online.svallo.model.dashboard._2014._09._05.UpdateSubscriptionSerialNumbersRequest;
import com.techmahindra.online.svallo.model.dashboard._2014._09._05.UpdateSubscriptionSerialNumbersResponse;

public class ManageDashboardServiceImpl implements ManageDashboardService
{
	final static PortalLogger logger = PortalLogger.getLogger(ManageDashboardServiceImpl.class);

	@Autowired
	private ManagePayment managePayment;

	@Autowired
	private DashboardService dashboardService;

	@Autowired
	private BillHistoryService billHistoryService;

	@Autowired
	private JdbcTemplate jdbcTemplate = null;

	@Autowired
	private JdbcTemplate jdbcTemplateLR = null;

	@Value("${data.not.available}")
	private String DATA_NOT_AVAILABLE;

	// @Value("${payment.unbilled.value.error.code}")
	private String PAYMENT_UNBILEED_VALUE_ERROR_CODE = "S_P_00002";

	// @Value("${payment.unbilled.value.error.message}")
	private String PAYMENT_UNBILEED_VALUE_ERROR_MESSAGE = "Error while fetching unbilled value";

	// @Value("${payment.account.balance.error.message}")
	private String PAYMENT_ACCOUNT_BALANCE_ERROR_CODE = "S_P_00003";

	// @Value("${payment.account.balance.error.message}")
	private String PAYMENT_ACCOUNT_BALANCE_ERROR_MESSAGE = "Error while fetching account balance";

	// @Value("${dahsboard.info.message}")
	private String DASHBOARD_INFO_ERROR_CODE = "S_DB_00005";

	// @Value("${dahsboard.info.error.message}")
	private String DASHBOARD_INFO_ERROR_MESSAGE = "Error while fetching DashBoard Information";
	// @Value("${managedashboard.update.subserialno.error.code}")
	private String MANAGEDASHBOARD_UPDATE_SUBSERIALNO_ERROR_CODE = "S_DB_000025";
	// @Value("${managedashboard.update.subserialno.error.message}")
	private String MANAGEDASHBOARD_UPDATE_SUBSERIALNO_ERROR_MESSAGE = "Error while updating subscription serial number";
	// @Value("${managedashboard.update.subserialno.exception.code}")
	private String MANAGEDASHBOARD_UPDATE_SUBSERIALNO_EXCEPTION_CODE = "S_DB_E000025 ";
	// @Value("${managedashboard.update.subserialno.exception.message}")
	private String MANAGEDASHBOARD_UPDATE_SUBSERIALNO_EXCEPTION_MESSAGE = "Exception while updating subscription serial number";
	// @Value("${data.not.available.postupgrade}")
	private String DATA_NOT_AVAILABLE_POSTUPGRADE = "subscription serial number has not been updated properly";

	/*
	 * private static String GET_USER_DETAILS="select data_ from ExpandoValue "+
	 * "where companyId in "+ "(select companyId from User_ where userId = ?) "+
	 * "and columnId in ("+ "select columnId from ExpandoColumn "+
	 * "where companyId in ("+
	 * "select companyId from User_ where userId = ?) and name='accountNum'); ";
	 * 
	 * private static String GET_USER_DETAILS="select data_  "+
	 * "from ExpandoValue where companyId = (select companyId  "+
	 * "from User_ where userId = ?) and columnId =(select columnId  "+
	 * "from ExpandoColumn where companyId in (select companyId  "+
	 * "from User_ where userId = ?) and name='accountNum') and classPk=(select userId  "
	 * + "from User_ where userId = ?);";
	 * 
	 * 
	 * private static String
	 * GET_USER_DETAILS="select ev.data_ as data_ from ExpandoValue ev "+
	 * "join User_ u on u.userId = ev.classPk "+
	 * "join ExpandoRow er on u.userId = er.classPk and ev.rowid_ = er.rowId_ "+
	 * "join ExpandoColumn ec on u.companyId=ec.companyId and ev.columnId=ec.columnId "
	 * + "where ec.name='accountNum' and u.userId='?'; ";
	 */

	private static String GET_USER_DETAILS = "select openId as accountNum from User_ where userId=?;";

	private static String INSERT_ARE_USER = "INSERT INTO areuser (userId, status) SELECT * FROM" + " (SELECT ?, '1') AS tmp WHERE NOT EXISTS (" + "SELECT userId FROM areuser WHERE userId = ?) LIMIT 1;";

	private static String GET_ARE_USER_STATUS = "SELECT count(*) as areFlag FROM areuser WHERE userId=?;";

	public String getAccount4Dashboard(long userId)
	{
		String accountNumber = "";
		try
		{
			accountNumber = (String) jdbcTemplateLR.query(GET_USER_DETAILS, new Long[]
			{ userId }, new ManageDashboardMapper()).get(0);
		}
		catch (ArrayIndexOutOfBoundsException ae)
		{
			logger.error(ae, "Array Index out of bound exception");
		}
		return accountNumber;
	}

	public void insertAreUser(long userId)
	{
		logger.debug("[ ManageDashboardServiceImpl.java | insertAreUser() ] START");
		logger.debug("[ ManageDashboardServiceImpl.java | insertAreUser() ] userId > " + userId);
		try
		{
			jdbcTemplate.update(INSERT_ARE_USER, userId, userId);
		}
		catch (ArrayIndexOutOfBoundsException ae)
		{
			logger.error(ae, "Array Index out of bound exception while inserting into are table");
		}
		catch (Exception e)
		{
			logger.error(e, "create are table by running the following sql file /Codebase/integration/selfcare-services/src/main/resources/selfcaredb-areuser.sql");
		}
		logger.debug("[ ManageDashboardServiceImpl.java | insertAreUser() ] END");
	}

	public int getAreUserStatus(long userId)
	{

		int status = 0;
		try
		{

			status = Integer.parseInt(jdbcTemplate.query(GET_ARE_USER_STATUS, new Long[]
			{ userId }, new ManageDashboardMapperForAre()).get(0));

			logger.debug("status of are flag is = " + status);
		}
		catch (ArrayIndexOutOfBoundsException ae)
		{
			logger.error(ae, "Array Index out of bound exception for fetching count of are table");
		}
		return status;

	}

	public DashboardInfoVo getDashboardInfo(String subscriptionNumber,String areFlagCheck, String oldPayMSubscriptionNumber,String oldPayMTarrifCode) throws DashBoardServiceException
	{

		DashboardInfoVo dashboardInfoVo = new DashboardInfoVo();

		try
		{
			// Get Billing type prepaid,postpaid,hybrid
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] subscriptionNumber =  " + subscriptionNumber);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] areFlagCheck =  " + areFlagCheck);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] oldPayMSubscriptionNumber =  " + oldPayMSubscriptionNumber);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] oldPayMTarrifCode =  " + oldPayMTarrifCode);
			
			
			DashboardInfo dashboardInfo = dashboardService.getDashboardInfo("", "", "", subscriptionNumber, false);

			logger.debug("ManageDashboardServiceImpl ||Billing Type: " + dashboardInfo.getBillingType());

			dashboardInfoVo.setBillingType(dashboardInfo.getBillingType());
			// dashboardInfoVo.setProposition(dashboardInfo.getProposition());
						
			if (areFlagCheck!=null && areFlagCheck.trim().equals("true"))
			{
				DashboardInfo dashboardInfo1 = dashboardService.getDashboardInfo("", "", "", oldPayMSubscriptionNumber, false);
				dashboardInfoVo.setTerminationInvoiceProduced(dashboardInfo1.getTerminationInvoiceProduced());
			}else{
				dashboardInfoVo.setTerminationInvoiceProduced(dashboardInfo.getTerminationInvoiceProduced());
			}
			

		}
		catch (SvalloDashboardIntegrationException sdie)
		{

			dashboardInfoVo.setBillingType(DATA_NOT_AVAILABLE);
			dashboardInfoVo.setTerminationInvoiceProduced(DATA_NOT_AVAILABLE);
			logger.error(sdie, "SvalloDashboardIntegrationException");
		}

		return dashboardInfoVo;
	}

	public void setWidgetManager(WidgetManager widgetMagr) throws DashBoardServiceException
	{

		WidgetManager widgetManager = widgetMagr;
	}

	public DashboardInfoVo getDashboardInfo(String accountNumber, String tariffCode, String mobileNumber, String subscriptionNumber, boolean controllerIdentifier,
			String areFlagCheck, String oldPayMSubscriptionNumber, String oldPayMTarrifCode) throws DashBoardServiceException
	{
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] controllerIdentifier =  " + controllerIdentifier);
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] accountNumber =  " + accountNumber);
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] tariffCode =  " + tariffCode);
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] mobileNumber =  " + mobileNumber);
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] subscriptionNumber =  " + subscriptionNumber);
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] areFlagCheck =  " + areFlagCheck);
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] oldPayMSubscriptionNumber =  " + oldPayMSubscriptionNumber);
		logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] oldPayMTarrifCode =  " + oldPayMTarrifCode);
		
		String noOfDays = "0";
		String noOffMonths = "0";
		String noOffDaysDiff = "0";
		String noOffMonthsAIO = "0";
		String networkCode = "";
		String bal_totalExtraCharges = "0";
		String bal_domesticExtraCharges = "0";
		String bal_roamingExtraCharges = "0";
		String bal_internationalExtraCharges = "0";
		String bal_topupCredit = "0";
		String avai_topupCredit = "0";

		DashboardInfoVo dashboardInfoVo = new DashboardInfoVo();
		String proposition = null;

		try
		{
			// Get tariff Data
			DashboardInfo dashboardInfo = dashboardService.getDashboardInfo("", tariffCode, "", "", false);
			dashboardInfoVo.setPlanName(dashboardInfo.getPlanName());
			dashboardInfoVo.setTariff(dashboardInfo.getTariff());
			logger.debug("dashboardInfo.getProposition(): " + dashboardInfo.getProposition());
			proposition = dashboardInfo.getProposition();
			logger.debug("proposition: " + proposition);
			logger.debug("Tariff: " + dashboardInfo.getTariff());
			dashboardInfoVo.setProposition(proposition);

		}
		catch (SvalloDashboardIntegrationException sdie)
		{
			dashboardInfoVo.setPlanName(DATA_NOT_AVAILABLE);
			dashboardInfoVo.setTariff(DATA_NOT_AVAILABLE);
			logger.error(sdie, "SvalloDashboardIntegrationException");
		}

		try
		{

			// Get Contract Data
			DashboardInfo dashboardInfo = dashboardService.getDashboardInfo("", "", "", subscriptionNumber, false);
			logger.debug("Inside AIO PLan start and end dateeeeeeeeeeeeeeee  ");

			dashboardInfoVo.setContractUpgradeDate(SelfCareUtil.getFormatedDate(dashboardInfo.getContractUpgradeDate()));
			dashboardInfoVo.setLengthOfContract(dashboardInfo.getLengthOfContract());
			dashboardInfoVo.setContractRenewalDate(SelfCareUtil.getFormatedDate(dashboardInfo.getContractRenewalDate()));
			dashboardInfoVo.setContractStartDate(SelfCareUtil.getFormatedDate(dashboardInfo.getContractStartDate()));

			// Added for My Account for particular format
			dashboardInfoVo.setMyAccountContractRenewalDate(SelfCareUtil.getFormatedDateMyAccount(dashboardInfo.getContractRenewalDate()));
			dashboardInfoVo.setMyAccountContractStartDate(SelfCareUtil.getFormatedDateMyAccount(dashboardInfo.getContractStartDate()));

			// antima
			logger.debug("******************before connected date*****************");
			if ((null != dashboardInfo.getConnectedDate() ) && ( !(dashboardInfo.getConnectedDate()).equalsIgnoreCase("")))
	{
			logger.debug("******************inside connected date*****************");

			dashboardInfoVo.setConnectedDate(SelfCareUtil.getFormatedDate(dashboardInfo.getConnectedDate()));
			logger.debug("******************after connected date*****************");

	}
				logger.debug("******************last connected date*****************");

		if ((null != dashboardInfo.getNonManagedSerialNumber() )&& !((dashboardInfo.getNonManagedSerialNumber()).equalsIgnoreCase("")))
	{
			dashboardInfoVo.setNonManagedSerialNumberValue(dashboardInfo.getNonManagedSerialNumber());
	}		// antima

			// NAmrata for AIO PLan

			String aioPlanStartDate = null;
			String aioPlanEndDate = null;
			String noOffDaysAIO = null;
			String firstDayActivation="";

			if (null != dashboardInfo.getAioPlanStartDate() && null != dashboardInfo.getAioPlanEndDate() && (!(dashboardInfo.getAioPlanStartDate()).equalsIgnoreCase("")) && (!(dashboardInfo.getAioPlanEndDate()).equalsIgnoreCase("")) &&  dashboardInfo.getAioPlanEndDate().length() > 6  && dashboardInfo.getAioPlanStartDate().length() > 6  )
			{
				
				aioPlanStartDate = SelfCareUtil.getFormatedDateMyAccount(dashboardInfo.getAioPlanStartDate());
				aioPlanEndDate = SelfCareUtil.getFormatedDateMyAccount(dashboardInfo.getAioPlanEndDate());

				dashboardInfoVo.setAioPlanStartDate(aioPlanStartDate);
				logger.debug("aioPlanStartDate: " + aioPlanStartDate);
				dashboardInfoVo.setAioPlanEndDate(aioPlanEndDate);
				logger.debug("aioPlanEndDate: " + aioPlanEndDate);
				noOffMonths = SelfCareUtil.getMonthdiffernce(dashboardInfo.getAioPlanEndDate());
				noOffMonthsAIO = SelfCareUtil.getMonthdiffernceAIO(dashboardInfo.getAioPlanStartDate(), dashboardInfo.getAioPlanEndDate());
				dashboardInfoVo.setNoOffMonthsAIO(noOffMonthsAIO);
				dashboardInfoVo.setNoOffMonths(noOffMonths);
				logger.debug("noOffMonths : " + dashboardInfoVo.getNoOffMonths());
			}
			logger.debug("nextInvoiceDate : " + dashboardInfo.getNextInvoiceDate());
			logger.debug("lastInvoiceDate : " + dashboardInfo.getLastInvoiceDate());
			dashboardInfoVo.setFirstInvoiceDate(SelfCareUtil.getFormatedDate(dashboardInfo.getFirstInvoiceDate()));
			
		
			firstDayActivation = SelfCareUtil.getFutureMonthDate();
			logger.debug("firstDayActivation : " + firstDayActivation);
			if(dashboardInfo.getLastInvoiceDate() == null || dashboardInfo.getLastInvoiceDate().length() <= 0){
			noOfDays =SelfCareUtil.getdaysdiffernceBetnTwoDates(dashboardInfo.getNextInvoiceDate(),firstDayActivation);
			}else{
				noOfDays = SelfCareUtil.getDatediffernce(dashboardInfo.getNextInvoiceDate());
			}
			
			logger.debug("noOfDays : " + noOfDays);
			noOffDaysDiff = SelfCareUtil.getDatediffernce(dashboardInfo.getContractRenewalDate());

			if (null != dashboardInfo.getAioPlanEndDate() && !(dashboardInfo.getAioPlanEndDate()).equalsIgnoreCase(""))
			{
				noOffDaysAIO = SelfCareUtil.getDatediffernce(dashboardInfo.getAioPlanEndDate());
				
				dashboardInfoVo.setNoOffDaysAIO(noOffDaysAIO);
				logger.debug("noOffDaysAIO : " + noOffDaysAIO);
			}

			dashboardInfoVo.setNoOffDaysDiff(noOffDaysDiff);

			dashboardInfoVo.setNoOfDays(noOfDays);
			dashboardInfoVo.setUnformattedNextInvoiceDate(dashboardInfo.getNextInvoiceDate());
			dashboardInfoVo.setUnformattedLastInvoiceDate(dashboardInfo.getLastInvoiceDate());
			dashboardInfoVo.setNextInvoiceDate(SelfCareUtil.getFormattedDateMMM(dashboardInfo.getNextInvoiceDate()));
			dashboardInfoVo.setLastInvoiceDate(SelfCareUtil.getFormatedDate(dashboardInfo.getLastInvoiceDate()));
			dashboardInfoVo.setNetworkCode(dashboardInfo.getNetworkCode());

			logger.debug("Length of Contract: " + dashboardInfo.getLengthOfContract());
			logger.debug("Contract Upgrade Date: " + dashboardInfo.getContractUpgradeDate());
			logger.debug("Contract Renewal Date : " + dashboardInfo.getContractRenewalDate());
			logger.debug("Network Code: " + dashboardInfo.getNetworkCode());
			logger.debug("Connected Date : " + dashboardInfoVo.getConnectedDate());

			logger.debug("nonManagedSerialNumber: " + dashboardInfoVo.getNonManagedSerialNumberValue());

		}
		catch (SvalloDashboardIntegrationException sdie)
		{

			dashboardInfoVo.setContractUpgradeDate(DATA_NOT_AVAILABLE);
			dashboardInfoVo.setLengthOfContract(DATA_NOT_AVAILABLE);
			dashboardInfoVo.setContractRenewalDate(DATA_NOT_AVAILABLE);
			logger.error(sdie, "SvalloDashboardIntegrationException");
		}

		try
		{
			// Get Allowances Data
			DashboardInfo dashboardInfo = dashboardService.getDashboardInfo("", "", "", subscriptionNumber, controllerIdentifier);
			dashboardInfoVo.setDataRolloverEligible(dashboardInfo.getDataRolloverEligible());
			logger.debug("ManageDashboardServiceImpl || Data Rollover Eligible: " + dashboardInfo.getDataRolloverEligible());
			dashboardInfoVo.setMinsRolloverEligible(dashboardInfo.getMinsRolloverEligible());
			logger.debug("ManageDashboardServiceImpl || Minutes Rollover Eligible: " + dashboardInfo.getMinsRolloverEligible());
			dashboardInfoVo.setTextsRolloverEligible(dashboardInfo.getTextsRolloverEligible());
			logger.debug("ManageDashboardServiceImpl || Texts Rollover Eligible: " + dashboardInfo.getTextsRolloverEligible());

			// Inclusive+Extra
			AllowancesVo allowancesVo = new AllowancesVo();
			UsageVo availableVo = new UsageVo();
			UsageVo usedVo = new UsageVo();
			UsageVo rolloverVo = new UsageVo();
			UsageVo recurringVo = new UsageVo();

			String inclusiveAndExtraDataAvailable = getFlatData("inclusiveAndExtraDataAvailable", dashboardInfo.getAllowances().getFlat().getName());
			logger.debug("inclusiveAndExtraDataAvailable: " + inclusiveAndExtraDataAvailable);
			String inclusiveAndExtraMinsAvailable = getFlatData("inclusiveAndExtraVoiceAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveAndExtraTextAvailable = getFlatData("inclusiveAndExtraTextAvailable", dashboardInfo.getAllowances().getFlat().getName());

			String inclusiveAndExtraDataUsed = getFlatData("inclusiveAndExtraDataUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveAndExtraMinsUsed = getFlatData("inclusiveAndExtraVoiceUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveAndExtraTextUsed = getFlatData("inclusiveAndExtraTextUsed", dashboardInfo.getAllowances().getFlat().getName());

			availableVo.setData(inclusiveAndExtraDataAvailable);
			availableVo.setMins(inclusiveAndExtraMinsAvailable);
			availableVo.setText(inclusiveAndExtraTextAvailable);
			usedVo.setData(inclusiveAndExtraDataUsed);
			usedVo.setMins(inclusiveAndExtraMinsUsed);
			usedVo.setText(inclusiveAndExtraTextUsed);

			allowancesVo.setAvailable(availableVo);
			allowancesVo.setUsed(usedVo);

			dashboardInfoVo.setAllowances(allowancesVo);

			// Inclusive
			allowancesVo = new AllowancesVo();
			availableVo = new UsageVo();
			usedVo = new UsageVo();

			String inclusiveDataAvailable = getFlatData("inclusiveDataAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveMinsAvailable = getFlatData("inclusiveVoiceAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveTextAvailable = getFlatData("inclusiveTextAvailable", dashboardInfo.getAllowances().getFlat().getName());

			String inclusiveDataUsed = getFlatData("inclusiveDataUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveMinsUsed = getFlatData("inclusiveVoiceUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveTextUsed = getFlatData("inclusiveTextUsed", dashboardInfo.getAllowances().getFlat().getName());

			availableVo.setData(inclusiveDataAvailable);
			availableVo.setMins(inclusiveMinsAvailable);
			availableVo.setText(inclusiveTextAvailable);
			usedVo.setData(inclusiveDataUsed);
			usedVo.setMins(inclusiveMinsUsed);
			usedVo.setText(inclusiveTextUsed);

			allowancesVo.setAvailable(availableVo);
			allowancesVo.setUsed(usedVo);

			dashboardInfoVo.setInclusiveAllowances(allowancesVo);

			// Extra
			allowancesVo = new AllowancesVo();
			availableVo = new UsageVo();
			usedVo = new UsageVo();
			String extraDataAvailable = getFlatData("extraDataAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String extraMinsAvailable = getFlatData("extraVoiceAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String extraTextAvailable = getFlatData("extraTextAvailable", dashboardInfo.getAllowances().getFlat().getName());

			String extraDataUsed = getFlatData("extraDataUsed", dashboardInfo.getAllowances().getFlat().getName());
			String extraMinsUsed = getFlatData("extraVoiceUsed", dashboardInfo.getAllowances().getFlat().getName());
			String extraTextUsed = getFlatData("extraTextUsed", dashboardInfo.getAllowances().getFlat().getName());

			String numberOfDataBolton = getFlatData("numberOfDataBolton", dashboardInfo.getAllowances().getFlat().getName());
			String numberOfVoiceBolton = getFlatData("numberOfVoiceBolton", dashboardInfo.getAllowances().getFlat().getName());
			String numberOfTextBolton = getFlatData("numberOfTextBolton", dashboardInfo.getAllowances().getFlat().getName());
			allowancesVo.setBoltonCount(Integer.parseInt(numberOfDataBolton) + Integer.parseInt(numberOfVoiceBolton) + Integer.parseInt(numberOfTextBolton));
			allowancesVo.setBolton((Integer.parseInt(numberOfDataBolton) + Integer.parseInt(numberOfVoiceBolton) + Integer.parseInt(numberOfTextBolton)) > 0);

			availableVo.setData(extraDataAvailable);
			availableVo.setMins(extraMinsAvailable);
			availableVo.setText(extraTextAvailable);
			usedVo.setData(extraDataUsed);
			usedVo.setMins(extraMinsUsed);
			usedVo.setText(extraTextUsed);

			allowancesVo.setAvailable(availableVo);
			allowancesVo.setUsed(usedVo);

			dashboardInfoVo.setExtraAllowances(allowancesVo);

			dashboardInfoVo.setNanIssue("false");

			// Rollover Allowance
			rolloverVo = new UsageVo();

			// Rollover Allowance start
			networkCode = dashboardInfo.getNetworkCode();
			logger.debug("ManageDashboardServiceImpl | Network Code: " + networkCode);

			if (networkCode.equalsIgnoreCase("MATRIX"))
			{
				String rolloverDataAllowance = getFlatData("rolloverDataAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String rolloverMinutesAllowance = getFlatData("rolloverVoiceAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String rolloverTextAllowance = getFlatData("rolloverTextAllowance", dashboardInfo.getAllowances().getFlat().getName());

				logger.debug("ManageDashboardServiceImpl | rolloverDataAllowance: ", rolloverDataAllowance);
				logger.debug("ManageDashboardServiceImpl | rolloverVoiceAllowance: ", rolloverMinutesAllowance);
				logger.debug("ManageDashboardServiceImpl | rolloverTextAllowance: ", rolloverTextAllowance);

				rolloverVo.setData(rolloverDataAllowance);
				rolloverVo.setMins(rolloverMinutesAllowance);
				rolloverVo.setText(rolloverTextAllowance);

				allowancesVo.setRollover(rolloverVo);

				dashboardInfoVo.setRolloverAllowances(allowancesVo);

				// Recurring Allowance start
				recurringVo = new UsageVo();

				String recurringDataAllowance = getFlatData("recurringDataAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String recurringMinutesAllowance = getFlatData("recurringVoiceAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String recurringTextAllowance = getFlatData("recurringTextAllowance", dashboardInfo.getAllowances().getFlat().getName());

				logger.debug("ManageDashboardServiceImpl | recurringDataAllowance: " + recurringDataAllowance);
				logger.debug("ManageDashboardServiceImpl | recurringVoiceAllowance: " + recurringMinutesAllowance);
				logger.debug("ManageDashboardServiceImpl | recurringTextAllowance: " + recurringTextAllowance);

				recurringVo.setData(recurringDataAllowance);
				recurringVo.setMins(recurringMinutesAllowance);
				recurringVo.setText(recurringTextAllowance);

				allowancesVo.setRecurring(recurringVo);

				dashboardInfoVo.setRecurringAllowances(allowancesVo);
				// Recurring Allowance end

				// View My Extra Charges from Baskets start
				String avai_totalExtraCharges = getFlatData("avai_totalExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				String avai_domesticExtraCharges = getFlatData("avai_domesticExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				String avai_roamingExtraCharges = getFlatData("avai_roamingExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				String avai_internationalExtraCharges = getFlatData("avai_internationalExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				avai_topupCredit = getFlatData("avai_topupCredit", dashboardInfo.getAllowances().getFlat().getName());

				bal_totalExtraCharges = getFlatData("bal_totalExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_domesticExtraCharges = getFlatData("bal_domesticExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_roamingExtraCharges = getFlatData("bal_roamingExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_internationalExtraCharges = getFlatData("bal_internationalExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_topupCredit = getFlatData("bal_topupCredit", dashboardInfo.getAllowances().getFlat().getName());

				logger.debug("avai_totalExtraCharges: " + avai_totalExtraCharges);
				logger.debug("avai_domesticExtraCharges: " + avai_domesticExtraCharges);
				logger.debug("avai_roamingExtraCharges: " + avai_roamingExtraCharges);
				logger.debug("avai_internationalExtraCharges: " + avai_internationalExtraCharges);
				logger.debug("bal_totalExtraCharges: " + bal_totalExtraCharges);
				logger.debug("bal_domesticExtraCharges: " + bal_domesticExtraCharges);
				logger.debug("bal_roamingExtraCharges: " + bal_roamingExtraCharges);
				logger.debug("bal_internationalExtraCharges: " + bal_internationalExtraCharges);
				logger.debug("avai_topupCredit: " + avai_topupCredit);
				logger.debug("bal_topupCredit: " + bal_topupCredit);
				// View My Extra Charges values from Baskets end
			}
			// Rollover end

		}
		catch (SvalloDashboardIntegrationException sdie)
		{
			dashboardInfoVo.setNetworkCode(DATA_NOT_AVAILABLE);

			UsageVo usageVo = new UsageVo();

			usageVo.setData("0");
			usageVo.setMins("0");
			usageVo.setText("0");

			AllowancesVo allowancesVo = new AllowancesVo();
			allowancesVo.setAvailable(usageVo);
			allowancesVo.setUsed(usageVo);
			allowancesVo.setRollover(usageVo);
			allowancesVo.setRecurring(usageVo);

			dashboardInfoVo.setAllowances(allowancesVo);
			dashboardInfoVo.setInclusiveAllowances(allowancesVo);
			dashboardInfoVo.setExtraAllowances(allowancesVo);
			dashboardInfoVo.setRolloverAllowances(allowancesVo);
			dashboardInfoVo.setRecurringAllowances(allowancesVo);
			dashboardInfoVo.setNanIssue("true");
			logger.error(sdie, "SvalloDashboardIntegrationException");
		}

		dashboardInfoVo.setScreenName(accountNumber);

		QueryAccount queryAccount = new QueryAccount();
		queryAccount.setAccountNumber(accountNumber);

		BalanceDetails balanceDetails = null;
		dashboardInfoVo.setAmountOverdue(DATA_NOT_AVAILABLE);
		dashboardInfoVo.setOutstandingBillAmount(DATA_NOT_AVAILABLE);
		dashboardInfoVo.setUnbilledAmount(DATA_NOT_AVAILABLE);

		try
		{
			balanceDetails = managePayment.getAccountBallance(queryAccount);

			if (networkCode.equalsIgnoreCase("MATRIX"))
			{
				logger.debug("areFlagCheck : " + areFlagCheck);
				if (areFlagCheck!=null && areFlagCheck.trim().equals("true"))
				{
					queryAccount.setSubscriptionNumber(oldPayMSubscriptionNumber);

					UnbilledUnitSummary unbilledUnitSummary = managePayment.getUnbilledValue(queryAccount);

					if (unbilledUnitSummary != null && unbilledUnitSummary.getTotalUnbilledValue() != null && unbilledUnitSummary.getTotalUnbilledValue().trim().length() > 0)
					{
						logger.debug("Unbilled total: " + unbilledUnitSummary.getTotalUnbilledValue().toString());
						dashboardInfoVo.setUnbilledAmount(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getTotalUnbilledValue().toString())));
						logger.debug("Unbilled sum: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getTotalUnbilledValue().toString())));
					}
					if (unbilledUnitSummary != null && unbilledUnitSummary.getDomesticCallPrice() != null && unbilledUnitSummary.getDomesticCallPrice().trim().length() > 0)
					{
						logger.debug("Domestic Call Price : " + unbilledUnitSummary.getDomesticCallPrice().toString());
						dashboardInfoVo.setDomesticCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getDomesticCallPrice().toString())));
						logger.debug("Domestic Call Price with rounding of to two decimal place :" + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getDomesticCallPrice().toString())));
					}
					if (unbilledUnitSummary != null && unbilledUnitSummary.getInternationalCallPrice() != null && unbilledUnitSummary.getInternationalCallPrice().trim().length() > 0)
					{
						logger.debug("International Call Price: " + unbilledUnitSummary.getInternationalCallPrice().toString());
						dashboardInfoVo.setInternationalCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getInternationalCallPrice().toString())));
						logger.debug("International Call Price with rounding of to two decimal place : " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getInternationalCallPrice().toString())));
					}
					if (unbilledUnitSummary != null && unbilledUnitSummary.getRoamedCallPrice() != null && unbilledUnitSummary.getRoamedCallPrice().trim().length() > 0)
					{
						logger.debug("Roamed Call Price: " + unbilledUnitSummary.getRoamedCallPrice().toString());
						dashboardInfoVo.setRoamedCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getRoamedCallPrice().toString())));
						logger.debug("Roamed Call Price with rounding of to two decimal place : " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getRoamedCallPrice().toString())));
					}
				}
				else
				{	
					if ((bal_totalExtraCharges != null) && (!bal_totalExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setUnbilledAmount(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_totalExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || Unbilled Amount: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_totalExtraCharges)));
					}
	
					if ((bal_domesticExtraCharges) != null && (!bal_domesticExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setDomesticCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_domesticExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || Domestic charge: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_domesticExtraCharges)));
					}
	
					if ((bal_roamingExtraCharges != null) && (!bal_roamingExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setRoamedCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_roamingExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || Roaming charge: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_roamingExtraCharges)));
					}
	
					if ((bal_internationalExtraCharges != null) && (!bal_internationalExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setInternationalCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_internationalExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || International charge: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_internationalExtraCharges)));
					}
	
					if ((bal_topupCredit != null) && (!bal_topupCredit.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setTopupCredit(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_topupCredit)));
						logger.debug("ManageDashboardServiceImpl || Topup credit: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_topupCredit)));
					}
				}	
			}
			else
			{

				queryAccount.setSubscriptionNumber(subscriptionNumber);

				UnbilledUnitSummary unbilledUnitSummary = managePayment.getUnbilledValue(queryAccount);

				if (unbilledUnitSummary != null && unbilledUnitSummary.getTotalUnbilledValue() != null && unbilledUnitSummary.getTotalUnbilledValue().trim().length() > 0)
				{
					logger.debug("Unbilled total: " + unbilledUnitSummary.getTotalUnbilledValue().toString());
					dashboardInfoVo.setUnbilledAmount(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getTotalUnbilledValue().toString())));
					logger.debug("Unbilled sum: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getTotalUnbilledValue().toString())));
				}
				if (unbilledUnitSummary != null && unbilledUnitSummary.getDomesticCallPrice() != null && unbilledUnitSummary.getDomesticCallPrice().trim().length() > 0)
				{
					logger.debug("Domestic Call Price : " + unbilledUnitSummary.getDomesticCallPrice().toString());
					dashboardInfoVo.setDomesticCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getDomesticCallPrice().toString())));
					logger.debug("Domestic Call Price with rounding of to two decimal place :" + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getDomesticCallPrice().toString())));
				}
				if (unbilledUnitSummary != null && unbilledUnitSummary.getInternationalCallPrice() != null && unbilledUnitSummary.getInternationalCallPrice().trim().length() > 0)
				{
					logger.debug("International Call Price: " + unbilledUnitSummary.getInternationalCallPrice().toString());
					dashboardInfoVo.setInternationalCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getInternationalCallPrice().toString())));
					logger.debug("International Call Price with rounding of to two decimal place : " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getInternationalCallPrice().toString())));
				}
				if (unbilledUnitSummary != null && unbilledUnitSummary.getRoamedCallPrice() != null && unbilledUnitSummary.getRoamedCallPrice().trim().length() > 0)
				{
					logger.debug("Roamed Call Price: " + unbilledUnitSummary.getRoamedCallPrice().toString());
					dashboardInfoVo.setRoamedCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getRoamedCallPrice().toString())));
					logger.debug("Roamed Call Price with rounding of to two decimal place : " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getRoamedCallPrice().toString())));
				}
			}

			if (balanceDetails != null)
			{
				logger.debug("[ ManageDashboardServiceImpl.java | getDashboardInfo() ] balanceDetails.getAmountOverdue()" + balanceDetails.getAmountOverdue());

				if (balanceDetails.getAmountOverdue() != null && balanceDetails.getAmountOverdue().trim().length() > 0)
				{
					dashboardInfoVo.setAmountOverdue(balanceDetails.getAmountOverdue());
					dashboardInfoVo.setOutstandingBillAmount(balanceDetails.getAmountOverdue());
				}
				//---------------------------------ARE Code---------------------------------
				/*if (balanceDetails != null)
				{
					logger.debug("[ ManageDashboardServiceImpl.java | getDashboardInfo() ] balanceDetails.getAmountOverdue()" + balanceDetails.getAmountOverdue());
					
					if (balanceDetails.getAmountOverdue() != null && balanceDetails.getAmountOverdue().trim().length() > 0)
					{
						dashboardInfoVo.setAmountOverdue(balanceDetails.getAmountOverdue());
					}
					
					if (balanceDetails.getBalance() != null && balanceDetails.getBalance().trim().length() > 0)
					{	
						if (areFlagCheck!=null && areFlagCheck.trim().equals("true"))
						{
							dashboardInfoVo.setOutstandingBillAmount(balanceDetails.getBalance());
						}
						else
						{
							if (balanceDetails.getAmountOverdue() != null && balanceDetails.getAmountOverdue().trim().length() > 0)
							{	
								dashboardInfoVo.setOutstandingBillAmount(balanceDetails.getAmountOverdue());
							}	
						}
					}
				}*/
				//---------------------------------ARE Code---------------------------------
			}
		}
		catch (SvalloPaymentAccountBalanceIntegrationException svalloPaymentAccountBalanceIntegrationException)
		{
			logger.error(svalloPaymentAccountBalanceIntegrationException, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] SvalloPaymentAccountBalanceIntegrationException Catch Block ");
			logger.error(svalloPaymentAccountBalanceIntegrationException, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] SvalloPaymentAccountBalanceIntegrationException Catch Block | Error Code =  " + PAYMENT_ACCOUNT_BALANCE_ERROR_CODE);
			logger.error(svalloPaymentAccountBalanceIntegrationException, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] SvalloPaymentAccountBalanceIntegrationException Catch Block | Error Message  =  " + PAYMENT_ACCOUNT_BALANCE_ERROR_MESSAGE);
			SvalloPaymentAccountBalanceServieException svalloPaymentAccountBalanceServieException = new SvalloPaymentAccountBalanceServieException();
			svalloPaymentAccountBalanceServieException.setErrorCode(PAYMENT_ACCOUNT_BALANCE_ERROR_CODE);
			svalloPaymentAccountBalanceServieException.setErrorMessage(PAYMENT_ACCOUNT_BALANCE_ERROR_MESSAGE);
			svalloPaymentAccountBalanceServieException.setRootCause(svalloPaymentAccountBalanceIntegrationException);
			DashBoardServiceException dashBoardServiceException = new DashBoardServiceException();
			dashBoardServiceException.setRootCause(svalloPaymentAccountBalanceServieException);
			throw dashBoardServiceException;
		}
		catch (SvalloPaymentUnbilledValueIntegrationException svalloPaymentUnbilledValueIntegrationException)
		{
			logger.error(svalloPaymentUnbilledValueIntegrationException, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] SvalloPaymentUnbilledValueIntegrationException Catch Block ");
			logger.error(svalloPaymentUnbilledValueIntegrationException, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] SvalloPaymentUnbilledValueIntegrationException Catch Block | Error Code =  " + PAYMENT_UNBILEED_VALUE_ERROR_CODE);
			logger.error(svalloPaymentUnbilledValueIntegrationException, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] SvalloPaymentUnbilledValueIntegrationException Catch Block | Error Message  =  " + PAYMENT_UNBILEED_VALUE_ERROR_MESSAGE);
			SvalloPaymentUnBilledValueServiceException svalloPaymentUnBilledValueServiceException = new SvalloPaymentUnBilledValueServiceException();
			svalloPaymentUnBilledValueServiceException.setErrorCode(PAYMENT_UNBILEED_VALUE_ERROR_CODE);
			svalloPaymentUnBilledValueServiceException.setErrorMessage(PAYMENT_UNBILEED_VALUE_ERROR_MESSAGE);
			svalloPaymentUnBilledValueServiceException.setRootCause(svalloPaymentUnbilledValueIntegrationException);
			DashBoardServiceException dashBoardServiceException = new DashBoardServiceException();
			dashBoardServiceException.setRootCause(svalloPaymentUnBilledValueServiceException);
			throw dashBoardServiceException;
		}
		catch (Exception exception)
		{

			// Error Code and Error Message in this(Exception) block will be
			// according to your business
			logger.error(exception, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] Exception   catch block ");
			logger.error(exception, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] Exception   catch bloc | Error Code =  " + DASHBOARD_INFO_ERROR_CODE);
			logger.error(exception, "\n[ DirectDebitServiceImpl | getDashboardInfo() ] Exception   catch bloc | Error Message  =  " + DASHBOARD_INFO_ERROR_MESSAGE);
			DashBoardServiceException dashBoardServiceException = new DashBoardServiceException();
			dashBoardServiceException.setErrorCode(DASHBOARD_INFO_ERROR_CODE);
			dashBoardServiceException.setErrorMessage(DASHBOARD_INFO_ERROR_MESSAGE);
			dashBoardServiceException.setRootCause(exception);
			throw dashBoardServiceException;
		}

		return dashboardInfoVo;
	}

	public DashboardService getDashboardService()
	{
		return dashboardService;
	}

	public void setDashboardService(DashboardService dashboardService)
	{
		this.dashboardService = dashboardService;
	}

	private static final class ManageDashboardMapper implements RowMapper<String>
	{

		public String mapRow(ResultSet rs, int rowNum) throws SQLException
		{

			return rs.getString("accountNum");

		}
	}

	private static final class ManageDashboardMapperForAre implements RowMapper<String>
	{

		public String mapRow(ResultSet rs, int rowNum) throws SQLException
		{

			return rs.getString("areFlag");

		}
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setJdbcTemplateLR(JdbcTemplate jdbcTemplateLR)
	{
		this.jdbcTemplateLR = jdbcTemplateLR;
	}

	public String getFlatData(String name, List<NameValuePair> names)
	{

		for (int i = 0; i < names.size(); i++)
		{

			if (name.equals(names.get(i).getKey()))
			{
				return names.get(i).getValue();
			}
		}
		return name + " Not found";
	}

	public DashboardInfoVo getAjaxDonutsInfo(String a, String b, String c, String subscriptionNumber, DashboardInfoVo originalDashboardInfoVo,String areFlagCheck
			, String oldPayMSubscriptionNumber,String oldPayMTarrifCode)
	{
		// TODO Auto-generated method stub
		String networkCode = "";
		String bal_totalExtraCharges = "0";
		String bal_domesticExtraCharges = "0";
		String bal_roamingExtraCharges = "0";
		String bal_internationalExtraCharges = "0";
		String bal_topupCredit = "0";
		String avai_topupCredit = "0";
		DashboardInfoVo dashboardInfoVo = originalDashboardInfoVo;
		try
		{
			// Get Allowances Data
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] a =  " + a);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] b =  " + b);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] c =  " + c);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] subscriptionNumber =  " + subscriptionNumber);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] originalDashboardInfoVo =  " + originalDashboardInfoVo);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] areFlagCheck =  " + areFlagCheck);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] oldPayMSubscriptionNumber =  " + oldPayMSubscriptionNumber);
			logger.debug("[ ManageDashboardServiceImpl.java |  getDashboardInfo() ] oldPayMTarrifCode =  " + oldPayMTarrifCode);
			
			DashboardInfo dashboardInfo = dashboardService.getDashboardInfo("", "", "", subscriptionNumber, true);

			dashboardInfoVo.setDataRolloverEligible(dashboardInfo.getDataRolloverEligible());
			logger.debug("ManageDashboardServiceImpl || Data Rollover Eligible: " + dashboardInfo.getDataRolloverEligible());
			dashboardInfoVo.setMinsRolloverEligible(dashboardInfo.getMinsRolloverEligible());
			logger.debug("ManageDashboardServiceImpl || Minutes Rollover Eligible: " + dashboardInfo.getMinsRolloverEligible());
			dashboardInfoVo.setTextsRolloverEligible(dashboardInfo.getTextsRolloverEligible());
			logger.debug("ManageDashboardServiceImpl || Texts Rollover Eligible: " + dashboardInfo.getTextsRolloverEligible());

			// Inclusive+Extra
			AllowancesVo allowancesVo = new AllowancesVo();
			UsageVo availableVo = new UsageVo();
			UsageVo usedVo = new UsageVo();
			UsageVo rolloverVo = new UsageVo();
			UsageVo recurringVo = new UsageVo();

			String inclusiveAndExtraDataAvailable = getFlatData("inclusiveAndExtraDataAvailable", dashboardInfo.getAllowances().getFlat().getName());
			logger.debug("inclusiveAndExtraDataAvailable: " + inclusiveAndExtraDataAvailable);
			String inclusiveAndExtraMinsAvailable = getFlatData("inclusiveAndExtraVoiceAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveAndExtraTextAvailable = getFlatData("inclusiveAndExtraTextAvailable", dashboardInfo.getAllowances().getFlat().getName());

			String inclusiveAndExtraDataUsed = getFlatData("inclusiveAndExtraDataUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveAndExtraMinsUsed = getFlatData("inclusiveAndExtraVoiceUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveAndExtraTextUsed = getFlatData("inclusiveAndExtraTextUsed", dashboardInfo.getAllowances().getFlat().getName());

			availableVo.setData(inclusiveAndExtraDataAvailable);
			availableVo.setMins(inclusiveAndExtraMinsAvailable);
			availableVo.setText(inclusiveAndExtraTextAvailable);
			usedVo.setData(inclusiveAndExtraDataUsed);
			usedVo.setMins(inclusiveAndExtraMinsUsed);
			usedVo.setText(inclusiveAndExtraTextUsed);

			allowancesVo.setAvailable(availableVo);
			allowancesVo.setUsed(usedVo);

			dashboardInfoVo.setAllowances(allowancesVo);

			// Inclusive
			allowancesVo = new AllowancesVo();
			availableVo = new UsageVo();
			usedVo = new UsageVo();

			String inclusiveDataAvailable = getFlatData("inclusiveDataAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveMinsAvailable = getFlatData("inclusiveVoiceAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveTextAvailable = getFlatData("inclusiveTextAvailable", dashboardInfo.getAllowances().getFlat().getName());

			String inclusiveDataUsed = getFlatData("inclusiveDataUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveMinsUsed = getFlatData("inclusiveVoiceUsed", dashboardInfo.getAllowances().getFlat().getName());
			String inclusiveTextUsed = getFlatData("inclusiveTextUsed", dashboardInfo.getAllowances().getFlat().getName());

			availableVo.setData(inclusiveDataAvailable);
			availableVo.setMins(inclusiveMinsAvailable);
			availableVo.setText(inclusiveTextAvailable);
			usedVo.setData(inclusiveDataUsed);
			usedVo.setMins(inclusiveMinsUsed);
			usedVo.setText(inclusiveTextUsed);

			allowancesVo.setAvailable(availableVo);
			allowancesVo.setUsed(usedVo);

			dashboardInfoVo.setInclusiveAllowances(allowancesVo);

			// Extra
			allowancesVo = new AllowancesVo();
			availableVo = new UsageVo();
			usedVo = new UsageVo();
			String extraDataAvailable = getFlatData("extraDataAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String extraMinsAvailable = getFlatData("extraVoiceAvailable", dashboardInfo.getAllowances().getFlat().getName());
			String extraTextAvailable = getFlatData("extraTextAvailable", dashboardInfo.getAllowances().getFlat().getName());

			String extraDataUsed = getFlatData("extraDataUsed", dashboardInfo.getAllowances().getFlat().getName());
			String extraMinsUsed = getFlatData("extraVoiceUsed", dashboardInfo.getAllowances().getFlat().getName());
			String extraTextUsed = getFlatData("extraTextUsed", dashboardInfo.getAllowances().getFlat().getName());

			String numberOfDataBolton = getFlatData("numberOfDataBolton", dashboardInfo.getAllowances().getFlat().getName());
			String numberOfVoiceBolton = getFlatData("numberOfVoiceBolton", dashboardInfo.getAllowances().getFlat().getName());
			String numberOfTextBolton = getFlatData("numberOfTextBolton", dashboardInfo.getAllowances().getFlat().getName());
			allowancesVo.setBoltonCount(Integer.parseInt(numberOfDataBolton) + Integer.parseInt(numberOfVoiceBolton) + Integer.parseInt(numberOfTextBolton));
			allowancesVo.setBolton((Integer.parseInt(numberOfDataBolton) + Integer.parseInt(numberOfVoiceBolton) + Integer.parseInt(numberOfTextBolton)) > 0);
			availableVo.setData(extraDataAvailable);
			availableVo.setMins(extraMinsAvailable);
			availableVo.setText(extraTextAvailable);
			usedVo.setData(extraDataUsed);
			usedVo.setMins(extraMinsUsed);
			usedVo.setText(extraTextUsed);

			allowancesVo.setAvailable(availableVo);
			allowancesVo.setUsed(usedVo);

			dashboardInfoVo.setExtraAllowances(allowancesVo);

			// Rollover Allowance start
			rolloverVo = new UsageVo();

			networkCode = dashboardInfo.getNetworkCode();
			logger.debug("ManageDashboardServiceImpl | Network Code: " + networkCode);

			if (networkCode.equalsIgnoreCase("MATRIX"))
			{
				String rolloverDataAllowance = getFlatData("rolloverDataAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String rolloverMinutesAllowance = getFlatData("rolloverVoiceAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String rolloverTextAllowance = getFlatData("rolloverTextAllowance", dashboardInfo.getAllowances().getFlat().getName());

				logger.debug("ManageDashboardServiceImpl | rolloverDataAllowance: ", rolloverDataAllowance);
				logger.debug("ManageDashboardServiceImpl | rolloverVoiceAllowance: ", rolloverMinutesAllowance);
				logger.debug("ManageDashboardServiceImpl | rolloverTextAllowance: ", rolloverTextAllowance);

				rolloverVo.setData(rolloverDataAllowance);
				rolloverVo.setMins(rolloverMinutesAllowance);
				rolloverVo.setText(rolloverTextAllowance);

				allowancesVo.setRollover(rolloverVo);

				dashboardInfoVo.setRolloverAllowances(allowancesVo);

				// Recurring Allowance start
				recurringVo = new UsageVo();

				String recurringDataAllowance = getFlatData("recurringDataAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String recurringMinutesAllowance = getFlatData("recurringVoiceAllowance", dashboardInfo.getAllowances().getFlat().getName());
				String recurringTextAllowance = getFlatData("recurringTextAllowance", dashboardInfo.getAllowances().getFlat().getName());

				logger.debug("ManageDashboardServiceImpl | recurringDataAllowance: " + recurringDataAllowance);
				logger.debug("ManageDashboardServiceImpl | recurringVoiceAllowance: " + recurringMinutesAllowance);
				logger.debug("ManageDashboardServiceImpl | recurringTextAllowance: " + recurringTextAllowance);

				recurringVo.setData(recurringDataAllowance);
				recurringVo.setMins(recurringMinutesAllowance);
				recurringVo.setText(recurringTextAllowance);

				allowancesVo.setRecurring(recurringVo);

				dashboardInfoVo.setRecurringAllowances(allowancesVo);
				// Recurring Allowance end

				dashboardInfoVo.setUnbilledAmount(DATA_NOT_AVAILABLE);

				bal_totalExtraCharges = getFlatData("bal_totalExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_domesticExtraCharges = getFlatData("bal_domesticExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_roamingExtraCharges = getFlatData("bal_roamingExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_internationalExtraCharges = getFlatData("bal_internationalExtraCharges", dashboardInfo.getAllowances().getFlat().getName());
				bal_topupCredit = getFlatData("bal_topupCredit", dashboardInfo.getAllowances().getFlat().getName());

				logger.debug("bal_totalExtraCharges: " + bal_totalExtraCharges);
				logger.debug("bal_domesticExtraCharges: " + bal_domesticExtraCharges);
				logger.debug("bal_roamingExtraCharges: " + bal_roamingExtraCharges);
				logger.debug("bal_internationalExtraCharges: " + bal_internationalExtraCharges);
				logger.debug("bal_topupCredit: " + bal_topupCredit);

				if (areFlagCheck!=null && areFlagCheck.trim().equals("true"))
				{
					QueryAccount queryAccount = new QueryAccount();
					queryAccount.setSubscriptionNumber(oldPayMSubscriptionNumber);

					UnbilledUnitSummary unbilledUnitSummary = managePayment.getUnbilledValue(queryAccount);

					if (unbilledUnitSummary != null && unbilledUnitSummary.getTotalUnbilledValue() != null && unbilledUnitSummary.getTotalUnbilledValue().trim().length() > 0)
					{
						logger.debug("Unbilled total: " + unbilledUnitSummary.getTotalUnbilledValue().toString());
						dashboardInfoVo.setUnbilledAmount(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getTotalUnbilledValue().toString())));
						logger.debug("Unbilled sum: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getTotalUnbilledValue().toString())));
					}
					if (unbilledUnitSummary != null && unbilledUnitSummary.getDomesticCallPrice() != null && unbilledUnitSummary.getDomesticCallPrice().trim().length() > 0)
					{
						logger.debug("Domestic Call Price : " + unbilledUnitSummary.getDomesticCallPrice().toString());
						dashboardInfoVo.setDomesticCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getDomesticCallPrice().toString())));
						logger.debug("Domestic Call Price with rounding of to two decimal place :" + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getDomesticCallPrice().toString())));
					}
					if (unbilledUnitSummary != null && unbilledUnitSummary.getInternationalCallPrice() != null && unbilledUnitSummary.getInternationalCallPrice().trim().length() > 0)
					{
						logger.debug("International Call Price: " + unbilledUnitSummary.getInternationalCallPrice().toString());
						dashboardInfoVo.setInternationalCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getInternationalCallPrice().toString())));
						logger.debug("International Call Price with rounding of to two decimal place : " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getInternationalCallPrice().toString())));
					}
					if (unbilledUnitSummary != null && unbilledUnitSummary.getRoamedCallPrice() != null && unbilledUnitSummary.getRoamedCallPrice().trim().length() > 0)
					{
						logger.debug("Roamed Call Price: " + unbilledUnitSummary.getRoamedCallPrice().toString());
						dashboardInfoVo.setRoamedCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getRoamedCallPrice().toString())));
						logger.debug("Roamed Call Price with rounding of to two decimal place : " + SelfCareUtil.roundToTwoDight(Float.parseFloat(unbilledUnitSummary.getRoamedCallPrice().toString())));
					}
				}else{
					if ((bal_totalExtraCharges != null) && (!bal_totalExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setUnbilledAmount(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_totalExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || Unbilled Amount: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_totalExtraCharges)));
					}
	
					if ((bal_domesticExtraCharges) != null && (!bal_domesticExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setDomesticCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_domesticExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || Domestic charge: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_domesticExtraCharges)));
					}
	
					if ((bal_roamingExtraCharges != null) && (!bal_roamingExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setRoamedCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_roamingExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || Roaming charge: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_roamingExtraCharges)));
					}
	
					if ((bal_internationalExtraCharges != null) && (!bal_internationalExtraCharges.equalsIgnoreCase("")))
					{
						dashboardInfoVo.setInternationalCallPrice(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_internationalExtraCharges)));
						logger.debug("ManageDashboardServiceImpl || International charge: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_internationalExtraCharges)));
					}
				}

				if ((bal_topupCredit != null) && (!bal_topupCredit.equalsIgnoreCase("")))
				{
					dashboardInfoVo.setTopupCredit(SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_topupCredit)));
					logger.debug("ManageDashboardServiceImpl || Topup credit: " + SelfCareUtil.roundToTwoDight(Float.parseFloat(bal_topupCredit)));
				}

			}
			// Rollover end

		}
		catch (SvalloDashboardIntegrationException sdie)
		{
			dashboardInfoVo.setNetworkCode(DATA_NOT_AVAILABLE);

			UsageVo usageVo = new UsageVo();
			usageVo.setData("0");
			usageVo.setMins("0");
			usageVo.setText("0");

			AllowancesVo allowancesVo = new AllowancesVo();
			allowancesVo.setAvailable(usageVo);
			allowancesVo.setUsed(usageVo);
			allowancesVo.setRollover(usageVo);
			allowancesVo.setRecurring(usageVo);

			dashboardInfoVo.setAllowances(allowancesVo);
			dashboardInfoVo.setInclusiveAllowances(allowancesVo);
			dashboardInfoVo.setExtraAllowances(allowancesVo);
			dashboardInfoVo.setRolloverAllowances(allowancesVo);
			dashboardInfoVo.setRecurringAllowances(allowancesVo);
			logger.error(sdie, "SvalloDashboardIntegrationException");
		}

		return dashboardInfoVo;
	}

	// antima
	public UpdateSubscriptionSerialNoVo updateSubscriptionSerialNumber(UpdateSubscriptionSerialNoVo updateSubscriptionSerialNoVo)
	{

		logger.debug("************************inside selfCare Services updateSubscriptionSerialNumber start**************");

		UpdateSubscriptionSerialNoVo updateSubscriptionSerialNoVo1 = new UpdateSubscriptionSerialNoVo();
		UpdateSubscriptionSerialNumbersRequest updateSubscriptionSerialNumbersRequest = new UpdateSubscriptionSerialNumbersRequest();
		try
		{
			updateSubscriptionSerialNumbersRequest.setManagedSerialNumber(updateSubscriptionSerialNoVo.getManagedSerialNumber());
			logger.debug("inside the slfcare service ManagedSerialNumber: " + updateSubscriptionSerialNumbersRequest.getManagedSerialNumber());
			updateSubscriptionSerialNumbersRequest.setSubscriptionNumber(updateSubscriptionSerialNoVo.getSubscriptionNumber());
			logger.debug("inside the slfcare service SubscriptionNumber: " + updateSubscriptionSerialNumbersRequest.getSubscriptionNumber());

			UpdateSubscriptionSerialNumbersResponse updateSubscriptionSerialNumbersResponse = dashboardService.updateSubscriptionSerialNumbersDetails(updateSubscriptionSerialNumbersRequest);
			updateSubscriptionSerialNoVo1.setExternalReferenceNo(updateSubscriptionSerialNumbersResponse.getExternalReferenceNo());

		}
		catch (SvalloDashboardPostUpgradeIntegrationException svalloDashboardPostUpgradeIntegrationException)
		{

			logger.error(svalloDashboardPostUpgradeIntegrationException, "\n[ ManageDashboardServiceImpl | updateSubscriptionSerialNumber() ] svalloDashboardPostUpgradeIntegrationException Catch Block ");
			logger.error(svalloDashboardPostUpgradeIntegrationException, "\n[ ManageDashboardServiceImpl | updateSubscriptionSerialNumber() ] svalloDashboardPostUpgradeIntegrationException Catch Block | Error Code =  " + MANAGEDASHBOARD_UPDATE_SUBSERIALNO_ERROR_CODE);
			logger.error(svalloDashboardPostUpgradeIntegrationException, "\n[ ManageDashboardServiceImpl | updateSubscriptionSerialNumber() ] svalloDashboardPostUpgradeIntegrationException Catch Block | Error Message  =  " + MANAGEDASHBOARD_UPDATE_SUBSERIALNO_ERROR_MESSAGE);
			DashboardPostUpgradeServiceException dashboardPostUpgradeServiceException = new DashboardPostUpgradeServiceException();
			dashboardPostUpgradeServiceException.setErrorCode(MANAGEDASHBOARD_UPDATE_SUBSERIALNO_ERROR_CODE);
			dashboardPostUpgradeServiceException.setErrorMessage(MANAGEDASHBOARD_UPDATE_SUBSERIALNO_ERROR_MESSAGE);
			dashboardPostUpgradeServiceException.setRootCause(svalloDashboardPostUpgradeIntegrationException);
			updateSubscriptionSerialNoVo1.setExternalReferenceNo(DATA_NOT_AVAILABLE_POSTUPGRADE);

		}
		catch (Exception exception)
		{

			// Error Code and Error Message in this(Exception) block will be
			// according to your business
			logger.error(exception, "\n[ ManageDashboardServiceImpl | updateSubscriptionSerialNumber() ] Exception Catch Block ");
			logger.error(exception, "\n[ ManageDashboardServiceImpl | updateSubscriptionSerialNumber() ] Exception Catch Block | Error Code =  " + MANAGEDASHBOARD_UPDATE_SUBSERIALNO_EXCEPTION_CODE);
			logger.error(exception, "\n[ ManageDashboardServiceImpl | updateSubscriptionSerialNumber() ] Exception Catch Block | Error Message  =  " + MANAGEDASHBOARD_UPDATE_SUBSERIALNO_EXCEPTION_MESSAGE);
			DashboardPostUpgradeServiceException dashboardPostUpgradeServiceException = new DashboardPostUpgradeServiceException();
			dashboardPostUpgradeServiceException.setErrorCode(MANAGEDASHBOARD_UPDATE_SUBSERIALNO_EXCEPTION_CODE);
			dashboardPostUpgradeServiceException.setErrorMessage(MANAGEDASHBOARD_UPDATE_SUBSERIALNO_EXCEPTION_MESSAGE);
			dashboardPostUpgradeServiceException.setRootCause(exception);
			updateSubscriptionSerialNoVo1.setExternalReferenceNo(DATA_NOT_AVAILABLE_POSTUPGRADE);

		}
		return updateSubscriptionSerialNoVo1;

	}

	public DashboardInfoVo getFeatures(String onlyFeatures, String subscriptionNumber, DashboardInfoVo originalDashboardInfoVo)
	{
		DashboardInfoVo dashboardInfoVoFromSession = originalDashboardInfoVo;
		try
		{

			logger.debug("********** Inside getFeatures() method in ManageDashboardServiceImpl.java ***********");

			DashboardInfo dashboardInfo = dashboardService.getDashboardInfo(onlyFeatures, "", "", subscriptionNumber, true);

			dashboardInfoVoFromSession.setDataRolloverEligible(dashboardInfo.getDataRolloverEligible());
			logger.debug("Getting FEATURES || ManageDashboardServiceImpl || Data Rollover Eligible: " + dashboardInfo.getDataRolloverEligible());
			dashboardInfoVoFromSession.setMinsRolloverEligible(dashboardInfo.getMinsRolloverEligible());
			logger.debug("Getting FEATURES || ManageDashboardServiceImpl || Minutes Rollover Eligible: " + dashboardInfo.getMinsRolloverEligible());
			dashboardInfoVoFromSession.setTextsRolloverEligible(dashboardInfo.getTextsRolloverEligible());
			logger.debug("Getting FEATURES || ManageDashboardServiceImpl || Texts Rollover Eligible: " + dashboardInfo.getTextsRolloverEligible());
		}
		catch (SvalloDashboardIntegrationException sdie)
		{
			logger.debug("*********** Exception occured while getting FEATURES *****************");
			dashboardInfoVoFromSession.setDataRolloverEligible("error");
			dashboardInfoVoFromSession.setMinsRolloverEligible("error");
			dashboardInfoVoFromSession.setTextsRolloverEligible("error");
		}

		return dashboardInfoVoFromSession;
	}
}

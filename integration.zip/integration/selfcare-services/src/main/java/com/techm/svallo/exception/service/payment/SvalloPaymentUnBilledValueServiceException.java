package com.techm.svallo.exception.service.payment;


import com.techm.svallo.exception.integration.SvalloIntegrationException;

public class SvalloPaymentUnBilledValueServiceException extends SvalloIntegrationException
{
	private static final long serialVersionUID = 1L;
}

package com.techm.svallo.service.topups;

import java.util.List;

import com.techm.svallo.vo.topups.HistoryListVo;
import com.techm.svallo.vo.topups.PaymentDetailsVo;
import com.techm.svallo.vo.topups.TopUpListVo;

public interface GetTopUpsSelfcareService 
{
	public List<TopUpListVo> getTopUps(String accountNumber);
	public String queryPurchaseProduct(PaymentDetailsVo paymentDetailsVo,String subscriptionNumber,String serviceCode,String servicePrice,String txnRef,String productType);
	public HistoryListVo getReloadHistory(String subscriptionNumber, String dataset1, String dataset2, String includeBasketData,String reloadStatusFilter, String date);
	public HistoryListVo getGReloadHistory(String subscriptionNumber, String dataset1, String dataset2, String includeBasketData,String reloadStatusFilter, String date);
}
package com.techm.svallo.vo.bundle;

import java.util.List;
import java.util.Set;

public class BundleListVo
{
	private Set<String> bundleTypes;
	private List<BundleVo> existingBundles;
	private List<BundleVo> applicableBundles;
	private List<BundleVo> pendingBundles;
	private Set<String> applicableBundleTypes;
	private String bundleError;

	public Set<String> getBundleTypes()
	{
		return bundleTypes;
	}
	
	public void setBundleTypes(Set<String> bundleTypes)
	{
		this.bundleTypes = bundleTypes;
	}
	
	public List<BundleVo> getExistingBundles()
	{
		return existingBundles;
	}
	
	public void setExistingBundles(List<BundleVo> existingBundles)
	{
		this.existingBundles = existingBundles;
	}
	
	public List<BundleVo> getApplicableBundles()
	{
		return applicableBundles;
	}
	
	public void setApplicableBundles(List<BundleVo> applicableBundles)
	{
		this.applicableBundles = applicableBundles;
	}
	
	public List<BundleVo> getPendingBundles()
	{
		return pendingBundles;
	}
	
	public void setPendingBundles(List<BundleVo> pendingBundles)
	{
		this.pendingBundles = pendingBundles;
	}
	
	public Set<String> getApplicableBundleTypes() {
		return applicableBundleTypes;
	}

	public void setApplicableBundleTypes(Set<String> applicableBundleTypes) {
		this.applicableBundleTypes = applicableBundleTypes;
	}

	public String getBundleError() {
		return bundleError;
	}

	public void setBundleError(String bundleError) {
		this.bundleError = bundleError;
	}	
}
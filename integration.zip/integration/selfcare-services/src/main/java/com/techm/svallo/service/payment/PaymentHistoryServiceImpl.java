package com.techm.svallo.service.payment;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.payment.SvalloPaymentHistoryServiceException;
import com.techm.svallo.vo.billingandpayment.PaymentNBillingVo;
import com.techmahindra.online.svallo.model.payment._2014._09._01.Payment;
import com.techmahindra.online.svallo.model.payment._2014._09._01.PaymentsDetail;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;
import com.techmahindra.online.svallo.service.common.exception.payment.SvalloPaymentPaymentsHistoryIntegrationException;
import com.techmahindra.online.svallo.service.payment._2014._09._01.ManagePayment;

@Service("paymentHistoryService")
public class PaymentHistoryServiceImpl implements PaymentHistoryService
{
	
	final static PortalLogger logger = PortalLogger.getLogger(PaymentHistoryServiceImpl.class);

	@Autowired
	private ManagePayment managePayment;
	
	@Value("${payment.payment.history.error.code}")
	private String PAYMENT_PAYMENT_HISTORY_ERROR_CODE;
	
	@Value("${payment.payment.history.error.message}")
	private String PAYMENT_PAYMENT_HISTORY_ERROR_MESSAGE;

	@Override
	public List<PaymentNBillingVo> getPaymentHistory(QueryAccount queryAccount) throws SvalloPaymentHistoryServiceException
	{
		List<PaymentNBillingVo> payments = null;
		try
		{
			logger.debug("[ getPaymentHistory() ] START");
			logger.debug("[ getPaymentHistory() ] queryAccount > " + queryAccount);
			PaymentsDetail paymentsDetail = managePayment.getPaymentHistory(queryAccount);
			logger.debug("[ getPaymentHistory() ] , Got response from camel service, paymentsDetail > " + paymentsDetail);
			List<Payment> paymentList = paymentsDetail.getPayments();
			logger.debug("[ getPaymentHistory() ] , Got response from camel service, paymentList > " + paymentList);
			if (paymentList != null && paymentList.size() > 0)
			{
				payments = new ArrayList<PaymentNBillingVo>();
				for (int i = 0; i < paymentList.size(); i++)
				{
					Payment payment = paymentList.get(i);
					PaymentNBillingVo paymentNBillingVo = new PaymentNBillingVo();
					mapPaymentNBillingVo(payment, paymentNBillingVo);
					payments.add(paymentNBillingVo);

				}
			}
			logger.debug("[ getPaymentHistory() ], Got response from camel service, payments > " + payments);
			logger.debug("[ getPaymentHistory() ] END");
		}
		catch (SvalloPaymentPaymentsHistoryIntegrationException svalloPaymentPaymentsHistoryIntegrationException)
		{
			logger.error(svalloPaymentPaymentsHistoryIntegrationException,"[ getPaymentHistory() ] SvalloPaymentPaymentsHistoryIntegrationException Catch Block ");
			logger.error(svalloPaymentPaymentsHistoryIntegrationException,"[ getPaymentHistory() ] SvalloPaymentPaymentsHistoryIntegrationException Catch Block | Error Code =  " + PAYMENT_PAYMENT_HISTORY_ERROR_CODE);
			logger.error(svalloPaymentPaymentsHistoryIntegrationException,"[ getPaymentHistory() ] SvalloPaymentPaymentsHistoryIntegrationException Catch Block | Error Message  =  " + PAYMENT_PAYMENT_HISTORY_ERROR_MESSAGE);
			SvalloPaymentHistoryServiceException svalloPaymentHistoryServiceException = new SvalloPaymentHistoryServiceException();
			svalloPaymentHistoryServiceException.setErrorCode(PAYMENT_PAYMENT_HISTORY_ERROR_CODE);
			svalloPaymentHistoryServiceException.setErrorMessage(PAYMENT_PAYMENT_HISTORY_ERROR_MESSAGE);
			svalloPaymentHistoryServiceException.setRootCause(svalloPaymentPaymentsHistoryIntegrationException);
			throw svalloPaymentHistoryServiceException;
		}
		catch (Exception exception)
		{
			logger.error(exception,"[ getPaymentHistory() ] Exception   catch block ");
			logger.error(exception,"[ getPaymentHistory() ] Exception   catch block | Error Code =  " + PAYMENT_PAYMENT_HISTORY_ERROR_CODE);
			logger.error(exception,"[ getPaymentHistory() ] Exception   catch block | Error Message  =  " + PAYMENT_PAYMENT_HISTORY_ERROR_MESSAGE);
			SvalloPaymentHistoryServiceException svalloPaymentHistoryServiceException = new SvalloPaymentHistoryServiceException();
			svalloPaymentHistoryServiceException.setErrorCode(PAYMENT_PAYMENT_HISTORY_ERROR_CODE);
			svalloPaymentHistoryServiceException.setErrorMessage(PAYMENT_PAYMENT_HISTORY_ERROR_MESSAGE);
			svalloPaymentHistoryServiceException.setRootCause(exception);
			throw svalloPaymentHistoryServiceException;
		}
		return payments;
	}

	private void mapPaymentNBillingVo(Payment payment, PaymentNBillingVo paymentNBillingVo)
	{
		if (payment != null && paymentNBillingVo != null)
		{
			try
			{
				if(payment.getAmountPaid()!=null)
				{	
					String amount_paid = payment.getAmountPaid();
					logger.debug("[ mapPaymentNBillingVo() ] amount_paid before > > > " + amount_paid);
					if(amount_paid!=null && amount_paid.indexOf("-")!=-1)
					{
						amount_paid=amount_paid.replaceAll("-", "");
						paymentNBillingVo.setMinusAmountCheck("true");
						
					}
					logger.debug("[ mapPaymentNBillingVo() ] amount_paid after > > > "+amount_paid);
					paymentNBillingVo.setAmountPaid(String.valueOf(amount_paid));
				}	
				//logger.debug("[ mapPaymentNBillingVo() ] amount_paid  > > > " + payment.getAmountPaid());
				//paymentNBillingVo.setAmountPaid(String.valueOf(payment.getAmountPaid()));
				paymentNBillingVo.setPaymentDate(payment.getPaymentDate());
				paymentNBillingVo.setPaymentReference(payment.getPaymentReference());
				paymentNBillingVo.setTransactionType(payment.getTransactionType());
				paymentNBillingVo.setTaxDate(payment.getTaxDate());
				paymentNBillingVo.setDescription(payment.getDescription());
				
				logger.debug("[ getPaymentHistory() ] payment.getPaymentDate()>>> " + payment.getPaymentDate());
				logger.debug("[ getPaymentHistory() ] payment.getPaymentReference()>>> " + payment.getPaymentReference());
				logger.debug("[ getPaymentHistory() ] payment.getTransactionType()>>> " + payment.getTransactionType());
				logger.debug("[ getPaymentHistory() ] payment.getTransactionType()>>> " + payment.getTransactionType());
				logger.debug("[ getPaymentHistory() ] payment.getTransactionType()>>> " + payment.getTransactionType());
				logger.debug("[ getPaymentHistory() ] payment.getDescription()>>> " + payment.getDescription());
			}
			catch (Exception exception)
			{
				logger.error(exception,"[ getPaymentHistory() ] Exception catch block ");
				logger.error(exception,"[ getPaymentHistory() ] Exception catch block | Error Code =  " + PAYMENT_PAYMENT_HISTORY_ERROR_CODE);
				logger.error(exception,"[ getPaymentHistory() ] Exception catch block | Error Message  =  " + PAYMENT_PAYMENT_HISTORY_ERROR_MESSAGE);
				SvalloPaymentHistoryServiceException svalloPaymentHistoryServiceException = new SvalloPaymentHistoryServiceException();
				svalloPaymentHistoryServiceException.setErrorCode(PAYMENT_PAYMENT_HISTORY_ERROR_CODE);
				svalloPaymentHistoryServiceException.setErrorMessage(PAYMENT_PAYMENT_HISTORY_ERROR_MESSAGE);
				svalloPaymentHistoryServiceException.setRootCause(exception);
				throw svalloPaymentHistoryServiceException;
			}
		}
	}

}

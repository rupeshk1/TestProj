package com.techm.svallo.vo.singlesignon;

public class SingleSignOnAccountListVo {

	private String attributeId;
	private String attributeValue;
	
	public String getAttributeId() {
		return attributeId;
	}
	public void setAttributeId(String attributeId) {
		this.attributeId = attributeId;
	}
	public String getAttributeValue() {
		return attributeValue;
	}
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
	
}

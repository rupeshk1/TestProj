package com.techm.svallo.service.myallowances;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.vo.dashboard.DashboardInfoVo;
import com.techm.svallo.vo.subscriptioncap.SubscriptionCapVo;
import com.techmahindra.online.svallo.model.myallowances._2014._10._07.MyAllowancesSumRequest;
import com.techmahindra.online.svallo.model.myallowances._2014._10._07.MyAllowancesSumResponse;
import com.techmahindra.online.svallo.model.myallowances._2014._10._07.SubscriptionCapRequest;
import com.techmahindra.online.svallo.model.myallowances._2014._10._07.SubscriptionCapResponse;
import com.techmahindra.online.svallo.model.myallowances._2014._10._07.SubscriptionCapUpdateRequest;
import com.techmahindra.online.svallo.model.myallowances._2014._10._07.SubscriptionCapUpdateResponse;
import com.techmahindra.online.svallo.service.common.exception.SvalloServiceException;
import com.techmahindra.online.svallo.service.common.exception.myallowances.SvalloCappingIntegrationException;
import com.techmahindra.online.svallo.service.common.exception.myallowances.SvalloMyAllowancesIntegrationException;
import com.techmahindra.online.svallo.service.myallowances._2014._10._07.MyAllowancesSum;
import com.techm.svallo.exception.service.myallowances.SvalloCappingServiceException;
import com.techm.svallo.exception.service.myallowances.SvalloMyAllowancesServiceException;
import com.techm.svallo.util.SelfCareUtil;
       
public class MyAllowancesServiceImpl implements MyAllowancesService
{
	final static PortalLogger logger = PortalLogger.getLogger(MyAllowancesServiceImpl.class);

	@Autowired
	private MyAllowancesSum myAllowancesSum;
	
	@Value("${data.not.available}")
	private String DATA_NOT_AVAILABLE;
	
	@Value("${myallowances.getMyAllowancesSum.error.code}")
	private String MYALLOWANCES_GETMYALLOWANCESSUM_ERROR_CODE;
	
	@Value("${myallowances.getMyAllowancesSum.error.message}")
	private String MYALLOWANCES_GETMYALLOWANCESSUM_ERROR_MESSAGE;
	
	@Value("${myallowances.getSubscriptionCap.error.code}")
	private String MYALLOWANCES_GETSUBSCRIPTIONCAP_ERROR_CODE;
	
	@Value("${myallowances.getSubscriptionCap.error.message}")
	private String MYALLOWANCES_GETSUBSCRIPTIONCAP_ERROR_MESSAGE;
	
	@Value("${myallowances.updateSubscriptionCap.error.code}")
	private String MYALLOWANCES_UPDATESUBSCRIPTIONCAP_ERROR_CODE;
	
	@Value("${myallowances.updateSubscriptionCap.error.message}")
	private String MYALLOWANCES_UPDATESUBSCRIPTIONCAP_ERROR_MESSAGE;
	
	@Value("${myallowances.getMyAllowancesSum.exception.code}")
	private String MYALLOWANCES_GETMYALLOWANCESSUM_EXCEPTION_CODE;
	
	@Value("${myallowances.getMyAllowancesSum.exception.message}")
	private String MYALLOWANCES_GETMYALLOWANCESSUM_EXCEPTION_MESSAGE;
	
	@Value("${myallowances.getSubscriptionCap.exception.code}")
	private String MYALLOWANCES_GETSUBSCRIPTIONCAP_EXCEPTION_CODE;
	
	@Value("${myallowances.getSubscriptionCap.exception.message}")
	private String MYALLOWANCES_GETSUBSCRIPTIONCAP_EXCEPTION_MESSAGE;
	
	@Value("${myallowances.updateSubscriptionCap.exception.code}")
	private String MYALLOWANCES_UPDATESUBSCRIPTIONCAP_EXCEPTION_CODE;
	
	@Value("${myallowances.updateSubscriptionCap.exception.message}")
	private String MYALLOWANCES_UPDATESUBSCRIPTIONCAP_EXCEPTION_MESSAGE;
	
	public void setMyAllowancesSum(MyAllowancesSum myAllowancesSum) {
		this.myAllowancesSum = myAllowancesSum;
	}

	public DashboardInfoVo getMyAllowancesSum(String subscriptionNumber) {
		// TODO Auto-generated method stub
		String currentMRCSum="0";
		String futureMRCSum = "0";
		String discountedCurrentMRCSum = "0";
		String discountedFutureMRCSum = "0";
		String boltonsSum = "0";
		DashboardInfoVo dashboardInfoVo = new DashboardInfoVo();
		try {			
		
			MyAllowancesSumRequest myAllowancesSumRequest = new MyAllowancesSumRequest();
			myAllowancesSumRequest.setSubscriptionNumber(subscriptionNumber);	
			logger.debug("request after setting" + myAllowancesSumRequest.getSubscriptionNumber());
			MyAllowancesSumResponse allowancesSum = myAllowancesSum.getMyAllowancesSum(myAllowancesSumRequest);	
			if(allowancesSum != null){			
				logger.debug("responsee" + allowancesSum.getCurrentMRCSum().toString());
				
				logger.debug("Current MRC services sum" +allowancesSum.getCurrentMRCSum().toString());
				currentMRCSum = SelfCareUtil.roundToTwoDight(Float.parseFloat(allowancesSum.getCurrentMRCSum().toString()));
				
				//myAllowancesSumTotal = allowancesSum.getMyAllowancesSum().toString();	
				//logger.debug("MRC Services sum: " + myAllowancesSumTotal);
				
				logger.debug("Current MRC sum: "+currentMRCSum);
				logger.debug("Future MRC Services Sum: " +allowancesSum.getFutureMRCSum().toString());
				futureMRCSum = SelfCareUtil.roundToTwoDight(Float.parseFloat(allowancesSum.getFutureMRCSum().toString()));
				logger.debug("Total Sum: " +futureMRCSum);
				
				//totalSum = allowancesSum.getTotalSum().toString();
				
				logger.debug("Discounted current MRC Sum: ", allowancesSum.getDiscountedCurrentMRCSum());
				discountedCurrentMRCSum = SelfCareUtil.roundToTwoDight(Float.parseFloat(allowancesSum.getDiscountedCurrentMRCSum().toString()));
				
				logger.debug("Discounted future MRC Sum: ", allowancesSum.getDiscountedFutureMRCSum());
				discountedFutureMRCSum = SelfCareUtil.roundToTwoDight(Float.parseFloat(allowancesSum.getDiscountedFutureMRCSum().toString()));
				
				logger.debug("Boltons Sum: ", allowancesSum.getBoltonsSum());
				boltonsSum = SelfCareUtil.roundToTwoDight(Float.parseFloat(allowancesSum.getBoltonsSum().toString()));
				
				
				dashboardInfoVo.setCurrentMrcSum(currentMRCSum);
				dashboardInfoVo.setFutureMrcSum(futureMRCSum);
				dashboardInfoVo.setDiscountedCurrentMrcSum(discountedCurrentMRCSum);
				dashboardInfoVo.setDiscountedFutureMrcSum(discountedFutureMRCSum);
				dashboardInfoVo.setBoltonsSum(boltonsSum);
			}
			
		}catch(SvalloMyAllowancesIntegrationException svalloMyAllowancesIntegrationException)
		{
			//es.printStackTrace();
			logger.error(svalloMyAllowancesIntegrationException, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] SvalloMyAllowancesServiceException Catch Block ");
			logger.error(svalloMyAllowancesIntegrationException, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] SvalloMyAllowancesServiceException Catch Block | Error Code =  "+MYALLOWANCES_GETMYALLOWANCESSUM_ERROR_CODE);
			logger.error(svalloMyAllowancesIntegrationException, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] SvalloMyAllowancesServiceException Catch Block | Error Message  =  "+MYALLOWANCES_GETMYALLOWANCESSUM_ERROR_MESSAGE);
			SvalloMyAllowancesServiceException svalloMyAllowancesServiceException = new SvalloMyAllowancesServiceException();
			svalloMyAllowancesServiceException.setErrorCode(MYALLOWANCES_GETMYALLOWANCESSUM_ERROR_CODE);
			svalloMyAllowancesServiceException.setErrorMessage(MYALLOWANCES_GETMYALLOWANCESSUM_ERROR_MESSAGE);
			svalloMyAllowancesServiceException.setRootCause(svalloMyAllowancesIntegrationException);
						
		}
		catch(Exception exception)
		{
			//es.printStackTrace();
			logger.error(exception, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] Exception Catch Block ");
			logger.error(exception, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] Exception Catch Block | Error Code =  "+MYALLOWANCES_GETMYALLOWANCESSUM_EXCEPTION_CODE);
			logger.error(exception, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] Exception Catch Block | Error Message  =  "+MYALLOWANCES_GETMYALLOWANCESSUM_EXCEPTION_MESSAGE);
			SvalloMyAllowancesServiceException svalloMyAllowancesServiceException = new SvalloMyAllowancesServiceException();
			svalloMyAllowancesServiceException.setErrorCode(MYALLOWANCES_GETMYALLOWANCESSUM_EXCEPTION_CODE);
			svalloMyAllowancesServiceException.setErrorMessage(MYALLOWANCES_GETMYALLOWANCESSUM_EXCEPTION_MESSAGE);
			svalloMyAllowancesServiceException.setRootCause(exception);	
			
		}
		return dashboardInfoVo;
	}

	public SubscriptionCapVo getSubscriptionCap(String subscriptionNumber) {
		// TODO Auto-generated method stub
		logger.debug("Subscription Number: " +subscriptionNumber);
		
		SubscriptionCapVo subscriptionCapVo = new SubscriptionCapVo();
		try{		
			SubscriptionCapRequest request = new SubscriptionCapRequest();
			request.setSubscriptionNumber(subscriptionNumber);
			
			SubscriptionCapResponse response = myAllowancesSum.getSubscriptionCap(request);
			
			if(response != null){				
				subscriptionCapVo.setAmount(response.getCapData().getTotal().getAmount());
				logger.debug("Amount: " +response.getCapData().getTotal().getAmount());
				subscriptionCapVo.setUnit(response.getCapData().getTotal().getUnit());
				logger.debug("Unit: " +response.getCapData().getTotal().getUnit());
				subscriptionCapVo.setUserDefinedCredit(response.getCapData().getTotal().getUserdefinedcredit());
				logger.debug("User defined credit: " +response.getCapData().getTotal().getUserdefinedcredit());
				subscriptionCapVo.setEffectiveDate(response.getCapData().getTotal().getEffectivedate());
				logger.debug("Effective date: " +response.getCapData().getTotal().getEffectivedate());
				subscriptionCapVo.setTopupCredit(response.getTopupCredit());
				logger.debug(" [ MyAllowancesServiceImpl | getSubscriptionCap() ] Topup credit: " +response.getTopupCredit());
			}	
			
		}catch(SvalloCappingIntegrationException svalloCappingIntegrationException)
		{
			//es.printStackTrace();
			logger.error(svalloCappingIntegrationException, "\n[ MyAllowancesSumImpl | getSubscriptionCap() ] SvalloCappingServiceException Catch Block ");
			logger.error(svalloCappingIntegrationException, "\n[ MyAllowancesSumImpl | getSubscriptionCap() ] SvalloCappingServiceException Catch Block | Error Code =  "+MYALLOWANCES_GETSUBSCRIPTIONCAP_ERROR_CODE);
			logger.error(svalloCappingIntegrationException, "\n[ MyAllowancesSumImpl | getSubscriptionCap() ] SvalloCappingServiceException Catch Block | Error Message  =  "+MYALLOWANCES_GETSUBSCRIPTIONCAP_ERROR_MESSAGE);
			SvalloCappingServiceException svalloCappingServiceException = new SvalloCappingServiceException();
			svalloCappingServiceException.setErrorCode(MYALLOWANCES_GETSUBSCRIPTIONCAP_ERROR_CODE);
			svalloCappingServiceException.setErrorMessage(MYALLOWANCES_GETSUBSCRIPTIONCAP_ERROR_MESSAGE);
			svalloCappingServiceException.setRootCause(svalloCappingIntegrationException);
			
			subscriptionCapVo.setAmount(DATA_NOT_AVAILABLE);
			subscriptionCapVo.setUnit(DATA_NOT_AVAILABLE);
			subscriptionCapVo.setUserDefinedCredit(DATA_NOT_AVAILABLE);
			subscriptionCapVo.setEffectiveDate(DATA_NOT_AVAILABLE);			
			
		}
		catch(Exception exception)
		{
			//es.printStackTrace();
			logger.error(exception, "\n[ MyAllowancesSumImpl | getSubscriptionCap() ] Exception Catch Block ");
			logger.error(exception, "\n[ MyAllowancesSumImpl | getSubscriptionCap() ] Exception Catch Block | Error Code =  "+MYALLOWANCES_GETSUBSCRIPTIONCAP_EXCEPTION_CODE);
			logger.error(exception, "\n[ MyAllowancesSumImpl | getSubscriptionCap() ] Exception Catch Block | Error Message  =  "+MYALLOWANCES_GETSUBSCRIPTIONCAP_EXCEPTION_MESSAGE);
			SvalloCappingServiceException svalloCappingServiceException = new SvalloCappingServiceException();
			svalloCappingServiceException.setErrorCode(MYALLOWANCES_GETSUBSCRIPTIONCAP_EXCEPTION_CODE);
			svalloCappingServiceException.setErrorMessage(MYALLOWANCES_GETSUBSCRIPTIONCAP_EXCEPTION_MESSAGE);
			svalloCappingServiceException.setRootCause(exception);
			
			subscriptionCapVo.setAmount(DATA_NOT_AVAILABLE);
			subscriptionCapVo.setUnit(DATA_NOT_AVAILABLE);
			subscriptionCapVo.setUserDefinedCredit(DATA_NOT_AVAILABLE);
			subscriptionCapVo.setEffectiveDate(DATA_NOT_AVAILABLE);		
		}
		return subscriptionCapVo;
	}

	public SubscriptionCapVo updateSubscriptionCap(
			SubscriptionCapVo subscriptionCapVo1) {
		// TODO Auto-generated method stub
		logger.debug("Subscription Number: " +subscriptionCapVo1.getSubscriptionNumber());
		logger.debug("Capcode: " +subscriptionCapVo1.getCapCode());
		logger.debug("Effective Date: " +subscriptionCapVo1.getEffectiveDate());
		logger.debug("Value: " +subscriptionCapVo1.getValue());
		logger.debug("Expiry date: " +subscriptionCapVo1.getExpiryDate());
		logger.debug("Operation: " +subscriptionCapVo1.getOperation());
		logger.debug("Unbar: " +subscriptionCapVo1.getUnbar());
		
		SubscriptionCapVo subscriptionCapVo = new SubscriptionCapVo();
		try{
			SubscriptionCapUpdateRequest request = new SubscriptionCapUpdateRequest();
			request.setSubscriptionNumber(subscriptionCapVo1.getSubscriptionNumber());
			request.setCapCode(subscriptionCapVo1.getCapCode());
			request.setEffectiveDate(subscriptionCapVo1.getEffectiveDate());
			if(subscriptionCapVo1.getUnbar().equalsIgnoreCase("true")){
			request.setUnBar(subscriptionCapVo1.getUnbar());
			}
			request.setValue(subscriptionCapVo1.getValue());
			request.setExpiryDate(subscriptionCapVo1.getExpiryDate());
			request.setOperation(subscriptionCapVo1.getOperation());
			
			SubscriptionCapUpdateResponse response = myAllowancesSum.updateSubscriptionCap(request);
			if(response != null){
			   subscriptionCapVo.setExternalReference(response.getExternalReference());
			   logger.debug("External Reference: " +response.getExternalReference());
			} 
			
		}catch(SvalloCappingIntegrationException svalloCappingIntegrationException)
		{
			//es.printStackTrace();
			logger.error(svalloCappingIntegrationException, "\n[ MyAllowancesSumImpl | updateSubscriptionCap() ] SvalloCappingServiceException Catch Block ");
			logger.error(svalloCappingIntegrationException, "\n[ MyAllowancesSumImpl | updateSubscriptionCap() ] SvalloCappingServiceException Catch Block | Error Code =  "+MYALLOWANCES_UPDATESUBSCRIPTIONCAP_ERROR_CODE);
			logger.error(svalloCappingIntegrationException, "\n[ MyAllowancesSumImpl | updateSubscriptionCap() ] SvalloCappingServiceException Catch Block | Error Message  =  "+MYALLOWANCES_UPDATESUBSCRIPTIONCAP_ERROR_MESSAGE);
			SvalloCappingServiceException svalloCappingServiceException = new SvalloCappingServiceException();
			svalloCappingServiceException.setErrorCode(MYALLOWANCES_UPDATESUBSCRIPTIONCAP_ERROR_CODE);
			svalloCappingServiceException.setErrorMessage(MYALLOWANCES_UPDATESUBSCRIPTIONCAP_ERROR_MESSAGE);
			svalloCappingServiceException.setRootCause(svalloCappingIntegrationException);
			
			subscriptionCapVo.setExternalReference(DATA_NOT_AVAILABLE);	
		}
		catch(Exception exception)
		{
			//es.printStackTrace();
			logger.error(exception, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] Exception Catch Block ");
			logger.error(exception, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] Exception Catch Block | Error Code =  "+MYALLOWANCES_UPDATESUBSCRIPTIONCAP_EXCEPTION_CODE);
			logger.error(exception, "\n[ MyAllowancesSumImpl | getMyAllowancesSum() ] Exception Catch Block | Error Message  =  "+MYALLOWANCES_UPDATESUBSCRIPTIONCAP_EXCEPTION_MESSAGE);
			SvalloCappingServiceException svalloCappingServiceException = new SvalloCappingServiceException();
			svalloCappingServiceException.setErrorCode(MYALLOWANCES_UPDATESUBSCRIPTIONCAP_EXCEPTION_CODE);
			svalloCappingServiceException.setErrorMessage(MYALLOWANCES_UPDATESUBSCRIPTIONCAP_EXCEPTION_MESSAGE);
			svalloCappingServiceException.setRootCause(exception);
			
			subscriptionCapVo.setExternalReference(DATA_NOT_AVAILABLE);			
		}		
		return subscriptionCapVo;
	}
}

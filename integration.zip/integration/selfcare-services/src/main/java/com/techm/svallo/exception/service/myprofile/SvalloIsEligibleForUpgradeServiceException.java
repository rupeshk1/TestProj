package com.techm.svallo.exception.service.myprofile;

import com.techm.svallo.exception.service.SvalloServiceException;

public class SvalloIsEligibleForUpgradeServiceException extends SvalloServiceException
{
	private static final long serialVersionUID = 1L;
}

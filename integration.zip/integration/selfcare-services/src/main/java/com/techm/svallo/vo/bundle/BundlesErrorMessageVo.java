package com.techm.svallo.vo.bundle;

public class BundlesErrorMessageVo
{
	
 private int isSuccessful; //1 if successful and 0 if unsuccessful
 private String message="";
 private String operation="";
 private String serviceName="";
 private String errorBundleType="";
 private String serviceCode="";
 
 
	public int getIsSuccessful() {
		return isSuccessful;
	}
	public void setIsSuccessful(int isSuccessful) {
		this.isSuccessful = isSuccessful;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getErrorBundleType() {
		return errorBundleType;
	}
	public void setErrorBundleType(String errorBundleType) {
		this.errorBundleType = errorBundleType;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
}

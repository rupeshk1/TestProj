package com.techm.svallo.vo.editprofile;

public class PreferencesVo {
	
	/*private String key;
	private String value;
	
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}*/
	
	private String marketingByLetter;
	private String marketingByEmail;
	private String marketingByTelephone;
	private String marketingBySMS;
	
	public String getMarketingByLetter() {
		return marketingByLetter;
	}
	public void setMarketingByLetter(String marketingByLetter) {
		this.marketingByLetter = marketingByLetter;
	}
	public String getMarketingByEmail() {
		return marketingByEmail;
	}
	public void setMarketingByEmail(String marketingByEmail) {
		this.marketingByEmail = marketingByEmail;
	}
	public String getMarketingByTelephone() {
		return marketingByTelephone;
	}
	public void setMarketingByTelephone(String marketingByTelephone) {
		this.marketingByTelephone = marketingByTelephone;
	}
	public String getMarketingBySMS() {
		return marketingBySMS;
	}
	public void setMarketingBySMS(String marketingBySMS) {
		this.marketingBySMS = marketingBySMS;
	}

}

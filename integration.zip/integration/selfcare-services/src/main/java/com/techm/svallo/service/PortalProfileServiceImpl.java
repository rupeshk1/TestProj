/**
 * 
 */
package com.techm.svallo.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.techm.svallo.vo.CustomerAccount;

/**
 * @author rk0012514
 *
 */
public class PortalProfileServiceImpl implements PortalProfileService {
	
	private static String GET_USER_ACCOUNTS="select acc_NickName as accountNickName, acc_Number as accountNumber,createdDate as createdDate,acc_status as status,lastUpdatedDate as lastUpdatedDate,prof_userId as userId from User_Acc as UserAccount where prof_userId=?";
	private static String CREATE_USER_ACCOUNTS="insert into User_Acc (acc_NickName,acc_Number,createdDate,acc_status,lastUpdatedDate,prof_userId) values(?,?,?,?,?,?)";
	private JdbcTemplate jdbcTemplate=null; 

	/* (non-Javadoc)
	 * @see com.techm.svallo.service.PortalProfileService#getUserAccount(java.lang.String)
	 */
	public List<CustomerAccount> getUserAccount(String userId) {
		List<CustomerAccount> custAcclist=jdbcTemplate.query(GET_USER_ACCOUNTS,new Object[]{userId}, new CustomerAccountMapper());
		return custAcclist;
	}

	/* (non-Javadoc)
	 * @see com.techm.svallo.service.PortalProfileService#createUserAccount(com.techm.svallo.vo.CustomerAccount)
	 */
	public void createUserAccount(CustomerAccount custAccount) {
		jdbcTemplate.update(CREATE_USER_ACCOUNTS,custAccount.getAccountNickName(),custAccount.getAccountNumber(),new Date(),custAccount.getStatus(),new Date(),custAccount.getUserId());
	}

	/**
	 * @param jdbcTemplate the jdbcTemplate to set
	 */
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	private static final class CustomerAccountMapper implements RowMapper<CustomerAccount> {

	    public CustomerAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
	    	CustomerAccount custAccount = new CustomerAccount();
	    	custAccount.setAccountNickName(rs.getString("accountNickName"));
	    	custAccount.setAccountNumber(rs.getString("accountNumber"));
	    	custAccount.setStatus(rs.getString("status"));
	    	custAccount.setCreatedDate(rs.getDate("createdDate"));
	    	custAccount.setLastUpdatedDate(rs.getDate("lastUpdatedDate"));
	    	custAccount.setUserId(rs.getString("userId"));
	        return custAccount;
	    }
	}

}

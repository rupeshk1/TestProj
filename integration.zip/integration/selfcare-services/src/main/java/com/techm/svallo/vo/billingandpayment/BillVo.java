package com.techm.svallo.vo.billingandpayment;


public class BillVo
{
    private String accountNumber;
    private String amountDue;
    private String amountOverdue;
    private String billDate;
    private String billendDate;
    private String billstartDate;
    private String id;
    private String invoiceNumber;
    private String lastPaymentAmount;
    private String lastPaymentDate;
    private String referenceNumber;
    private String status;
    private String unBilledAmount;
    private String month;
    private String year;
    private String day;
    private String billDateMonthYear;
    private String billPath;
    private String ddenabled;
    private String duedate;
    
	public String getDdenabled() {
		return ddenabled;
	}
	public void setDdenabled(String ddenabled) {
		this.ddenabled = ddenabled;
	}
	public String getDuedate() {
		return duedate;
	}
	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	public String getAmountDue()
	{
		return amountDue;
	}
	public void setAmountDue(String amountDue)
	{
		this.amountDue = amountDue;
	}
	public String getAmountOverdue()
	{
		return amountOverdue;
	}
	public void setAmountOverdue(String amountOverdue)
	{
		this.amountOverdue = amountOverdue;
	}
	public String getBillDate()
	{
		return billDate;
	}
	public void setBillDate(String billDate)
	{
		this.billDate = billDate;
	}
	public String getBillendDate()
	{
		return billendDate;
	}
	public void setBillendDate(String billendDate)
	{
		this.billendDate = billendDate;
	}
	public String getBillstartDate()
	{
		return billstartDate;
	}
	public void setBillstartDate(String billstartDate)
	{
		this.billstartDate = billstartDate;
	}
	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getInvoiceNumber()
	{
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber)
	{
		this.invoiceNumber = invoiceNumber;
	}
	public String getLastPaymentAmount()
	{
		return lastPaymentAmount;
	}
	public void setLastPaymentAmount(String lastPaymentAmount)
	{
		this.lastPaymentAmount = lastPaymentAmount;
	}
	public String getLastPaymentDate()
	{
		return lastPaymentDate;
	}
	public void setLastPaymentDate(String lastPaymentDate)
	{
		this.lastPaymentDate = lastPaymentDate;
	}
	public String getReferenceNumber()
	{
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber)
	{
		this.referenceNumber = referenceNumber;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public String getUnBilledAmount()
	{
		return unBilledAmount;
	}
	public void setUnBilledAmount(String unBilledAmount)
	{
		this.unBilledAmount = unBilledAmount;
	}
	public String getMonth()
	{
		return month;
	}
	public void setMonth(String month)
	{
		this.month = month;
	}
	public String getYear()
	{
		return year;
	}
	public void setYear(String year)
	{
		this.year = year;
	}
	public String getDay()
	{
		return day;
	}
	public void setDay(String day)
	{
		this.day = day;
	}
	public String getBillDateMonthYear()
	{
		return billDateMonthYear;
	}
	public void setBillDateMonthYear(String billDateMonthYear)
	{
		this.billDateMonthYear = billDateMonthYear;
	}
	public String getBillPath()
	{
		return billPath;
	}
	public void setBillPath(String billPath)
	{
		this.billPath = billPath;
	}
    
    
}

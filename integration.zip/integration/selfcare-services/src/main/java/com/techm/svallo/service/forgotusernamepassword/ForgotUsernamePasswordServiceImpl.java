package com.techm.svallo.service.forgotusernamepassword;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.vo.forgotusernamepassword.ForgotUsernamePasswordVo;
import com.techm.svallo.vo.registration.RegistrationVo;
import com.techmahindra.online.svallo.service.common.exception.registration.SvalloRegistrationIntegrationException;
import com.techmahindra.online.svallo.model.registration_login._2014._08._22.Account;
import com.techmahindra.online.svallo.model.registration_login._2014._08._22.ForgotUnPwDetailsResponse;
import com.techmahindra.online.svallo.model.registration_login._2014._08._22.ForgotUnPwRequest;
import com.techmahindra.online.svallo.service.common.exception.SvalloServiceException;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloRegistrationLogin;
import com.techmahindra.online.svallo.service.registration_login._2014._08._22.SvalloResendPreRegistrationPINResponse;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.techm.svallo.exception.service.forgotusername.SvalloForgotUsernamePasswordServiceException;
import com.techm.svallo.util.SelfCareUtil;

public class ForgotUsernamePasswordServiceImpl implements ForgotUsernamePasswordService
{

	final static PortalLogger logger = PortalLogger.getLogger(ForgotUsernamePasswordServiceImpl.class);
	
	@Autowired
	private SvalloRegistrationLogin  forgotUsernamePassword;
	
	@Autowired
	private JdbcTemplate jdbcTemplate=null;	

	public void setForgotUsernamePassword(SvalloRegistrationLogin forgotUsernamePassword) {
		this.forgotUsernamePassword = forgotUsernamePassword;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	private static String GET_USER_USERNAME="select screenName from User_ where emailAddress=?;";
	
	private static String IS_USER_EXISTS="select userId from User_ where screenName=?;";

	private static String UPDATE_USERDETAILS_TO_UPDATE_LOCKOUT="update User_ set lockout=0 where userId=?;";
	
	/*
	private static String GET_USER_DETAILS="select ev.data_ as data_ from ExpandoValue ev "+
			"join User_ u on u.userId = ev.classPk "+
			"join ExpandoRow er on u.userId = er.classPk and ev.rowid_ = er.rowId_ "+
			"join ExpandoColumn ec on u.companyId=ec.companyId and ev.columnId=ec.columnId "+
			"where ec.name='accountNum' and u.userId='?'; ";
	*/
	
	private static String GET_USER_DETAILS="select openId as accountNum from User_ where userId=?;";
			
	
	@Value("${forgot.data.not.available}")
	private String FORGOT_DATA_NOT_AVAILABLE;
	

	@Value("${forgot.username.impl.getusernameaccountdetails.error.code}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_ERROR_CODE;
	
	@Value("${forgot.username.impl.getusernameaccountdetails.error.message}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_ERROR_MESSAGE;
	
	@Value("${forgot.username.impl.getusernameaccountdetails.exception.code}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_EXCEPTION_CODE;
	
	@Value("${forgot.username.impl.getusernameaccountdetails.exception.message}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${forgot.username.impl.getUsernamePinDetails.error.code}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_ERROR_CODE;
	
	@Value("${forgot.username.impl.getUsernamePinDetails.error.message}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_ERROR_MESSAGE;
	
	@Value("${forgot.username.impl.getUsernamePinDetails.exception.code}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_EXCEPTION_CODE;
	
	@Value("${forgot.username.impl.getUsernamePinDetails.exception.message}")
	private String FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${forgot.password.impl.getPasswordAccountDetails.error.code}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_ERROR_CODE;
	
	@Value("${forgot.password.impl.getPasswordAccountDetails.error.message}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_ERROR_MESSAGE;
	
	@Value("${forgot.password.impl.getPasswordAccountDetails.exception.code}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_EXCEPTION_CODE;
	
	@Value("${forgot.password.impl.getPasswordAccountDetails.exception.message}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${forgot.password.impl.getPasswordPinDetails.error.code}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_ERROR_CODE;
	
	@Value("${forgot.password.impl.getPasswordPinDetails.error.message}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_ERROR_MESSAGE;
	
	@Value("${forgot.password.impl.getPasswordPinDetails.exception.code}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_EXCEPTION_CODE;
	
	@Value("${forgot.password.impl.getPasswordPinDetails.exception.message}")
	private String FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_EXCEPTION_MESSAGE;
	
	/*
	private static String GET_USER_USERNAME_FROM_ACCOUNTNUMBER="select screenName from User_ "+
            "where userId IN (select classPk from ExpandoValue where data_ = '?') "+
                     "order by userId desc limit 1; ";
	*/
	
	private static String GET_USER_USERNAME_FROM_ACCOUNTNUMBER="select screenName from User_ where openId=? order by createDate desc,userId desc;";
	
	@Override
	public ForgotUsernamePasswordVo getUsernameAccountDetails(ForgotUsernamePasswordVo forgotUsernameVo) {
		ForgotUsernamePasswordVo forgotUsernameVoService = new ForgotUsernamePasswordVo();
		try {			
		
			ForgotUnPwRequest forgotUsernameDetailsRequest = new ForgotUnPwRequest();			
			forgotUsernameDetailsRequest.setMobileNumber(forgotUsernameVo.getMobileNumber());			
			
			ForgotUnPwDetailsResponse forgotUsernameResponse = forgotUsernamePassword.forgotUnamePwordDetails(forgotUsernameDetailsRequest);	
		
			forgotUsernameVoService.setAccountNumber(forgotUsernameResponse.getAccountNumber());
			forgotUsernameVoService.setEmail(forgotUsernameResponse.getEmailAddress());			
			forgotUsernameVoService.setLastName(forgotUsernameResponse.getLastName());		
			forgotUsernameVoService.setDob(SelfCareUtil.getNewFormatedDate(forgotUsernameResponse.getDateOfBirth()));
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getUsernameAccountDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block");
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getUsernameAccountDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Code ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getUsernameAccountDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Message ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_ERROR_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_ERROR_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_ERROR_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(srie);
			//srie.printStackTrace();
			forgotUsernameVoService.setAccountNumber(FORGOT_DATA_NOT_AVAILABLE);
			forgotUsernameVoService.setEmail(FORGOT_DATA_NOT_AVAILABLE);			
			forgotUsernameVoService.setLastName(FORGOT_DATA_NOT_AVAILABLE);		
			forgotUsernameVoService.setDob(FORGOT_DATA_NOT_AVAILABLE);
			//throw svalloForgotUsernamePasswordImplException;
		} catch (Exception e) {			
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getUsernameAccountDetails() ] Exception Catch Block");
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getUsernameAccountDetails() ] Exception Catch Block | Error Code ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getUsernameAccountDetails() ] Exception Catch Block | Error Message ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_EXCEPTION_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_EXCEPTION_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_USERNAME_IMPL_GETUSERNAMEACCOUNTDETAILS_EXCEPTION_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(e);
			//e.printStackTrace();
			forgotUsernameVoService.setAccountNumber(FORGOT_DATA_NOT_AVAILABLE);
			forgotUsernameVoService.setEmail(FORGOT_DATA_NOT_AVAILABLE);			
			forgotUsernameVoService.setLastName(FORGOT_DATA_NOT_AVAILABLE);		
			forgotUsernameVoService.setDob(FORGOT_DATA_NOT_AVAILABLE);					
		}	
		return forgotUsernameVoService;
	}


	@Override
	public ForgotUsernamePasswordVo getUsernamePinDetails(ForgotUsernamePasswordVo forgotUsernamePinVo) {
		ForgotUsernamePasswordVo forgotUsernamePinVoService = new ForgotUsernamePasswordVo();
		try {			
		
			ForgotUnPwRequest forgotUsernamePinRequest = new ForgotUnPwRequest();			
			forgotUsernamePinRequest.setAccountNumber(forgotUsernamePinVo.getAccountNumber());				
			
			SvalloResendPreRegistrationPINResponse forgotUsernamePinResponse = forgotUsernamePassword.forgotUsername(forgotUsernamePinRequest);			
			forgotUsernamePinVoService.setOtpPin(forgotUsernamePinResponse.getSmsMessage());
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getUsernamePinDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block");
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getUsernamePinDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Code ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getUsernamePinDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Message ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_ERROR_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_ERROR_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_ERROR_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(srie);
			//srie.printStackTrace();
			forgotUsernamePinVoService.setOtpPin(FORGOT_DATA_NOT_AVAILABLE);			
		} catch (Exception e) {			
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getUsernamePinDetails() ] Exception Catch Block");
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getUsernamePinDetails() ] Exception Catch Block | Error Code ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getUsernamePinDetails() ] Exception Catch Block | Error Message ="+ FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_EXCEPTION_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_EXCEPTION_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_USERNAME_IMPL_GETUSERNAMEPINDETAILS_EXCEPTION_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(e);
			//e.printStackTrace();
			forgotUsernamePinVoService.setOtpPin(FORGOT_DATA_NOT_AVAILABLE);					
		}
		return forgotUsernamePinVoService;
	}


	@Override
	public String getUsernameFromDB(ForgotUsernamePasswordVo forgotUsernameValueVo) {
		//GET_USER_USERNAME=GET_USER_USERNAME.replaceAll("\\?",forgotUsernameValueVo.getEmail()+"");
		String userName = "";		
		logger.debug("GET_USER_USERNAME : "+ GET_USER_USERNAME);
		try{
		   userName = (String)jdbcTemplate.query(GET_USER_USERNAME,new String[]{forgotUsernameValueVo.getEmail()},new ManageGetUsernameMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){		
			logger.error(ae,"Array Index out of bound exception");
		} catch(Exception e){			
			logger.error(e,"Exception in forgot username GET_USER_USERNAME");
		}		
		finally{
		return userName;
		}
	}
	

	@Override
	public String getUsernameExits(ForgotUsernamePasswordVo forgotUsernameExitsVo) {
		String userId = "";
		//System.out.println("username setted="+forgotUsernameExitsVo.getUserName());
		try{
			userId = (String)jdbcTemplate.query(IS_USER_EXISTS,new String[]{forgotUsernameExitsVo.getUserName()},new ManageGetUsernameExitsMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){			
			logger.error(ae,"Array Index out of bound exception");
		} catch(Exception e){			
			logger.error(e,"Exception in forgot username IS_USER_EXISTS");
		}
		finally{			
		logger.debug("UserId from DB to check whether exits="+userId);
		return userId;
		}
	}


	@Override
	public ForgotUsernamePasswordVo getPasswordAccountDetails(ForgotUsernamePasswordVo forgotPasswordVo) {
		ForgotUsernamePasswordVo forgotPasswordVoService = new ForgotUsernamePasswordVo();
		try {			
		
			ForgotUnPwRequest forgotPasswordDetailsRequest = new ForgotUnPwRequest();			
			forgotPasswordDetailsRequest.setMobileNumber(forgotPasswordVo.getMobileNumber());			
			
			ForgotUnPwDetailsResponse forgotPasswordResponse = forgotUsernamePassword.forgotUnamePwordDetails(forgotPasswordDetailsRequest);	
		
			forgotPasswordVoService.setAccountNumber(forgotPasswordResponse.getAccountNumber());
			forgotPasswordVoService.setEmail(forgotPasswordResponse.getEmailAddress());	
			forgotPasswordVoService.setDob(SelfCareUtil.getNewFormatedDate(forgotPasswordResponse.getDateOfBirth()));						
			forgotPasswordVoService.setLastName(forgotPasswordResponse.getLastName());
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordAccountDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block");
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordAccountDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Code ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordAccountDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Message ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_ERROR_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_ERROR_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_ERROR_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(srie);
			//srie.printStackTrace();
			forgotPasswordVoService.setAccountNumber(FORGOT_DATA_NOT_AVAILABLE);
			forgotPasswordVoService.setEmail(FORGOT_DATA_NOT_AVAILABLE);	
			forgotPasswordVoService.setDob(FORGOT_DATA_NOT_AVAILABLE);						
			forgotPasswordVoService.setLastName(FORGOT_DATA_NOT_AVAILABLE);			
		} catch (Exception e) {			
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordAccountDetails() ] Exception Catch Block");
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordAccountDetails() ] Exception Catch Block | Error Code ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordAccountDetails() ] Exception Catch Block | Error Message ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_EXCEPTION_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_EXCEPTION_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_PASSWORD_IMPL_GETPASSWORDACCOUNTDETAILS_EXCEPTION_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(e);
			//e.printStackTrace();
			forgotPasswordVoService.setAccountNumber(FORGOT_DATA_NOT_AVAILABLE);
			forgotPasswordVoService.setEmail(FORGOT_DATA_NOT_AVAILABLE);	
			forgotPasswordVoService.setDob(FORGOT_DATA_NOT_AVAILABLE);						
			forgotPasswordVoService.setLastName(FORGOT_DATA_NOT_AVAILABLE);
			//throw svalloForgotUsernamePasswordImplException;			
		}	
		return forgotPasswordVoService;
	}


	@Override
	public ForgotUsernamePasswordVo getPasswordPinDetails(ForgotUsernamePasswordVo forgotPasswordPinVo) {
		ForgotUsernamePasswordVo forgotPasswordPinVoService = new ForgotUsernamePasswordVo();
		try {			
		
			ForgotUnPwRequest forgotPasswordPinRequest = new ForgotUnPwRequest();			
			forgotPasswordPinRequest.setAccountNumber(forgotPasswordPinVo.getAccountNumber());
			
			SvalloResendPreRegistrationPINResponse forgotPasswordPinResponse = forgotUsernamePassword.forgotPassword(forgotPasswordPinRequest);			
			forgotPasswordPinVoService.setOtpPin(forgotPasswordPinResponse.getSmsMessage());
			
		} catch (SvalloRegistrationIntegrationException srie) {
			// TODO Auto-generated catch block			
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordPinDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block");
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordPinDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Code ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_ERROR_CODE);
			logger.error(srie,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordPinDetails() ] SvalloForgotUsernamePasswordServiceException Catch Block | Error Message ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_ERROR_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_ERROR_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_ERROR_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(srie);
			//srie.printStackTrace();
			forgotPasswordPinVoService.setOtpPin(FORGOT_DATA_NOT_AVAILABLE);			
		}	catch (Exception e) {			
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordPinDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordPinDetails() ] Exception Catch Block | Error Code ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ ForgotUsernamePasswordServiceImpl | getPasswordPinDetails() ] Exception Catch Block | Error Message ="+ FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_EXCEPTION_MESSAGE);
			SvalloForgotUsernamePasswordServiceException svalloForgotUsernamePasswordImplException = new SvalloForgotUsernamePasswordServiceException();
			svalloForgotUsernamePasswordImplException.setErrorCode(FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_EXCEPTION_CODE);
			svalloForgotUsernamePasswordImplException.setErrorMessage(FORGOT_PASSWORD_IMPL_GETPASSWORDPINDETAILS_EXCEPTION_MESSAGE);
			svalloForgotUsernamePasswordImplException.setRootCause(e);
			//e.printStackTrace();
			forgotPasswordPinVoService.setOtpPin(FORGOT_DATA_NOT_AVAILABLE);			
		}		
		return forgotPasswordPinVoService;
	}


	public void updatePasswordDetails(long userId) {
		//System.out.println("UserId="+userId);
		try{
			jdbcTemplate.update(UPDATE_USERDETAILS_TO_UPDATE_LOCKOUT,userId);			
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");
		}  catch(Exception e){		
			logger.error(e,"Exception in forgot username UPDATE_USERDETAILS_TO_UPDATE_LOCKOUT");
		}
	}

	private static final class ManageGetUsernameMapper implements RowMapper<String> {
	    public String mapRow(ResultSet rs, int rowNum) throws SQLException {	    
	    	return rs.getString("screenName");	    
	    }
	}
	
	private static final class ManageGetUsernameExitsMapper implements RowMapper<String> {
		 public String mapRow(ResultSet rs, int rowNum) throws SQLException {			
			 logger.debug("value from DB="+String.valueOf(rs.getInt("userId")));
		    	return String.valueOf(rs.getInt("userId"));	    
		    }
	}
	
	public String getScreenName(String accountNumber) {
		String screenName = "";		
		logger.debug("Account Number ="+accountNumber);
		//logger.debug("Query="+GET_USER_USERNAME_FROM_ACCOUNTNUMBER);
		try{
			//screenName = (String)jdbcTemplate.query(GET_USER_USERNAME_FROM_ACCOUNTNUMBER.replaceAll("\\?",accountNumber+""),new ManageGetScreenNameMapper()).get(0);
			screenName = (String)jdbcTemplate.query(GET_USER_USERNAME_FROM_ACCOUNTNUMBER,new String[]{accountNumber},new ManageGetScreenNameMapper()).get(0);
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");	
		}
		finally{		
			//logger.debug("Screen name from DB="+screenName);
		return screenName;
		}
	}
	
	public  String getAccountNumberFromUserID(long userId)
	{
		String accountNumber="";
	    try{
		//accountNumber = (String)jdbcTemplate.query(GET_USER_DETAILS.replaceAll("\\?",userId+""),new ManageGetAccountNumberMapper()).get(0);
		accountNumber = (String)jdbcTemplate.query(GET_USER_DETAILS,new Long[]{userId},new ManageGetAccountNumberMapper()).get(0);
	    }
	    catch(ArrayIndexOutOfBoundsException ae){
	    	logger.error(ae,"Array Index out of bound exception");
	    }
		return accountNumber;
	}
	
	
	private static final class ManageGetScreenNameMapper implements RowMapper<String> {
		 public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		    	return rs.getString("screenName");	    
		    }
	}
	
	private static final class ManageGetAccountNumberMapper implements RowMapper<String> {

	    public String mapRow(ResultSet rs, int rowNum) throws SQLException {	    
	    	return rs.getString("accountNum");	    
	    }
	}
}


package com.techm.svallo.vo.editprofile;

import java.util.List;

import com.techmahindra.online.svallo.model.myprofile._2014._09._29.*;
import com.techm.svallo.vo.editprofile.ReasonCodeListVo;
import java.util.ArrayList;
public class IsEligibleForUpgradeVo {
	
	public String getExternalReference() {
		return externalReference;
	}
	public void setExternalReference(String externalReference) {
		this.externalReference = externalReference;
	}
	public String getSubscriptionNumber() {
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber) {
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getEligibleFlag() {
		return eligibleFlag;
	}
	public void setEligibleFlag(String eligibleFlag) {
		this.eligibleFlag = eligibleFlag;
	}
	public String getUpgradeDate() {
		return upgradeDate;
	}
	public void setUpgradeDate(String upgradeDate) {
		this.upgradeDate = upgradeDate;
	}
	public String getEarlyUpgradeCharge() {
		return earlyUpgradeCharge;
	}
	public void setEarlyUpgradeCharge(String earlyUpgradeCharge) {
		this.earlyUpgradeCharge = earlyUpgradeCharge;
	}

	private String externalReference;
	private String subscriptionNumber;
	private String eligibleFlag;
	private String upgradeDate;
	private String earlyUpgradeCharge;
	private List<ReasonCodeListVo> reasonCode;
	private int size;	
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}

public void setReasonCode(List<ReasonCodeListVo> reasonCode) {
	this.reasonCode = reasonCode;
}
	
	 public List<ReasonCodeListVo> getReasonCode() {
	        if (reasonCode == null) {
	            reasonCode = new ArrayList<ReasonCodeListVo>();
	        }
	        return this.reasonCode;
	    }
	
}

package com.techm.svallo.service.editprofile;

import com.techm.svallo.vo.editprofile.IsEligibleForUpgradeVo;
import com.techm.svallo.vo.editprofile.ReasonCodeListVo;
import com.techm.svallo.vo.editprofile.MyCommunicationPreferencesVo;
import com.techm.svallo.vo.editprofile.PreferencesVo;

public interface EditProfileService {
	public String updateAddress(String adressLine1, String adressLine2, String adressLine3, String adressLine4, String adressLine5, String postCode, String accountNumber, String mobileNumber, String subscriptionNumber, String title, String surname);
	public String updateEmail(String emailAddr, String accountNumber, String mobileNumber, String subscriptionNumber);
	public String updatePassword(String accountNumber, String mobileNumber, String subscriptionNumber);
	public String validateCurrentPassword(String currentPassword,Long userId);
	public String updateEmailAddressInDb(String emailAddr, Long userId);
	public MyCommunicationPreferencesVo getCommunicationPreferences(MyCommunicationPreferencesVo myCommunicationPreferencesVo);
	public String updateCommunicationPreferences(MyCommunicationPreferencesVo myCommunicationPreferencesVo);
	public IsEligibleForUpgradeVo isEligibleForUpgrade(IsEligibleForUpgradeVo isEligibleForUpgradeVo);
}
package com.techm.svallo.service.rollover;

import com.techm.svallo.vo.rollover.RolloverListVo;

public interface RolloverService {
	
	public RolloverListVo getRollover(String subscriptionNumber);

}

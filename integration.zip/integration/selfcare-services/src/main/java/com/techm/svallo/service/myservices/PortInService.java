package com.techm.svallo.service.myservices;


import com.techm.svallo.vo.myservices.PortInVo;
import com.techm.svallo.vo.myservices.PrePortInVo;

public interface PortInService
{
	public PortInVo getPortInDetails(PortInVo portInVo);
	public PrePortInVo getPrePortInDetails(PrePortInVo prePortInVo);
	public PrePortInVo getIsPortInAlreadyDoneDetails(String accountNumber);
	public void insertPortInDetails(PortInVo portInVo);
	public void deletePortInDetails(String accountNumber);
}


package com.techm.svallo.vo.topups;

public class PaymentDetailsVo {
		
		private String subscriptionNumber;
		private String reloadMethod;
		private String avsHouseStreetNumber;
	    private String authorisationCode;
	    private String cardNumber;
	    private String cardReference;
	    private String countryCode;
	    private String currencyCode;
	    private String expiryDateMonth;
	    private String expiryDateYear;
	    private String nameOnCard;
	    private String paymentReference;
	    private String paymentType;
	    private String postCode;
	    private String productService;
	    private String reasonCode;
	    private String startDateMonth;
	    private String startDateYear;
	    private String transactionDateTime;
	    private String transactionReference;
	    private String auditRecordProgram;
	    private String auditRecordUserID;
	    
	    
		public String getAvsHouseStreetNumber() {
			return avsHouseStreetNumber;
		}
		public void setAvsHouseStreetNumber(String avsHouseStreetNumber) {
			this.avsHouseStreetNumber = avsHouseStreetNumber;
		}
		public String getAuthorisationCode() {
			return authorisationCode;
		}
		public void setAuthorisationCode(String authorisationCode) {
			this.authorisationCode = authorisationCode;
		}
		public String getCardNumber() {
			return cardNumber;
		}
		public void setCardNumber(String cardNumber) {
			this.cardNumber = cardNumber;
		}
		public String getCardReference() {
			return cardReference;
		}
		public void setCardReference(String cardReference) {
			this.cardReference = cardReference;
		}
		public String getCountryCode() {
			return countryCode;
		}
		public void setCountryCode(String countryCode) {
			this.countryCode = countryCode;
		}
		public String getCurrencyCode() {
			return currencyCode;
		}
		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}
		public String getExpiryDateMonth() {
			return expiryDateMonth;
		}
		public void setExpiryDateMonth(String expiryDateMonth) {
			this.expiryDateMonth = expiryDateMonth;
		}
		public String getExpiryDateYear() {
			return expiryDateYear;
		}
		public void setExpiryDateYear(String expiryDateYear) {
			this.expiryDateYear = expiryDateYear;
		}
		public String getNameOnCard() {
			return nameOnCard;
		}
		public void setNameOnCard(String nameOnCard) {
			this.nameOnCard = nameOnCard;
		}
		public String getPaymentReference() {
			return paymentReference;
		}
		public void setPaymentReference(String paymentReference) {
			this.paymentReference = paymentReference;
		}
		public String getPaymentType() {
			return paymentType;
		}
		public void setPaymentType(String paymentType) {
			this.paymentType = paymentType;
		}
		public String getPostCode() {
			return postCode;
		}
		public void setPostCode(String postCode) {
			this.postCode = postCode;
		}
		public String getProductService() {
			return productService;
		}
		public void setProductService(String productService) {
			this.productService = productService;
		}
		public String getReasonCode() {
			return reasonCode;
		}
		public void setReasonCode(String reasonCode) {
			this.reasonCode = reasonCode;
		}
		public String getStartDateMonth() {
			return startDateMonth;
		}
		public void setStartDateMonth(String startDateMonth) {
			this.startDateMonth = startDateMonth;
		}
		public String getStartDateYear() {
			return startDateYear;
		}
		public void setStartDateYear(String startDateYear) {
			this.startDateYear = startDateYear;
		}
		public String getTransactionDateTime() {
			return transactionDateTime;
		}
		public void setTransactionDateTime(String transactionDateTime) {
			this.transactionDateTime = transactionDateTime;
		}
		public String getTransactionReference() {
			return transactionReference;
		}
		public void setTransactionReference(String transactionReference) {
			this.transactionReference = transactionReference;
		}
		public String getSubscriptionNumber() {
			return subscriptionNumber;
		}
		public void setSubscriptionNumber(String subscriptionNumber) {
			this.subscriptionNumber = subscriptionNumber;
		}
		public String getReloadMethod() {
			return reloadMethod;
		}
		public void setReloadMethod(String reloadMethod) {
			this.reloadMethod = reloadMethod;
		}
		public String getAuditRecordProgram() {
			return auditRecordProgram;
		}
		public void setAuditRecordProgram(String auditRecordProgram) {
			this.auditRecordProgram = auditRecordProgram;
		}
		public String getAuditRecordUserID() {
			return auditRecordUserID;
		}
		public void setAuditRecordUserID(String auditRecordUserID) {
			this.auditRecordUserID = auditRecordUserID;
		}
}

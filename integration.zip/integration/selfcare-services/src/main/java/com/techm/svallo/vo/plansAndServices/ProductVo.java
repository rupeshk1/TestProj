package com.techm.svallo.vo.plansAndServices;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

public class ProductVo implements Serializable
{
	
	private static final long serialVersionUID = 7032176932292687257L;
	
	private String productId="";
	private String productName="";
	private String productDescription="";
	private String productQuantity="";
	private String productCharges="";
	private String productImagePath="";

	private PlanVo planVo=null;
	

	
	private String description="";
	
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLongDescription() {
		return longDescription;
	}
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	public String getLargeImgURL() {
		return largeImgURL;
	}
	public void setLargeImgURL(String largeImgURL) {
		this.largeImgURL = largeImgURL;
	}
	public String getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(String productDetails) {
		this.productDetails = productDetails;
	}
	public String getAddtionalImg1() {
		return addtionalImg1;
	}
	public void setAddtionalImg1(String addtionalImg1) {
		this.addtionalImg1 = addtionalImg1;
	}
	public String getAddtionalImg2() {
		return addtionalImg2;
	}
	public void setAddtionalImg2(String addtionalImg2) {
		this.addtionalImg2 = addtionalImg2;
	}
	public String getAddtionalImg3() {
		return addtionalImg3;
	}
	public void setAddtionalImg3(String addtionalImg3) {
		this.addtionalImg3 = addtionalImg3;
	}
	private String longDescription="";
	//productName
	private String largeImgURL="";
	private String productDetails="";
	private String addtionalImg1="";
	private String addtionalImg2="";
	private String addtionalImg3="";

					
	private List<AddOn> addOnList=new ArrayList<AddOn>();
	
	public String getProductId()
	{
		return productId;
	}
	public void setProductId(String productId)
	{
		this.productId = productId;
	}
	public String getProductName()
	{
		return productName;
	}
	public void setProductName(String productName)
	{
		this.productName = productName;
	}
	public String getProductDescription()
	{
		return productDescription;
	}
	public void setProductDescription(String productDescription)
	{
		this.productDescription = productDescription;
	}
	public String getProductQuantity()
	{
		return productQuantity;
	}
	public void setProductQuantity(String productQuantity)
	{
		this.productQuantity = productQuantity;
	}
	public String getProductCharges()
	{
		return productCharges;
	}
	public void setProductCharges(String string)
	{
		this.productCharges = string;
	}
	public String getProductImagePath()
	{
		return productImagePath;
	}
	public void setProductImagePath(String productImagePath)
	{
		this.productImagePath = productImagePath;
	}
	public PlanVo getPlanVo()
	{
		return planVo;
	}
	public void setPlanVo(PlanVo planVo)
	{
		this.planVo = planVo;
	}
	public List<AddOn> getAddOnList()
	{
		return addOnList;
	}
	public void setAddOnList(List<AddOn> addOnList)
	{
		this.addOnList = addOnList;
	}
	

	
	
}

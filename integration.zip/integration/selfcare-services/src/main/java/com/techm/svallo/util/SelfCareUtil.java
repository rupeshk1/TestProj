package com.techm.svallo.util;

import java.text.DecimalFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.techm.portal.common.loggerwrapper.PortalLogger;

public class SelfCareUtil {

	final static PortalLogger logger = PortalLogger.getLogger(SelfCareUtil.class);
	
	public static String CUSTACCOUNT_LIST_KEY="custAccountList";
	private static String SELFCARE_DATE_FORMAT="dd-MM-yyyy";
	private static String CPW_DATE_FORMAT="yyyy-MM-dd'Z'";
	private static String MONTH_YEAR_DATE_FORMAT="MMM-yyyy";
	private static int NUMBER_OF_DIGIT_TO_BE_SHOWN=3;
	private static String MASKING_CHARACTER="X";
	private static String CPW_DATETIME_FORMAT="yyyy-MM-dd'T'hh:mm:ss'Z'";
	private static String SELFCARE_DB_DATE_FORMAT="yyyy-MM-dd";
	private static String DASHBOARD_DATE_FORMAT="dd MMM yyyy";
	private static String BOLTON_DATE_FORMAT = "dd/MM/yyyy";
	private static String DONUTS_DRILLDOWN_MONTH = "MMMM yyyy";
	//Added for My Account
	private static String SELFCARE_DATE_FORMAT_Account="dd MMM yyyy";
	
	public static String getFormatedDate(String srcDate)
	{
		String formatedDate = "";
		try
		{
			//String date = "2014-05-27Z";
			if(srcDate!=null && srcDate.length()>0)
			{	
				SimpleDateFormat cpwDateFormat = new SimpleDateFormat(CPW_DATE_FORMAT);
				SimpleDateFormat selfCareDateFormat = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
				Date date2 = cpwDateFormat.parse(srcDate);
				formatedDate = selfCareDateFormat.format(date2);				
			
				logger.debug("formatedDate =" + formatedDate);
			}	
		}
		catch (Exception e)
		{			
			logger.error(e,"Exception");
		}
		return formatedDate;
	}
	
	
	
	public static String getFormatedDateMyAccount(String srcDate)
	{
		String formatedDate = "";
		try
		{
			//String date = "2014-05-27Z";
			if(srcDate!=null && srcDate.length()>0)
			{	
				SimpleDateFormat cpwDateFormat = new SimpleDateFormat(CPW_DATE_FORMAT);
				SimpleDateFormat selfCareDateFormat = new SimpleDateFormat(SELFCARE_DATE_FORMAT_Account);
				Date date2 = cpwDateFormat.parse(srcDate);
				formatedDate = (selfCareDateFormat.format(date2)).toUpperCase();				
			
				logger.debug("formatedDate for My Account == " + formatedDate);
			}	
		}
		catch (Exception e)
		{			
			logger.error(e,"Exception");
		}
		return formatedDate;
	}
	
	
	public static String getMonthYearDate(String srcDate)
	{
		String formatedDate = "";
		try
		{
			//String date = "2014-05-27Z";
			if(srcDate!=null && srcDate.length()>0)
			{	
				SimpleDateFormat cpwDateFormat = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
				SimpleDateFormat selfCareDateFormat = new SimpleDateFormat(MONTH_YEAR_DATE_FORMAT);
				Date date2 = cpwDateFormat.parse(srcDate);
				formatedDate = selfCareDateFormat.format(date2);
				
				logger.debug("formatedDate =" + formatedDate);
			}	
		}
		catch (Exception e)
		{
			logger.error(e,"Exception");
		}
		return formatedDate;
	}

	
	public static String maskString(String srcStr)
	{
		String maskedStr="";
		String last4Digit="";
		if(srcStr!=null && srcStr.trim().length()>NUMBER_OF_DIGIT_TO_BE_SHOWN)
		{
			last4Digit = srcStr.substring(srcStr.length()-NUMBER_OF_DIGIT_TO_BE_SHOWN);
			logger.debug("last4Digit >>> "+last4Digit);
		}
		for (int i = 0; i < srcStr.length()-NUMBER_OF_DIGIT_TO_BE_SHOWN; i++)
		{
			maskedStr=maskedStr+MASKING_CHARACTER;
		}
		maskedStr=maskedStr+last4Digit;
		logger.debug("maskedStr >>> "+maskedStr);
		return maskedStr;
	}
	
	public static String getFormatedDateWithoutTime(String srcDateWithTime)
	{
		String formatedDateWithoutTime = "";
		try
		{			
			if(srcDateWithTime!=null && srcDateWithTime.length()>0)
			{	
				SimpleDateFormat cpwDateFormat = new SimpleDateFormat(CPW_DATETIME_FORMAT);
				SimpleDateFormat selfCareDateFormat = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
				Date date2 = cpwDateFormat.parse(srcDateWithTime);
				formatedDateWithoutTime = selfCareDateFormat.format(date2);
				
				logger.debug("formatedDateWithoutTime =" + formatedDateWithoutTime);
			}	
		}
		catch (Exception e)
		{
			logger.error(e,"Exception");
		}
		return formatedDateWithoutTime;
	}
	
	public static String getFormatedDateForDisplay(String srcDate)
	{
		String formatedDate = "";
		try
		{
			//String date = "2014-05-27Z";
			if(srcDate!=null && srcDate.length()>0)
			{	
				SimpleDateFormat cpwDateFormat = new SimpleDateFormat(SELFCARE_DB_DATE_FORMAT);
				SimpleDateFormat selfCareDateFormat = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
				Date date2 = cpwDateFormat.parse(srcDate);
				formatedDate = selfCareDateFormat.format(date2);
				
				logger.debug("formatedDBDate =" + formatedDate);
			}	
		}
		catch (Exception e)
		{
		    logger.error(e,"Exception");
		}
		return formatedDate;
	}
	
	public static String getFormattedDateMMM(String srcDate)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(CPW_DATE_FORMAT);
		SimpleDateFormat formatter1 = new SimpleDateFormat(DASHBOARD_DATE_FORMAT);
		//String dateInString = "2014-11-19Z";		
		String formatedDate = "";	 
		try {	 
			Date date = formatter.parse(srcDate);
			//logger.debug(date);			
			formatedDate = formatter1.format(date);			
			logger.debug(formatedDate);	 
		} catch (ParseException e) {
			logger.error(e,"Exception");
		}		
		return formatedDate;		
	}
	
	public static String getDatediffernce(String srcDate)
	      {
			SimpleDateFormat formatter  = new SimpleDateFormat(CPW_DATE_FORMAT);
			Date currentdate = new Date();		 
		    String dd1="";
			Date d1 = null;
			Date d2 = null;	 
			String noOfDays="";
			try {
				if(srcDate!=null && srcDate.length()>0)
				{
				dd1 = formatter.format(currentdate);
				//logger.debug("test date1="+dd1);
				d1=formatter.parse(dd1);

				d2 = formatter.parse(srcDate);
				//logger.debug("test date2="+d1);
				//logger.debug("test date2="+d2);
								 
								
				//in milliseconds
				long diff = d2.getTime() - d1.getTime();
					
	 
				//long diffSeconds = diff / 1000 % 60;
				//long diffMinutes = diff / (60 * 1000) % 60;
				//long diffHours = diff / (60 * 60 * 1000) % 24;
				long diffDays = diff / (24 * 60 * 60 * 1000);
	 
				//logger.debug(diffDays + " days, ");
				//logger.debug(diffHours + " hours, ");
				//logger.debug(diffMinutes + " minutes, ");
				//logger.debug(diffSeconds + " seconds.");
				noOfDays = String.valueOf(diffDays);
			}	
			} catch (Exception e) {
				logger.error(e,"Exception");
			}	
			return noOfDays;
		}
	
	
		
	
	public static String getMonthdiffernceAIO(String startDate,String endDate)
    {
		String noOffMonthsAio="";
		try{
		Date endAioDate=null;
		SimpleDateFormat  formatter  = new SimpleDateFormat(CPW_DATE_FORMAT);
		endAioDate = formatter.parse(endDate);	
				
				
		Date startAioDate=null;
		startAioDate = formatter.parse(startDate);		
		
			/*dd1 = formatter.format(srcDate);*/
				
		Calendar startCalendar = new GregorianCalendar();
		startCalendar.setTime(startAioDate);
		Calendar endCalendar = new GregorianCalendar();
		endCalendar.setTime(endAioDate);

		int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		int diffDay = endCalendar.get(Calendar.DAY_OF_MONTH) - startCalendar.get(Calendar.DAY_OF_MONTH);
		int diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
		noOffMonthsAio= String.valueOf(diffMonth);
		}
		catch(Exception e){
			logger.error(e,"Exception");
		}	
		return noOffMonthsAio;
	}
	
	public static String getMonthdiffernce(String srcDate)
    {
		Date currentdate = new Date();
		SimpleDateFormat  formatter  = new SimpleDateFormat(CPW_DATE_FORMAT);
		Date endDate=null;
		String noOffMonths="";
		
		try {
			
			/*dd1 = formatter.format(srcDate);*/
			endDate = formatter.parse(srcDate);	
			
		Calendar startCalendar = new GregorianCalendar();
		startCalendar.setTime(currentdate);
		Calendar endCalendar = new GregorianCalendar();
		endCalendar.setTime(endDate);

		int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		int diffDay = endCalendar.get(Calendar.DAY_OF_MONTH) - startCalendar.get(Calendar.DAY_OF_MONTH);
		int diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
		noOffMonths= String.valueOf(diffMonth);
		}
		catch(Exception e){
			logger.error(e,"Exception");
		}	
		return noOffMonths;
	}
	
	
	public static String getBoltOnFormattedDate(String srcDate)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(CPW_DATE_FORMAT);
		SimpleDateFormat formatter1 = new SimpleDateFormat(BOLTON_DATE_FORMAT);
		//String dateInString = "2014-11-19Z";		
		String formatedDate = "";	 
		try {	 
			Date date = formatter.parse(srcDate);
			//logger.debug(date);			
			formatedDate = formatter1.format(date);			
			logger.debug(formatedDate);	 
		} catch (ParseException e) {
			logger.error(e,"Exception");
		}		
		return formatedDate;		
	}

	public static String getFormattedDateSelfcareToDashboard(String srcDate)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
		SimpleDateFormat formatter1 = new SimpleDateFormat(DASHBOARD_DATE_FORMAT);
		//String dateInString = "2014-11-19Z";		
		String formatedDate = "";	 
		try {	 
			Date date = formatter.parse(srcDate);
			//logger.debug(date);			
			formatedDate = formatter1.format(date);			
			logger.debug(formatedDate);	 
		} catch (ParseException e) {
			logger.error(e,"Exception");
		}		
		return formatedDate;		
	}
	
	public static String roundToTwoDight(float value) 
	{
		DecimalFormat df = new DecimalFormat("####0.00");
		return df.format(value);
	}

	
	public static boolean checkAccountDisconnected(String srcDate){
		boolean disconnected = false;
	   try{		   
		   if(!srcDate.equalsIgnoreCase("")){
			   
			  String formattedSrcDate =  getFormatedDate(srcDate);
			
			   if(!formattedSrcDate.equalsIgnoreCase("")){
				   
				    SimpleDateFormat sdf = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
		            Date date1 = sdf.parse(formattedSrcDate);		            
		            String date3 = sdf.format(new Date());
		            Date date2 = sdf.parse(date3);
		       
		            //logger.debug(date1);
		            //logger.debug(date2);

		            //logger.debug(sdf.format(date1));
		            //logger.debug(sdf.format(date2));
		            //logger.debug(date1.compareTo(date2));

		            if(date1.compareTo(date2)>0){
		                //logger.debug("Date1 is greater than current date");
		                disconnected = false;
		            }else if(date1.compareTo(date2)<0){
		                //logger.debug("Date1 is less than current date");
		                disconnected = true;
		            }else if(date1.compareTo(date2)==0){
		                //logger.debug("Date1 is equal to current date");
		                disconnected = true;
		            }else{
		                //logger.debug("How to get here?");
		                disconnected = false;
		            }				    
			    }else{
			      disconnected = false;
			    }			   
		   }else{
			  disconnected = false;
		   }		  
		   
	   }catch(Exception e){
		   logger.error(e,"Exception");
	   }		
		return disconnected;
	}
	
	public static String getRolloverDrillDownMonth(String effectiveDate)
	{
		//SimpleDateFormat formatter = new SimpleDateFormat("MMMM"); 
	    //String s = formatter.format(new Date());
	    //System.out.println(s);
	    
	    SimpleDateFormat formatter = new SimpleDateFormat(CPW_DATE_FORMAT);
		SimpleDateFormat formatter1 = new SimpleDateFormat(DONUTS_DRILLDOWN_MONTH);
		//String dateInString = "2014-11-19Z";
		String formatedDate = "";
		try {	 
			Date date = formatter.parse(effectiveDate);
			//logger.debug(date);			
			formatedDate = formatter1.format(date);
			logger.debug(formatedDate);	 
		} catch (ParseException e) {
			logger.error(e,"Exception");
		}		
		return formatedDate;	
	}
	
	//antima
		public static int compareWithCurrentDate(String srcDate1)
		{
			int flag=0;
			
			SimpleDateFormat ft = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
			//SimpleDateFormat formatter1 = new SimpleDateFormat(DASHBOARD_DATE_FORMAT);
			//String dateInString = "2014-11-19Z";		
			//String datefrombackend = "";	 
			try {	 
				Date datefrombackend=ft.parse(srcDate1);
				//logger.debug("datefrombackend::"+datefrombackend);			
				//datefrombackend = ft.format(myDate);
				Date currentDate = new Date();
				String currentDate1 = ft.format(currentDate);
				Date today=ft.parse(currentDate1);
				//logger.debug("today date::"+today);
				 if (today.compareTo(datefrombackend)<0){
					 flag=1;
			     }
			  else if (today.compareTo(datefrombackend)>0){
				   flag=2;
			   
			  }
			  else{
			flag=3;
			     
			  }
			} catch (ParseException e) {
				logger.error(e,"[SelfCareUtil | compareWithCurrentDate() ] exception block  > " + e);
			}		
			return flag;		
		}
	//antima
	
		
		public static String getFutureDateFromDays(String noOfDays)
		{
			SimpleDateFormat formatter = new SimpleDateFormat(SELFCARE_DATE_FORMAT);
			String formatedDate = "";	 
			try {	 
				
				String firstWord = "";
				if(noOfDays.contains(" ")){
					   firstWord= noOfDays.substring(0, noOfDays.indexOf(" ")); 
					}
				if(!("".equalsIgnoreCase(firstWord) || "unlimited".equalsIgnoreCase(firstWord))){	
				    Calendar c = Calendar.getInstance();    
					c.setTime(new Date());
					c.add(Calendar.DATE, Integer.parseInt(firstWord));
					formatedDate = formatter.format(c.getTime());
					logger.debug("Future formatted date="+formatedDate);
				}		
			} catch (Exception e) {
				logger.error(e,"Exception");
			}		
			return formatedDate;		
		}
		
		public static String getCMPPreviousDate(String srcDate)
		{		
		    SimpleDateFormat formatter = new SimpleDateFormat(CPW_DATE_FORMAT);
			
			String formatedDate = "";
			try {	 
				 Date myDate = formatter.parse(srcDate);
				 Date oneDayBefore = new Date(myDate.getTime() - 2);	
				formatedDate = formatter.format(oneDayBefore);
				logger.debug(formatedDate);	 
			} catch (ParseException e) {
				logger.error(e,"Exception");
			}		
			return formatedDate;
		}
		
		public static String getdaysdiffernceBetnTwoDates(String srcDate1, String srcDate2)
	      {
			SimpleDateFormat formatter  = new SimpleDateFormat(CPW_DATE_FORMAT);			
			Date d1 = null;
			Date d2 = null;	 
			String noOfDays="";
			try {							
				d1=formatter.parse(srcDate1);
				d2 = formatter.parse(srcDate2);
				//logger.debug("test date2="+d1);
				//logger.debug("test date2="+d2);
	 
				//in milliseconds
				long diff = d2.getTime() - d1.getTime();
	 
				//long diffSeconds = diff / 1000 % 60;
				//long diffMinutes = diff / (60 * 1000) % 60;
				//long diffHours = diff / (60 * 60 * 1000) % 24;
				long diffDays = diff / (24 * 60 * 60 * 1000);
	 
				//logger.debug(diffDays + " days, ");
				//logger.debug(diffHours + " hours, ");
				//logger.debug(diffMinutes + " minutes, ");
				//logger.debug(diffSeconds + " seconds.");
				noOfDays = String.valueOf(diffDays);
			} catch (Exception e) {
				logger.error(e,"Exception");
			}	
			return noOfDays;
		}
		
		public static String getNewFormatedDate(String srcDate)
		{
			String formatedDate = "";
			try
			{
				//String date = "2014-05-27Z";
				if(srcDate!=null && srcDate.length()>0)
				{	
					SimpleDateFormat cpwDateFormat = new SimpleDateFormat(CPW_DATE_FORMAT);
					SimpleDateFormat selfCareDateFormat = new SimpleDateFormat(BOLTON_DATE_FORMAT);
					Date date2 = cpwDateFormat.parse(srcDate);
					formatedDate = selfCareDateFormat.format(date2);				
				
					logger.debug("formatedDate for phase2 R2=" + formatedDate);
				}	
			}
			catch (Exception e)
			{			
				logger.error(e,"Exception");
			}
			return formatedDate;
		}
//Namrata		
		public static String getCpwFormatedDate(String srcDate)
		{
			String formatedDate = "";
			try
			{
				//String date = "2014-05-27Z";
				if(srcDate!=null && srcDate.length()>0)
				{	
					SimpleDateFormat cpwDateFormat = new SimpleDateFormat(CPW_DATE_FORMAT);
					SimpleDateFormat selfCareDateFormat = new SimpleDateFormat(BOLTON_DATE_FORMAT);
					Date date = selfCareDateFormat.parse(srcDate);
					formatedDate = (cpwDateFormat.format(date));		
					
					
				}	
			}
			catch (Exception e)
			{	;
				logger.error(e,"Exception");
			}
			return formatedDate;
		}

	public static String getFutureMonthDate()
		{
			SimpleDateFormat formatter = new SimpleDateFormat(CPW_DATE_FORMAT);
			String formatedDate = "";	 
			try {	
				    Calendar c = Calendar.getInstance();    
					c.setTime(new Date());
					c.add(Calendar.MONTH, 1);
					formatedDate = formatter.format(c.getTime());
					//logger.debug("Future formatted date="+formatedDate);			
			} catch (Exception e) {
				logger.error(e,"Exception");
			}		
			return formatedDate;		
		}		
		
		
		
}

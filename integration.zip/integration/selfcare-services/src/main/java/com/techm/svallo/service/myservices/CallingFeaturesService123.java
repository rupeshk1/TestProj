package com.techm.svallo.service.myservices;


import java.util.List;

import com.techm.svallo.vo.myservices.MyServicesVo;

public interface CallingFeaturesService123
{
	public List<MyServicesVo> getcallingFeaturesDetails(MyServicesVo myServicesVo);
	public MyServicesVo getAddCallingFeatureDetails(MyServicesVo myServicesVo);
	public MyServicesVo getRemoveCallingFeatureDetails(MyServicesVo myServicesVo);
	
}


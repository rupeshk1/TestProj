package com.techm.svallo.vo.oneofpayment;

public class OneOfPaymentVo
{
	public String externalReference;
	public String accountNumber;
	public String transactionReference;
	public String paymentReference;
	public String cardReference;
	public String transactionDateTime;
	public String amount;
	public String currencyCode;
	public String paymentType;
	public String cardNumber;
	public String successfulpaymentStatus;
	public String userID;
	public String auditRecordProgram;
	public String message;
	public String transactionMessage;
	public String transactionResult;
	public String email;
	public String merchantErrorCode;
	public String merchantErrorDesc;
	public String expiryMonth;
	public String expiryYear;
	public String authCode;
	public String address1;
	public String address2;
	public String address3;
	public String address4;
	public String address5;
	public String postCode;
	public String firstName;
	public String lastName;
	
	/* For verifone payment details */
	public String paymentMerchantID;
	public String paymentSystemGUIID;
	public String paymentMerchantTemplateID;
	public String paymentMerchantReference;
	public String paymentAccountID;
	public String paymentRedirectValue;
	
	public String paymentProductType;
	
	/* For reload verifone payment details */
	public String reloadPaymentMerchantTemplateID;
	public String reloadPaymentAccountID;
	
	public String getExternalReference() {
		return externalReference;
	}
	public void setExternalReference(String externalReference) {
		this.externalReference = externalReference;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getTransactionReference() {
		return transactionReference;
	}
	public void setTransactionReference(String transactionReference) {
		this.transactionReference = transactionReference;
	}
	public String getPaymentReference() {
		return paymentReference;
	}
	public void setPaymentReference(String paymentReference) {
		this.paymentReference = paymentReference;
	}
	public String getCardReference() {
		return cardReference;
	}
	public void setCardReference(String cardReference) {
		this.cardReference = cardReference;
	}
	public String getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getSuccessfulpaymentStatus() {
		return successfulpaymentStatus;
	}
	public void setSuccessfulpaymentStatus(String successfulpaymentStatus) {
		this.successfulpaymentStatus = successfulpaymentStatus;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getAuditRecordProgram() {
		return auditRecordProgram;
	}
	public void setAuditRecordProgram(String auditRecordProgram) {
		this.auditRecordProgram = auditRecordProgram;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTransactionMessage() {
		return transactionMessage;
	}
	public void setTransactionMessage(String transactionMessage) {
		this.transactionMessage = transactionMessage;
	}
	public String getTransactionResult() {
		return transactionResult;
	}
	public void setTransactionResult(String transactionResult) {
		this.transactionResult = transactionResult;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMerchantErrorCode() {
		return merchantErrorCode;
	}
	public void setMerchantErrorCode(String merchantErrorCode) {
		this.merchantErrorCode = merchantErrorCode;
	}
	public String getMerchantErrorDesc() {
		return merchantErrorDesc;
	}
	public void setMerchantErrorDesc(String merchantErrorDesc) {
		this.merchantErrorDesc = merchantErrorDesc;
	}
	public String getExpiryMonth() {
		return expiryMonth;
	}
	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth = expiryMonth;
	}
	public String getExpiryYear() {
		return expiryYear;
	}
	public void setExpiryYear(String expiryYear) {
		this.expiryYear = expiryYear;
	}
	public String getAuthCode() {
		return authCode;
	}
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getAddress4() {
		return address4;
	}
	public void setAddress4(String address4) {
		this.address4 = address4;
	}
	public String getAddress5() {
		return address5;
	}
	public void setAddress5(String address5) {
		this.address5 = address5;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPaymentMerchantID() {
		return paymentMerchantID;
	}
	public void setPaymentMerchantID(String paymentMerchantID) {
		this.paymentMerchantID = paymentMerchantID;
	}
	public String getPaymentSystemGUIID() {
		return paymentSystemGUIID;
	}
	public void setPaymentSystemGUIID(String paymentSystemGUIID) {
		this.paymentSystemGUIID = paymentSystemGUIID;
	}
	public String getPaymentMerchantTemplateID() {
		return paymentMerchantTemplateID;
	}
	public void setPaymentMerchantTemplateID(String paymentMerchantTemplateID) {
		this.paymentMerchantTemplateID = paymentMerchantTemplateID;
	}
	public String getPaymentMerchantReference() {
		return paymentMerchantReference;
	}
	public void setPaymentMerchantReference(String paymentMerchantReference) {
		this.paymentMerchantReference = paymentMerchantReference;
	}
	public String getPaymentAccountID() {
		return paymentAccountID;
	}
	public void setPaymentAccountID(String paymentAccountID) {
		this.paymentAccountID = paymentAccountID;
	}
	public String getPaymentRedirectValue() {
		return paymentRedirectValue;
	}
	public void setPaymentRedirectValue(String paymentRedirectValue) {
		this.paymentRedirectValue = paymentRedirectValue;
	}
	public String getPaymentProductType() {
		return paymentProductType;
	}
	public void setPaymentProductType(String paymentProductType) {
		this.paymentProductType = paymentProductType;
	}
	public String getReloadPaymentMerchantTemplateID() {
		return reloadPaymentMerchantTemplateID;
	}
	public void setReloadPaymentMerchantTemplateID(String reloadPaymentMerchantTemplateID) {
		this.reloadPaymentMerchantTemplateID = reloadPaymentMerchantTemplateID;
	}	
	public String getReloadPaymentAccountID() {
		return reloadPaymentAccountID;
	}
	public void setReloadPaymentAccountID(String reloadPaymentAccountID) {
		this.reloadPaymentAccountID = reloadPaymentAccountID;
	}	
	
}

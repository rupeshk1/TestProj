package com.techm.svallo.service.takeabreak;


import com.techm.svallo.vo.myprofile.TakeABreakQueryVo;
import com.techm.svallo.vo.takeabreak.QueryAccount;
import com.techm.svallo.vo.takeabreak.SubscriptionInfoVo;
import com.techm.svallo.vo.takeabreak.TakeABreakServiceStatusVo;

public interface TakeABreakService
{
	public TakeABreakServiceStatusVo checkTakeABreakService(QueryAccount queryAccount);
	public TakeABreakServiceStatusVo createTakeABreakService(TakeABreakQueryVo akeABreakQueryVo,SubscriptionInfoVo subscriptionInfoVo);
}

package com.techm.svallo.vo.bundle;

public class BundleVo
{
	private String serviceCode;
	private String bundleName;
	private String bundleDescription;
	private String bundleExtendedDescription;
	private String bundleType;
	private double bundlePrice;
	private String bundleServicePrice;
	private String bundleEffectiveDate;
	private String recurring;
	private String bundleMinutes;
	private String bundleTexts;
	private String bundleData;
	private String bundleDays;
	private String operation;
	private String crossSellCategoryName;
	private String bundleTopUpCredit;
	private String bundleRedirectionURL;
	public String oneOffCode;
	public String recurringCode;
	public String bundleCodeType;
	public String bundleEndDate;
	public String bundleSelectedCodeType;
	public boolean isUserEligibleForTopup;
	public String userTopupCredit;
	public String paymentMethod;
	public String bundleRenewsExpireValue;
	private String bundleExpired;
	private String bundleExpiredDate;
	/*private String bundleAvaiableAmount;
	private String bundleRemainingValue;
	private String bundleUsedValue;
	private String bundleAllowanceValue;
	private String bundleLastGrantAmount;
	private String bundleTotalValue;*/
	private String bundlebarGraphTotalValue;
	
	private String bundleDataAvailableAmount;
	private String bundleDataLastGrantAmount;
	private String bundleDataBalanceAmount;
	private String bundleTextAvailableAmount;
	private String bundleTextLastGrantAmount;
	private String bundleTextBalanceAmount;
	private String bundleMinutesAvailableAmount;
	private String bundleMinutesLastGrantAmount;
	private String bundleMinutesBalanceAmount;
	/*private String bundleTotalAvailableAmount;
	private String bundleTotalLastGrantAmount;
	private String bundleTotalBalanceAmount;*/
	
	
    public String getBundleDataAvailableAmount() {
		return bundleDataAvailableAmount;
	}

	public void setBundleDataAvailableAmount(String bundleDataAvailableAmount) {
		this.bundleDataAvailableAmount = bundleDataAvailableAmount;
	}

	public String getBundleDataLastGrantAmount() {
		return bundleDataLastGrantAmount;
	}

	public void setBundleDataLastGrantAmount(String bundleDataLastGrantAmount) {
		this.bundleDataLastGrantAmount = bundleDataLastGrantAmount;
	}

	public String getBundleDataBalanceAmount() {
		return bundleDataBalanceAmount;
	}

	public void setBundleDataBalanceAmount(String bundleDataBalanceAmount) {
		this.bundleDataBalanceAmount = bundleDataBalanceAmount;
	}

	public String getBundleTextAvailableAmount() {
		return bundleTextAvailableAmount;
	}

	public void setBundleTextAvailableAmount(String bundleTextAvailableAmount) {
		this.bundleTextAvailableAmount = bundleTextAvailableAmount;
	}

	public String getBundleTextLastGrantAmount() {
		return bundleTextLastGrantAmount;
	}

	public void setBundleTextLastGrantAmount(String bundleTextLastGrantAmount) {
		this.bundleTextLastGrantAmount = bundleTextLastGrantAmount;
	}

	public String getBundleTextBalanceAmount() {
		return bundleTextBalanceAmount;
	}

	public void setBundleTextBalanceAmount(String bundleTextBalanceAmount) {
		this.bundleTextBalanceAmount = bundleTextBalanceAmount;
	}

	public String getBundleMinutesAvailableAmount() {
		return bundleMinutesAvailableAmount;
	}

	public void setBundleMinutesAvailableAmount(String bundleMinutesAvailableAmount) {
		this.bundleMinutesAvailableAmount = bundleMinutesAvailableAmount;
	}

	public String getBundleMinutesLastGrantAmount() {
		return bundleMinutesLastGrantAmount;
	}

	public void setBundleMinutesLastGrantAmount(String bundleMinutesLastGrantAmount) {
		this.bundleMinutesLastGrantAmount = bundleMinutesLastGrantAmount;
	}

	public String getBundleMinutesBalanceAmount() {
		return bundleMinutesBalanceAmount;
	}

	public void setBundleMinutesBalanceAmount(String bundleMinutesBalanceAmount) {
		this.bundleMinutesBalanceAmount = bundleMinutesBalanceAmount;
	}

	/*public String getBundleTotalAvailableAmount() {
		return bundleTotalAvailableAmount;
	}

	public void setBundleTotalAvailableAmount(String bundleTotalAvailableAmount) {
		this.bundleTotalAvailableAmount = bundleTotalAvailableAmount;
	}

	public String getBundleTotalLastGrantAmount() {
		return bundleTotalLastGrantAmount;
	}

	public void setBundleTotalLastGrantAmount(String bundleTotalLastGrantAmount) {
		this.bundleTotalLastGrantAmount = bundleTotalLastGrantAmount;
	}

	public String getBundleTotalBalanceAmount() {
		return bundleTotalBalanceAmount;
	}

	public void setBundleTotalBalanceAmount(String bundleTotalBalanceAmount) {
		this.bundleTotalBalanceAmount = bundleTotalBalanceAmount;
	}*/

	public BundleVo(){		
		}
	 
	public String getServiceCode()
	{
		return serviceCode;
	}

	public void setServiceCode(String serviceCode)
	{
		this.serviceCode = serviceCode;
	}

	public String getBundleName()
	{
		return bundleName;
	}

	public void setBundleName(String bundleName)
	{
		this.bundleName = bundleName;
	}

	public String getBundleDescription()
	{
		return bundleDescription;
	}

	public void setBundleDescription(String bundleDescription)
	{
		this.bundleDescription = bundleDescription;
	}

	public String getBundleExtendedDescription()
	{
		return bundleExtendedDescription;
	}

	public void setBundleExtendedDescription(String bundleExtendedDescription)
	{
		this.bundleExtendedDescription = bundleExtendedDescription;
	}

	public String getBundleType()
	{
		return bundleType;
	}

	public void setBundleType(String bundleType)
	{
		this.bundleType = bundleType;
	}

	public double getBundlePrice()
	{
		return bundlePrice;
	}

	public void setBundlePrice(double bundlePrice)
	{
		this.bundlePrice = bundlePrice;
	}
	
	public String getBundleServicePrice()
	{
		return bundleServicePrice;
	}

	public void setBundleServicePrice(String bundleServicePrice)
	{
		this.bundleServicePrice = bundleServicePrice;
	}

	public String getBundleEffectiveDate() {
		return bundleEffectiveDate;
	}

	public void setBundleEffectiveDate(String bundleEffectiveDate) {
		this.bundleEffectiveDate = bundleEffectiveDate;
	}

	public String getRecurring() {
		return recurring;
	}

	public void setRecurring(String recurring) {
		this.recurring = recurring;
	}
	
	/* setCode & getType is used only for applicale boltons */
	public void setCode(String recurring, String code){
		if("false".equals(recurring)){
		   this.oneOffCode=code;
		}else{
		   this.recurringCode=code;
		}
	   }
	
	
	public String getType(){				
		if(this.oneOffCode != null && this.recurringCode != null){			
			return "both";			 
			}else if(this.recurringCode != null){
				return "recurring";
			}else{
				return "oneOff";
			}
	}
	
	public BundleVo(String crossSellCategoryName,String recurring, String code){
		this.crossSellCategoryName=crossSellCategoryName;
		if("false".equals(recurring)){
			   this.oneOffCode=code;
			}else{
			   this.recurringCode=code;
			}
		}

	public String getBundleMinutes() {
		return bundleMinutes;
	}

	public void setBundleMinutes(String bundleMinutes) {
		this.bundleMinutes = bundleMinutes;
	}

	public String getBundleTexts() {
		return bundleTexts;
	}

	public void setBundleTexts(String bundleTexts) {
		this.bundleTexts = bundleTexts;
	}

	public String getBundleData() {
		return bundleData;
	}

	public void setBundleData(String bundleData) {
		this.bundleData = bundleData;
	}

	public String getBundleDays() {
		return bundleDays;
	}

	public void setBundleDays(String bundleDays) {
		this.bundleDays = bundleDays;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getCrossSellCategoryName() {
		return crossSellCategoryName;
	}

	public void setCrossSellCategoryName(String crossSellCategoryName) {
		this.crossSellCategoryName = crossSellCategoryName;
	}

	public String getBundleTopUpCredit() {
		return bundleTopUpCredit;
	}

	public void setBundleTopUpCredit(String bundleTopUpCredit) {
		this.bundleTopUpCredit = bundleTopUpCredit;
	}

	public String getBundleRedirectionURL() {
		return bundleRedirectionURL;
	}

	public void setBundleRedirectionURL(String bundleRedirectionURL) {
		this.bundleRedirectionURL = bundleRedirectionURL;
	}

	public String getOneOffCode() {
		return oneOffCode;
	}

	public void setOneOffCode(String oneOffCode) {
		this.oneOffCode = oneOffCode;
	}

	public String getRecurringCode() {
		return recurringCode;
	}

	public void setRecurringCode(String recurringCode) {
		this.recurringCode = recurringCode;
	}

	public String getBundleCodeType() {
		return bundleCodeType;
	}

	public void setBundleCodeType(String bundleCodeType) {
		this.bundleCodeType = bundleCodeType;
	}

	public String getBundleEndDate() {
		return bundleEndDate;
	}

	public void setBundleEndDate(String bundleEndDate) {
		this.bundleEndDate = bundleEndDate;
	}

	public String getBundleSelectedCodeType() {
		return bundleSelectedCodeType;
	}

	public void setBundleSelectedCodeType(String bundleSelectedCodeType) {
		this.bundleSelectedCodeType = bundleSelectedCodeType;
	}

	public boolean isUserEligibleForTopup() {
		return isUserEligibleForTopup;
	}

	public void setUserEligibleForTopup(boolean isUserEligibleForTopup) {
		this.isUserEligibleForTopup = isUserEligibleForTopup;
	}

	public String getUserTopupCredit() {
		return userTopupCredit;
	}

	public void setUserTopupCredit(String userTopupCredit) {
		this.userTopupCredit = userTopupCredit;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getBundleRenewsExpireValue() {
		return bundleRenewsExpireValue;
	}

	public void setBundleRenewsExpireValue(String bundleRenewsExpireValue) {
		this.bundleRenewsExpireValue = bundleRenewsExpireValue;
	}

	public String getBundleExpired() {
		return bundleExpired;
	}

	public void setBundleExpired(String bundleExpired) {
		this.bundleExpired = bundleExpired;
	}

	public String getBundleExpiredDate() {
		return bundleExpiredDate;
	}

	public void setBundleExpiredDate(String bundleExpiredDate) {
		this.bundleExpiredDate = bundleExpiredDate;
	}

	/*public String getBundleAvaiableAmount() {
		return bundleAvaiableAmount;
	}

	public void setBundleAvaiableAmount(String bundleAvaiableAmount) {
		this.bundleAvaiableAmount = bundleAvaiableAmount;
	}

	public String getBundleRemainingValue() {
		return bundleRemainingValue;
	}

	public void setBundleRemainingValue(String bundleRemainingValue) {
		this.bundleRemainingValue = bundleRemainingValue;
	}

	public String getBundleUsedValue() {
		return bundleUsedValue;
	}

	public void setBundleUsedValue(String bundleUsedValue) {
		this.bundleUsedValue = bundleUsedValue;
	}

	public String getBundleAllowanceValue() {
		return bundleAllowanceValue;
	}

	public void setBundleAllowanceValue(String bundleAllowanceValue) {
		this.bundleAllowanceValue = bundleAllowanceValue;
	}

	public String getBundleLastGrantAmount() {
		return bundleLastGrantAmount;
	}

	public void setBundleLastGrantAmount(String bundleLastGrantAmount) {
		this.bundleLastGrantAmount = bundleLastGrantAmount;
	}

	public String getBundleTotalValue() {
		return bundleTotalValue;
	}

	public void setBundleTotalValue(String bundleTotalValue) {
		this.bundleTotalValue = bundleTotalValue;
	}*/

	public String getBundlebarGraphTotalValue() {
		return bundlebarGraphTotalValue;
	}

	public void setBundlebarGraphTotalValue(String bundlebarGraphTotalValue) {
		this.bundlebarGraphTotalValue = bundlebarGraphTotalValue;
	}

}
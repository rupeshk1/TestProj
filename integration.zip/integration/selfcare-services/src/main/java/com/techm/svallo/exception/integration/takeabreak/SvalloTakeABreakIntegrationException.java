package com.techm.svallo.exception.integration.takeabreak;

import com.techm.svallo.exception.integration.SvalloIntegrationException;

public class SvalloTakeABreakIntegrationException extends SvalloIntegrationException
{
	private static final long serialVersionUID = 1L;
}

package com.techm.svallo.vo.topups;


public class BasketListVo {
	
	  	private String amount;
	    private String availableAmount;
	    private String balanceAmount;
	    private String basketCode;
	    private String basketDefinitionAttributeSeqNo;
	    private String basketDefinitionAttributeType;
	    private String basketDefinitionAttributeTypeDescription;
	    private String basketDefinitionAttributeValue;
	    private String basketDefinitionCode;
	    private String basketDefinitionDescription;
	    private String basketDescription;
	    private String basketEffective;
	    private String basketExpiry;
	    private String billingOption;
	    private String creditLimit;
	    private String defaultCreditLimitMaximum;
	    private String defaultCreditLimitMinimum;
	    private String effectiveDate;
	    private String expiryDate;
	    private String formattedAvailableAmount;
	    private String formattedBalanceAmount;
	    private String formattedReservedAmount;
	    private String formattedThresholdLimit;
	    private String headerOrDetail;
	    private String headerService;
	    private String intervalId;
	    private String isBillCycleAligned;
	    private String isCreditLimitUpdatable;
	    private String isPeriodic;
	    private String isPrepaid;
	    private String isShared;
	    private String isVirtual;
	    private String lastGrantAmount;
	    private String rtcBalanceResourceID;
	    private String rtcCreditLimitThresholdID;
	    private String rtcUnitOfMeasure;
	    private String reservedAmount;
	    private String sharedLevel;
	    private String thresholdLimit;
	    private String displayTopup;
	    
		public String getAmount() {
			return amount;
		}
		public void setAmount(String amount) {
			this.amount = amount;
		}
		public String getAvailableAmount() {
			return availableAmount;
		}
		public void setAvailableAmount(String availableAmount) {
			this.availableAmount = availableAmount;
		}
		public String getBalanceAmount() {
			return balanceAmount;
		}
		public void setBalanceAmount(String balanceAmount) {
			this.balanceAmount = balanceAmount;
		}
		public String getBasketCode() {
			return basketCode;
		}
		public void setBasketCode(String basketCode) {
			this.basketCode = basketCode;
		}
		public String getBasketDefinitionAttributeSeqNo() {
			return basketDefinitionAttributeSeqNo;
		}
		public void setBasketDefinitionAttributeSeqNo(
				String basketDefinitionAttributeSeqNo) {
			this.basketDefinitionAttributeSeqNo = basketDefinitionAttributeSeqNo;
		}
		public String getBasketDefinitionAttributeType() {
			return basketDefinitionAttributeType;
		}
		public void setBasketDefinitionAttributeType(
				String basketDefinitionAttributeType) {
			this.basketDefinitionAttributeType = basketDefinitionAttributeType;
		}
		public String getBasketDefinitionAttributeTypeDescription() {
			return basketDefinitionAttributeTypeDescription;
		}
		public void setBasketDefinitionAttributeTypeDescription(
				String basketDefinitionAttributeTypeDescription) {
			this.basketDefinitionAttributeTypeDescription = basketDefinitionAttributeTypeDescription;
		}
		public String getBasketDefinitionAttributeValue() {
			return basketDefinitionAttributeValue;
		}
		public void setBasketDefinitionAttributeValue(
				String basketDefinitionAttributeValue) {
			this.basketDefinitionAttributeValue = basketDefinitionAttributeValue;
		}
		public String getBasketDefinitionCode() {
			return basketDefinitionCode;
		}
		public void setBasketDefinitionCode(String basketDefinitionCode) {
			this.basketDefinitionCode = basketDefinitionCode;
		}
		public String getBasketDefinitionDescription() {
			return basketDefinitionDescription;
		}
		public void setBasketDefinitionDescription(String basketDefinitionDescription) {
			this.basketDefinitionDescription = basketDefinitionDescription;
		}
		public String getBasketDescription() {
			return basketDescription;
		}
		public void setBasketDescription(String basketDescription) {
			this.basketDescription = basketDescription;
		}
		public String getBasketEffective() {
			return basketEffective;
		}
		public void setBasketEffective(String basketEffective) {
			this.basketEffective = basketEffective;
		}
		public String getBasketExpiry() {
			return basketExpiry;
		}
		public void setBasketExpiry(String basketExpiry) {
			this.basketExpiry = basketExpiry;
		}
		public String getBillingOption() {
			return billingOption;
		}
		public void setBillingOption(String billingOption) {
			this.billingOption = billingOption;
		}
		public String getCreditLimit() {
			return creditLimit;
		}
		public void setCreditLimit(String creditLimit) {
			this.creditLimit = creditLimit;
		}
		public String getDefaultCreditLimitMaximum() {
			return defaultCreditLimitMaximum;
		}
		public void setDefaultCreditLimitMaximum(String defaultCreditLimitMaximum) {
			this.defaultCreditLimitMaximum = defaultCreditLimitMaximum;
		}
		public String getDefaultCreditLimitMinimum() {
			return defaultCreditLimitMinimum;
		}
		public void setDefaultCreditLimitMinimum(String defaultCreditLimitMinimum) {
			this.defaultCreditLimitMinimum = defaultCreditLimitMinimum;
		}
		public String getEffectiveDate() {
			return effectiveDate;
		}
		public void setEffectiveDate(String effectiveDate) {
			this.effectiveDate = effectiveDate;
		}
		public String getExpiryDate() {
			return expiryDate;
		}
		public void setExpiryDate(String expiryDate) {
			this.expiryDate = expiryDate;
		}
		public String getFormattedAvailableAmount() {
			return formattedAvailableAmount;
		}
		public void setFormattedAvailableAmount(String formattedAvailableAmount) {
			this.formattedAvailableAmount = formattedAvailableAmount;
		}
		public String getFormattedBalanceAmount() {
			return formattedBalanceAmount;
		}
		public void setFormattedBalanceAmount(String formattedBalanceAmount) {
			this.formattedBalanceAmount = formattedBalanceAmount;
		}
		public String getFormattedReservedAmount() {
			return formattedReservedAmount;
		}
		public void setFormattedReservedAmount(String formattedReservedAmount) {
			this.formattedReservedAmount = formattedReservedAmount;
		}
		public String getFormattedThresholdLimit() {
			return formattedThresholdLimit;
		}
		public void setFormattedThresholdLimit(String formattedThresholdLimit) {
			this.formattedThresholdLimit = formattedThresholdLimit;
		}
		public String getHeaderOrDetail() {
			return headerOrDetail;
		}
		public void setHeaderOrDetail(String headerOrDetail) {
			this.headerOrDetail = headerOrDetail;
		}
		public String getHeaderService() {
			return headerService;
		}
		public void setHeaderService(String headerService) {
			this.headerService = headerService;
		}
		public String getIntervalId() {
			return intervalId;
		}
		public void setIntervalId(String intervalId) {
			this.intervalId = intervalId;
		}
		public String getIsBillCycleAligned() {
			return isBillCycleAligned;
		}
		public void setIsBillCycleAligned(String isBillCycleAligned) {
			this.isBillCycleAligned = isBillCycleAligned;
		}
		public String getIsCreditLimitUpdatable() {
			return isCreditLimitUpdatable;
		}
		public void setIsCreditLimitUpdatable(String isCreditLimitUpdatable) {
			this.isCreditLimitUpdatable = isCreditLimitUpdatable;
		}
		public String getIsPeriodic() {
			return isPeriodic;
		}
		public void setIsPeriodic(String isPeriodic) {
			this.isPeriodic = isPeriodic;
		}
		public String getIsPrepaid() {
			return isPrepaid;
		}
		public void setIsPrepaid(String isPrepaid) {
			this.isPrepaid = isPrepaid;
		}
		public String getIsShared() {
			return isShared;
		}
		public void setIsShared(String isShared) {
			this.isShared = isShared;
		}
		public String getIsVirtual() {
			return isVirtual;
		}
		public void setIsVirtual(String isVirtual) {
			this.isVirtual = isVirtual;
		}
		public String getLastGrantAmount() {
			return lastGrantAmount;
		}
		public void setLastGrantAmount(String lastGrantAmount) {
			this.lastGrantAmount = lastGrantAmount;
		}
		public String getRtcBalanceResourceID() {
			return rtcBalanceResourceID;
		}
		public void setRtcBalanceResourceID(String rtcBalanceResourceID) {
			this.rtcBalanceResourceID = rtcBalanceResourceID;
		}
		public String getRtcCreditLimitThresholdID() {
			return rtcCreditLimitThresholdID;
		}
		public void setRtcCreditLimitThresholdID(String rtcCreditLimitThresholdID) {
			this.rtcCreditLimitThresholdID = rtcCreditLimitThresholdID;
		}
		public String getRtcUnitOfMeasure() {
			return rtcUnitOfMeasure;
		}
		public void setRtcUnitOfMeasure(String rtcUnitOfMeasure) {
			this.rtcUnitOfMeasure = rtcUnitOfMeasure;
		}
		public String getReservedAmount() {
			return reservedAmount;
		}
		public void setReservedAmount(String reservedAmount) {
			this.reservedAmount = reservedAmount;
		}
		public String getSharedLevel() {
			return sharedLevel;
		}
		public void setSharedLevel(String sharedLevel) {
			this.sharedLevel = sharedLevel;
		}
		public String getThresholdLimit() {
			return thresholdLimit;
		}
		public void setThresholdLimit(String thresholdLimit) {
			this.thresholdLimit = thresholdLimit;
		}
		public String getDisplayTopup() {
			return displayTopup;
		}
		public void setDisplayTopup(String displayTopup) {
			this.displayTopup = displayTopup;
		}

}

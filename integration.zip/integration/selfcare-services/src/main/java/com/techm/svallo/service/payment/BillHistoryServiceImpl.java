package com.techm.svallo.service.payment;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.payment.SvalloServiceBillingException;
import com.techm.svallo.vo.billingandpayment.BillVo;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;
import com.techmahindra.online.svallo.model.payment._2014._09._01.UnbilledUnitSummary;
import com.techmahindra.online.svallo.service.payment._2014._09._01.ManagePayment;

import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service("billHistoryService")
public class BillHistoryServiceImpl implements BillHistoryService
{
	
	final static PortalLogger logger = PortalLogger.getLogger(BillHistoryServiceImpl.class);
	
	@Autowired
	private ManagePayment  managePayment;
	
	@Value("${payment.previous.bill.error.code}")
	private String PAYMENT_PREVIOUS_BILL_ERROR_CODE;
	
	@Value("${payment.previous.bill.error.message}")
	private String PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE;
	
	@Value("${payment.previous.bill.error.message.detail}")
	private String PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE_DETAIL;
	
	private JdbcTemplate jdbcTemplate=null;

	private static String GET_BILL_HISTORY="select id as id_mine,"
			+ "invoicenumber as invoice_Number,"
			+ "accountnumber as account_Number,"
			+ "billstartdate as billstart_Date,"
			+ "billenddate as billend_Date,"
			+ "amountdue as amount_Due,"
			+ "status as status_a,"
			+ "billdate as bill_date,"
			+ "ddenabled as dd_Enabled,"
			+ "duedate as due_Date "
			+ "from invoicesummary as invoice_summary where accountnumber=? order by STR_TO_DATE(billdate,'%d-%m-%Y') desc limit 12";
	
	@Override
	public List<BillVo> getBillHistory(String accountNumber) throws SvalloServiceBillingException
	{
		logger.debug("[ getBillHistory() ] START ");
		logger.debug("[ getBillHistory() ] accountNumber >>> "+accountNumber);
		List<BillVo> billHistoryList=null;
		try
		{
			billHistoryList=jdbcTemplate.query(GET_BILL_HISTORY,new String[]{accountNumber},new BillHistoryMapper());
			logger.debug("[ getBillHistory() ] billHistoryList >>> "+billHistoryList);
	    	if(billHistoryList!=null)
	    	{
	    		logger.debug("[ getBillHistory() ] billHistoryList .size() >>> "+billHistoryList.size());
	    	}
	    	logger.debug("[ getBillHistory() ] END");
		}
		catch (InvalidResultSetAccessException invalidResultSetAccessException )
		{
			logger.error(invalidResultSetAccessException,"[ getBillHistory() ] InvalidResultSetAccessException Catch Block ");
			logger.error(invalidResultSetAccessException,"[ getBillHistory() ] InvalidResultSetAccessException Catch Block | Error Code =  "+PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			logger.error(invalidResultSetAccessException,"[ getBillHistory() ] InvalidResultSetAccessException Catch Block | Error Message  =  "+PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			SvalloServiceBillingException svalloServiceBillingException = new SvalloServiceBillingException();
			svalloServiceBillingException.setErrorCode(PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			svalloServiceBillingException.setErrorMessage(PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			svalloServiceBillingException.setErrorMessageDetail(PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE_DETAIL);
			svalloServiceBillingException.setRootCause(invalidResultSetAccessException);
			throw svalloServiceBillingException;
		}
		catch (EmptyResultDataAccessException emptyResultDataAccessException  )
		{
			logger.error(emptyResultDataAccessException,"[ getBillHistory() ] InvalidResultSetAccessException Catch Block ");
			logger.error(emptyResultDataAccessException,"[ getBillHistory() ] InvalidResultSetAccessException Catch Block | Error Code =  "+PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			logger.error(emptyResultDataAccessException,"[ getBillHistory() ] InvalidResultSetAccessException Catch Block | Error Message  =  "+PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			SvalloServiceBillingException svalloServiceBillingException = new SvalloServiceBillingException();
			svalloServiceBillingException.setErrorCode(PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			svalloServiceBillingException.setErrorMessage(PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			svalloServiceBillingException.setErrorMessageDetail(PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE_DETAIL);
			svalloServiceBillingException.setRootCause(emptyResultDataAccessException);
			throw svalloServiceBillingException;
		}
		catch (DataAccessException dataAccessException  )
		{
			logger.error(dataAccessException,"[ getBillHistory() ] DataAccessException Catch Block ");
			logger.error(dataAccessException,"[ getBillHistory() ] DataAccessException Catch Block | Error Code =  "+PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			logger.error(dataAccessException,"[ getBillHistory() ] DataAccessException Catch Block | Error Message  =  "+PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			SvalloServiceBillingException svalloServiceBillingException = new SvalloServiceBillingException();
			svalloServiceBillingException.setErrorCode(PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			svalloServiceBillingException.setErrorMessage(PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			svalloServiceBillingException.setErrorMessageDetail(PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE_DETAIL);
			svalloServiceBillingException.setRootCause(dataAccessException);
			throw svalloServiceBillingException;
		}
		catch (Exception exception)
		{
			logger.error(exception,"[ getBillHistory() ] Exception catch block ");
			logger.error(exception,"[ getBillHistory() ] Exception catch bloc | Error Code =  "+PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			logger.error(exception,"[ getBillHistory() ] Exception catch bloc | Error Message  =  "+PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			SvalloServiceBillingException svalloServiceBillingException = new SvalloServiceBillingException();
			svalloServiceBillingException.setErrorCode(PAYMENT_PREVIOUS_BILL_ERROR_CODE);
			svalloServiceBillingException.setErrorMessage(PAYMENT_PREVIOUS_BILL_ERROR_MESSAGE);
			svalloServiceBillingException.setRootCause(exception);
			throw svalloServiceBillingException;
		}
    	
		return billHistoryList;
	}
	
	/**
	 * @param jdbcTemplate the jdbcTemplate to set
	 */
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	private static final class BillHistoryMapper implements RowMapper<BillVo> {

	    public BillVo mapRow(ResultSet rs, int rowNum) throws SQLException {
	    	BillVo billVo = new BillVo();
	    	String id = String.valueOf(rs.getInt("id_mine"));
	    	billVo.setId(id);
	    	billVo.setInvoiceNumber(rs.getString("invoice_Number"));
	    	billVo.setAccountNumber(rs.getString("account_Number"));
	    	billVo.setBillstartDate(rs.getString("billstart_Date"));
	    	billVo.setBillendDate(rs.getString("billend_Date"));
	    	billVo.setAmountDue(rs.getString("amount_Due"));
	    	billVo.setStatus(rs.getString("status_a"));
	    	billVo.setBillDate(rs.getString("bill_date"));
	    	billVo.setDdenabled(rs.getString("dd_enabled"));
	    	billVo.setDuedate(rs.getString("due_date"));
	        return billVo;
	    }
	}

	@Override
	public UnbilledUnitSummary getUnbilledValue(QueryAccount queryAccount)
	{
		logger.debug("[getUnbilledValue() ] START");
		UnbilledUnitSummary unbilledUnitSummary =  managePayment.getUnbilledValue(queryAccount);
		logger.debug("[getUnbilledValue() ] unbilledUnitSummary >>> "+unbilledUnitSummary);
		logger.debug("[getUnbilledValue() ] END");
		return unbilledUnitSummary;
	}
	
}

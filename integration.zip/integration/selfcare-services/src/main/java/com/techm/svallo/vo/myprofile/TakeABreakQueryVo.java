package com.techm.svallo.vo.myprofile;

public class TakeABreakQueryVo
{
	private String subscriptionNumber;
	private String date;
	private String serviceCode;
	private String totalPrice;
	private String attributeGroupId;
	private String takeABreakCounter;
	

	public String getTakeABreakCounter()
	{
		return takeABreakCounter;
	}
	public void setTakeABreakCounter(String takeABreakCounter)
	{
		this.takeABreakCounter = takeABreakCounter;
	}
	public String getSubscriptionNumber()
	{
		return subscriptionNumber;
	}
	public void setSubscriptionNumber(String subscriptionNumber)
	{
		this.subscriptionNumber = subscriptionNumber;
	}
	public String getDate()
	{
		return date;
	}
	public void setDate(String date)
	{
		this.date = date;
	}
	public String getServiceCode()
	{
		return serviceCode;
	}
	public void setServiceCode(String serviceCode)
	{
		this.serviceCode = serviceCode;
	}
	public String getTotalPrice()
	{
		return totalPrice;
	}
	public void setTotalPrice(String totalPrice)
	{
		this.totalPrice = totalPrice;
	}
	public String getAttributeGroupId()
	{
		return attributeGroupId;
	}
	public void setAttributeGroupId(String attributeGroupId)
	{
		this.attributeGroupId = attributeGroupId;
	}
	
	
	
}

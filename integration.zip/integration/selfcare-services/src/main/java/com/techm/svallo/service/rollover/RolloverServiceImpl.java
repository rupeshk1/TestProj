package com.techm.svallo.service.rollover;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.exception.service.myallowances.SvalloMyAllowancesServiceException;
import com.techm.svallo.exception.service.rollover.SvalloRolloverServiceException;
import com.techm.svallo.util.SelfCareUtil;
import com.techm.svallo.vo.rollover.RolloverListVo;
import com.techm.svallo.vo.rollover.RolloverVo;
import com.techmahindra.online.svallo.model.rollover._2015._07._16.RolloverList;
import com.techmahindra.online.svallo.model.rollover._2015._07._16.SvalloRolloverRequest;
import com.techmahindra.online.svallo.service.common.exception.rollover.SvalloRolloverIntegrationException;
import com.techmahindra.online.svallo.service.rollover._2015._07._16.Rollover;

public class RolloverServiceImpl implements RolloverService{
	
	final static PortalLogger logger = PortalLogger.getLogger(RolloverServiceImpl.class);
	
	@Autowired
	private Rollover rollover;

	public Rollover getRollover() {
		return rollover;
	}

	public void setRollover(Rollover rollover) {
		this.rollover = rollover;
	}
	
	@Value("${rollover.getRollover.error.code}")
	private String ROLLOVER_GETROLLOVER_ERROR_CODE;
	
	@Value("${rollover.getRollover.error.message}")
	private String ROLLOVER_GETROLLOVER_ERROR_MESSAGE;
	
	@Value("${rollover.getRollover.exception.code}")
	private String ROLLOVER_GETROLLOVER_EXCEPTION_CODE;
	
	@Value("${rollover.getRollover.exception.message}")
	private String ROLLOVER_GETROLLOVER_EXCEPTION_MESSAGE;

	public RolloverListVo getRollover(String subscriptionNumber) {
		// TODO Auto-generated method stub
		
		logger.debug("==================In RolloverServiceImpl================");
		logger.debug("Subscription number: " +subscriptionNumber);
		
		SvalloRolloverRequest request = new SvalloRolloverRequest();
		request.setSubscriptionNumber(subscriptionNumber);
		
		RolloverListVo rolloverListVo = new RolloverListVo();
		
		try{
		List<RolloverVo> minsRolloverValuesList = new ArrayList<RolloverVo>();
		List<RolloverVo> textsRolloverValuesList = new ArrayList<RolloverVo>();
		List<RolloverVo> dataRolloverValuesList = new ArrayList<RolloverVo>();
		
		RolloverList list = rollover.getRollover(request);
		
		if(list != null){
			for(int i=0; i<list.getMinsRollover().getValue().getMonth().size(); i++){
				logger.debug("**************** RolloverServiceImpl || Mins rollover ****************");
				float availableAmount = Float.parseFloat(list.getMinsRollover().getValue().getMonth().get(i).getAvailableAmount());
				String minsEffectiveDate = list.getMinsRollover().getValue().getMonth().get(i).getEffectiveDate();
				if(!minsEffectiveDate.equalsIgnoreCase("1111-11-11Z"))
				{
					logger.debug("Effective date("+i+"): " +SelfCareUtil.getRolloverDrillDownMonth(list.getMinsRollover().getValue().getMonth().get(i).getEffectiveDate()));			
					logger.debug("Available amount("+i+"): " +list.getMinsRollover().getValue().getMonth().get(i).getAvailableAmount());
					logger.debug("Used amount("+i+"): " +list.getMinsRollover().getValue().getMonth().get(i).getUsedAmount());
					
					RolloverVo minsRollover = new RolloverVo();
					
					minsRollover.setEffectiveDate(SelfCareUtil.getRolloverDrillDownMonth(list.getMinsRollover().getValue().getMonth().get(i).getEffectiveDate()));			
					minsRollover.setAvailableAmount(list.getMinsRollover().getValue().getMonth().get(i).getAvailableAmount());
					minsRollover.setUsedAmount(list.getMinsRollover().getValue().getMonth().get(i).getUsedAmount());
					
					minsRolloverValuesList.add(minsRollover);
				}
				
			}
			
			for(int i=0; i<list.getTextsRollover().getValue().getMonth().size(); i++){
				logger.debug("***************** RolloverServiceImpl || Texts rollover ********************");
				float availableAmount = Float.parseFloat(list.getTextsRollover().getValue().getMonth().get(i).getAvailableAmount());
				String textsEffectiveDate = list.getTextsRollover().getValue().getMonth().get(i).getEffectiveDate();
				if(!textsEffectiveDate.equalsIgnoreCase("1111-11-11Z"))
				{
					logger.debug("Effective date("+i+"): " +SelfCareUtil.getRolloverDrillDownMonth(list.getTextsRollover().getValue().getMonth().get(i).getEffectiveDate()));			
					logger.debug("Available amount("+i+"): " +list.getTextsRollover().getValue().getMonth().get(i).getAvailableAmount());
					logger.debug("Used amount("+i+"): " +list.getTextsRollover().getValue().getMonth().get(i).getUsedAmount());
					
					RolloverVo textsRollover = new RolloverVo();
					
					textsRollover.setEffectiveDate(SelfCareUtil.getRolloverDrillDownMonth(list.getTextsRollover().getValue().getMonth().get(i).getEffectiveDate()));			
					textsRollover.setAvailableAmount(list.getTextsRollover().getValue().getMonth().get(i).getAvailableAmount());
					textsRollover.setUsedAmount(list.getTextsRollover().getValue().getMonth().get(i).getUsedAmount());
					
					textsRolloverValuesList.add(textsRollover);
				}			
			}
			
			for(int i=0; i<list.getDataRollover().getValue().getMonth().size(); i++){
				logger.debug("********************** RolloverServiceImpl || Data rollover ***************************");
				float availableAmount = Float.parseFloat(list.getDataRollover().getValue().getMonth().get(i).getAvailableAmount());
				String dataEffectiveDate = list.getDataRollover().getValue().getMonth().get(i).getEffectiveDate();
				logger.debug("Data effective date outside if: " +dataEffectiveDate);
				if(!dataEffectiveDate.equalsIgnoreCase("1111-11-11Z"))
				{
					logger.debug("Effective date("+i+"): " +SelfCareUtil.getRolloverDrillDownMonth(list.getDataRollover().getValue().getMonth().get(i).getEffectiveDate()));			
					logger.debug("Available amount("+i+"): " +list.getDataRollover().getValue().getMonth().get(i).getAvailableAmount());
					logger.debug("Used amount("+i+"): " +list.getDataRollover().getValue().getMonth().get(i).getUsedAmount());
					
					RolloverVo dataRollover = new RolloverVo();
					
					dataRollover.setEffectiveDate(SelfCareUtil.getRolloverDrillDownMonth(list.getDataRollover().getValue().getMonth().get(i).getEffectiveDate()));			
					dataRollover.setAvailableAmount(list.getDataRollover().getValue().getMonth().get(i).getAvailableAmount());
					dataRollover.setUsedAmount(list.getDataRollover().getValue().getMonth().get(i).getUsedAmount());
					
					dataRolloverValuesList.add(dataRollover);
				}
			}
			
			rolloverListVo.setMinsrolloverValuesList(minsRolloverValuesList);
			rolloverListVo.setTextsrolloverValuesList(textsRolloverValuesList);
			rolloverListVo.setDatarolloverValuesList(dataRolloverValuesList);
		}
		
		}catch(SvalloRolloverIntegrationException svalloRolloverIntegrationException)
		{
			//es.printStackTrace();
			logger.error(svalloRolloverIntegrationException, "\n[ RolloverServiceImpl | getRollover() ] SvalloRolloverServiceException Catch Block ");
			logger.error(svalloRolloverIntegrationException, "\n[ RolloverServiceImpl | getRollover() ] SvalloRolloverServiceException Catch Block | Error Code =  "+ROLLOVER_GETROLLOVER_ERROR_CODE);
			logger.error(svalloRolloverIntegrationException, "\n[ RolloverServiceImpl | getRollover() ] SvalloRolloverServiceException Catch Block | Error Message  =  "+ROLLOVER_GETROLLOVER_ERROR_MESSAGE);
			SvalloRolloverServiceException svalloRolloverServiceException = new SvalloRolloverServiceException();
			svalloRolloverServiceException.setErrorCode(ROLLOVER_GETROLLOVER_ERROR_CODE);
			svalloRolloverServiceException.setErrorMessage(ROLLOVER_GETROLLOVER_ERROR_MESSAGE);
			svalloRolloverServiceException.setRootCause(svalloRolloverIntegrationException);
			
			//dashboardInfoVo.setMrcSum(DATA_NOT_AVAILABLE);
			//dashboardInfoVo.setTotalSum(DATA_NOT_AVAILABLE);
		}
		catch(Exception exception)
		{
			//es.printStackTrace();
			logger.error(exception, "\n[ RolloverServiceImpl | getRollover() ] Exception Catch Block ");
			logger.error(exception, "\n[ RolloverServiceImpl | getRollover() ] Exception Catch Block | Error Code =  "+ROLLOVER_GETROLLOVER_EXCEPTION_CODE);
			logger.error(exception, "\n[ RolloverServiceImpl | getRollover() ] Exception Catch Block | Error Message  =  "+ROLLOVER_GETROLLOVER_EXCEPTION_MESSAGE);
			SvalloRolloverServiceException svalloRolloverServiceException = new SvalloRolloverServiceException();
			svalloRolloverServiceException.setErrorCode(ROLLOVER_GETROLLOVER_EXCEPTION_CODE);
			svalloRolloverServiceException.setErrorMessage(ROLLOVER_GETROLLOVER_EXCEPTION_MESSAGE);
			svalloRolloverServiceException.setRootCause(exception);	
			
			//dashboardInfoVo.setMrcSum(DATA_NOT_AVAILABLE);
			//dashboardInfoVo.setTotalSum(DATA_NOT_AVAILABLE);
		}
		
		return rolloverListVo;
	}

}

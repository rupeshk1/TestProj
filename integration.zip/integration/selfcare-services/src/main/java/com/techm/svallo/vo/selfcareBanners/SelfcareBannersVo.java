package com.techm.svallo.vo.selfcareBanners;

public class SelfcareBannersVo
{
	private String bannerUrl;
	private String sameWindowFlag;
	private String imageName;
	
	public String getImageName()
	{
		return imageName;
	}
	public void setImageName(String imageName)
	{
		this.imageName = imageName;
	}
	public String getBannerUrl()
	{
		return bannerUrl;
	}
	public void setBannerUrl(String bannerUrl)
	{
		this.bannerUrl = bannerUrl;
	}
	public String getSameWindowFlag()
	{
		return sameWindowFlag;
	}
	public void setSameWindowFlag(String sameWindowFlag)
	{
		this.sameWindowFlag = sameWindowFlag;
	}	
}

package com.techm.svallo.vo;

public class UpdateAccountVO {
	private String name;
	private String mahindraTelecomNumber;
	private String residentialAddress;
	private String pin;
	private String alternateContactNumber;
	private String emailId;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the mahindraTelecomNumber
	 */
	public String getMahindraTelecomNumber() {
		return mahindraTelecomNumber;
	}
	/**
	 * @param mahindraTelecomNumber the mahindraTelecomNumber to set
	 */
	public void setMahindraTelecomNumber(String mahindraTelecomNumber) {
		this.mahindraTelecomNumber = mahindraTelecomNumber;
	}
	/**
	 * @return the residentialAddress
	 */
	public String getResidentialAddress() {
		return residentialAddress;
	}
	/**
	 * @param residentialAddress the residentialAddress to set
	 */
	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	/**
	 * @return the alternateContactNumber
	 */
	public String getAlternateContactNumber() {
		return alternateContactNumber;
	}
	/**
	 * @param alternateContactNumber the alternateContactNumber to set
	 */
	public void setAlternateContactNumber(String alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}
	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
}

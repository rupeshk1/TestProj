package com.techm.svallo.service.byot;

import com.techm.svallo.vo.byot.ByotInfoVo;



public interface ByotService {
	
	public String updateByotDetails(String externalReference,String subscriptionNumber,String packageCode,String tariffCode,String mins,String data,String text);
	public ByotInfoVo getMrcAllowanceDetails(String dataSet, String externalReference, String primarySerialNumber,String subscriptionNumber);
	//public String getCostAllowanceDetails (String key,String name,String value);
	public String getCostAllowanceDetails (String tariffCode);
}

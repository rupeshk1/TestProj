package com.techm.svallo.vo.topups;

import java.util.List;

public class HistoryListVo
{
	private List<HistoryVo> topupHistories;
	private List<HistoryVo> bundleHistories;
	private List<HistoryVo> addonHistories;
	private List<HistoryVo> generalHistories;

	private String totalAddonPrice;
	private String totalBundlePrice;
	private String totalTopupPrice;
	private String totalPrice;
	
	private String historyExceptionPresent="false";
	private String bundlehistoryExceptionPresent="false";
	private String addonHistoryExceptionPresent="false";
	private String topupHistoryExceptionPresent="false";

	public List<HistoryVo> getTopupHistories()
	{
		return topupHistories;
	}

	public void setTopupHistories(List<HistoryVo> topupHistories)
	{
		this.topupHistories = topupHistories;
	}

	public List<HistoryVo> getBundleHistories()
	{
		return bundleHistories;
	}

	public void setBundleHistories(List<HistoryVo> bundleHistories)
	{
		this.bundleHistories = bundleHistories;
	}

	public List<HistoryVo> getAddonHistories()
	{
		return addonHistories;
	}

	public void setAddonHistories(List<HistoryVo> addonHistories)
	{
		this.addonHistories = addonHistories;
	}

	public String getTotalAddonPrice()
	{
		return totalAddonPrice;
	}

	public void setTotalAddonPrice(String totalAddonPrice)
	{
		this.totalAddonPrice = totalAddonPrice;
	}

	public String getTotalBundlePrice()
	{
		return totalBundlePrice;
	}

	public void setTotalBundlePrice(String totalBundlePrice)
	{
		this.totalBundlePrice = totalBundlePrice;
	}

	public String getTotalTopupPrice()
	{
		return totalTopupPrice;
	}

	public void setTotalTopupPrice(String totalTopupPrice)
	{
		this.totalTopupPrice = totalTopupPrice;
	}

	public List<HistoryVo> getGeneralHistories()
	{
		return generalHistories;
	}

	public void setGeneralHistories(List<HistoryVo> generalHistories)
	{
		this.generalHistories = generalHistories;
	}

	public String getTotalPrice()
	{
		return totalPrice;
	}

	public void setTotalPrice(String totalPrice)
	{
		this.totalPrice = totalPrice;
	}

	public String getHistoryExceptionPresent()
	{
		return historyExceptionPresent;
	}

	public void setHistoryExceptionPresent(String historyExceptionPresent)
	{
		this.historyExceptionPresent = historyExceptionPresent;
	}

	public String getBundlehistoryExceptionPresent()
	{
		return bundlehistoryExceptionPresent;
	}

	public void setBundlehistoryExceptionPresent(String bundlehistoryExceptionPresent)
	{
		this.bundlehistoryExceptionPresent = bundlehistoryExceptionPresent;
	}

	public String getAddonHistoryExceptionPresent()
	{
		return addonHistoryExceptionPresent;
	}

	public void setAddonHistoryExceptionPresent(String addonHistoryExceptionPresent)
	{
		this.addonHistoryExceptionPresent = addonHistoryExceptionPresent;
	}

	public String getTopupHistoryExceptionPresent()
	{
		return topupHistoryExceptionPresent;
	}

	public void setTopupHistoryExceptionPresent(String topupHistoryExceptionPresent)
	{
		this.topupHistoryExceptionPresent = topupHistoryExceptionPresent;
	}

	
}

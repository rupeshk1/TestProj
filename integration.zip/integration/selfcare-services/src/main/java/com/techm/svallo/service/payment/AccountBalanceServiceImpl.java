package com.techm.svallo.service.payment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techmahindra.online.svallo.model.payment._2014._09._01.BalanceDetails;
import com.techmahindra.online.svallo.model.payment._2014._09._01.QueryAccount;
import com.techmahindra.online.svallo.service.payment._2014._09._01.ManagePayment;

@Service("accountBalanceService")
public class AccountBalanceServiceImpl implements AccountBalanceService
{
	
	final static PortalLogger logger = PortalLogger.getLogger(AccountBalanceServiceImpl.class);
	
	@Autowired
	private ManagePayment  managePayment;

	@Override
	public BalanceDetails getAccountBallance(QueryAccount queryAccount)
	{
		logger.debug("[ getAccountBallance() ] START");
		BalanceDetails balanceDetails =  managePayment.getAccountBallance(queryAccount);
		logger.debug("[ getAccountBallance() ] balanceDetails >>> "+balanceDetails);
		logger.debug("[ getAccountBallance() ] END");
		return balanceDetails;
	}

}

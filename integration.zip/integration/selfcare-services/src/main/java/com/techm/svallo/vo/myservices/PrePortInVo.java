package com.techm.svallo.vo.myservices;

public class PrePortInVo {
	
	private String externalReference;
	private String customerLevel;
	private String customerLevelReference;
	private String statusFilter;
	private String eventTypeCode;
	private String eventCode;
	private String queryLimitExceeded;
	private String eventNumber;
	private String eventStatus;
	private String eventType;	
	private String currentUserID;
	private String createdDate;
	private String portInNumber;
	private String prePortInError;
	
	public String getExternalReference() {
		return externalReference;
	}
	public void setExternalReference(String externalReference) {
		this.externalReference = externalReference;
	}
	public String getCustomerLevel() {
		return customerLevel;
	}
	public void setCustomerLevel(String customerLevel) {
		this.customerLevel = customerLevel;
	}
	public String getCustomerLevelReference() {
		return customerLevelReference;
	}
	public void setCustomerLevelReference(String customerLevelReference) {
		this.customerLevelReference = customerLevelReference;
	}
	public String getStatusFilter() {
		return statusFilter;
	}
	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}
	public String getEventTypeCode() {
		return eventTypeCode;
	}
	public void setEventTypeCode(String eventTypeCode) {
		this.eventTypeCode = eventTypeCode;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public String getQueryLimitExceeded() {
		return queryLimitExceeded;
	}
	public void setQueryLimitExceeded(String queryLimitExceeded) {
		this.queryLimitExceeded = queryLimitExceeded;
	}
	public String getEventNumber() {
		return eventNumber;
	}
	public void setEventNumber(String eventNumber) {
		this.eventNumber = eventNumber;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getCurrentUserID() {
		return currentUserID;
	}
	public void setCurrentUserID(String currentUserID) {
		this.currentUserID = currentUserID;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getPortInNumber() {
		return portInNumber;
	}
	public void setPortInNumber(String portInNumber) {
		this.portInNumber = portInNumber;
	}
	public String getPrePortInError() {
		return prePortInError;
	}
	public void setPrePortInError(String prePortInError) {
		this.prePortInError = prePortInError;
	}
	
	
}

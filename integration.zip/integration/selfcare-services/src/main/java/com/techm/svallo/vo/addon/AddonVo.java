package com.techm.svallo.vo.addon;


public class AddonVo
{
	private String serviceCode;
	private String addonName;
	private String addonNameDescription;
	private String addonDescription;
	private String addonExtendedDescription;
	private String addonType;
	private double addonPrice;
	private String addonServicePrice;
	private String addonEffectiveDate;
	private String recurring;
	private String rolloverApplicable;
	private String addonMinutes;
	private String addonTexts;
	private String addonData;
	private String addonDays;
	private String operation;
	private String crossSellCategoryName;
	private String addonTopUpCredit;
	private String addonRedirectionURL;
	public String oneOffCode;
	public String recurringCode;
	public String addonCodeType;
	public String addonEndDate;
	public String addonSelectedCodeType;
	public boolean isUserEligibleForTopup;
	public String userTopupCredit;
	public String paymentMethod;
	private String addonExpired;
	private String addonExpiredDate;
	private String addonAvaiableAmount;
	private String addonRemainingValue;
	private String addonUsedValue;
	private String addonAllowanceValue;
	private String addonLastGrantAmount; 
	private String addonRenewsExpireValue;
	private String addonTotalValue;
	private String addonBarGraphTotalValue;
	private String paymentDone;
	private String reloadMethod;

    public String getReloadMethod()
	{
		return reloadMethod;
	}

	public void setReloadMethod(String reloadMethod)
	{
		this.reloadMethod = reloadMethod;
	}

	public AddonVo(){		
	}
	
	public String getAddonNameDescription()
	{
		return addonNameDescription;
	}

	public void setAddonNameDescription(String addonNameDescription)
	{
		this.addonNameDescription = addonNameDescription;
	}

	public String getServiceCode()
	{
		return serviceCode;
	}

	public void setServiceCode(String serviceCode)
	{
		this.serviceCode = serviceCode;
	}

	public String getAddonName()
	{
		return addonName;
	}

	public void setAddonName(String addonName)
	{
		this.addonName = addonName;
	}

	public String getAddonDescription()
	{
		return addonDescription;
	}

	public void setAddonDescription(String addonDescription)
	{
		this.addonDescription = addonDescription;
	}

	public String getAddonExtendedDescription()
	{
		return addonExtendedDescription;
	}

	public void setAddonExtendedDescription(String addonExtendedDescription)
	{
		this.addonExtendedDescription = addonExtendedDescription;
	}

	public String getAddonType()
	{
		return addonType;
	}

	public void setAddonType(String addonType)
	{
		this.addonType = addonType;
	}

	public double getAddonPrice()
	{
		return addonPrice;
	}

	public void setAddonPrice(double addonPrice)
	{
		this.addonPrice = addonPrice;
	}
	
	public String getAddonServicePrice()
	{
		return addonServicePrice;
	}

	public void setAddonServicePrice(String addonServicePrice)
	{
		this.addonServicePrice = addonServicePrice;
	}

	public String getAddonEffectiveDate() {
		return addonEffectiveDate;
	}

	public void setAddonEffectiveDate(String addonEffectiveDate) {
		this.addonEffectiveDate = addonEffectiveDate;
	}

	public String getRecurring() {
		return recurring;
	}

	public void setRecurring(String recurring) {
		this.recurring = recurring;
	}	
	
	public String getRolloverApplicable() {
		return rolloverApplicable;
	}

	public void setRolloverApplicable(String rolloverApplicable) {
		this.rolloverApplicable = rolloverApplicable;
	}

	public String getAddonMinutes() {
		return addonMinutes;
	}

	public void setAddonMinutes(String addonMinutes) {
		this.addonMinutes = addonMinutes;
	}

	public String getAddonTexts() {
		return addonTexts;
	}

	public void setAddonTexts(String addonTexts) {
		this.addonTexts = addonTexts;
	}

	public String getAddonData() {
		return addonData;
	}

	public void setAddonData(String addonData) {
		this.addonData = addonData;
	}

	public String getAddonDays() {
		return addonDays;
	}

	public void setAddonDays(String addonDays) {
		this.addonDays = addonDays;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getCrossSellCategoryName() {
		return crossSellCategoryName;
	}

	public void setCrossSellCategoryName(String crossSellCategoryName) {
		this.crossSellCategoryName = crossSellCategoryName;
	}
	
	/* setCode & getType is used only for applicale boltons */
	public void setCode(String recurring, String code){
		if("false".equals(recurring)){
		   this.oneOffCode=code;
		}else{
		   this.recurringCode=code;
		}
	   }
	
	
	public String getType(){				
		if(this.oneOffCode != null && this.recurringCode != null){			
			return "both";			 
			}else if(this.recurringCode != null){
				return "recurring";
			}else{
				return "oneOff";
			}
	}

	public String getOneOffCode() {
		return oneOffCode;
	}

	public void setOneOffCode(String oneOffCode) {
		this.oneOffCode = oneOffCode;
	}

	public String getRecurringCode() {
		return recurringCode;
	}

	public void setRecurringCode(String recurringCode) {
		this.recurringCode = recurringCode;
	}
	
	public AddonVo(String crossSellCategoryName,String recurring, String code){
		this.crossSellCategoryName=crossSellCategoryName;
		if("false".equals(recurring)){
			   this.oneOffCode=code;
			}else{
			   this.recurringCode=code;
			}
		}
	
	
	public String getAddonTopUpCredit() {
		return addonTopUpCredit;
	}

	public void setAddonTopUpCredit(String addonTopUpCredit) {
		this.addonTopUpCredit = addonTopUpCredit;
	}

	public String getAddonRedirectionURL() {
		return addonRedirectionURL;
	}

	public void setAddonRedirectionURL(String addonRedirectionURL) {
		this.addonRedirectionURL = addonRedirectionURL;
	}

	public String getAddonCodeType() {
		return addonCodeType;
	}

	public void setAddonCodeType(String addonCodeType) {
		this.addonCodeType = addonCodeType;
	}

	public String getAddonEndDate() {
		return addonEndDate;
	}

	public void setAddonEndDate(String addonEndDate) {
		this.addonEndDate = addonEndDate;
	}

	public String getAddonSelectedCodeType() {
		return addonSelectedCodeType;
	}

	public void setAddonSelectedCodeType(String addonSelectedCodeType) {
		this.addonSelectedCodeType = addonSelectedCodeType;
	}

	public boolean isUserEligibleForTopup() {
		return isUserEligibleForTopup;
	}

	public void setUserEligibleForTopup(boolean isUserEligibleForTopup) {
		this.isUserEligibleForTopup = isUserEligibleForTopup;
	}

	public String getUserTopupCredit() {
		return userTopupCredit;
	}

	public void setUserTopupCredit(String userTopupCredit) {
		this.userTopupCredit = userTopupCredit;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getAddonExpired() {
		return addonExpired;
	}

	public void setAddonExpired(String addonExpired) {
		this.addonExpired = addonExpired;
	}

	public String getAddonExpiredDate() {
		return addonExpiredDate;
	}

	public void setAddonExpiredDate(String addonExpiredDate) {
		this.addonExpiredDate = addonExpiredDate;
	}

	public String getAddonAvaiableAmount() {
		return addonAvaiableAmount;
	}

	public void setAddonAvaiableAmount(String addonAvaiableAmount) {
		this.addonAvaiableAmount = addonAvaiableAmount;
	}

	public String getAddonRemainingValue() {
		return addonRemainingValue;
	}

	public void setAddonRemainingValue(String addonRemainingValue) {
		this.addonRemainingValue = addonRemainingValue;
	}

	public String getAddonUsedValue() {
		return addonUsedValue;
	}

	public void setAddonUsedValue(String addonUsedValue) {
		this.addonUsedValue = addonUsedValue;
	}

	public String getAddonAllowanceValue() {
		return addonAllowanceValue;
	}

	public void setAddonAllowanceValue(String addonAllowanceValue) {
		this.addonAllowanceValue = addonAllowanceValue;
	}

	public String getAddonLastGrantAmount() {
		return addonLastGrantAmount;
	}

	public void setAddonLastGrantAmount(String addonLastGrantAmount) {
		this.addonLastGrantAmount = addonLastGrantAmount;
	}
	
	public String getAddonRenewsExpireValue() {
		return addonRenewsExpireValue;
	}

	public void setAddonRenewsExpireValue(String addonRenewsExpireValue) {
		this.addonRenewsExpireValue = addonRenewsExpireValue;
	}

	public String getAddonTotalValue() {
		return addonTotalValue;
	}

	public void setAddonTotalValue(String addonTotalValue) {
		this.addonTotalValue = addonTotalValue;
	}	

	public String getAddonBarGraphTotalValue() {
		return addonBarGraphTotalValue;
	}

	public void setAddonBarGraphTotalValue(String addonBarGraphTotalValue) {
		this.addonBarGraphTotalValue = addonBarGraphTotalValue;
	}

	public String getPaymentDone()
	{
		return paymentDone;
	}

	public void setPaymentDone(String paymentDone)
	{
		this.paymentDone = paymentDone;
	}	
	
	
	
}
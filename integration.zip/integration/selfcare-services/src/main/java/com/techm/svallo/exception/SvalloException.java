package com.techm.svallo.exception;

import java.util.List;

public class SvalloException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	private String errorCode;
	private String errorMessage;
	private String errorMessageDetail;
	private String errorContext = null;
	private List<String> errorMessages;
	private Throwable rootCause;
	
	public String getErrorCode()
	{
		return errorCode;
	}
	public void setErrorCode(String errorCode)
	{
		this.errorCode = errorCode;
	}
	public String getErrorMessage()
	{
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}
	public String getErrorMessageDetail()
	{
		return errorMessageDetail;
	}
	public void setErrorMessageDetail(String errorMessageDetail)
	{
		this.errorMessageDetail = errorMessageDetail;
	}
	public String getErrorContext()
	{
		return errorContext;
	}
	public void setErrorContext(String errorContext)
	{
		this.errorContext = errorContext;
	}
	public List<String> getErrorMessages()
	{
		return errorMessages;
	}
	public void setErrorMessages(List<String> errorMessages)
	{
		this.errorMessages = errorMessages;
	}
	public Throwable getRootCause()
	{
		return rootCause;
	}
	public void setRootCause(Throwable rootCause)
	{
		this.rootCause = rootCause;
	}

	
}

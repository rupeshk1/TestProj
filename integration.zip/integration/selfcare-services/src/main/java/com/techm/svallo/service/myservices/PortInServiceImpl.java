package com.techm.svallo.service.myservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.techm.portal.common.loggerwrapper.PortalLogger;
import com.techm.svallo.vo.billingandpayment.BillVo;
import com.techm.svallo.vo.myservices.PortInVo;
import com.techm.svallo.vo.myservices.PrePortInVo;
import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPortInDetails;
import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPortInDetailsResponse;
import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPrePortInRequestDetails;
import com.techmahindra.online.svallo.model.portin._2014._09._18.SvalloPrePortInResponseDetails;
import com.techmahindra.online.svallo.service.common.exception.portin.SvalloPortinIntegrationException;
import com.techmahindra.online.svallo.service.portin._2014._09._18.SvalloPortIn;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.techm.svallo.exception.service.portin.SvalloPortInServiceException;
import com.techm.svallo.util.SelfCareUtil;

public class PortInServiceImpl implements PortInService 
{
	final static PortalLogger logger = PortalLogger.getLogger(PortInServiceImpl.class);
	
	@Autowired
	private SvalloPortIn  svalloPortIn;
	
	@Autowired
	private JdbcTemplate jdbcTemplate=null;	
	
	public void setSvalloPortIn(SvalloPortIn svalloPortIn) {
		this.svalloPortIn = svalloPortIn;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	private static String IS_PORTIN_ALREADYDONE="select ported_date,mobile_number from portin where accountnumber=?;";

	private static String INSERT_PORTIN_DETAILS="insert into portin(accountnumber,portin_date,ported_date,mobile_number) "+
			"values(?,?,?,?);";
	
	private static String DELETE_PORTIN_REQUEST="delete from portin where accountnumber=?;";
	
	@Value("${portin.validation.error}")
	private String PORTIN_VALIDATION_ERROR;
	
	@Value("${preportin.system.error}")
	private String PREPORTIN_SYSTEM_ERROR;
	
	@Value("${data.not.available}")
	private String DATA_NOT_AVAILABLE;
	
	
	@Value("${portin.impl.getPortInDetails.error.code}")
	private String PORTIN_IMPL_GETPORTINDETAILS_ERROR_CODE;
	
	@Value("${portin.impl.getPortInDetails.error.message}")
	private String PORTIN_IMPL_GETPORTINDETAILS_ERROR_MESSAGE;
	
	@Value("${portin.impl.getPortInDetails.exception.code}")
	private String PORTIN_IMPL_GETPORTINDETAILS_EXCEPTION_CODE;
	
	@Value("${portin.impl.getPortInDetails.exception.message}")
	private String PORTIN_IMPL_GETPORTINDETAILS_EXCEPTION_MESSAGE;
	
	
	@Value("${portin.impl.getPrePortInDetails.error.code}")
	private String PORTIN_IMPL_GETPREPORTINDETAILS_ERROR_CODE;
	
	@Value("${portin.impl.getPrePortInDetails.error.message}")
	private String PORTIN_IMPL_GETPREPORTINDETAILS_ERROR_MESSAGE;
	
	@Value("${portin.impl.getPrePortInDetails.exception.code}")
	private String PORTIN_IMPL_GETPREPORTINDETAILS_EXCEPTION_CODE;
	
	@Value("${portin.impl.getPrePortInDetails.exception.message}")
	private String PORTIN_IMPL_GETPREPORTINDETAILS_EXCEPTION_MESSAGE;
	
	
	
	@Override
	public PortInVo getPortInDetails(PortInVo portInVo) {
		PortInVo portInServiceVo = new PortInVo();
		try {		
			
			SvalloPortInDetails svalloPortInDetails = new SvalloPortInDetails();
			svalloPortInDetails.setSubscriptionNumber(portInVo.getSubScriptionNumber());
			svalloPortInDetails.setPacCode(portInVo.getPacCode());
			svalloPortInDetails.setPortDate(portInVo.getPortDate());
			svalloPortInDetails.setNumberToPort(portInVo.getNumberToPort());
			
			SvalloPortInDetailsResponse getPortInDetailsResponse = svalloPortIn.getPortInDetails(svalloPortInDetails);
			if(getPortInDetailsResponse != null){		
			   portInServiceVo.setPortInMessage(getPortInDetailsResponse.getMessage());
			}

		} catch (SvalloPortinIntegrationException spie) {
			// TODO Auto-generated catch block
			logger.error(spie,"\n[ PortInServiceImpl | getPortInDetails() ] SvalloPortInServiceException Catch Block ");
			logger.error(spie,"\n[ PortInServiceImpl | getPortInDetails() ] SvalloPortInServiceException Catch Block | Error Code ="+ PORTIN_IMPL_GETPORTINDETAILS_ERROR_CODE);
			logger.error(spie,"\n[ PortInServiceImpl | getPortInDetails() ] SvalloPortInServiceException Catch Block | Error Message ="+ PORTIN_IMPL_GETPORTINDETAILS_ERROR_MESSAGE);
			SvalloPortInServiceException svalloPortInServiceException = new SvalloPortInServiceException();
			svalloPortInServiceException.setErrorCode(PORTIN_IMPL_GETPORTINDETAILS_ERROR_CODE);
			svalloPortInServiceException.setErrorMessage(PORTIN_IMPL_GETPORTINDETAILS_ERROR_MESSAGE);
			svalloPortInServiceException.setRootCause(spie);
			//spie.printStackTrace();			
			portInServiceVo.setPortInMessage(PORTIN_VALIDATION_ERROR);
		}	catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e,"\n[ PortInServiceImpl | getPortInDetails() ] Exception Catch Block ");
			logger.error(e,"\n[ PortInServiceImpl | getPortInDetails() ] Exception Catch Block | Error Code ="+ PORTIN_IMPL_GETPORTINDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ PortInServiceImpl | getPortInDetails() ] Exception Catch Block | Error Message ="+ PORTIN_IMPL_GETPORTINDETAILS_EXCEPTION_MESSAGE);
			SvalloPortInServiceException svalloPortInServiceException = new SvalloPortInServiceException();
			svalloPortInServiceException.setErrorCode(PORTIN_IMPL_GETPORTINDETAILS_EXCEPTION_CODE);
			svalloPortInServiceException.setErrorMessage(PORTIN_IMPL_GETPORTINDETAILS_EXCEPTION_MESSAGE);
			svalloPortInServiceException.setRootCause(e);
			//e.printStackTrace();			
			portInServiceVo.setPortInMessage(PORTIN_VALIDATION_ERROR);
		}		
		return portInServiceVo;
	}

	@Override
	public PrePortInVo getPrePortInDetails(PrePortInVo prePortInVo) {
		PrePortInVo prePortInServiceVo = new PrePortInVo();
		try{
			SvalloPrePortInRequestDetails svalloPrePortInRequestDetails = new SvalloPrePortInRequestDetails();
			svalloPrePortInRequestDetails.setCustomerLevelReference(prePortInVo.getCustomerLevelReference());
			svalloPrePortInRequestDetails.setEventTypeCode(prePortInVo.getEventTypeCode());
			svalloPrePortInRequestDetails.setEventCode(prePortInVo.getEventCode());
			
			SvalloPrePortInResponseDetails getPrePortInResponseDetails = svalloPortIn.getPrePortInDetails(svalloPrePortInRequestDetails);
			if(getPrePortInResponseDetails != null){	
			  prePortInServiceVo.setEventStatus(getPrePortInResponseDetails.getEventStatus());
			  prePortInServiceVo.setCreatedDate(SelfCareUtil.getFormatedDateWithoutTime(getPrePortInResponseDetails.getCreatedDate()));
			}
		}catch (SvalloPortinIntegrationException spie) {
			// TODO Auto-generated catch block
			logger.error(spie,"\n[ PortInServiceImpl | getPrePortInDetails() ] SvalloPortInServiceException Catch Block ");
			logger.error(spie,"\n[ PortInServiceImpl | getPrePortInDetails() ] SvalloPortInServiceException Catch Block | Error Code ="+ PORTIN_IMPL_GETPREPORTINDETAILS_ERROR_CODE);
			logger.error(spie,"\n[ PortInServiceImpl | getPrePortInDetails() ] SvalloPortInServiceException Catch Block | Error Message ="+ PORTIN_IMPL_GETPREPORTINDETAILS_ERROR_MESSAGE);
			SvalloPortInServiceException svalloPortInServiceException = new SvalloPortInServiceException();
			svalloPortInServiceException.setErrorCode(PORTIN_IMPL_GETPREPORTINDETAILS_ERROR_CODE);
			svalloPortInServiceException.setErrorMessage(PORTIN_IMPL_GETPORTINDETAILS_ERROR_MESSAGE);
			svalloPortInServiceException.setRootCause(spie);
			//spie.printStackTrace();
			prePortInServiceVo.setEventStatus(DATA_NOT_AVAILABLE);
			prePortInServiceVo.setCreatedDate(DATA_NOT_AVAILABLE);
			prePortInServiceVo.setPrePortInError(PREPORTIN_SYSTEM_ERROR);		
		}	catch (Exception e) {
			// TODO Auto-generated catch block			
			logger.error(e,"\n[ PortInServiceImpl | getPrePortInDetails() ] Exception Catch Block");
			logger.error(e,"\n[ PortInServiceImpl | getPrePortInDetails() ] Exception Catch Block | Error Code ="+ PORTIN_IMPL_GETPREPORTINDETAILS_EXCEPTION_CODE);
			logger.error(e,"\n[ PortInServiceImpl | getPrePortInDetails() ] Exception Catch Block | Error Message ="+ PORTIN_IMPL_GETPREPORTINDETAILS_EXCEPTION_MESSAGE);
			SvalloPortInServiceException svalloPortInServiceException = new SvalloPortInServiceException();
			svalloPortInServiceException.setErrorCode(PORTIN_IMPL_GETPREPORTINDETAILS_EXCEPTION_CODE);
			svalloPortInServiceException.setErrorMessage(PORTIN_IMPL_GETPORTINDETAILS_EXCEPTION_MESSAGE);
			svalloPortInServiceException.setRootCause(e);
			//e.printStackTrace();
			prePortInServiceVo.setEventStatus(DATA_NOT_AVAILABLE);
			prePortInServiceVo.setCreatedDate(DATA_NOT_AVAILABLE);
			prePortInServiceVo.setPrePortInError(PREPORTIN_SYSTEM_ERROR);		
		}	
		return prePortInServiceVo;
	}

	@Override
	public PrePortInVo getIsPortInAlreadyDoneDetails(String accountNumber) {
		PrePortInVo prePortInResponse = new PrePortInVo();		
		//logger.debug("IS_PORTIN_ALREADYDONE : "+ IS_PORTIN_ALREADYDONE ); 
		try{				
		prePortInResponse = jdbcTemplate.queryForObject(IS_PORTIN_ALREADYDONE,  new ManageGetIsPortInAlreadyDoneMapper(), accountNumber);
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");
		}		
		finally{
			return prePortInResponse;
		}		
	}

	@Override
	public void insertPortInDetails(PortInVo portInVo) {
		// TODO Auto-generated method stub
		try{
			jdbcTemplate.update(INSERT_PORTIN_DETAILS,portInVo.getAccountNumber(),portInVo.getPortDate(),portInVo.getPortedDate(),portInVo.getNumberToPort());			
		} catch(ArrayIndexOutOfBoundsException ae){
			logger.error(ae,"Array Index out of bound exception");
		}	
	}

	
	private static final class ManageGetIsPortInAlreadyDoneMapper implements RowMapper<PrePortInVo> {

	    public PrePortInVo mapRow(ResultSet rs, int rowNum) throws SQLException {
	    
	    	PrePortInVo prePortInVo = new PrePortInVo();
	    	prePortInVo.setCreatedDate(SelfCareUtil.getFormatedDateForDisplay(rs.getString("ported_date")));
	    	prePortInVo.setPortInNumber(rs.getString("mobile_number"));
	    	
	        return prePortInVo;	    
	    }
	}


	@Override
	public void deletePortInDetails(String accountNumber) {
		// TODO Auto-generated method stub		
		try{
			jdbcTemplate.update(DELETE_PORTIN_REQUEST,accountNumber);			
		} catch(Exception e){
			logger.error(e,"Exception in DELETE_PORTIN_REQUEST");
		}	
	}	

}


package test.java;
import java.io.File;
import junit.framework.TestCase;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class BoltonServiceImplWorkingTest extends TestCase {	
	
	Source xsl = new StreamSource(new File("src/test/resources/xsl/QuerySubscriptionSvalloTest.xsl"));
	Source xsl1 = new StreamSource(new File("src/main/resources/META-INF/xsl/GetAddonMDS-GetAddonStd.xsl"));
	Transformer transformer;
	Transformer transformer1;
	
	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	
	
	public void testGetAddonRecurring(){
		
		// System.out.println("-------------------- Start of junit test case for bolt-ons -----------------------------");
		 
		try {
			
			Source xmlInput = new StreamSource(new File("src/test/resources/input_xml/searchForPriceListResponseCMP.xml"));         
            Result xmlOutput  = new StreamResult(new File("src/test/resources/output_xml/searchForPriceListResponseCMP_out.xml"));    
            
            Source xmlInput1 = new StreamSource(new File("src/test/resources/input_xml/QuerySubscriptionResponse_CMP.xml"));   
            Result xmlOutput1  = new StreamResult(new File("src/test/resources/output_xml/activeAndPending_out.xml"));     
            transformer = TransformerFactory.newInstance().newTransformer(xsl);
            
         transformer.transform(xmlInput1, xmlOutput1);
         
         String filepath = "src/test/resources/output_xml/activeAndPending_out.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
         
            
	         String existingActivatedList = doc.getElementsByTagName("existingActivatedServices").item(0).getTextContent();
	         String existingPendingList = doc.getElementsByTagName("existingPendingServices").item(0).getTextContent();
	         String effectiveDateServiceCodeList = doc.getElementsByTagName("serviceCodeList").item(0).getTextContent();
	         effectiveDateServiceCodeList = effectiveDateServiceCodeList+"##";
	         
	         System.out.println("existingActivatedList:" +existingActivatedList);
	         System.out.println("existingPendingList:" +existingPendingList);
	         System.out.println("effectiveDateServiceCodeList:" +effectiveDateServiceCodeList);
	         
	         
	         transformer1 = TransformerFactory.newInstance().newTransformer(xsl1);
	         transformer1.setParameter("existingActivatedServices", existingActivatedList);
	         transformer1.setParameter("existingPendingServices", existingPendingList);
	         transformer1.setParameter("effectiveDateServiceCodeList", effectiveDateServiceCodeList);
	         
	         transformer1.transform(xmlInput, xmlOutput);

         	String filepath1 = "src/test/resources/output_xml/searchForPriceListResponseCMP_out.xml";
			DocumentBuilderFactory docFactory1 = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder1 = docFactory1.newDocumentBuilder();
			Document doc1 = docBuilder1.parse(filepath1);
		    doc1.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
		    System.out.println("\n------------------ fetching applicable addon ----------------------\n");
			NodeList applicableAddonlist = doc1.getElementsByTagName("applicableAddon");		
			
			//System.out.println("Total of elements : " + applicableAddonlist.getLength());	
			//do this the old way, because nodeList is not iterable			
			for (int itr = 0; itr < applicableAddonlist.getLength(); itr++) {
				Node node = applicableAddonlist.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());
				NodeList list1 = node.getChildNodes();				
				//System.out.println("Total of month elements : " + list1.getLength());
				
				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
					String productName="";
					String productId="";
					String productDescription="";
					String productPrice="";
					String recurring="";
					Node node1 = list1.item(itr1);
					//System.out.println("\nNode Name1 :" + node1.getNodeName());
				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) node1;		
					//System.out.println("\neElement :" +eElement);
					productName=eElement.getElementsByTagName("productName").item(0).getTextContent().replaceAll("\\s+", " ");
					productId=eElement.getElementsByTagName("productId").item(0).getTextContent().replaceAll("\\s+", " ");
					productDescription=eElement.getElementsByTagName("productDescription").item(0).getTextContent().replaceAll("\\s+", " ");
					productPrice=eElement.getElementsByTagName("productPrice").item(0).getTextContent().replaceAll("\\s+", " ");
					recurring=eElement.getElementsByTagName("recurring").item(0).getTextContent().replaceAll("\\s+", " ");
					if(productId.equalsIgnoreCase("S500BO"))
					{
						assertEquals("reccurring value for productId = S500BO ","false", recurring);
					}
					if(productId.equalsIgnoreCase("S50MMS")){
						assertEquals("reccurring value for productId = S50MMS ","true", recurring);
					}
					System.out.println("productId = "+productId+" ,productName is "+productName+", productDescription is "+productName+", productPrice is "+productName+", recurring is "+recurring);
				}
				
			
	          }
			}			
			
			 System.out.println("\n------------------ completed fetching applicable addon ------------------------");
			 System.out.println("\n-------------------- fetching existing addon ----------------------\n");
				NodeList existingAddonlist = doc1.getElementsByTagName("existingAddon");		
				
				//System.out.println("Total of elements : " + existingAddonlist.getLength());	
				for (int itr = 0; itr < existingAddonlist.getLength(); itr++) {
					Node node = existingAddonlist.item(itr);
					//System.out.println("\nNode Name :" + node.getNodeName());
					NodeList list1 = node.getChildNodes();				
					//System.out.println("Total of month elements : " + list1.getLength());
					
					for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
						String productName="";
						String productId="";
						String productDescription="";
						String productPrice="";
						String recurring="";
						Node node1 = list1.item(itr1);
						//System.out.println("\nNode Name1 :" + node1.getNodeName());
					if (node1.getNodeType() == Node.ELEMENT_NODE) {					
						Element eElement = (Element) node1;		
						//System.out.println("\neElement :" +eElement);
						productName=eElement.getElementsByTagName("productName").item(0).getTextContent().replaceAll("\\s+", " ");
						productId=eElement.getElementsByTagName("productId").item(0).getTextContent().replaceAll("\\s+", " ");
						productDescription=eElement.getElementsByTagName("productDescription").item(0).getTextContent().replaceAll("\\s+", " ");
						productPrice=eElement.getElementsByTagName("productPrice").item(0).getTextContent().replaceAll("\\s+", " ");
						recurring=eElement.getElementsByTagName("recurring").item(0).getTextContent().replaceAll("\\s+", " ");
						
						if(productId.equalsIgnoreCase("S1GBO"))
						{
							assertEquals("reccurring value for productId = S1GBO ","false", recurring);
						}
						if(productId.equalsIgnoreCase("S250MN")){
							assertEquals("reccurring value for productId = S250MN ","true", recurring);
						}
						System.out.println("productId = "+productId+" ,productName is "+productName+", productDescription is "+productName+", productPrice is "+productName+", recurring is "+recurring);
				
		          }
				}	
				
				}
				
				 System.out.println("\n------------------ completed fetching existing addon ------------------------");
				 System.out.println("\n------------------ fetching pending addon ------------------------\n");
					NodeList pendingAddonlist = doc1.getElementsByTagName("pendingAddon");		
					
					//System.out.println("Total of elements : " + pendingAddonlist.getLength());	
					//do this the old way, because nodeList is not iterable			
					for (int itr = 0; itr < pendingAddonlist.getLength(); itr++) {
						Node node = pendingAddonlist.item(itr);
						//System.out.println("\nNode Name :" + node.getNodeName());
						NodeList list1 = node.getChildNodes();				
						//System.out.println("Total of month elements : " + list1.getLength());
						
						for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
							String productName="";
							String productId="";
							String productDescription="";
							String productPrice="";
							String recurring="";
							Node node1 = list1.item(itr1);
							//System.out.println("\nNode Name1 :" + node1.getNodeName());
						if (node1.getNodeType() == Node.ELEMENT_NODE) {					
							Element eElement = (Element) node1;		
							//System.out.println("\neElement :" +eElement);
							productName=eElement.getElementsByTagName("productName").item(0).getTextContent().replaceAll("\\s+", " ");
							productId=eElement.getElementsByTagName("productId").item(0).getTextContent().replaceAll("\\s+", " ");
							productDescription=eElement.getElementsByTagName("productDescription").item(0).getTextContent().replaceAll("\\s+", " ");
							productPrice=eElement.getElementsByTagName("productPrice").item(0).getTextContent().replaceAll("\\s+", " ");
							//recurring=eElement.getElementsByTagName("recurring").item(0).getTextContent().replaceAll("\\s+", " ");
							
							System.out.println("productId = "+productId+" ,productName is "+productName+", productDescription is "+productName+", productPrice is "+productName+", recurring is "+recurring);
						
						}
						
					
			          }
					}	
			
					 System.out.println("\n------------------ completed fetching pending addon ------------------------");
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		// System.out.println("--------------------------- End of junit test case for bolt-ons --------------------------------");
	} 
	
}

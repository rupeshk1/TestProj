package test.java;
import java.io.File;
import junit.framework.TestCase;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class BoltonServiceImplUpdateAddonTest extends TestCase {	
	

	Source xsl = new StreamSource(new File("src/main/resources/META-INF/xsl/AddAddonStd-AddAddonMATRIX.xsl"));
	Transformer transformer;
	Transformer transformer1;
	
	/**
	 *  this method is used for to create the instance of classes.
	 */
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * this method is used for nullify the object instance.
	 */
	public void tearDown() throws Exception {
	   super.tearDown();
	}
	
	
	
	public void testUpdateAddonMds(){
		
		 //System.out.println("---------------------- Start of junit test case for updating bolt-ons ----------------------------------");
		 
		try {
		
			 String boltonTypeName;
			 String networkCodeName;
			
         String filepath = "src/test/resources/input_xml/UpdateAddonAddRequestMds.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);
         doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
         
            String operation = doc.getElementsByTagName("operation").item(0).getTextContent();
            String serviceCode = doc.getElementsByTagName("serviceCode").item(0).getTextContent();
            String servicePrice = doc.getElementsByTagName("servicePrice").item(0).getTextContent();
            String effectiveDate = doc.getElementsByTagName("effectiveDate").item(0).getTextContent();
            String description = doc.getElementsByTagName("description").item(0).getTextContent();
            
         // System.out.println("operation is "+operation+", serviceCode is "+serviceCode+", servicePrice is "+servicePrice+", effectiveDate is "+effectiveDate+", description is "+description);
            if (description.equalsIgnoreCase("recurring")){
            	  boltonTypeName = "recurring";
            	  networkCodeName = "";
            }else{
            	 boltonTypeName = "";
            	 String filepath1 = "src/test/resources/output_xml/MDSQuerySubscriptionResponseMdsOut.xml";
                 DocumentBuilderFactory docFactory1 = DocumentBuilderFactory.newInstance();
                 DocumentBuilder docBuilder1 = docFactory1.newDocumentBuilder();
                 Document doc1 = docBuilder1.parse(filepath1);
              doc1.getDocumentElement().normalize();
                 System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
              
                 String networkCode = doc1.getElementsByTagName("NetworkCode").item(0).getTextContent();
                 
                 if(networkCode.equalsIgnoreCase("MATRIX")){
                	 
                	 networkCodeName = "oneoff";
                 }else{
                	 
                	 networkCodeName = "recurring";
                 }
            }
            
            if(boltonTypeName.equalsIgnoreCase("recurring") || networkCodeName.equalsIgnoreCase("recurring")){
            	
            	System.out.println("-------------- call create service -------------------");
            	
            }
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		// System.out.println("---------------------- End of junit test case for updating bolt-ons ----------------------------------");
	} 
	
	public void testUpdateAddonMatrix(){
		
		 //System.out.println("---------------------- Start of junit test case for updating bolt-ons ----------------------------------");
		 
		try {
		
			 String boltonTypeName;
			 String networkCodeName;
			
        String filepath = "src/test/resources/input_xml/UpdateAddonAddRequestMatrix.xml";
           DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
           DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
           Document doc = docBuilder.parse(filepath);
        doc.getDocumentElement().normalize();
           System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
        
           String operation = doc.getElementsByTagName("operation").item(0).getTextContent();
           String serviceCode = doc.getElementsByTagName("serviceCode").item(0).getTextContent();
           String servicePrice = doc.getElementsByTagName("servicePrice").item(0).getTextContent();
           String effectiveDate = doc.getElementsByTagName("effectiveDate").item(0).getTextContent();
           String description = doc.getElementsByTagName("description").item(0).getTextContent();
           
        // System.out.println("operation is "+operation+", serviceCode is "+serviceCode+", servicePrice is "+servicePrice+", effectiveDate is "+effectiveDate+", description is "+description);
           if (description.equalsIgnoreCase("recurring")){
           	  boltonTypeName = "recurring";
           	  networkCodeName = "";
           }else{
           	 boltonTypeName = "";
           	 String filepath1 = "src/test/resources/output_xml/MDSQuerySubscriptionResponseMatrixOut.xml";
                DocumentBuilderFactory docFactory1 = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder1 = docFactory1.newDocumentBuilder();
                Document doc1 = docBuilder1.parse(filepath1);
             doc1.getDocumentElement().normalize();
                System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
             
                String networkCode = doc1.getElementsByTagName("NetworkCode").item(0).getTextContent();
                
                if(networkCode.equalsIgnoreCase("MATRIX")){
               	 
               	 networkCodeName = "oneoff";
                }else{
               	 
               	 networkCodeName = "recurring";
                }
           }
           
           if(!(boltonTypeName.equalsIgnoreCase("recurring") || networkCodeName.equalsIgnoreCase("recurring"))){
           	
           	System.out.println("--------------- call basket service ------------------------");
           	
           	transformer1 = TransformerFactory.newInstance().newTransformer(xsl);
           	transformer1.setParameter("externalReference", "Selfcare");
           	transformer1.setParameter("customerLevelReference", "401");
           	transformer1.setParameter("serviceCode", serviceCode);
           	transformer1.setParameter("servicePrice",servicePrice);
           	Source xmlInput1 = new StreamSource(new File("src/test/resources/input_xml/SampleRequest.xml")); 	
           	Result xmlOutput1  = new StreamResult(new File("src/test/resources/output_xml/AddAddonSvalloRequest.xml"));     
            
                
           	transformer1.transform(xmlInput1, xmlOutput1);
           	
           	String filepath1 = "src/test/resources/output_xml/AddAddonSvalloRequest.xml";
   			DocumentBuilderFactory docFactory1 = DocumentBuilderFactory.newInstance();
   			DocumentBuilder docBuilder1 = docFactory1.newDocumentBuilder();
   			Document doc1 = docBuilder1.parse(filepath1);
   		    doc1.getDocumentElement().normalize();
   			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
   			
   		  //  System.out.println("-------------fetching PurchaseOffers ----------------------");
   			NodeList PurchaseOfferslist = doc1.getElementsByTagName("PurchaseOffers");		
   			
   			//System.out.println("Total of elements : " + PurchaseOfferslist.getLength());	
   			for (int itr = 0; itr < PurchaseOfferslist.getLength(); itr++) {
   				Node node = PurchaseOfferslist.item(itr);
   				System.out.println("\nNode Name :" + node.getNodeName());
   				NodeList list1 = node.getChildNodes();				
   				//System.out.println("Total of month elements : " + list1.getLength());
   				
   				for (int itr1 = 0; itr1 < list1.getLength(); itr1++) {
   					String reloadOption="";
   					Node node1 = list1.item(itr1);
   					System.out.println("\nNode Name1 :" + node1.getNodeName());
   				if (node1.getNodeType() == Node.ELEMENT_NODE) {					
   					Element eElement = (Element) node1;		
   					System.out.println("\neElement :" +eElement);
   					reloadOption=eElement.getElementsByTagName("ReloadOption").item(0).getTextContent().replaceAll("\\s+", " ");
   					
   					assertEquals("reload option for service code STE003 is","RTE003", reloadOption);
   				}
   			}			
   		 }
           }
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		// System.out.println("---------------------- End of junit test case for updating bolt-ons ----------------------------------");
	} 
	
}

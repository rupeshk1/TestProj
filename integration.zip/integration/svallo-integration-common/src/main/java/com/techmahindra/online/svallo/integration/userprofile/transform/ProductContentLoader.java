package com.techmahindra.online.svallo.integration.userprofile.transform;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.properties.PropertiesComponent;
import org.apache.camel.component.xmlrpc.XmlRpcConstants;
import org.apache.camel.impl.DefaultCamelContext;

public class ProductContentLoader {
	 public static void main() throws Exception {
 	  	final CamelContext context = new DefaultCamelContext();
 	  	final String ofbiz_userid= "admin";
        final String ofbiz_pwd= "ofbiz";
 	  	final Map paramMap = new HashMap<String, String>();
 	  	String configFilePath = "E:/Siebel/camelPropertyFile/camel.properties";
 	  	Properties properties = new Properties();
 	  	FileInputStream  fis = new FileInputStream(configFilePath);
 	  	properties.load(fis);
 	  	final String fromFile = properties.getProperty("camel.xmlrpcurl");
        final ProducerTemplate template = context.createProducerTemplate();
        context.addRoutes(new RouteBuilder() {
         public void configure()throws Exception{           	
               from("file://E:/siebel/contentInput")
                .split(xpath("//List/ProductContent"))
                                .setHeader("productId", xpath("//ProductContent/productId/text()").stringResult())
                                .setHeader("mediumImageUrl", xpath("//ProductContent/mediumImageUrl/text()").stringResult())
                                .setHeader("largeImageUrl", xpath("//ProductContent/largeImageUrl/text()").stringResult())
                                .setHeader("xtraImgUrl", xpath("//ProductContent/xtraImgUrl/text()").stringResult())
                               .process(new Processor() {
                                      public void process(Exchange exchange) {
                                                  //update product
                                                  System.out.println("update Product");  
                                                        paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                                                        paramMap.put("mediumImageUrl", exchange.getIn().getHeader("mediumImageUrl", String.class));
                                                        paramMap.put("largeImageUrl", exchange.getIn().getHeader("largeImageUrl", String.class));
                                                        paramMap.put("xtraImgUrl", exchange.getIn().getHeader("xtraImgUrl", String.class));
                                                        paramMap.put("login.username", ofbiz_userid);
                                                        paramMap.put("login.password", ofbiz_pwd);
                                                        String response = template.requestBodyAndHeader(
                                                        		fromFile,
                                                              new Object[] {paramMap},
                                                                    XmlRpcConstants.METHOD_NAME, "updateProduct", String.class);
                                                        System.out.println("Updated Product for      "+paramMap+"**********************");
                                                        paramMap.clear();
                                                        exchange.setProperty("productId",exchange.getIn().getHeader("productId", String.class));
                                                  	}
                                                                 
										}
									)
									.split(xpath("//ProductContent/DataResources/DataResource"))
                                         .setHeader("dataResourceId", xpath("//DataResource/dataResourceId/text()").stringResult())
                                         .setHeader("dataResourceName", xpath("//DataResource/dataResourceName/text()").stringResult())
                                         .setHeader("dataResourceTypeId", xpath("//DataResource/dataResourceTypeId/text()").stringResult())
                                         .setHeader("objectInfo", xpath("//DataResource/objectInfo/text()").stringResult())
                                         .setHeader("statusId", xpath("//DataResource/statusId/text()").stringResult())
                                         .setHeader("mimeTypeId", xpath("//DataResource/mimeTypeId/text()").stringResult())
                                         .setHeader("textData", xpath("//DataResource/textData/text()").stringResult())
                                            .process(new Processor() {
                                                     public void process(Exchange exchange) throws Exception {	
                                                                    //create Data resource
                                                                    System.out.println("creating DataResource");
                                                                    paramMap.put("dataResourceId", exchange.getIn().getHeader("dataResourceId", String.class));
                                                                    paramMap.put("dataResourceName", exchange.getIn().getHeader("dataResourceName", String.class));
                                                                    paramMap.put("objectInfo", exchange.getIn().getHeader("objectInfo", String.class));
                                                                    paramMap.put("dataResourceTypeId", exchange.getIn().getHeader("dataResourceTypeId", String.class));
                                                                    paramMap.put("dataTemplateTypeId", "NONE");
                                                                    paramMap.put("statusId", exchange.getIn().getHeader("statusId", String.class));
                                                                    paramMap.put("mimeTypeId", exchange.getIn().getHeader("mimeTypeId", String.class));
                                                                    paramMap.put("isPublic", "Y");
                                                                    paramMap.put("login.username", ofbiz_userid);
                                                                    paramMap.put("login.password", ofbiz_pwd);
                                                                    String res1 = template.requestBodyAndHeader(
                                                                                fromFile,
                                                                          new Object[] { paramMap },
                                                                                XmlRpcConstants.METHOD_NAME, "createDataResource", String.class);
                                                                    System.out.println("DataRESOURCE CREATED FOR for      "+paramMap+"**********************");
                                                                    paramMap.clear();
                                                                    
                                                                   if(exchange.getIn().getHeader("dataResourceTypeId", String.class).equalsIgnoreCase("ELECTRONIC_TEXT")){
                                                                    	paramMap.put("dataResourceId", exchange.getIn().getHeader("dataResourceId", String.class));
                                                                        paramMap.put("textData", exchange.getIn().getHeader("textData", String.class));
                                                                        paramMap.put("login.username", ofbiz_userid);
                                                                        paramMap.put("login.password", ofbiz_pwd);
                                                                    	String res2 = template.requestBodyAndHeader(
                                                                                fromFile,
                                                                          new Object[] { paramMap },
                                                                                XmlRpcConstants.METHOD_NAME, "createElectronicText", String.class);
                                                                        System.out.println("Content created for     "+paramMap+"$$$$$$$$$$$$$$$$$$$$$$$$$");
                                                                    	paramMap.clear();
                                                                    }
                                                                    else{
                                                                    	System.out.println("No text content");
                                                                    }
                                                                    exchange.setProperty("dataResourceId",exchange.getIn().getHeader("dataResourceId", String.class));
															}
													}
												)
												.split(xpath("//DataResource/Content"))
                                               .setHeader("contentId", xpath("//Content/contentId/text()").stringResult())
                                               .setHeader("contentTypeId", xpath("//Content/contentTypeId/text()").stringResult())
                                               .setHeader("ownerContentId", xpath("//Content/ownerContentId/text()").stringResult())
                                               .setHeader("statusId", xpath("//Content/statusId/text()").stringResult())
                                               .setHeader("privilegeEnumId", xpath("//Content/privilegeEnumId/text()").stringResult())
                                               .setHeader("contentName", xpath("//Content/contentName/text()").stringResult())
                                               .setHeader("contentIdTo", xpath("//Content/contentIdTo/text()").stringResult())
                                               .setHeader("contentAssocTypeId", xpath("//Content/contentAssocTypeId/text()").stringResult())
                                               .setHeader("fromDate", constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                               .process(new Processor() {
                                                     public void process(Exchange exchange) throws Exception {
                                                    	 System.out.println("creating Content");
                                                         paramMap.put("contentId", exchange.getIn().getHeader("contentId", String.class));
                                                         paramMap.put("contentTypeId", exchange.getIn().getHeader("contentTypeId", String.class));
                                                         paramMap.put("ownerContentId", exchange.getIn().getHeader("ownerContentId", String.class));
                                                         paramMap.put("contentName", exchange.getIn().getHeader("contentName", String.class));
                                                         paramMap.put("dataResourceId", exchange.getProperty("dataResourceId",String.class));
                                                         paramMap.put("statusId", exchange.getIn().getHeader("statusId", String.class));
                                                         paramMap.put("privilegeEnumId", exchange.getIn().getHeader("privilegeEnumId", String.class));
                                                         paramMap.put("login.username", ofbiz_userid);
                                                         paramMap.put("login.password", ofbiz_pwd);
                                                         String res2 = template.requestBodyAndHeader(
                                                                     fromFile,
                                                               new Object[] { paramMap },
                                                                     XmlRpcConstants.METHOD_NAME, "createContent", String.class);
                                                         System.out.println("Content created for   "+paramMap+"**********************");
                                                         paramMap.clear();
                                                         exchange.setProperty("contentId",exchange.getIn().getHeader("contentId", String.class));
                                                         
                                                         if(exchange.getIn().getHeader("contentAssocTypeId", String.class).contains("PUBLISH_LINK"))
                                                         {	 paramMap.put("contentId", exchange.getIn().getHeader("contentId", String.class));
                                                         paramMap.put("contentIdTo", exchange.getIn().getHeader("contentIdTo", String.class));
                                                         paramMap.put("contentAssocTypeId", exchange.getIn().getHeader("contentAssocTypeId", String.class));
                                                         paramMap.put("privilegeEnumId", exchange.getIn().getHeader("privilegeEnumId", String.class));
                                                         paramMap.put("fromDate", exchange.getIn().getHeader("fromDate", String.class));
                                                         paramMap.put("login.username", ofbiz_userid);
                                                         paramMap.put("login.password", ofbiz_pwd);
                                                         
                                                         String res3 = template.requestBodyAndHeader(fromFile,new Object[] { paramMap },XmlRpcConstants.METHOD_NAME, "createContentAssoc", String.class);
                                                         
                                                         System.out.println("ContentAssociation can be created for      "+paramMap+"**********************");
                                                         paramMap.clear();
                                                        	 
                                                         }
                                                         
                                                         else
                                                         {
                                                        	 
                                                        	 System.out.println("Content Association not required");
                                                         }
                                                         
														}
                                                     }
												)
                                                    
											.split(xpath("//Content/ContentType"))
                                             .setHeader("productContentTypeId", xpath("//ContentType/productContentTypeId/text()").stringResult())
                                              .setHeader("fromDate", constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                                .process(new Processor() {
                                                        public void process(Exchange exchange) throws Exception {
                                                          	 System.out.println("creating Product Content");
                                                               paramMap.put("productId", exchange.getProperty("productId",String.class));
                                                               paramMap.put("contentId", exchange.getProperty("contentId",String.class));
                                                               paramMap.put("productContentTypeId", exchange.getIn().getHeader("productContentTypeId", String.class));
                                                               paramMap.put("fromDate", exchange.getIn().getHeader("fromDate", String.class));
                                                               paramMap.put("login.username", ofbiz_userid);
                                                               paramMap.put("login.password", ofbiz_pwd);
                                                               String res3 = template.requestBodyAndHeader(
                                                                           fromFile,
                                                                     new Object[] { paramMap },
                                                                           XmlRpcConstants.METHOD_NAME, "createProductContent", String.class);
                                                               System.out.println("ContentType created for      "+paramMap+"**********************");
                                                               paramMap.clear();
															}

														}
													)
                                  
               .to("file:target/");
               
                                                  }
                                 });
                                 context.start();
         Thread.sleep(100000);
         context.stop();
                                
         }
         
}


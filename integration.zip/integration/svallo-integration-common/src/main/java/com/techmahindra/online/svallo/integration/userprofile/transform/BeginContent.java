package com.techmahindra.online.svallo.integration.userprofile.transform;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@Path("/contentmapper/")
public class BeginContent {
	@Context
	private UriInfo uriInfo;
	 
	public BeginContent() {
	}
	 
	@GET
	public Response getContent() {
 
		return Response.status(200).entity("contentMapper is called").build();
 
	}
	 }



package com.techmahindra.online.svallo.integration.userprofile.transform;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import com.techmahindra.online.svallo.integration.userprofile.transform.AuditService;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.xmlrpc.XmlRpcConstants;
import org.apache.camel.impl.DefaultCamelContext;

public class Mapper {
	public static void main() throws Exception {
        final CamelContext context = new DefaultCamelContext();
        final ProducerTemplate template = context.createProducerTemplate();
        final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        final String DB_URL = "jdbc:mysql://localhost/ofbizlatest";
        final String USER = "ofbiz";
        final String PASS = "ofbiz";
        final String TALEND_URL = "jdbc:mysql://localhost/Logging_Talend_Data2";
        final String TALEND_USER = "TalendJob";
        final String TALEND_PASS = "TalendJob";
        final String ofbiz_userid= "admin";
        final String ofbiz_pwd= "ofbiz";
        final Map paramMap = new HashMap<String, String>();
        String configFilePath = "E:/Siebel/camelPropertyFile/camel.properties";
 	  	Properties properties = new Properties();
 	  	FileInputStream  fis = new FileInputStream(configFilePath);
 	  	properties.load(fis);
 	  	final String fromFile = properties.getProperty("camel.xmlrpcurl");
	    final String thruDate = properties.getProperty("camel.thrudate");
		final String categoryId = properties.getProperty("camel.configcategoryid");
        //update job_history
        
        AuditService insertHistory=new AuditService();
        insertHistory.auditFile();
        
        //begin router
        context.addRoutes(new RouteBuilder() {
        public void configure()throws Exception{
        	from("file://E:/siebel/camelInput")
                    .split(xpath("//ListOfProducts/Product"))
                                .setHeader("productId", xpath("//Product/PartNumber/text()").stringResult())
                                .setHeader("productName", xpath("//Product/ProductName/text()").stringResult())
                                .setHeader("description", xpath("//Product/Description/text()").stringResult())
                                .setHeader("introductionDate",
                                            constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                .setHeader("releaseDate",
                                            constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                .setHeader("supportDiscontinuationDate",
                                            constant(new java.sql.Timestamp(System.currentTimeMillis() + (1000 * 60 * 60 * 24 * 365))))
                                .setHeader("priceOneOff", xpath("//Product/PriceOneOff/text()").stringResult())
                                .setHeader("priceRecurring", xpath("//Product/PriceRecurring/text()").stringResult())
                                .process(new Processor() {
                                      public void process(Exchange exchange) {
                                            //create or update configurable product                                                   
                                            try{
                                                  int count = 0;
                                                  Connection conn = null;
                                                  Statement stmt = null;
                                                  Class.forName(JDBC_DRIVER);
                                                  conn = DriverManager.getConnection(DB_URL, USER, PASS);
                                                  stmt = conn.createStatement();
                                                  String sql = "select COUNT(*) from product where product_Id='"+exchange.getIn().getHeader("productId", String.class)+"'";
                                                  ResultSet rs = stmt.executeQuery(sql);
                                                  
                                              //check if product exists
                                                  while (rs.next()) {
                                                        count = rs.getInt(1);
                                                  }
                                                  try{
                                                	  if(stmt!=null)
                                                              rs.close();
                                                              conn.close();
                                                        }catch(SQLException se){}
                                                        try{
                                                           if(conn!=null)
                                                               rs.close();
                                                              conn.close();
                                                        }catch(SQLException se){se.printStackTrace();}
                                                  if(count==0){
                                                     //create Product
                                                    System.out.println("create Product");
                                                              paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                                                              paramMap.put("productName", exchange.getIn().getHeader("productName", String.class));
                                                              paramMap.put("productTypeId", "AGGREGATED");
                                                              paramMap.put("description", exchange.getIn().getHeader("description", String.class));
                                                              paramMap.put("introductionDate", exchange.getIn().getHeader("introductionDate", String.class));
                                                              paramMap.put("releaseDate", exchange.getIn().getHeader("releaseDate", String.class));
                                                              paramMap.put("supportDiscontinuationDate", exchange.getIn().getHeader("supportDiscontinuationDate", String.class));
                                                              paramMap.put("login.username", ofbiz_userid);
                                                              paramMap.put("login.password", ofbiz_pwd);
                                                        
                                                              String response = template.requestBodyAndHeader(
                                                                          fromFile,
                                                                    new Object[] { paramMap },
                                                                          XmlRpcConstants.METHOD_NAME, "createProduct", String.class);
                                                              exchange.setProperty("pid",exchange.getIn().getHeader("productId", String.class));
                                                              
                                                              //update job_audit with status
                                                              Connection Tconn = null;
                                                              Statement Tstmt = null;
                                                              int his_id = 0;
                                                              try {
                                                      			Class.forName(JDBC_DRIVER);
                                                      			try {
                                                      				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                      				Tstmt = Tconn.createStatement();
                                                                    String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                    ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                      while (Trs.next()) {
                                                                    	  his_id = Trs.getInt("history_id");
                                                                      }
                                                                    String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','CREATING_PRAENT_PRODUCT','Ok')";
                                                                    int ins_res = Tstmt.executeUpdate(job_audit);
                                                                    } catch (SQLException e) {e.printStackTrace();}
                                                      		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                              
                                                              paramMap.clear();
                                                              
                                                             //create Product Price one-off
                                                              
                                                            String fromDate=exchange.getIn().getHeader("introductionDate", String.class);
                                  							paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                                  							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                                  							paramMap.put("productPricePurposeId", "PURCHASE");
                                  							paramMap.put("currencyUomId", "USD");
                                  							paramMap.put("productStoreGroupId", "_NA_");
                                  							paramMap.put("fromDate", fromDate);
                                  							paramMap.put("thruDate", thruDate);
                                  							paramMap.put("price", exchange.getIn().getHeader("priceOneOff", String.class));
                                  							paramMap.put("login.username", ofbiz_userid);
                                  							paramMap.put("login.password", ofbiz_pwd);
                                  							
                                  							String cpri_res = template.requestBodyAndHeader(
                                  									fromFile,
                                  								new Object[] { paramMap },
                                  									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                                  							
                                  							paramMap.clear();
                                  							
                                  							//create Product recurring price
                                  							paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                                  							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                                  							paramMap.put("productPricePurposeId", "RECURRING_CHARGE");
                                  							paramMap.put("currencyUomId", "USD");
                                  							paramMap.put("productStoreGroupId", "_NA_");
                                  							paramMap.put("fromDate", fromDate);
                                  							paramMap.put("thruDate", thruDate);
                                  							paramMap.put("price", exchange.getIn().getHeader("priceRecurring", String.class));
                                  							paramMap.put("login.username", ofbiz_userid);
                                  							paramMap.put("login.password", ofbiz_pwd);
                                  							
                                  							String rpri_res = template.requestBodyAndHeader(
                                  									fromFile,
                                  								new Object[] { paramMap },
                                  									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                                                              
                                  							paramMap.clear();
                                                              
                                                              //assign it to a category
                                                              paramMap.put("productId",exchange.getIn().getHeader("productId", String.class));
                                                              paramMap.put("productCategoryId",categoryId);
                                                              paramMap.put("login.username", ofbiz_userid);
                                                              paramMap.put("login.password", ofbiz_pwd);
                                                              String res = template.requestBodyAndHeader(
                                                                          fromFile,
                                                                          new Object[] { paramMap },
                                                                    XmlRpcConstants.METHOD_NAME, "addProductToCategory", String.class);
                                                              paramMap.clear();
                                                    }
                                                  else
                                                  {
                                                  //update product
                                                  System.out.println("do update Product");  
                                                        paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                                                        paramMap.put("productName", exchange.getIn().getHeader("productName", String.class));
                                                        paramMap.put("productTypeId", "AGGREGATED");
                                                        paramMap.put("description", exchange.getIn().getHeader("description", String.class));
                                                        paramMap.put("introductionDate", exchange.getIn().getHeader("introductionDate", String.class));
                                                        paramMap.put("releaseDate", exchange.getIn().getHeader("releaseDate", String.class));
                                                        paramMap.put("supportDiscontinuationDate", exchange.getIn().getHeader("supportDiscontinuationDate", String.class));
                                                        paramMap.put("login.username", ofbiz_userid);
                                                        paramMap.put("login.password", ofbiz_pwd);
                                                        
                                                       String response = template.requestBodyAndHeader(
                                                                    fromFile,
                                                              new Object[] { paramMap },
                                                                    XmlRpcConstants.METHOD_NAME, "updateProduct", String.class);
                                                        exchange.setProperty("pid",exchange.getIn().getHeader("productId", String.class));
                                                        paramMap.clear();
                                                        
                                                        //update job_audit with status
                                                        Connection Tconn = null;
                                                        Statement Tstmt = null;
                                                        int his_id = 0;
                                                        try {
                                                  			Class.forName(JDBC_DRIVER);
                                                  			try {
                                                  				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                  				Tstmt = Tconn.createStatement();
                                                                String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                  while (Trs.next()) {
                                                                	  his_id = Trs.getInt("history_id");
                                                                  }
                                                                String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','UPDATING_PAR_PRODUCT','Ok')";
                                                                int ins_res = Tstmt.executeUpdate(job_audit);
                                                                } catch (SQLException e) {e.printStackTrace();}
                                                  		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                        
                                                        String fromDate=exchange.getIn().getHeader("introductionDate", String.class);
                                                        
                                                        //create Product Price one-off
                                                        paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                              							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                              							paramMap.put("productPricePurposeId", "PURCHASE");
                              							paramMap.put("currencyUomId", "USD");
                              							paramMap.put("productStoreGroupId", "_NA_");
                              							paramMap.put("fromDate", fromDate);
                              							paramMap.put("thruDate", thruDate);
                              							paramMap.put("price", exchange.getIn().getHeader("priceOneOff", String.class));
                              							paramMap.put("login.username", ofbiz_userid);
                              							paramMap.put("login.password", ofbiz_pwd);
                              							
                              							String cpri_res = template.requestBodyAndHeader(
                              									fromFile,
                              								new Object[] { paramMap },
                              									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                              							paramMap.clear();
                              							
                              							//create Product recurring price
                              							paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                              							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                              							paramMap.put("productPricePurposeId", "RECURRING_CHARGE");
                              							paramMap.put("currencyUomId", "USD");
                              							paramMap.put("productStoreGroupId", "_NA_");
                              							paramMap.put("fromDate", fromDate);
                              							paramMap.put("thruDate", thruDate);
                              							paramMap.put("price", exchange.getIn().getHeader("priceRecurring", String.class));
                              							paramMap.put("login.username", ofbiz_userid);
                              							paramMap.put("login.password", ofbiz_pwd);
                              							
                              							String rpri_res = template.requestBodyAndHeader(
                              									fromFile,
                              								new Object[] { paramMap },
                              									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                              							paramMap.clear();
                                                  }
                                                                 
                                      }
                                            catch(Exception e){
                                                  e.printStackTrace();
                                            }
                                      }
                                })
                                            .split(xpath("//Product/ListOfRelationship/Relationship"))
                                                  .setHeader("configItemName", xpath("//Relationship/ItemName/text()").stringResult())
                                                        .process(new Processor() {
                                                              public void process(Exchange exchange) throws Exception {
                                                                    try{
                                                                    	  //check if item exists for the product
                                                                    	String id=null;
                                                                          Connection conn = null;
                                                                          Statement stmt = null;
                                                                          Class.forName("com.mysql.jdbc.Driver");
                                                                          conn = DriverManager.getConnection(DB_URL, USER, PASS);
                                                                          stmt = conn.createStatement();
                                                                          String sql = "select PCI.config_Item_Id from Product_Config_Item PCI, Product_Config PC where PCI.config_Item_Name='"+exchange.getIn().getHeader("configItemName", String.class)+"' AND PC.product_id='"+exchange.getProperty("pid",String.class)+"' AND PCI.config_Item_Id=PC.config_Item_Id";
                                                                          ResultSet rs = stmt.executeQuery(sql);
                                                                          while (rs.next()) {
                                                                                id=rs.getString("config_Item_Id");
                                                                           }
                                                                          try{
                                                                               if(stmt!=null)
                                                                                        rs.close();
                                                                                      conn.close();
                                                                                }catch(SQLException se){
                                                                                }
                                                                                try{
                                                                                   if(conn!=null)
                                                                                       rs.close();
                                                                                      conn.close();
                                                                                }catch(SQLException se){se.printStackTrace();}
                                                                    if(id==null)
                                                                    {
                                                                    //create items
                                                                    System.out.println("creating items");
                                                                    paramMap.put("configItemName", exchange.getIn().getHeader("configItemName", String.class));
                                                                    paramMap.put("description", exchange.getIn().getHeader("configItemName", String.class));
                                                                    paramMap.put("configItemTypeId", "MULTIPLE");
                                                                    paramMap.put("login.username", ofbiz_userid);
                                                                    paramMap.put("login.password", ofbiz_pwd);
                                                                    String res2 = template.requestBodyAndHeader(
                                                                                fromFile,
                                                                          new Object[] { paramMap },
                                                                                XmlRpcConstants.METHOD_NAME, "createProductConfigItem", String.class);
                                                                    String[] itemId = res2.split("=");
                                                                    itemId[1] = itemId[1].replace("}", "");
                                                                    exchange.setProperty("createItemId", itemId[1]);
                                                                    paramMap.clear();
                                                                    
                                                                    //update job_audit with status
                                                                    Connection Tconn = null;
                                                                    Statement Tstmt = null;
                                                                    int his_id = 0;
                                                                    try {
                                                              			Class.forName(JDBC_DRIVER);
                                                              			try {
                                                              				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                              				Tstmt = Tconn.createStatement();
                                                                            String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                            ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                              while (Trs.next()) {
                                                                            	  his_id = Trs.getInt("history_id");
                                                                              }
                                                                            String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','CREATING_ITEM','Ok')";
                                                                            int ins_res = Tstmt.executeUpdate(job_audit);
                                                                            } catch (SQLException e) {e.printStackTrace();}
                                                              		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                                          
                                                                    //assign items to config product
                                                                    paramMap.put("configItemId", itemId[1]);
                                                                    paramMap.put("productId", exchange.getProperty("pid",String.class));
                                                                    paramMap.put("configTypeId", "QUESTION");
                                                                    paramMap.put("sequenceNum", "10");
                                                                    paramMap.put("login.username", ofbiz_userid);
                                                                    paramMap.put("login.password", ofbiz_pwd);
                                                                    String res = template.requestBodyAndHeader(
                                                                                fromFile,
                                                                          new Object[] { paramMap },
                                                                                XmlRpcConstants.METHOD_NAME, "createProductConfig", String.class);
                                                                    paramMap.clear();
                                                                    }
                                                                    else
                                                                    {
                                                                    //update the item
                                                                    exchange.setProperty("createItemId",id);
                                                                    System.out.println("updating items");
                                                                    paramMap.put("configItemId", exchange.getProperty("createItemId",String.class));
                                                                    paramMap.put("configItemName", exchange.getIn().getHeader("configItemName", String.class));
                                                                    paramMap.put("description", exchange.getIn().getHeader("configItemName", String.class));
                                                                    paramMap.put("configItemTypeId", "MULTIPLE");
                                                                    paramMap.put("login.username", ofbiz_userid);
                                                                    paramMap.put("login.password", ofbiz_pwd);
                                                                    String res2 = template.requestBodyAndHeader(
                                                                                fromFile,
                                                                          new Object[] { paramMap },
                                                                                XmlRpcConstants.METHOD_NAME, "updateProductConfigItem", String.class);
                                                                    paramMap.clear();
                                                                    
                                                                    //update job_audit with status
                                                                    Connection Tconn = null;
                                                                    Statement Tstmt = null;
                                                                    int his_id = 0;
                                                                    try {
                                                              			Class.forName(JDBC_DRIVER);
                                                              			try {
                                                              				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                              				Tstmt = Tconn.createStatement();
                                                                            String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                            ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                              while (Trs.next()) {
                                                                            	  his_id = Trs.getInt("history_id");
                                                                              }
                                                                            String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','UPDATING_ITEM','Ok')";
                                                                            int ins_res = Tstmt.executeUpdate(job_audit);
                                                                            } catch (SQLException e) {e.printStackTrace();}
                                                              		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                                    }
                                                              }catch(Exception e){e.printStackTrace();}
                                                                    }
                                                        })
                                                                   .split(xpath("//Relationship/ListOfChildProduct/ChildProduct"))
                                                                                .setHeader("childProductId", xpath("//ChildProduct/ProductPartNumber/text()").stringResult())
                                                                                .setHeader("childProductName", xpath("//ChildProduct/ProductName/text()").stringResult())
                                                                                .setHeader("childOneOff", xpath("//ChildProduct/PriceOneOff/text()").stringResult())
                                                                                .setHeader("childRecurring", xpath("//ChildProduct/PriceRecurring/text()").stringResult())
                                                                                .setHeader("introductionDate",constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                                                    .process(new Processor() {
                                                                          public void process(Exchange exchange) throws Exception {
                                                                          try{
                                                                               	int count = 0;
                                                                                Connection conn = null;
                                                                                Statement stmt = null;
                                                                                String myId=exchange.getIn().getHeader("childProductId", String.class);
                                                                                //check if child products exist
                                                                                Class.forName(JDBC_DRIVER);
                                                                                conn = DriverManager.getConnection(DB_URL, USER, PASS);
                                                                                stmt = conn.createStatement();
                                                                                String sql = "select COUNT(*) from product where product_Id='"+myId+"'";
                                                                                ResultSet rs = stmt.executeQuery(sql);
                                                                                while (rs.next()) {
                                                                                      count = rs.getInt(1);
                                                                                      String s=Integer.toString(count);
                                                                                      System.out.println(s);
                                                                                }
                                                                                try{
                                                                                         if(stmt!=null)
                                                                                              rs.close();
                                                                                            conn.close();
                                                                                      }catch(SQLException se){
                                                                                      }
                                                                                      try{
                                                                                         if(conn!=null)
                                                                                               rs.close();
                                                                                            conn.close();
                                                                                      }catch(SQLException se){se.printStackTrace();}
                                                                                if(count==0){
                                                                                              //create child products
                                                                                                    System.out.println("create Option products");
                                                                                                        paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                                                        paramMap.put("productName",exchange.getIn().getHeader("childProductName", String.class));
                                                                                                        paramMap.put("internalName",exchange.getIn().getHeader("childProductName", String.class));
                                                                                                        paramMap.put("description",exchange.getIn().getHeader("childProductName", String.class));
                                                                                                        paramMap.put("productTypeId", "FINISHED_GOOD");
                                                                                                        paramMap.put("login.username", ofbiz_userid);
                                                                                                        paramMap.put("login.password", ofbiz_pwd);
                                                                                                        String res = template.requestBodyAndHeader(
                                                                                                                    fromFile,
                                                                                                              new Object[] { paramMap },
                                                                                                                    XmlRpcConstants.METHOD_NAME, "createProduct", String.class);
                                                                                                        System.out.println("created child products");
                                                                                                        paramMap.clear();
                                                                                                        
                                                                                                        //update job_audit with status
                                                                                                        Connection Tconn = null;
                                                                                                        Statement Tstmt = null;
                                                                                                        int his_id = 0;
                                                                                                        try {
                                                                                                  			Class.forName(JDBC_DRIVER);
                                                                                                  			try {
                                                                                                  				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                                                                  				Tstmt = Tconn.createStatement();
                                                                                                                String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                                                                ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                                                                  while (Trs.next()) {
                                                                                                                	  his_id = Trs.getInt("history_id");
                                                                                                                  }
                                                                                                                String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','CREATING CHILD PRODUCTS','Ok')";
                                                                                                                int ins_res = Tstmt.executeUpdate(job_audit);
                                                                                                                } catch (SQLException e) {e.printStackTrace();}
                                                                                                  		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                                                                        
                                                                                                        String fromDate=exchange.getIn().getHeader("introductionDate", String.class);
                                                                                                        
                                                                                                      //create Product Price one-off
                                                                                                        paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                              							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                                                                              							paramMap.put("productPricePurposeId", "PURCHASE");
                                                                              							paramMap.put("currencyUomId", "USD");
                                                                              							paramMap.put("productStoreGroupId", "_NA_");
                                                                              							paramMap.put("fromDate", fromDate);
                                                                              							paramMap.put("thruDate", thruDate);
                                                                              							paramMap.put("price", exchange.getIn().getHeader("childOneOff", String.class));
                                                                              							paramMap.put("login.username", ofbiz_userid);
                                                                              							paramMap.put("login.password", ofbiz_pwd);
                                                                              							
                                                                              							String cpri_res = template.requestBodyAndHeader(
                                                                              									fromFile,
                                                                              								new Object[] { paramMap },
                                                                              									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                                                                              							paramMap.clear();
                                                                              							//create Product recurring price
                                                                              							
                                                                                                        paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                              							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                                                                              							paramMap.put("productPricePurposeId", "RECURRING_CHARGE");
                                                                              							paramMap.put("currencyUomId", "USD");
                                                                              							paramMap.put("productStoreGroupId", "_NA_");
                                                                              							paramMap.put("fromDate", exchange.getIn().getHeader("introductionDate", String.class));
                                                                              							paramMap.put("thruDate", thruDate);
                                                                              							paramMap.put("price", exchange.getIn().getHeader("childRecurring", String.class));
                                                                              							paramMap.put("login.username", ofbiz_userid);
                                                                              							paramMap.put("login.password", ofbiz_pwd);
                                                                              							
                                                                              							String rpri_res = template.requestBodyAndHeader(
                                                                              									fromFile,
                                                                              								new Object[] { paramMap },
                                                                              									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                                                                              							paramMap.clear();
                                                                                      				}
                                                                                      		else{ 
                                                                                      			
                                                                                           //update child products
                                                                                      			System.out.println("update Option products");
                                                                                                      	paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                                                        paramMap.put("productName",exchange.getIn().getHeader("childProductName", String.class));
                                                                                                        paramMap.put("internalName",exchange.getIn().getHeader("childProductName", String.class));
                                                                                                        paramMap.put("description",exchange.getIn().getHeader("childProductName", String.class));
                                                                                                        paramMap.put("productTypeId", "FINISHED_GOOD");
                                                                                                        paramMap.put("login.username", ofbiz_userid);
                                                                                                        paramMap.put("login.password", ofbiz_pwd);
                                                                                                        String res = template.requestBodyAndHeader(
                                                                                                                    fromFile,
                                                                                                              new Object[] { paramMap },
                                                                                                                    XmlRpcConstants.METHOD_NAME, "updateProduct", String.class);
                                                                                                        paramMap.clear();
                                                                                                        
                                                                                                        //update job_audit with status
                                                                                                        Connection Tconn = null;
                                                                                                        Statement Tstmt = null;
                                                                                                        int his_id = 0;
                                                                                                        try {
                                                                                                  			Class.forName(JDBC_DRIVER);
                                                                                                  			try {
                                                                                                  				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                                                                  				Tstmt = Tconn.createStatement();
                                                                                                                String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                                                                ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                                                                  while (Trs.next()) {
                                                                                                                	  his_id = Trs.getInt("history_id");
                                                                                                                  }
                                                                                                                String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','UPDATING_CHILD_PRODUCTS','Ok')";
                                                                                                                int ins_res = Tstmt.executeUpdate(job_audit);
                                                                                                                } catch (SQLException e) {e.printStackTrace();}
                                                                                                  		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                                                                        
                                                                                                        String fromDate=exchange.getIn().getHeader("introductionDate", String.class);
                                                                                                        
                                                                                                      //create Product Price one-off
                                                                                                        paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                              							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                                                                              							paramMap.put("productPricePurposeId", "PURCHASE");
                                                                              							paramMap.put("currencyUomId", "USD");
                                                                              							paramMap.put("productStoreGroupId", "_NA_");
                                                                              							paramMap.put("fromDate", fromDate);
                                                                              							paramMap.put("thruDate", thruDate);
                                                                              							paramMap.put("price", exchange.getIn().getHeader("childOneOff", String.class));
                                                                              							paramMap.put("login.username", ofbiz_userid);
                                                                              							paramMap.put("login.password", ofbiz_pwd);
                                                                              							
                                                                              							String cpri_res = template.requestBodyAndHeader(
                                                                              									fromFile,
                                                                              								new Object[] { paramMap },
                                                                              									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                                                                              							paramMap.clear();
                                                                              							//create Product recurring price
                                                                              							paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                              							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                                                                              							paramMap.put("productPricePurposeId", "RECURRING_CHARGE");
                                                                              							paramMap.put("currencyUomId", "USD");
                                                                              							paramMap.put("productStoreGroupId", "_NA_");
                                                                              							paramMap.put("fromDate", exchange.getIn().getHeader("introductionDate", String.class));
                                                                              							paramMap.put("thruDate", thruDate);
                                                                              							paramMap.put("price", exchange.getIn().getHeader("childRecurring", String.class));
                                                                              							paramMap.put("login.username", ofbiz_userid);
                                                                              							paramMap.put("login.password", ofbiz_pwd);
                                                                              							
                                                                              							String rpri_res = template.requestBodyAndHeader(
                                                                              									fromFile,
                                                                              								new Object[] { paramMap },
                                                                              									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                                                                              							paramMap.clear();
                                                                                        
                                                                                      }
                                                                                      	String id=null;
                                                                                        String chkOption=exchange.getIn().getHeader("childProductName", String.class);
                                                                                        Class.forName(JDBC_DRIVER);
                                                                                      conn = DriverManager.getConnection(DB_URL, USER, PASS);
                                                                                      stmt = conn.createStatement();
                                                                                      String sql1 ="select config_option_Id from Product_Config_option where config_Item_Id='"+exchange.getProperty("createItemId",String.class)+"' AND config_Option_Name='"+exchange.getIn().getHeader("childProductName", String.class)+"'";
                                                                                      ResultSet rs1 = stmt.executeQuery(sql1);
                                                                                      while (rs1.next()) {
                                                                                            id=rs1.getString("config_Option_Id");
                                                                                       }
                                                                                      try{
                                                                                               if(stmt!=null)
                                                                                                    rs1.close();
                                                                                                  conn.close();
                                                                                            }catch(SQLException se){
                                                                                            }
                                                                                            try{
                                                                                               if(conn!=null)
                                                                                                     rs1.close();
                                                                                                  conn.close();
                                                                                            }catch(SQLException se){se.printStackTrace();}          
                                                                                if(id==null)
                                                                                {
                                                                                //create options
                                                                                System.out.println("create Options");
                                                                                paramMap.put("configItemId", exchange.getProperty("createItemId",String.class));
                                                                                paramMap.put("configOptionName",exchange.getIn().getHeader("childProductName", String.class));
                                                                                paramMap.put("description",exchange.getIn().getHeader("childProductName", String.class));
                                                                                paramMap.put("login.username", ofbiz_userid);
                                                                                paramMap.put("login.password", ofbiz_pwd);
                                                                                String res1 = template.requestBodyAndHeader(
                                                                                            fromFile,
                                                                                      new Object[] { paramMap },
                                                                                            XmlRpcConstants.METHOD_NAME, "createProductConfigOption", String.class);
                                                                                paramMap.clear();
                                                                                String[] optionItemIds = res1.split(",");
                                                                                String[] optionIds = optionItemIds[0].split("=");
                                                                                String[] itemIds = optionItemIds[1].split("=");
                                                                                String optionId = optionIds[1];
                                                                                String itemId = itemIds[1];
                                                                                itemId = itemId.replace("}", "");
                                                                                exchange.setProperty("ItemId",itemId);
                                                                                exchange.setProperty("OptionId",optionId);
                                                                                
                                                                                //update job_audit with status
                                                                                Connection Tconn = null;
                                                                                Statement Tstmt = null;
                                                                                int his_id = 0;
                                                                                try {
                                                                          			Class.forName(JDBC_DRIVER);
                                                                          			try {
                                                                          				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                                          				Tstmt = Tconn.createStatement();
                                                                                        String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                                        ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                                          while (Trs.next()) {
                                                                                        	  his_id = Trs.getInt("history_id");
                                                                                          }
                                                                                        String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','CREATING_OPTION','Ok')";
                                                                                        int ins_res = Tstmt.executeUpdate(job_audit);
                                                                                        } catch (SQLException e) {e.printStackTrace();}
                                                                          		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                                                }else{
                                                                                      //update options
                                                                                        System.out.println("update Options");
                                                                                        exchange.setProperty("createOptionId",id);
                                                                                          paramMap.put("configItemId", exchange.getProperty("createItemId",String.class));
	                                                                                      paramMap.put("configOptionId", exchange.getProperty("createOptionId",String.class));
	                                                                                      paramMap.put("configOptionName",exchange.getIn().getHeader("childProductName", String.class));
	                                                                                      paramMap.put("description",exchange.getIn().getHeader("childProductName", String.class));
	                                                                                      paramMap.put("login.username", ofbiz_userid);
	                                                                                      paramMap.put("login.password", ofbiz_pwd);
	                                                                                      
                                                                                      String test=paramMap.toString();
                                                                                      String res1 = template.requestBodyAndHeader(
                                                                                                  fromFile,
                                                                                            new Object[] { paramMap },
                                                                                                  XmlRpcConstants.METHOD_NAME, "updateProductConfigOption", String.class);
                                                                                      exchange.setProperty("ItemId",exchange.getProperty("createItemId",String.class));
                                                                                      exchange.setProperty("OptionId",exchange.getProperty("createOptionId",String.class));
                                                                                      paramMap.clear();
                                                                                      
                                                                                      //update job_audit with status
                                                                                      Connection Tconn = null;
                                                                                      Statement Tstmt = null;
                                                                                      int his_id = 0;
                                                                                      try {
                                                                                			Class.forName(JDBC_DRIVER);
                                                                                			try {
                                                                                				Tconn = DriverManager.getConnection(TALEND_URL, TALEND_USER, TALEND_PASS);
                                                                                				Tstmt = Tconn.createStatement();
                                                                                              String sel_hid = "select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
                                                                                              ResultSet Trs = Tstmt.executeQuery(sel_hid);
                                                                                                while (Trs.next()) {
                                                                                              	  his_id = Trs.getInt("history_id");
                                                                                                }
                                                                                              String job_audit="INSERT INTO `job_audit`(`history_id`, `job_state`, `ex_result`) VALUES ('"+his_id+"','UPDATING_OPTION','Ok')";
                                                                                              int ins_res = Tstmt.executeUpdate(job_audit);
                                                                                              } catch (SQLException e) {e.printStackTrace();}
                                                                                		} catch (ClassNotFoundException e) {e.printStackTrace();}
                                                                                }
                                                                                int present = 0;
                                                                                Class.forName(JDBC_DRIVER);
                                                                                conn = DriverManager.getConnection(DB_URL, USER, PASS);
                                                                                stmt = conn.createStatement();
                                                                                String sql2 = "select count(*) from Product_Config_Product where product_Id='"+exchange.getIn().getHeader("childProductId", String.class)+"'AND config_Item_Id='"+exchange.getProperty("ItemId",String.class)+"'AND config_Option_Id='"+exchange.getProperty("OptionId",String.class)+"'";
                                                                                ResultSet rs2 = stmt.executeQuery(sql2);
                                                                                while (rs2.next()) {
                                                                                      present = rs2.getInt(1);
                                                                                }
                                                                                try{
                                                                                	if(stmt!=null)
                                                                                              rs2.close();
                                                                                            conn.close();
                                                                                      }catch(SQLException se){
                                                                                      }
                                                                                      try{
                                                                                         if(conn!=null)
                                                                                               rs2.close();
                                                                                            conn.close();
                                                                                      }catch(SQLException se){se.printStackTrace();}
                                                                                if(present==0)
                                                                                {
                                                                                //configure item, option and product
                                                                                paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                                paramMap.put("configItemId",exchange.getProperty("ItemId",String.class));
                                                                                paramMap.put("configOptionId",exchange.getProperty("OptionId",String.class));
                                                                                paramMap.put("login.username", ofbiz_userid);
                                                                                paramMap.put("login.password", ofbiz_pwd);
                                                                                String s2=paramMap.toString();
                                                                                String res2 = template.requestBodyAndHeader(
                                                                                            fromFile,
                                                                                      new Object[] { paramMap },
                                                                                            XmlRpcConstants.METHOD_NAME, "createProductConfigProduct", String.class);
                                                                                paramMap.clear();
                                                                          }else
                                                                          {
                                                                                System.out.println("do nothing");
                                                                          }
                                                                          }
                                                                          catch(Exception e){e.printStackTrace();}
                                                                          }
                                                                          })
                          .to("file:target/")
                          
                          //update job_history
                          .wireTap("seda:done");
        	   from("seda:done")
              .bean(UpdateService.class, "auditFile");
             }
        });
        context.start();
        Thread.sleep(100000);
        context.stop();
        }
	}


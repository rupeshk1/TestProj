package com.techmahindra.online.svallo.integration.userprofile.transform;

import java.io.ByteArrayInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.techmahindra.online.svallo.model.common.userprofile._2013._08._01.Party;
import com.techmahindra.online.svallo.model.common.userprofile._2013._08._01.Person;
import com.techmahindra.online.svallo.service.userprofile._2013._08._01.GetPartyResponse;



public class EnrichBean1 {

    public Document enrich(Document doc) throws Exception{
        
		Node node = doc.getElementsByTagName("emailAddress").item(0);
        String emailAddress = node.getTextContent();
		
		node = doc.getElementsByTagName("firstName").item(0);
        String firstName = node.getTextContent();
		
		node = doc.getElementsByTagName("screenName").item(0);
        String screenName = node.getTextContent();

		
		/*String context = "com.liferay.portal.service.http";
		JAXBContext jContext = JAXBContext.newInstance(context);

		Unmarshaller jaxbUnmarshaller = jContext.createUnmarshaller();
		GetUserByScreenNameResponse userSoap = (GetUserByScreenNameResponse) jaxbUnmarshaller.unmarshal(doc);
		System.out.println(userSoap); 
		*/
		
		
		
		
		Person person=new Person();
		person.setFirstName(emailAddress);
		
		
		Party party=new Party();
		party.setPerson(person);
		
		GetPartyResponse getPartyResponse=new GetPartyResponse();
		getPartyResponse.setParty(party);
		
		
		JAXBContext jaxbContext = JAXBContext.newInstance(GetPartyResponse.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		java.io.StringWriter sw = new java.io.StringWriter();
		jaxbMarshaller.marshal(getPartyResponse, sw);		

		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		
		//String xmlData="<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" >"+sw.toString()+"</soap:Envelope>";
		
		String xmlData="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body>"+sw.toString().replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>","")+"</S:Body></S:Envelope>";
		
		doc=builder.parse(new ByteArrayInputStream(xmlData.getBytes()));
        return doc;
    }
}


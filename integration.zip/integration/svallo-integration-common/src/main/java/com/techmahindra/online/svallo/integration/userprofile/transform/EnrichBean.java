package com.techmahindra.online.svallo.integration.userprofile.transform;

import java.io.ByteArrayInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.techmahindra.online.svallo.service.userprofile._2013._08._01.GetParty;
import com.techmahindra.online.svallo.service.userprofile._2013._08._01.PartyQuery;

import org.w3c.dom.*;
import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class EnrichBean {

    public Document enrich(Document doc) throws Exception{
        
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
	
		Source source = new DOMSource(doc);
		StringWriter stringWriter = new StringWriter();
		Result result = new StreamResult(stringWriter);
		TransformerFactory factory1 = TransformerFactory.newInstance();
		Transformer transformer = factory1.newTransformer();
		transformer.transform(source, result);
		
		JAXBContext jaxbContext = JAXBContext.newInstance(GetParty.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		String xmlString=stringWriter.getBuffer().toString();
		
		
		xmlString=xmlString.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body>","");
		xmlString=xmlString.replace("</S:Body></S:Envelope>","");
		
		
		java.io.StringReader xmlStream = new java.io.StringReader(xmlString);
		GetParty party = (GetParty) jaxbUnmarshaller.unmarshal(xmlStream);
		PartyQuery partyQuery=party.getPartyRequest();
		String username = partyQuery.getUsername();
		String companyID = partyQuery.getCompanyId();
		String partyID = partyQuery.getPartyId();
		
		/*
		Node node = doc.getElementsByTagName("ns3:username").item(0);
        String username = node.getTextContent();
        node = doc.getElementsByTagName("ns3:companyId").item(0);
		String companyID = node.getTextContent();
		*/
		//<?xml version=\"1.0\" ?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body><getParty xmlns=\"http://services.techmahindra.com/svallo/service/userprofile/2013/08/01\" xmlns:ns2=\"http://services.techmahindra.com/svallo/model/common/userprofile/2013/08/01\"><getPartyRequest><username>test</username><partyId>10154</partyId></getPartyRequest></getParty></S:Body></S:Envelope>
		
		String transFormedXML="<?xml version=\"1.0\" encoding=\"UTF-8\"?> "
		                      +"<ns1:getUserByScreenName soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" "
							  +"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"urn:http.service.portal.liferay.com\">"
							  +"<companyId xsi:type=\"xsd:long\">MACRO_COMPANYID</companyId>"
							  +"<screenName xsi:type=\"xsd:string\">MACRO_SCREENNAME</screenName>"
							  +"</ns1:getUserByScreenName>";
		
		transFormedXML=transFormedXML.replace("MACRO_COMPANYID",companyID);
		transFormedXML=transFormedXML.replace("MACRO_SCREENNAME",username);
		
		doc=builder.parse(new ByteArrayInputStream(transFormedXML.getBytes()));
		
        return doc;
    }
}


package com.techmahindra.online.svallo.integration.userprofile.transform;
import java.sql.ResultSet;
import java.sql.*;

public class UpdateService {
	public void auditFile(String body) {  
        String DB_URL = "jdbc:mysql://localhost/Logging_Talend_Data2";
        String USER = "TalendJob";
        String PASS = "TalendJob";
        Connection conn = null;
        Statement stmt = null;
        try {
			Class.forName("com.mysql.jdbc.Driver");
			try {
				conn = DriverManager.getConnection(DB_URL, USER, PASS);
				stmt = conn.createStatement();
				String stat="idle";
				String strt="UPDATE `"+ "job_definition"+"` SET `execution_status`= '"+ stat +"' WHERE `job_name` LIKE '%replica%'";
				stmt.executeUpdate(strt);
				
				String latest_id="select history_id from job_histroy ORDER BY history_id DESC LIMIT 1";
				ResultSet rs=stmt.executeQuery(latest_id);
				String his_id=null;
				while (rs.next()) {
					his_id = rs.getString(1);
              }
				int i=Integer.parseInt(his_id);
				String sql="UPDATE `job_histroy` SET `job_status` = 'success' WHERE `history_id` = " + i;
				stmt.executeUpdate(sql);
				} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}

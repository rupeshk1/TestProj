package com.techmahindra.online.svallo.integration.userprofile.transform;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.xmlrpc.XmlRpcConstants;
import org.apache.camel.impl.DefaultCamelContext;

public class MapperVirtualProds {
	public static void main() throws Exception {
        final CamelContext context = new DefaultCamelContext();
        final ProducerTemplate template = context.createProducerTemplate();
        final String ofbiz_userid= "admin";
        final String ofbiz_pwd= "ofbiz";
        final Map paramMap = new HashMap<String, String>();
        String configFilePath = "E:/Siebel/camelPropertyFile/camel.properties";
 	  	Properties properties = new Properties();
 	  	FileInputStream  fis = new FileInputStream(configFilePath);
 	  	properties.load(fis);
 	  	final String fromFile = properties.getProperty("camel.xmlrpcurl");
        final String thruDate = properties.getProperty("camel.thrudate");
		final String categoryId = properties.getProperty("camel.virtualcategoryid");
        
               //begin router
        context.addRoutes(new RouteBuilder() {
        public void configure()throws Exception{
        	from("file://E:/siebel/virtualInput/camelInput")
                    .split(xpath("//ListOfProducts/Products/Product"))
                                .setHeader("productId", xpath("//Product/productId/text()").stringResult())
                                
                                .setHeader("productName", xpath("//Product/productName/text()").stringResult())
                                .setHeader("description", xpath("//Product/description/text()").stringResult())
                                .setHeader("introductionDate",
                                            constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                .setHeader("releaseDate",
                                            constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                .setHeader("supportDiscontinuationDate",
                                            constant(new java.sql.Timestamp(System.currentTimeMillis() + (1000 * 60 * 60 * 24 * 365))))
                                .setHeader("priceOneOff", xpath("//Product/PriceOneOff/text()").stringResult())
                                .process(new Processor() {
                                      public void process(Exchange exchange) {
                                    	  //create Product
                                                    System.out.println("create the virtual Product");
                                                              
                                                              paramMap.put("login.username", ofbiz_userid);
                                                              paramMap.put("login.password", ofbiz_pwd);
                                                              paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                                                              paramMap.put("productName", exchange.getIn().getHeader("productName", String.class));
                                                              paramMap.put("internalName", exchange.getIn().getHeader("productName", String.class));
                                                              paramMap.put("productTypeId", "FINISHED_GOOD");
                                                              paramMap.put("isVirtual", "Y");
                                                              paramMap.put("isVariant", "N");
                                                              paramMap.put("description", exchange.getIn().getHeader("description", String.class));
                                                              paramMap.put("introductionDate", exchange.getIn().getHeader("introductionDate", String.class));
                                                              paramMap.put("releaseDate", exchange.getIn().getHeader("releaseDate", String.class));
                                                              paramMap.put("supportDiscontinuationDate", exchange.getIn().getHeader("supportDiscontinuationDate", String.class));
                                                              String response = template.requestBodyAndHeader(
                                                                          fromFile,
                                                                    new Object[] { paramMap },
                                                                          XmlRpcConstants.METHOD_NAME, "createProduct", String.class);
                                                              
                                                              exchange.setProperty("virtualProductId", exchange.getIn().getHeader("productId", String.class));
                                                              
                                                             System.out.println("Virtual Product Created for      "+paramMap+"*********************************");
                                                             paramMap.clear();
                                                              
                                                             //create Product Price one-off
                                                              
                                                        System.out.println("create the virtual Product Price");
														
                                  							paramMap.put("productId", exchange.getIn().getHeader("productId", String.class));
                                  							paramMap.put("productPriceTypeId", "DEFAULT_PRICE");
                                  							paramMap.put("productPricePurposeId", "PURCHASE");
                                  							paramMap.put("currencyUomId", "USD");
                                  							paramMap.put("productStoreGroupId", "_NA_");
                                  							paramMap.put("fromDate", exchange.getIn().getHeader("introductionDate", String.class));
                                  							paramMap.put("thruDate", thruDate);
                                  							paramMap.put("price", exchange.getIn().getHeader("priceOneOff", String.class));
                                  							paramMap.put("login.username", ofbiz_userid);
                                  							paramMap.put("login.password", ofbiz_pwd);
                                  							
                                  							String cpri_res = template.requestBodyAndHeader(
                                  									fromFile,
                                  								new Object[] { paramMap },
                                  									XmlRpcConstants.METHOD_NAME, "createProductPrice", String.class);
                                  							System.out.println("virtual Product Price created for      "+paramMap+"*********************************");
                                  							
                                  							paramMap.clear();
                                  							
                                                    System.out.println("create the virtual Product category");    
														//assign it to a category
                                                              paramMap.put("productId",exchange.getIn().getHeader("productId", String.class));
                                                              paramMap.put("productCategoryId",categoryId);
                                                              paramMap.put("login.username", ofbiz_userid);
                                                              paramMap.put("login.password", ofbiz_pwd); 
															  String res = template.requestBodyAndHeader(
                                                                          fromFile,
                                                                          new Object[] { paramMap },
                                                                    XmlRpcConstants.METHOD_NAME, "addProductToCategory", String.class);
                                                              System.out.println("Product assigned to category     "+paramMap+"*********************************");
                                                              
                                                             paramMap.clear();
                                                    }
                                                  
                                })
                                            .split(xpath("//Product/ChildProducts/ChildProduct"))
                                                  .setHeader("childProductId", xpath("//ChildProduct/productId/text()").stringResult())
                                                  .setHeader("childProductName", xpath("//ChildProduct/productName/text()").stringResult())
                                                  .setHeader("fromDate",constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                                  .setHeader("supportDiscontinuationDate",constant(new java.sql.Timestamp(System.currentTimeMillis() + (1000 * 60 * 60 * 24 * 365))))
                                                        .process(new Processor() {
                                                              public void process(Exchange exchange) throws Exception {
                                                            	//create Variant Product
                                                                System.out.println("create Variant Product");
                                                                           paramMap.put("productId", exchange.getIn().getHeader("childProductId", String.class));
                                                                            paramMap.put("productName", exchange.getIn().getHeader("childProductName", String.class));
                                                                            paramMap.put("internalName", exchange.getIn().getHeader("childProductName", String.class));
                                                                            paramMap.put("productTypeId", "FINISHED_GOOD");
                                                                            paramMap.put("isVirtual", "N");
                                                                            paramMap.put("isVariant", "Y");
                                                                            paramMap.put("introductionDate", exchange.getIn().getHeader("fromDate", String.class));
                                                                            paramMap.put("releaseDate", exchange.getIn().getHeader("fromDate", String.class));
                                                                            paramMap.put("supportDiscontinuationDate", exchange.getIn().getHeader("supportDiscontinuationDate", String.class));
                                                                            paramMap.put("login.username", ofbiz_userid);
                                                                            paramMap.put("login.password", ofbiz_pwd); 
                                                                      
                                                                         String response = template.requestBodyAndHeader(
                                                                                        fromFile,
                                                                                  new Object[] { paramMap },
                                                                                        XmlRpcConstants.METHOD_NAME, "createProduct", String.class);
                                                                            
                                                                          exchange.setProperty("variantProductId",exchange.getIn().getHeader("childProductId", String.class));
                                                                            
                                                                              System.out.println("Vaiant Product Created for    "+paramMap+"*********************************");
                                                                            
                                                                            paramMap.clear(); 
                                                                            
                                                                     //assign Variants to the Virtual Product
                                                                           System.out.println("create Variant Virtual Association");
                                                                            paramMap.put("productId", exchange.getProperty("virtualProductId",String.class));
                                                                            paramMap.put("productIdTo",exchange.getProperty("variantProductId",String.class));
                                                                            paramMap.put("productAssocTypeId", "PRODUCT_VARIANT");
                                                                            paramMap.put("fromDate", exchange.getIn().getHeader("fromDate", String.class));
                                                                            paramMap.put("login.username", ofbiz_userid);
                                                                            paramMap.put("login.password", ofbiz_pwd); 
                                                                      
                                                                          String response1 = template.requestBodyAndHeader(
                                                                                        fromFile,
                                                                                  new Object[] { paramMap },
                                                                                        XmlRpcConstants.METHOD_NAME, "createProductAssoc", String.class);
                                                                            
                                                                            System.out.println("Variant Virtual Association created for   "+paramMap+"*********************************");
                                                                            
                                                                            paramMap.clear();
                                                                    }
                                                        })
                                                                   .split(xpath("//ChildProduct/Features/Feature"))
                                                                   .setHeader("featureId", xpath("//Feature/featureId/text()").stringResult())
                                                                   .setHeader("fromDate",constant(new java.sql.Timestamp(System.currentTimeMillis())))
                                                                    .process(new Processor() {
                                                                          public void process(Exchange exchange) throws Exception {
																		  System.out.println("create Feature Application SELECTABLE");
																		 
																		  
                                                                        	  paramMap.put("productId", exchange.getProperty("virtualProductId",String.class));
                                                                              paramMap.put("productFeatureId", exchange.getIn().getHeader("featureId", String.class));
                                                                              paramMap.put("productFeatureApplTypeId", "SELECTABLE_FEATURE");
                                                                              paramMap.put("fromDate", exchange.getIn().getHeader("fromDate", String.class));
                                                                              paramMap.put("login.username", ofbiz_userid);
                                                                              paramMap.put("login.password", ofbiz_pwd);
                                                                        
                                                                             String response = template.requestBodyAndHeader(
                                                                                          fromFile,
                                                                                    new Object[] { paramMap },
                                                                                          XmlRpcConstants.METHOD_NAME, "applyFeatureToProduct", String.class);
                                                                             
                                                                             
                                                                              System.out.println("^^^^^^^^^^^^^^^^^^^^^");
                                                                              System.out.println("Feature Application for Virtual Selectable  "+paramMap+"*********************************");	
                                                                              System.out.println("^^^^^^^^^^^^^^^^^^^^^");
                                                                              paramMap.clear();
																			  
																			System.out.println("create Feature Application STANDARD"); 
                                                                              
                                                                              paramMap.put("productId", exchange.getProperty("variantProductId",String.class) );
                                                                              paramMap.put("productFeatureId", exchange.getIn().getHeader("featureId", String.class));
                                                                              paramMap.put("productFeatureApplTypeId", "STANDARD_FEATURE");
                                                                              paramMap.put("fromDate", exchange.getIn().getHeader("fromDate", String.class));
                                                                              paramMap.put("login.username", ofbiz_userid);
                                                                              paramMap.put("login.password", ofbiz_pwd);
                                                                        
                                                                            String response1 = template.requestBodyAndHeader(
                                                                                          fromFile,
                                                                                    new Object[] { paramMap },
                                                                                          XmlRpcConstants.METHOD_NAME, "applyFeatureToProduct", String.class);
                                                                              System.out.println("^^^^^^^^^^^^^^^^^^^^^");
                                                                              System.out.println("Feature Application created for  Standard  "+paramMap+"*********************************");
                                                                              System.out.println("^^^^^^^^^^^^^^^^^^^^^");
                                                                              paramMap.clear();
                                                                              
                                                                             
                                                                          }})
                          .to("file:target/");
                          
                          //update job_history
                         // .wireTap("seda:done");
        	   /*from("seda:done")
              .bean(UpdateService.class, "auditFile");*/
             }
        });
        context.start();
        Thread.sleep(100000);
        context.stop();
        }
	}


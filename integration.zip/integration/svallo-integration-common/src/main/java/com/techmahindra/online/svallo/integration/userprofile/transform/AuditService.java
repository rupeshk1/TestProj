package com.techmahindra.online.svallo.integration.userprofile.transform;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import java.sql.*;

public class AuditService {
	private Log LOG = LogFactory.getLog(AuditService.class);
	public void auditFile() {
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/Logging_Talend_Data2";
        String USER = "TalendJob";
        String PASS = "TalendJob";
        
        Connection conn = null;
        Statement stmt = null;
        try {
			Class.forName(JDBC_DRIVER);
			try {
				conn = DriverManager.getConnection(DB_URL, USER, PASS);
				stmt = conn.createStatement();
				String stat="in_progress";
				String strt="UPDATE `"+ "job_definition"+"` SET `execution_status`= '"+ stat +"' WHERE `job_name` LIKE '%replica%'";
				int jb = stmt.executeUpdate(strt);
				Timestamp starttime=new java.sql.Timestamp(System.currentTimeMillis());
				String sql = "INSERT INTO `"
						+ "job_histroy"
						+ "` (`job_name`,`ex_start_datetime`,`ex_duration`) VALUES ('replica','"+starttime+"','100000')";
                int rs = stmt.executeUpdate(sql);
                System.out.println("insert history&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& "+rs);
					} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

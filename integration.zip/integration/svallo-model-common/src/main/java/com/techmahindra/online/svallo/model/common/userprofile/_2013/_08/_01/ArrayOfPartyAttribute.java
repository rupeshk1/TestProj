
package com.techmahindra.online.svallo.model.common.userprofile._2013._08._01;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOf_PartyAttribute complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOf_PartyAttribute">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="partyAttribute" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}PartyAttribute" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOf_PartyAttribute", propOrder = {
    "partyAttribute"
})
public class ArrayOfPartyAttribute {

    @XmlElement(required = true, nillable = true)
    protected List<PartyAttribute> partyAttribute;

    /**
     * Gets the value of the partyAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyAttribute }
     * 
     * 
     */
    public List<PartyAttribute> getPartyAttribute() {
        if (partyAttribute == null) {
            partyAttribute = new ArrayList<PartyAttribute>();
        }
        return this.partyAttribute;
    }

}

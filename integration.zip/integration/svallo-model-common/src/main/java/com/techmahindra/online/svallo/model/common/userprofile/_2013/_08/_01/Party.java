
package com.techmahindra.online.svallo.model.common.userprofile._2013._08._01;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Party complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Party">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="createdDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="externalId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastModifiedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="partyAttributes" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_PartyAttribute"/>
 *         &lt;element name="partycontacts" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_PartyContact"/>
 *         &lt;element name="partyGroup" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}PartyGroup"/>
 *         &lt;element name="partyId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="partyRoles" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_PartyRole"/>
 *         &lt;element name="partyStatusId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="partyTypeId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="person" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}Person"/>
 *         &lt;element name="uom" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}Uom"/>
 *         &lt;element name="userLogins" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_UserLogin"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Party", propOrder = {
    "createdDate",
    "description",
    "externalId",
    "lastModifiedDate",
    "partyAttributes",
    "partycontacts",
    "partyGroup",
    "partyId",
    "partyRoles",
    "partyStatusId",
    "partyTypeId",
    "person",
    "uom",
    "userLogins"
})
public class Party {

    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdDate;
    @XmlElement(required = true, nillable = true)
    protected String description;
    @XmlElement(required = true, nillable = true)
    protected String externalId;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastModifiedDate;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfPartyAttribute partyAttributes;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfPartyContact partycontacts;
    @XmlElement(required = true, nillable = true)
    protected PartyGroup partyGroup;
    @XmlElement(required = true, nillable = true)
    protected String partyId;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfPartyRole partyRoles;
    @XmlElement(required = true, nillable = true)
    protected String partyStatusId;
    @XmlElement(required = true, nillable = true)
    protected String partyTypeId;
    @XmlElement(required = true, nillable = true)
    protected Person person;
    @XmlElement(required = true, nillable = true)
    protected Uom uom;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfUserLogin userLogins;

    /**
     * Gets the value of the createdDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the value of the createdDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedDate(XMLGregorianCalendar value) {
        this.createdDate = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the externalId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * Sets the value of the externalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalId(String value) {
        this.externalId = value;
    }

    /**
     * Gets the value of the lastModifiedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastModifiedDate() {
        return lastModifiedDate;
    }

    /**
     * Sets the value of the lastModifiedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastModifiedDate(XMLGregorianCalendar value) {
        this.lastModifiedDate = value;
    }

    /**
     * Gets the value of the partyAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfPartyAttribute }
     *     
     */
    public ArrayOfPartyAttribute getPartyAttributes() {
        return partyAttributes;
    }

    /**
     * Sets the value of the partyAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfPartyAttribute }
     *     
     */
    public void setPartyAttributes(ArrayOfPartyAttribute value) {
        this.partyAttributes = value;
    }

    /**
     * Gets the value of the partycontacts property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfPartyContact }
     *     
     */
    public ArrayOfPartyContact getPartycontacts() {
        return partycontacts;
    }

    /**
     * Sets the value of the partycontacts property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfPartyContact }
     *     
     */
    public void setPartycontacts(ArrayOfPartyContact value) {
        this.partycontacts = value;
    }

    /**
     * Gets the value of the partyGroup property.
     * 
     * @return
     *     possible object is
     *     {@link PartyGroup }
     *     
     */
    public PartyGroup getPartyGroup() {
        return partyGroup;
    }

    /**
     * Sets the value of the partyGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyGroup }
     *     
     */
    public void setPartyGroup(PartyGroup value) {
        this.partyGroup = value;
    }

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the partyRoles property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfPartyRole }
     *     
     */
    public ArrayOfPartyRole getPartyRoles() {
        return partyRoles;
    }

    /**
     * Sets the value of the partyRoles property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfPartyRole }
     *     
     */
    public void setPartyRoles(ArrayOfPartyRole value) {
        this.partyRoles = value;
    }

    /**
     * Gets the value of the partyStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyStatusId() {
        return partyStatusId;
    }

    /**
     * Sets the value of the partyStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyStatusId(String value) {
        this.partyStatusId = value;
    }

    /**
     * Gets the value of the partyTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyTypeId() {
        return partyTypeId;
    }

    /**
     * Sets the value of the partyTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyTypeId(String value) {
        this.partyTypeId = value;
    }

    /**
     * Gets the value of the person property.
     * 
     * @return
     *     possible object is
     *     {@link Person }
     *     
     */
    public Person getPerson() {
        return person;
    }

    /**
     * Sets the value of the person property.
     * 
     * @param value
     *     allowed object is
     *     {@link Person }
     *     
     */
    public void setPerson(Person value) {
        this.person = value;
    }

    /**
     * Gets the value of the uom property.
     * 
     * @return
     *     possible object is
     *     {@link Uom }
     *     
     */
    public Uom getUom() {
        return uom;
    }

    /**
     * Sets the value of the uom property.
     * 
     * @param value
     *     allowed object is
     *     {@link Uom }
     *     
     */
    public void setUom(Uom value) {
        this.uom = value;
    }

    /**
     * Gets the value of the userLogins property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfUserLogin }
     *     
     */
    public ArrayOfUserLogin getUserLogins() {
        return userLogins;
    }

    /**
     * Sets the value of the userLogins property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfUserLogin }
     *     
     */
    public void setUserLogins(ArrayOfUserLogin value) {
        this.userLogins = value;
    }

}

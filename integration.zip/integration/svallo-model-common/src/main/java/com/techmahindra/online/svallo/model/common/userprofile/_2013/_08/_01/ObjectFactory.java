
package com.techmahindra.online.svallo.model.common.userprofile._2013._08._01;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.techmahindra.online.svallo.model.common.userprofile._2013._08._01 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.techmahindra.online.svallo.model.common.userprofile._2013._08._01
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ArrayOfBillingAccount }
     * 
     */
    public ArrayOfBillingAccount createArrayOfBillingAccount() {
        return new ArrayOfBillingAccount();
    }

    /**
     * Create an instance of {@link ArrayOfPartyAttribute }
     * 
     */
    public ArrayOfPartyAttribute createArrayOfPartyAttribute() {
        return new ArrayOfPartyAttribute();
    }

    /**
     * Create an instance of {@link UserLogin }
     * 
     */
    public UserLogin createUserLogin() {
        return new UserLogin();
    }

    /**
     * Create an instance of {@link ArrayOfPostalAddress }
     * 
     */
    public ArrayOfPostalAddress createArrayOfPostalAddress() {
        return new ArrayOfPostalAddress();
    }

    /**
     * Create an instance of {@link ArrayOfTelecomNumber }
     * 
     */
    public ArrayOfTelecomNumber createArrayOfTelecomNumber() {
        return new ArrayOfTelecomNumber();
    }

    /**
     * Create an instance of {@link Party }
     * 
     */
    public Party createParty() {
        return new Party();
    }

    /**
     * Create an instance of {@link Contact }
     * 
     */
    public Contact createContact() {
        return new Contact();
    }

    /**
     * Create an instance of {@link PostalAddress }
     * 
     */
    public PostalAddress createPostalAddress() {
        return new PostalAddress();
    }

    /**
     * Create an instance of {@link ArrayOfUserLogin }
     * 
     */
    public ArrayOfUserLogin createArrayOfUserLogin() {
        return new ArrayOfUserLogin();
    }

    /**
     * Create an instance of {@link BillingAccount }
     * 
     */
    public BillingAccount createBillingAccount() {
        return new BillingAccount();
    }

    /**
     * Create an instance of {@link ArrayOfPartyRole }
     * 
     */
    public ArrayOfPartyRole createArrayOfPartyRole() {
        return new ArrayOfPartyRole();
    }

    /**
     * Create an instance of {@link Uom }
     * 
     */
    public Uom createUom() {
        return new Uom();
    }

    /**
     * Create an instance of {@link ArrayOfPartyContact }
     * 
     */
    public ArrayOfPartyContact createArrayOfPartyContact() {
        return new ArrayOfPartyContact();
    }

    /**
     * Create an instance of {@link PartyRole }
     * 
     */
    public PartyRole createPartyRole() {
        return new PartyRole();
    }

    /**
     * Create an instance of {@link ArrayOfContactAttribute }
     * 
     */
    public ArrayOfContactAttribute createArrayOfContactAttribute() {
        return new ArrayOfContactAttribute();
    }

    /**
     * Create an instance of {@link PartyAttribute }
     * 
     */
    public PartyAttribute createPartyAttribute() {
        return new PartyAttribute();
    }

    /**
     * Create an instance of {@link ContactAttribute }
     * 
     */
    public ContactAttribute createContactAttribute() {
        return new ContactAttribute();
    }

    /**
     * Create an instance of {@link EmailAddress }
     * 
     */
    public EmailAddress createEmailAddress() {
        return new EmailAddress();
    }

    /**
     * Create an instance of {@link PartyGroup }
     * 
     */
    public PartyGroup createPartyGroup() {
        return new PartyGroup();
    }

    /**
     * Create an instance of {@link ArrayOfEmailAddress }
     * 
     */
    public ArrayOfEmailAddress createArrayOfEmailAddress() {
        return new ArrayOfEmailAddress();
    }

    /**
     * Create an instance of {@link TelecomNumber }
     * 
     */
    public TelecomNumber createTelecomNumber() {
        return new TelecomNumber();
    }

    /**
     * Create an instance of {@link PartyContact }
     * 
     */
    public PartyContact createPartyContact() {
        return new PartyContact();
    }

    /**
     * Create an instance of {@link Person }
     * 
     */
    public Person createPerson() {
        return new Person();
    }

}

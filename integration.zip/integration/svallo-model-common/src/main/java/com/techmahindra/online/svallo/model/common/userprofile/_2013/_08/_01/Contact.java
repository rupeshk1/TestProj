
package com.techmahindra.online.svallo.model.common.userprofile._2013._08._01;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Contact complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Contact">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="billingAccounts" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_BillingAccount"/>
 *         &lt;element name="contactAttributes" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_ContactAttribute"/>
 *         &lt;element name="contactId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="emailAddresses" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_EmailAddress"/>
 *         &lt;element name="postalAddresses" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_PostalAddress"/>
 *         &lt;element name="telecomNumbers" type="{http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01}ArrayOf_TelecomNumber"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Contact", propOrder = {
    "billingAccounts",
    "contactAttributes",
    "contactId",
    "emailAddresses",
    "postalAddresses",
    "telecomNumbers"
})
public class Contact {

    @XmlElement(required = true, nillable = true)
    protected ArrayOfBillingAccount billingAccounts;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfContactAttribute contactAttributes;
    @XmlElement(required = true, nillable = true)
    protected String contactId;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfEmailAddress emailAddresses;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfPostalAddress postalAddresses;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfTelecomNumber telecomNumbers;

    /**
     * Gets the value of the billingAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfBillingAccount }
     *     
     */
    public ArrayOfBillingAccount getBillingAccounts() {
        return billingAccounts;
    }

    /**
     * Sets the value of the billingAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfBillingAccount }
     *     
     */
    public void setBillingAccounts(ArrayOfBillingAccount value) {
        this.billingAccounts = value;
    }

    /**
     * Gets the value of the contactAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfContactAttribute }
     *     
     */
    public ArrayOfContactAttribute getContactAttributes() {
        return contactAttributes;
    }

    /**
     * Sets the value of the contactAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfContactAttribute }
     *     
     */
    public void setContactAttributes(ArrayOfContactAttribute value) {
        this.contactAttributes = value;
    }

    /**
     * Gets the value of the contactId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactId() {
        return contactId;
    }

    /**
     * Sets the value of the contactId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactId(String value) {
        this.contactId = value;
    }

    /**
     * Gets the value of the emailAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfEmailAddress }
     *     
     */
    public ArrayOfEmailAddress getEmailAddresses() {
        return emailAddresses;
    }

    /**
     * Sets the value of the emailAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfEmailAddress }
     *     
     */
    public void setEmailAddresses(ArrayOfEmailAddress value) {
        this.emailAddresses = value;
    }

    /**
     * Gets the value of the postalAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfPostalAddress }
     *     
     */
    public ArrayOfPostalAddress getPostalAddresses() {
        return postalAddresses;
    }

    /**
     * Sets the value of the postalAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfPostalAddress }
     *     
     */
    public void setPostalAddresses(ArrayOfPostalAddress value) {
        this.postalAddresses = value;
    }

    /**
     * Gets the value of the telecomNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTelecomNumber }
     *     
     */
    public ArrayOfTelecomNumber getTelecomNumbers() {
        return telecomNumbers;
    }

    /**
     * Sets the value of the telecomNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTelecomNumber }
     *     
     */
    public void setTelecomNumbers(ArrayOfTelecomNumber value) {
        this.telecomNumbers = value;
    }

}

@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/common/userprofile/2013/08/01", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.techmahindra.online.svallo.model.common.userprofile._2013._08._01;

@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/common/content/2013/08/13", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.techmahindra.online.svallo.model.common.content._2013._08._13;

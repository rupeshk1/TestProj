
package com.techmahindra.online.svallo.model.common.content._2013._08._13;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import com.techmahindra.online.svallo.model.common.content.Root;
import com.techmahindra.online.svallo.model.common.content.Root.DynamicElement;
import com.techmahindra.online.svallo.model.common.content.Root.DynamicElement.DynamicContent;


/**
 * <p>Java class for JcrContent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JcrContent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="articleId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="classNameId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="classPK" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="companyId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="content" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="createDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="displayDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="groupId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="indexable" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="layoutUuid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="modifiedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="primaryKey" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="resourcePrimKey" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="reviewDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="smallImage" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="smallImageId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="smallImageURL" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="statusByUserId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="statusByUserName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="statusDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="structureId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="templateId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="urlTitle" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="version" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JcrContent", propOrder = {
    "articleId",
    "classNameId",
    "classPK",
    "companyId",
    "content",
    "createDate",
    "description",
    "displayDate",
    "expirationDate",
    "groupId",
    "id",
    "indexable",
    "layoutUuid",
    "modifiedDate",
    "primaryKey",
    "resourcePrimKey",
    "reviewDate",
    "smallImage",
    "smallImageId",
    "smallImageURL",
    "status",
    "statusByUserId",
    "statusByUserName",
    "statusDate",
    "structureId",
    "templateId",
    "title",
    "type",
    "urlTitle",
    "userId",
    "userName",
    "version"
})
public class JcrContent {

    @XmlElement(required = true, nillable = true)
    protected String articleId;
    protected long classNameId;
    protected long classPK;
    protected long companyId;
    @XmlElement(required = true, nillable = true)
    protected String content;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createDate;
    @XmlElement(required = true, nillable = true)
    protected String description;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar displayDate;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar expirationDate;
    protected long groupId;
    protected long id;
    protected boolean indexable;
    @XmlElement(required = true, nillable = true)
    protected String layoutUuid;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modifiedDate;
    protected long primaryKey;
    protected long resourcePrimKey;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reviewDate;
    protected boolean smallImage;
    protected long smallImageId;
    @XmlElement(required = true, nillable = true)
    protected String smallImageURL;
    protected int status;
    protected long statusByUserId;
    @XmlElement(required = true, nillable = true)
    protected String statusByUserName;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar statusDate;
    @XmlElement(required = true, nillable = true)
    protected String structureId;
    @XmlElement(required = true, nillable = true)
    protected String templateId;
    @XmlElement(required = true, nillable = true)
    protected String title;
    @XmlElement(required = true, nillable = true)
    protected String type;
    @XmlElement(required = true, nillable = true)
    protected String urlTitle;
    protected long userId;
    @XmlElement(required = true, nillable = true)
    protected String userName;
    protected double version;

    /**
     * Gets the value of the articleId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArticleId() {
        return articleId;
    }

    /**
     * Sets the value of the articleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArticleId(String value) {
        this.articleId = value;
    }

    /**
     * Gets the value of the classNameId property.
     * 
     */
    public long getClassNameId() {
        return classNameId;
    }

    /**
     * Sets the value of the classNameId property.
     * 
     */
    public void setClassNameId(long value) {
        this.classNameId = value;
    }

    /**
     * Gets the value of the classPK property.
     * 
     */
    public long getClassPK() {
        return classPK;
    }

    /**
     * Sets the value of the classPK property.
     * 
     */
    public void setClassPK(long value) {
        this.classPK = value;
    }

    /**
     * Gets the value of the companyId property.
     * 
     */
    public long getCompanyId() {
        return companyId;
    }

    /**
     * Sets the value of the companyId property.
     * 
     */
    public void setCompanyId(long value) {
        this.companyId = value;
    }

    /**
     * Gets the value of the content property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContent() {
        return content;
    }
    
    
    public Map<String, Object> getContent(String locale)
	{
 
	
		try 
		{
			JAXBContext jaxbContext = JAXBContext.newInstance(Root.class);
			
			String result = content;
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			InputStream result_is = new ByteArrayInputStream(result.getBytes());
			
			Root product = (Root) jaxbUnmarshaller.unmarshal(result_is);	
			
			List<DynamicElement> dynamicElementList = product.getDynamicElement();
			DynamicElement dynamicElement = null;
			

			Map<String,Object> contentObject = new HashMap<String,Object>();
			contentObject = new HashMap<String,Object>();
			
			String availableLocales = product.getAvailableLocales();
			String[] locales = availableLocales.split(",");
			for(int k=0; k<locales.length; k++)
			{
				locales[k] = locales[k].replaceAll("\\s","");
			}
			
			for(int i=0; i < dynamicElementList.size(); i++)
			{
				dynamicElement = (DynamicElement)dynamicElementList.get(i);
				List<DynamicContent> dynamicContentList = dynamicElement.getDynamicContent();
				String contentValue = "";
				String localeFound = "N";
				String defaultLangContent = "";
				
				for(int j=0; j < dynamicContentList.size(); j++)
				{
					DynamicContent dynamicContent = dynamicContentList.get(j);
					if(j==0)
					{
						defaultLangContent = dynamicContent.getValue();
					}
					if(locale.equals(dynamicContent.getLanguageId()))
					{
						contentValue = dynamicContent.getValue();
						localeFound = "Y";
					}
				}
				if(localeFound.equals("N"))
				{
					contentValue = defaultLangContent;
				}
				contentObject.put(dynamicElement.getName(), contentValue);
			}
				
			return contentObject;
		}
		catch(Exception e)
		{
			System.out.println("Exception while getting article content :: JcrContent.java");
			e.printStackTrace();
		}
		return null;
	}    
    
    /**
     * Sets the value of the content property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContent(String value) {
        this.content = value;
    }

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreateDate(XMLGregorianCalendar value) {
        this.createDate = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the displayDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDisplayDate() {
        return displayDate;
    }

    /**
     * Sets the value of the displayDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDisplayDate(XMLGregorianCalendar value) {
        this.displayDate = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExpirationDate(XMLGregorianCalendar value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the groupId property.
     * 
     */
    public long getGroupId() {
        return groupId;
    }

    /**
     * Sets the value of the groupId property.
     * 
     */
    public void setGroupId(long value) {
        this.groupId = value;
    }

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the indexable property.
     * 
     */
    public boolean isIndexable() {
        return indexable;
    }

    /**
     * Sets the value of the indexable property.
     * 
     */
    public void setIndexable(boolean value) {
        this.indexable = value;
    }

    /**
     * Gets the value of the layoutUuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLayoutUuid() {
        return layoutUuid;
    }

    /**
     * Sets the value of the layoutUuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLayoutUuid(String value) {
        this.layoutUuid = value;
    }

    /**
     * Gets the value of the modifiedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedDate() {
        return modifiedDate;
    }

    /**
     * Sets the value of the modifiedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedDate(XMLGregorianCalendar value) {
        this.modifiedDate = value;
    }

    /**
     * Gets the value of the primaryKey property.
     * 
     */
    public long getPrimaryKey() {
        return primaryKey;
    }

    /**
     * Sets the value of the primaryKey property.
     * 
     */
    public void setPrimaryKey(long value) {
        this.primaryKey = value;
    }

    /**
     * Gets the value of the resourcePrimKey property.
     * 
     */
    public long getResourcePrimKey() {
        return resourcePrimKey;
    }

    /**
     * Sets the value of the resourcePrimKey property.
     * 
     */
    public void setResourcePrimKey(long value) {
        this.resourcePrimKey = value;
    }

    /**
     * Gets the value of the reviewDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReviewDate() {
        return reviewDate;
    }

    /**
     * Sets the value of the reviewDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReviewDate(XMLGregorianCalendar value) {
        this.reviewDate = value;
    }

    /**
     * Gets the value of the smallImage property.
     * 
     */
    public boolean isSmallImage() {
        return smallImage;
    }

    /**
     * Sets the value of the smallImage property.
     * 
     */
    public void setSmallImage(boolean value) {
        this.smallImage = value;
    }

    /**
     * Gets the value of the smallImageId property.
     * 
     */
    public long getSmallImageId() {
        return smallImageId;
    }

    /**
     * Sets the value of the smallImageId property.
     * 
     */
    public void setSmallImageId(long value) {
        this.smallImageId = value;
    }

    /**
     * Gets the value of the smallImageURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSmallImageURL() {
        return smallImageURL;
    }

    /**
     * Sets the value of the smallImageURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSmallImageURL(String value) {
        this.smallImageURL = value;
    }

    /**
     * Gets the value of the status property.
     * 
     */
    public int getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     */
    public void setStatus(int value) {
        this.status = value;
    }

    /**
     * Gets the value of the statusByUserId property.
     * 
     */
    public long getStatusByUserId() {
        return statusByUserId;
    }

    /**
     * Sets the value of the statusByUserId property.
     * 
     */
    public void setStatusByUserId(long value) {
        this.statusByUserId = value;
    }

    /**
     * Gets the value of the statusByUserName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusByUserName() {
        return statusByUserName;
    }

    /**
     * Sets the value of the statusByUserName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusByUserName(String value) {
        this.statusByUserName = value;
    }

    /**
     * Gets the value of the statusDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStatusDate() {
        return statusDate;
    }

    /**
     * Sets the value of the statusDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStatusDate(XMLGregorianCalendar value) {
        this.statusDate = value;
    }

    /**
     * Gets the value of the structureId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStructureId() {
        return structureId;
    }

    /**
     * Sets the value of the structureId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStructureId(String value) {
        this.structureId = value;
    }

    /**
     * Gets the value of the templateId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateId() {
        return templateId;
    }

    /**
     * Sets the value of the templateId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateId(String value) {
        this.templateId = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the urlTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUrlTitle() {
        return urlTitle;
    }

    /**
     * Sets the value of the urlTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUrlTitle(String value) {
        this.urlTitle = value;
    }

    /**
     * Gets the value of the userId property.
     * 
     */
    public long getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     */
    public void setUserId(long value) {
        this.userId = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the version property.
     * 
     */
    public double getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     */
    public void setVersion(double value) {
        this.version = value;
    }

}

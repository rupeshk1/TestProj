package com.techmahindra.online.svallo.integration.payment.processor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class DateProcessor implements Processor
{

	private static String CPW_DATE_FORMAT = "yyyy-MM-dd'Z'";

	@Override
	public void process(Exchange exchange) throws Exception
	{
		try
		{
			System.out.println("[DateProcessor.java | process ()]");
			if (exchange.getIn().getHeader("takeABreakDaysAfterContractValue") != null && exchange.getIn().getHeader("contractStartDate") != null)
			{
				exchange.getIn().setHeader("isDateCheckPassed", "false");
				String takeABreakDaysAfterContractValue = (String) exchange.getIn().getHeader("takeABreakDaysAfterContractValue");
				String contractStartDate = (String) exchange.getIn().getHeader("contractStartDate");
				
				System.out.println("[DateProcessor.java | process ()] takeABreakDaysAfterContractValue >>>> "+takeABreakDaysAfterContractValue);
				System.out.println("[DateProcessor.java | process ()] contractStartDate >>>> "+contractStartDate);
				
				if(takeABreakDaysAfterContractValue.trim().length()>0 && contractStartDate.trim().length()>0)
				{
					System.out.println("[DateProcessor.java | process ()] takeABreakDaysAfterContractValue >>>> "+takeABreakDaysAfterContractValue);
					System.out.println("[DateProcessor.java | process ()] contractStartDate >>>> "+contractStartDate);
					
					long takeABreakDays = Long.parseLong(takeABreakDaysAfterContractValue);
					System.out.println("[DateProcessor.java | process ()] takeABreakDays >>>> "+takeABreakDays);
					long daysDifference = getDateDifference(contractStartDate);
					System.out.println("[DateProcessor.java | process ()] daysDifference >>> " + daysDifference);
		
					if (daysDifference > takeABreakDays)
					{
						exchange.getIn().setHeader("isDateCheckPassed", "true");
						System.out.println("[DateProcessor.java | process ()] isDateCheckPassed >>> " + "true");
					} 
					else
					{
						exchange.getIn().setHeader("isDateCheckPassed", "false");
						System.out.println("[DateProcessor.java | process ()] isDateCheckPassed >>> " + "false");
					}
					System.out.println("\n\n[DateProcessor.java | process() ] takeABreakDaysAfterContractValue >" + takeABreakDaysAfterContractValue);
					System.out.println("\n\n[DateProcessor.java | process() ] contractStartDate >" + contractStartDate);
				}	
			}
		}
		catch (ParseException exception)
		{
			exchange.getIn().setHeader("isDateCheckPassed", "false");
			System.out.println("\n[ DateProcessor | process() ] ParseException Catch Block ");
			System.out.println("\n[ DateProcessor | process() ] ParseException Catch Block | Error Code =  " + "I_TAB_0006");
			System.out.println("\n[ DateProcessor | process() ] ParseException Catch Block | Error Message  =  " + "Erro in getDateDifference method of DateProcessor");
			throw exception;
		}
		catch (Exception exception)
		{
			exchange.getIn().setHeader("isDateCheckPassed", "false");
			System.out.println("\n[ DateProcessor | process() ] Exception Catch Block ");
			System.out.println("\n[ DateProcessor | process() ] Exception Catch Block | Error Code =  " + "I_TAB_0006");
			System.out.println("\n[ DateProcessor | process() ] Exception Catch Block | Error Message  =  " + "Erro in process method of DateProcessor");
		}
	}

	private static long getDateDifference(String contractStartDate) throws ParseException
	{
		long daysDifference = -1;

		try
		{
			SimpleDateFormat cpwDateFormat = new SimpleDateFormat(CPW_DATE_FORMAT);
			Date date3 = cpwDateFormat.parse(contractStartDate);
			long currentTime = System.currentTimeMillis();
			long diff = currentTime - date3.getTime();
			daysDifference = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		}
		catch (ParseException exception)
		{
			System.out.println("\n[ DateProcessor | getDateDifference() ] Exception Catch Block ");
			System.out.println("\n[ DateProcessor | getDateDifference() ] Exception Catch Block | Error Code =  " + "I_TAB_0007");
			System.out.println("\n[ DateProcessor | getDateDifference() ] Exception Catch Block | Error Message  =  " + "Erro in getDateDifference method of DateProcessor");
			throw exception;
		}
		return daysDifference;
	}

}

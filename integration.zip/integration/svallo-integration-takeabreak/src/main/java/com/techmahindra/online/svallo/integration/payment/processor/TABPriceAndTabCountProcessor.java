package com.techmahindra.online.svallo.integration.payment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class TABPriceAndTabCountProcessor implements Processor
{

	@Override
	public void process(Exchange exchange) throws Exception
	{
		String serviceCodeList = (String) exchange.getIn().getHeader("serviceCodeList");
		String takeABreakServiceCodeValue = (String) exchange.getIn().getHeader("takeABreakServiceCodeValue");
		String mrcServiceSum = (String) exchange.getIn().getHeader("mrcServiceSum");
		String takeABreakValue = (String) exchange.getIn().getHeader("takeABreakValue");
		

		System.out.println("\n\n[TABPriceAndTabCountProcessor.java | process() ] mrcServiceSum >>>>" + mrcServiceSum);
		System.out.println("[TABPriceAndTabCountProcessor.java | process() ] serviceCodeList >>>> " + serviceCodeList);
		System.out.println("[TABPriceAndTabCountProcessor.java | process() ] takeABreakServiceCodeValue >>>> " + takeABreakServiceCodeValue);
		System.out.println("[TABPriceAndTabCountProcessor.java | process() ] takeABreakValue >>>> " + takeABreakValue);
		
		try
		{
			exchange.getIn().setHeader("tabPriceAndTabCountProcessorCheck", "true");
			exchange.getIn().setHeader("finalTotalMrcServiceSum", mrcServiceSum);
			boolean isTakeABreakServiceCodeValuePresentInServiceCodeList = false;
			if (serviceCodeList != null && serviceCodeList.length() > 0)
			{
				String[] serviceCodes = serviceCodeList.split("##");
				if (serviceCodes != null && serviceCodes.length > 0)
				{
					for (int i = 0; i < serviceCodes.length; i++)
					{
						String serviceCode = serviceCodes[i];
						System.out.println("serviceCode >>>>> "+serviceCode);
						if (serviceCode != null && serviceCode.indexOf(takeABreakServiceCodeValue) != -1)
						{
							isTakeABreakServiceCodeValuePresentInServiceCodeList=true;
							int takeABreakServiceCodeValueStrLength = takeABreakServiceCodeValue.length();
							System.out.println("\n\n[TABPriceAndTabCountProcessor.java | process() ] takeABreakServiceCodeValueStrLength >>>> " + takeABreakServiceCodeValueStrLength);
							String takeABreakServiceCodePrice = serviceCode.substring(takeABreakServiceCodeValueStrLength);
							System.out.println("\n\n[TABPriceAndTabCountProcessor.java | process() ] takeABreakServiceCodePrice >>>> " + takeABreakServiceCodePrice);
							
							float totalMrcServiceSum = Float.parseFloat(mrcServiceSum);
							float tabCodePrice = Float.parseFloat(takeABreakServiceCodePrice);
							
							float serviceSum = totalMrcServiceSum-tabCodePrice;
							
							String finalTotalMrcServiceSum = String.valueOf(serviceSum);
							if(finalTotalMrcServiceSum!=null && finalTotalMrcServiceSum.trim().length()>0)
							{
								System.out.println("\n\n[TABPriceAndTabCountProcessor.java | process() , tabPriceAndTabCountProcessorCheck is true ]");
								//exchange.getIn().setHeader("finalTotalMrcServiceSum", finalTotalMrcServiceSum);
							}
							
							System.out.println("\n\n[TABPriceAndTabCountProcessor.java | process() ] finalTotalMrcServiceSum >>>> " + finalTotalMrcServiceSum);
						}
					}
				}
				
			}
			if(isTakeABreakServiceCodeValuePresentInServiceCodeList==true)
			{
				System.out.println("n[ TABPriceAndTabCountProcessor.java | process() ] Inside Else. takeABreakServiceCodeValue is present in serviceCodeList");
			}
			else
			{
				System.out.println("n[ TABPriceAndTabCountProcessor.java | process() ] Inside Else. takeABreakServiceCodeValue is not present in serviceCodeList");
			}
			if(takeABreakValue!=null && takeABreakValue.length()>0)
			{
				int takeABreakVal = Integer.parseInt(takeABreakValue);
				takeABreakVal = takeABreakVal-1;
				System.out.println("\n\n[TABPriceAndTabCountProcessor.java | process() ] finalTakeABreakValue >>>> " + takeABreakVal);
				exchange.getIn().setHeader("finalTakeABreakValue", String.valueOf(takeABreakVal));
				exchange.getIn().setHeader("takeABreakValue", String.valueOf(takeABreakVal));
			}
		}
		catch (Exception exception)
		{
			exchange.getIn().setHeader("tabPriceAndTabCountProcessorCheck", "false");
			System.out.println("\n[ TABPriceAndTabCountProcessor.java | process() ] Exception Catch Block ");
			System.out.println("\n[ TABPriceAndTabCountProcessor.java | process() ] Exception Catch Block | Error Code =  " + "I_TAB_0002");
			System.out.println("\n[ TABPriceAndTabCountProcessor.java | process() ] Exception Catch Block | Error Message  =  " + "Error in Process of TABPriceAndTabCountProcessor");
		}

	}

}


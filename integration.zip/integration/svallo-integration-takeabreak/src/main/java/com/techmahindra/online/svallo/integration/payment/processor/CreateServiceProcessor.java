package com.techmahindra.online.svallo.integration.payment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class CreateServiceProcessor implements Processor
{

	@Override
	public void process(Exchange exchange) throws Exception
	{
		String subscriptionNumberReq = (String) exchange.getIn().getHeader("subscriptionNumberReq");
		

		System.out.println("\n\n[CreateServiceProcessor.java | process() ] subscriptionNumberReq >>>>" + subscriptionNumberReq);
		
		try
		{
			if (subscriptionNumberReq != null && subscriptionNumberReq.length() >0)
			{
				String[] subscriptionNumberReqArry = subscriptionNumberReq.split("#");
				if (subscriptionNumberReqArry != null && subscriptionNumberReqArry.length > 0)
				{
					String subscriptionNumberReqVal = subscriptionNumberReqArry[0];
					String takeABreakCounterValue = subscriptionNumberReqArry[1];
					System.out.println("\n\n[CreateServiceProcessor.java | process() ] subscriptionNumberReqVal >>>>" + subscriptionNumberReqVal);
					System.out.println("\n\n[CreateServiceProcessor.java | process() ] takeABreakCounterValue >>>>" + takeABreakCounterValue);
					
					exchange.getIn().setHeader("subscriptionNumberReqVal", subscriptionNumberReqVal);
					exchange.getIn().setHeader("takeABreakCounterValue", takeABreakCounterValue);
				}
				
			}
			
		}
		catch (Exception exception)
		{
			System.out.println("\n[ CreateServiceProcessor.java | process() ] Exception Catch Block ");
			System.out.println("\n[ CreateServiceProcessor.java | process() ] Exception Catch Block | Error Code =  " + "I_TAB_0002");
			System.out.println("\n[ CreateServiceProcessor.java | process() ] Exception Catch Block | Error Message  =  " + "Error in Process of CreateServiceProcessor");
		}

	}

}


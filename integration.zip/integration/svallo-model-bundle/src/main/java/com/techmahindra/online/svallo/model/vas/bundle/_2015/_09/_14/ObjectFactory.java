
package com.techmahindra.online.svallo.model.vas.bundle._2015._09._14;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.techmahindra.online.svallo.model.vas.bundle._2015._09._14 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _QueryBundleResponse_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", "queryBundleResponse");
    private final static QName _UpdateBundleResponse_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", "updateBundleResponse");
    private final static QName _UpdateBundleRequest_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", "updateBundleRequest");
    private final static QName _QueryBundleRequest_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", "queryBundleRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.techmahindra.online.svallo.model.vas.bundle._2015._09._14
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Service }
     * 
     */
    public Service createService() {
        return new Service();
    }

    /**
     * Create an instance of {@link Account }
     * 
     */
    public Account createAccount() {
        return new Account();
    }

    /**
     * Create an instance of {@link UpdateBundleRequest }
     * 
     */
    public UpdateBundleRequest createUpdateBundleRequest() {
        return new UpdateBundleRequest();
    }

    /**
     * Create an instance of {@link QueryBundleResponse }
     * 
     */
    public QueryBundleResponse createQueryBundleResponse() {
        return new QueryBundleResponse();
    }

    /**
     * Create an instance of {@link Bundle }
     * 
     */
    public Bundle createBundle() {
        return new Bundle();
    }

    /**
     * Create an instance of {@link UpdateBundleResponse }
     * 
     */
    public UpdateBundleResponse createUpdateBundleResponse() {
        return new UpdateBundleResponse();
    }

    /**
     * Create an instance of {@link ExistingBundle }
     * 
     */
    public ExistingBundle createExistingBundle() {
        return new ExistingBundle();
    }

    /**
     * Create an instance of {@link QueryBundleRequest }
     * 
     */
    public QueryBundleRequest createQueryBundleRequest() {
        return new QueryBundleRequest();
    }

    /**
     * Create an instance of {@link Customer }
     * 
     */
    public Customer createCustomer() {
        return new Customer();
    }

    /**
     * Create an instance of {@link PendingBundle }
     * 
     */
    public PendingBundle createPendingBundle() {
        return new PendingBundle();
    }

    /**
     * Create an instance of {@link CustomerSubscriptionInfo }
     * 
     */
    public CustomerSubscriptionInfo createCustomerSubscriptionInfo() {
        return new CustomerSubscriptionInfo();
    }

    /**
     * Create an instance of {@link ApplicableBundle }
     * 
     */
    public ApplicableBundle createApplicableBundle() {
        return new ApplicableBundle();
    }

    /**
     * Create an instance of {@link Subscription }
     * 
     */
    public Subscription createSubscription() {
        return new Subscription();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBundleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", name = "queryBundleResponse")
    public JAXBElement<QueryBundleResponse> createQueryBundleResponse(QueryBundleResponse value) {
        return new JAXBElement<QueryBundleResponse>(_QueryBundleResponse_QNAME, QueryBundleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateBundleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", name = "updateBundleResponse")
    public JAXBElement<UpdateBundleResponse> createUpdateBundleResponse(UpdateBundleResponse value) {
        return new JAXBElement<UpdateBundleResponse>(_UpdateBundleResponse_QNAME, UpdateBundleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateBundleRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", name = "updateBundleRequest")
    public JAXBElement<UpdateBundleRequest> createUpdateBundleRequest(UpdateBundleRequest value) {
        return new JAXBElement<UpdateBundleRequest>(_UpdateBundleRequest_QNAME, UpdateBundleRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryBundleRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14", name = "queryBundleRequest")
    public JAXBElement<QueryBundleRequest> createQueryBundleRequest(QueryBundleRequest value) {
        return new JAXBElement<QueryBundleRequest>(_QueryBundleRequest_QNAME, QueryBundleRequest.class, null, value);
    }

}

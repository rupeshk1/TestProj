@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14")
package com.techmahindra.online.svallo.model.vas.bundle._2015._09._14;


package com.techmahindra.online.svallo.model.vas.bundle._2015._09._14;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.techmahindra.online.svallo.model.common._2015._09._14.Header;


/**
 * <p>Java class for queryBundleResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="queryBundleResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="customerSubscriptionInfo" type="{http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14}customerSubscriptionInfo" minOccurs="0"/>
 *         &lt;element name="header" type="{http://online.techmahindra.com/svallo/model/common/2015/09/14}Header" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryBundleResponse", propOrder = {
    "customerSubscriptionInfo",
    "header"
})
public class QueryBundleResponse {

    protected CustomerSubscriptionInfo customerSubscriptionInfo;
    protected Header header;

    /**
     * Gets the value of the customerSubscriptionInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerSubscriptionInfo }
     *     
     */
    public CustomerSubscriptionInfo getCustomerSubscriptionInfo() {
        return customerSubscriptionInfo;
    }

    /**
     * Sets the value of the customerSubscriptionInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerSubscriptionInfo }
     *     
     */
    public void setCustomerSubscriptionInfo(CustomerSubscriptionInfo value) {
        this.customerSubscriptionInfo = value;
    }

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

}


package com.techmahindra.online.svallo.model.vas.bundle._2015._09._14;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for service complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="service">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicableBundle" type="{http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14}applicableBundle" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="effectiveDate" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" minOccurs="0"/>
 *         &lt;element name="existingBundle" type="{http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14}existingBundle" minOccurs="0"/>
 *         &lt;element name="serviceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="servicePrice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pendingBundle" type="{http://online.techmahindra.com/svallo/model/vas/bundle/2015/09/14}pendingBundle" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "service", propOrder = {
    "applicableBundle",
    "description",
    "effectiveDate",
    "existingBundle",
    "serviceCode",
    "servicePrice",
    "pendingBundle"
})
public class Service {

    protected ApplicableBundle applicableBundle;
    protected String description;
    @XmlSchemaType(name = "anySimpleType")
    protected Object effectiveDate;
    protected ExistingBundle existingBundle;
    protected String serviceCode;
    protected String servicePrice;
    protected PendingBundle pendingBundle;

    /**
     * Gets the value of the applicableBundle property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicableBundle }
     *     
     */
    public ApplicableBundle getApplicableBundle() {
        return applicableBundle;
    }

    /**
     * Sets the value of the applicableBundle property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicableBundle }
     *     
     */
    public void setApplicableBundle(ApplicableBundle value) {
        this.applicableBundle = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setEffectiveDate(Object value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the existingBundle property.
     * 
     * @return
     *     possible object is
     *     {@link ExistingBundle }
     *     
     */
    public ExistingBundle getExistingBundle() {
        return existingBundle;
    }

    /**
     * Sets the value of the existingBundle property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExistingBundle }
     *     
     */
    public void setExistingBundle(ExistingBundle value) {
        this.existingBundle = value;
    }

    /**
     * Gets the value of the serviceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Sets the value of the serviceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCode(String value) {
        this.serviceCode = value;
    }

    /**
     * Gets the value of the servicePrice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePrice() {
        return servicePrice;
    }

    /**
     * Sets the value of the servicePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePrice(String value) {
        this.servicePrice = value;
    }

    /**
     * Gets the value of the pendingBundle property.
     * 
     * @return
     *     possible object is
     *     {@link PendingBundle }
     *     
     */
    public PendingBundle getPendingBundle() {
        return pendingBundle;
    }

    /**
     * Sets the value of the pendingBundle property.
     * 
     * @param value
     *     allowed object is
     *     {@link PendingBundle }
     *     
     */
    public void setPendingBundle(PendingBundle value) {
        this.pendingBundle = value;
    }

}

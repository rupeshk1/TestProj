@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28")
package com.techmahindra.online.svallo.model.vas.addon._2014._08._28;

@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/common/2014/08/28")
package com.techmahindra.online.svallo.model.common._2014._08._28;


package com.techmahindra.online.svallo.model.vas.addon._2014._08._28;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rolloverAddon complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="rolloverAddon">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dataRolloverAddon" type="{http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28}addon" minOccurs="0"/>
 *         &lt;element name="minsRolloverAddon" type="{http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28}addon" minOccurs="0"/>
 *         &lt;element name="textsRolloverAddon" type="{http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28}addon" minOccurs="0"/>
 *         &lt;element name="dataRolloverPackageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="textsRolloverPackageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="minsRolloverPackageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rolloverAddon", propOrder = {
    "dataRolloverAddon",
    "minsRolloverAddon",
    "textsRolloverAddon",
    "dataRolloverPackageCode",
    "textsRolloverPackageCode",
    "minsRolloverPackageCode"
})
public class RolloverAddon {

    @XmlElementRef(name = "dataRolloverAddon", type = JAXBElement.class)
    protected JAXBElement<Addon> dataRolloverAddon;
    @XmlElementRef(name = "minsRolloverAddon", type = JAXBElement.class)
    protected JAXBElement<Addon> minsRolloverAddon;
    @XmlElementRef(name = "textsRolloverAddon", type = JAXBElement.class)
    protected JAXBElement<Addon> textsRolloverAddon;
    protected String dataRolloverPackageCode;
    protected String textsRolloverPackageCode;
    protected String minsRolloverPackageCode;

    /**
     * Gets the value of the dataRolloverAddon property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Addon }{@code >}
     *     
     */
    public JAXBElement<Addon> getDataRolloverAddon() {
        return dataRolloverAddon;
    }

    /**
     * Sets the value of the dataRolloverAddon property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Addon }{@code >}
     *     
     */
    public void setDataRolloverAddon(JAXBElement<Addon> value) {
        this.dataRolloverAddon = ((JAXBElement<Addon> ) value);
    }

    /**
     * Gets the value of the minsRolloverAddon property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Addon }{@code >}
     *     
     */
    public JAXBElement<Addon> getMinsRolloverAddon() {
        return minsRolloverAddon;
    }

    /**
     * Sets the value of the minsRolloverAddon property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Addon }{@code >}
     *     
     */
    public void setMinsRolloverAddon(JAXBElement<Addon> value) {
        this.minsRolloverAddon = ((JAXBElement<Addon> ) value);
    }

    /**
     * Gets the value of the textsRolloverAddon property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Addon }{@code >}
     *     
     */
    public JAXBElement<Addon> getTextsRolloverAddon() {
        return textsRolloverAddon;
    }

    /**
     * Sets the value of the textsRolloverAddon property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Addon }{@code >}
     *     
     */
    public void setTextsRolloverAddon(JAXBElement<Addon> value) {
        this.textsRolloverAddon = ((JAXBElement<Addon> ) value);
    }

    /**
     * Gets the value of the dataRolloverPackageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataRolloverPackageCode() {
        return dataRolloverPackageCode;
    }

    /**
     * Sets the value of the dataRolloverPackageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataRolloverPackageCode(String value) {
        this.dataRolloverPackageCode = value;
    }

    /**
     * Gets the value of the textsRolloverPackageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTextsRolloverPackageCode() {
        return textsRolloverPackageCode;
    }

    /**
     * Sets the value of the textsRolloverPackageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTextsRolloverPackageCode(String value) {
        this.textsRolloverPackageCode = value;
    }

    /**
     * Gets the value of the minsRolloverPackageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinsRolloverPackageCode() {
        return minsRolloverPackageCode;
    }

    /**
     * Sets the value of the minsRolloverPackageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinsRolloverPackageCode(String value) {
        this.minsRolloverPackageCode = value;
    }

}

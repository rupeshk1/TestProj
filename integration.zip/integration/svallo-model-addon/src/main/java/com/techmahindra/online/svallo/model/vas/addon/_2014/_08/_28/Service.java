
package com.techmahindra.online.svallo.model.vas.addon._2014._08._28;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for service complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="service">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicableAddon" type="{http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28}applicableAddon" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="effectiveDate" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" minOccurs="0"/>
 *         &lt;element name="existingAddon" type="{http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28}existingAddon" minOccurs="0"/>
 *         &lt;element name="serviceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="servicePrice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pendingAddon" type="{http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28}pendingAddon" minOccurs="0"/>
 *         &lt;element name="rolloverAddon" type="{http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28}rolloverAddon" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "service", propOrder = {
    "applicableAddon",
    "description",
    "effectiveDate",
    "existingAddon",
    "serviceCode",
    "servicePrice",
    "pendingAddon",
    "rolloverAddon"
})
public class Service {

    protected ApplicableAddon applicableAddon;
    protected String description;
    @XmlSchemaType(name = "anySimpleType")
    protected Object effectiveDate;
    protected ExistingAddon existingAddon;
    protected String serviceCode;
    protected String servicePrice;
    protected PendingAddon pendingAddon;
    protected RolloverAddon rolloverAddon;

    /**
     * Gets the value of the applicableAddon property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicableAddon }
     *     
     */
    public ApplicableAddon getApplicableAddon() {
        return applicableAddon;
    }

    /**
     * Sets the value of the applicableAddon property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicableAddon }
     *     
     */
    public void setApplicableAddon(ApplicableAddon value) {
        this.applicableAddon = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setEffectiveDate(Object value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the existingAddon property.
     * 
     * @return
     *     possible object is
     *     {@link ExistingAddon }
     *     
     */
    public ExistingAddon getExistingAddon() {
        return existingAddon;
    }

    /**
     * Sets the value of the existingAddon property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExistingAddon }
     *     
     */
    public void setExistingAddon(ExistingAddon value) {
        this.existingAddon = value;
    }

    /**
     * Gets the value of the serviceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Sets the value of the serviceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCode(String value) {
        this.serviceCode = value;
    }

    /**
     * Gets the value of the servicePrice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePrice() {
        return servicePrice;
    }

    /**
     * Sets the value of the servicePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePrice(String value) {
        this.servicePrice = value;
    }

    /**
     * Gets the value of the pendingAddon property.
     * 
     * @return
     *     possible object is
     *     {@link PendingAddon }
     *     
     */
    public PendingAddon getPendingAddon() {
        return pendingAddon;
    }

    /**
     * Sets the value of the pendingAddon property.
     * 
     * @param value
     *     allowed object is
     *     {@link PendingAddon }
     *     
     */
    public void setPendingAddon(PendingAddon value) {
        this.pendingAddon = value;
    }

    /**
     * Gets the value of the rolloverAddon property.
     * 
     * @return
     *     possible object is
     *     {@link RolloverAddon }
     *     
     */
    public RolloverAddon getRolloverAddon() {
        return rolloverAddon;
    }

    /**
     * Sets the value of the rolloverAddon property.
     * 
     * @param value
     *     allowed object is
     *     {@link RolloverAddon }
     *     
     */
    public void setRolloverAddon(RolloverAddon value) {
        this.rolloverAddon = value;
    }

}

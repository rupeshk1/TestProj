
package com.techmahindra.online.svallo.model.common._2014._08._28;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Header complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Header">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="responseStatus" type="{http://online.techmahindra.com/svallo/model/common/2014/08/28}ResponseStatus"/>
 *         &lt;element name="transactionTrace" type="{http://online.techmahindra.com/svallo/model/common/2014/08/28}TransactionTrace"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Header", propOrder = {
    "responseStatus",
    "transactionTrace"
})
public class Header {

    @XmlElement(required = true)
    protected ResponseStatus responseStatus;
    @XmlElement(required = true)
    protected TransactionTrace transactionTrace;

    /**
     * Gets the value of the responseStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ResponseStatus }
     *     
     */
    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    /**
     * Sets the value of the responseStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseStatus }
     *     
     */
    public void setResponseStatus(ResponseStatus value) {
        this.responseStatus = value;
    }

    /**
     * Gets the value of the transactionTrace property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionTrace }
     *     
     */
    public TransactionTrace getTransactionTrace() {
        return transactionTrace;
    }

    /**
     * Sets the value of the transactionTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionTrace }
     *     
     */
    public void setTransactionTrace(TransactionTrace value) {
        this.transactionTrace = value;
    }

}

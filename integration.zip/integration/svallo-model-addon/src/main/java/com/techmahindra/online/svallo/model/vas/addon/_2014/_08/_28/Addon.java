
package com.techmahindra.online.svallo.model.vas.addon._2014._08._28;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for addon complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="addon">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="crossSellCategoryId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="crossSellCategoryName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productDisplayPriority" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="productId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productImageUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productLongDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productPrice" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="productType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="startDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stopDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addonServicePrice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recurring" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rolloverApplicable" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="minutes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="texts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="data" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="days" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cscname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addonEffectiveDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="expiryDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addonAvailableAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addonLastGrantAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addonBalanceAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cancelbuttonValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reloadMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "addon", propOrder = {
    "crossSellCategoryId",
    "crossSellCategoryName",
    "productDescription",
    "productDisplayPriority",
    "productId",
    "productImageUrl",
    "productLongDescription",
    "productName",
    "productPrice",
    "productType",
    "startDate",
    "stopDate",
    "addonServicePrice",
    "recurring",
    "rolloverApplicable",
    "minutes",
    "texts",
    "data",
    "days",
    "cscname",
    "addonEffectiveDate",
    "expiryDate",
    "addonAvailableAmount",
    "addonLastGrantAmount",
    "addonBalanceAmount",
    "cancelbuttonValue",
    "reloadMethod"
})
public class Addon {

    protected String crossSellCategoryId;
    protected String crossSellCategoryName;
    protected String productDescription;
    protected long productDisplayPriority;
    protected String productId;
    protected String productImageUrl;
    protected String productLongDescription;
    protected String productName;
    protected double productPrice;
    protected String productType;
    protected String startDate;
    protected String stopDate;
    protected String addonServicePrice;
    protected String recurring;
    protected String rolloverApplicable;
    protected String minutes;
    protected String texts;
    protected String data;
    protected String days;
    protected String cscname;
    protected String addonEffectiveDate;
    protected String expiryDate;
    protected String addonAvailableAmount;
    protected String addonLastGrantAmount;
    protected String addonBalanceAmount;
    protected String cancelbuttonValue;
    protected String reloadMethod;

    public String getReloadMethod() {
		return reloadMethod;
	}

	public void setReloadMethod(String reloadMethod) {
		this.reloadMethod = reloadMethod;
	}

	/**
     * Gets the value of the crossSellCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCrossSellCategoryId() {
        return crossSellCategoryId;
    }

    /**
     * Sets the value of the crossSellCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCrossSellCategoryId(String value) {
        this.crossSellCategoryId = value;
    }

    /**
     * Gets the value of the crossSellCategoryName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCrossSellCategoryName() {
        return crossSellCategoryName;
    }

    /**
     * Sets the value of the crossSellCategoryName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCrossSellCategoryName(String value) {
        this.crossSellCategoryName = value;
    }

    /**
     * Gets the value of the productDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductDescription() {
        return productDescription;
    }

    /**
     * Sets the value of the productDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductDescription(String value) {
        this.productDescription = value;
    }

    /**
     * Gets the value of the productDisplayPriority property.
     * 
     */
    public long getProductDisplayPriority() {
        return productDisplayPriority;
    }

    /**
     * Sets the value of the productDisplayPriority property.
     * 
     */
    public void setProductDisplayPriority(long value) {
        this.productDisplayPriority = value;
    }

    /**
     * Gets the value of the productId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the value of the productId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductId(String value) {
        this.productId = value;
    }

    /**
     * Gets the value of the productImageUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductImageUrl() {
        return productImageUrl;
    }

    /**
     * Sets the value of the productImageUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductImageUrl(String value) {
        this.productImageUrl = value;
    }

    /**
     * Gets the value of the productLongDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductLongDescription() {
        return productLongDescription;
    }

    /**
     * Sets the value of the productLongDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductLongDescription(String value) {
        this.productLongDescription = value;
    }

    /**
     * Gets the value of the productName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the productName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductName(String value) {
        this.productName = value;
    }

    /**
     * Gets the value of the productPrice property.
     * 
     */
    public double getProductPrice() {
        return productPrice;
    }

    /**
     * Sets the value of the productPrice property.
     * 
     */
    public void setProductPrice(double value) {
        this.productPrice = value;
    }

    /**
     * Gets the value of the productType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductType() {
        return productType;
    }

    /**
     * Sets the value of the productType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductType(String value) {
        this.productType = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDate(String value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the stopDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStopDate() {
        return stopDate;
    }

    /**
     * Sets the value of the stopDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStopDate(String value) {
        this.stopDate = value;
    }

    /**
     * Gets the value of the addonServicePrice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddonServicePrice() {
        return addonServicePrice;
    }

    /**
     * Sets the value of the addonServicePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddonServicePrice(String value) {
        this.addonServicePrice = value;
    }

    /**
     * Gets the value of the recurring property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecurring() {
        return recurring;
    }

    /**
     * Sets the value of the recurring property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecurring(String value) {
        this.recurring = value;
    }

    /**
     * Gets the value of the rolloverApplicable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRolloverApplicable() {
        return rolloverApplicable;
    }

    /**
     * Sets the value of the rolloverApplicable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRolloverApplicable(String value) {
        this.rolloverApplicable = value;
    }

    /**
     * Gets the value of the minutes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinutes() {
        return minutes;
    }

    /**
     * Sets the value of the minutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinutes(String value) {
        this.minutes = value;
    }

    /**
     * Gets the value of the texts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTexts() {
        return texts;
    }

    /**
     * Sets the value of the texts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTexts(String value) {
        this.texts = value;
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setData(String value) {
        this.data = value;
    }

    /**
     * Gets the value of the days property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDays() {
        return days;
    }

    /**
     * Sets the value of the days property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDays(String value) {
        this.days = value;
    }

    /**
     * Gets the value of the cscname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCscname() {
        return cscname;
    }

    /**
     * Sets the value of the cscname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCscname(String value) {
        this.cscname = value;
    }

    /**
     * Gets the value of the addonEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddonEffectiveDate() {
        return addonEffectiveDate;
    }

    /**
     * Sets the value of the addonEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddonEffectiveDate(String value) {
        this.addonEffectiveDate = value;
    }

    /**
     * Gets the value of the expiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the value of the expiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpiryDate(String value) {
        this.expiryDate = value;
    }

    /**
     * Gets the value of the addonAvailableAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddonAvailableAmount() {
        return addonAvailableAmount;
    }

    /**
     * Sets the value of the addonAvailableAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddonAvailableAmount(String value) {
        this.addonAvailableAmount = value;
    }

    /**
     * Gets the value of the addonLastGrantAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddonLastGrantAmount() {
        return addonLastGrantAmount;
    }

    /**
     * Sets the value of the addonLastGrantAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddonLastGrantAmount(String value) {
        this.addonLastGrantAmount = value;
    }

    /**
     * Gets the value of the addonBalanceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddonBalanceAmount() {
        return addonBalanceAmount;
    }

    /**
     * Sets the value of the addonBalanceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddonBalanceAmount(String value) {
        this.addonBalanceAmount = value;
    }

    /**
     * Gets the value of the cancelbuttonValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelbuttonValue() {
        return cancelbuttonValue;
    }

    /**
     * Sets the value of the cancelbuttonValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelbuttonValue(String value) {
        this.cancelbuttonValue = value;
    }

}

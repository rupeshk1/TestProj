
package com.techmahindra.online.svallo.model.vas.addon._2014._08._28;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.techmahindra.online.svallo.model.vas.addon._2014._08._28 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _QueryAddonResponse_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", "queryAddonResponse");
    private final static QName _UpdateAddonRequest_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", "updateAddonRequest");
    private final static QName _UpdateAddonResponse_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", "updateAddonResponse");
    private final static QName _QueryAddonRequest_QNAME = new QName("http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", "queryAddonRequest");
    private final static QName _RolloverAddonDataRolloverAddon_QNAME = new QName("", "dataRolloverAddon");
    private final static QName _RolloverAddonTextsRolloverAddon_QNAME = new QName("", "textsRolloverAddon");
    private final static QName _RolloverAddonMinsRolloverAddon_QNAME = new QName("", "minsRolloverAddon");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.techmahindra.online.svallo.model.vas.addon._2014._08._28
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PendingAddon }
     * 
     */
    public PendingAddon createPendingAddon() {
        return new PendingAddon();
    }

    /**
     * Create an instance of {@link Customer }
     * 
     */
    public Customer createCustomer() {
        return new Customer();
    }

    /**
     * Create an instance of {@link Addon }
     * 
     */
    public Addon createAddon() {
        return new Addon();
    }

    /**
     * Create an instance of {@link QueryAddonRequest }
     * 
     */
    public QueryAddonRequest createQueryAddonRequest() {
        return new QueryAddonRequest();
    }

    /**
     * Create an instance of {@link UpdateAddonResponse }
     * 
     */
    public UpdateAddonResponse createUpdateAddonResponse() {
        return new UpdateAddonResponse();
    }

    /**
     * Create an instance of {@link Subscription }
     * 
     */
    public Subscription createSubscription() {
        return new Subscription();
    }

    /**
     * Create an instance of {@link QueryAddonResponse }
     * 
     */
    public QueryAddonResponse createQueryAddonResponse() {
        return new QueryAddonResponse();
    }

    /**
     * Create an instance of {@link Account }
     * 
     */
    public Account createAccount() {
        return new Account();
    }

    /**
     * Create an instance of {@link RolloverAddon }
     * 
     */
    public RolloverAddon createRolloverAddon() {
        return new RolloverAddon();
    }

    /**
     * Create an instance of {@link Service }
     * 
     */
    public Service createService() {
        return new Service();
    }

    /**
     * Create an instance of {@link CustomerSubscriptionInfo }
     * 
     */
    public CustomerSubscriptionInfo createCustomerSubscriptionInfo() {
        return new CustomerSubscriptionInfo();
    }

    /**
     * Create an instance of {@link ApplicableAddon }
     * 
     */
    public ApplicableAddon createApplicableAddon() {
        return new ApplicableAddon();
    }

    /**
     * Create an instance of {@link UpdateAddonRequest }
     * 
     */
    public UpdateAddonRequest createUpdateAddonRequest() {
        return new UpdateAddonRequest();
    }

    /**
     * Create an instance of {@link ExistingAddon }
     * 
     */
    public ExistingAddon createExistingAddon() {
        return new ExistingAddon();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryAddonResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", name = "queryAddonResponse")
    public JAXBElement<QueryAddonResponse> createQueryAddonResponse(QueryAddonResponse value) {
        return new JAXBElement<QueryAddonResponse>(_QueryAddonResponse_QNAME, QueryAddonResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAddonRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", name = "updateAddonRequest")
    public JAXBElement<UpdateAddonRequest> createUpdateAddonRequest(UpdateAddonRequest value) {
        return new JAXBElement<UpdateAddonRequest>(_UpdateAddonRequest_QNAME, UpdateAddonRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAddonResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", name = "updateAddonResponse")
    public JAXBElement<UpdateAddonResponse> createUpdateAddonResponse(UpdateAddonResponse value) {
        return new JAXBElement<UpdateAddonResponse>(_UpdateAddonResponse_QNAME, UpdateAddonResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryAddonRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://online.techmahindra.com/svallo/model/vas/addon/2014/08/28", name = "queryAddonRequest")
    public JAXBElement<QueryAddonRequest> createQueryAddonRequest(QueryAddonRequest value) {
        return new JAXBElement<QueryAddonRequest>(_QueryAddonRequest_QNAME, QueryAddonRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Addon }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dataRolloverAddon", scope = RolloverAddon.class)
    public JAXBElement<Addon> createRolloverAddonDataRolloverAddon(Addon value) {
        return new JAXBElement<Addon>(_RolloverAddonDataRolloverAddon_QNAME, Addon.class, RolloverAddon.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Addon }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "textsRolloverAddon", scope = RolloverAddon.class)
    public JAXBElement<Addon> createRolloverAddonTextsRolloverAddon(Addon value) {
        return new JAXBElement<Addon>(_RolloverAddonTextsRolloverAddon_QNAME, Addon.class, RolloverAddon.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Addon }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "minsRolloverAddon", scope = RolloverAddon.class)
    public JAXBElement<Addon> createRolloverAddonMinsRolloverAddon(Addon value) {
        return new JAXBElement<Addon>(_RolloverAddonMinsRolloverAddon_QNAME, Addon.class, RolloverAddon.class, value);
    }

}


package com.techmahindra.online.svallo.model.common._2014._08._28;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TransactionTrace complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransactionTrace">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sourcePid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sourceBpid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sourceSystem" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="destinationSystem" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="destinationService" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="destinationOperation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionTrace", propOrder = {
    "sourcePid",
    "sourceBpid",
    "sourceSystem",
    "destinationSystem",
    "destinationService",
    "destinationOperation"
})
public class TransactionTrace {

    @XmlElement(required = true, nillable = true)
    protected String sourcePid;
    @XmlElement(required = true, nillable = true)
    protected String sourceBpid;
    @XmlElement(required = true, nillable = true)
    protected String sourceSystem;
    @XmlElement(required = true, nillable = true)
    protected String destinationSystem;
    @XmlElement(required = true, nillable = true)
    protected String destinationService;
    @XmlElement(required = true, nillable = true)
    protected String destinationOperation;

    /**
     * Gets the value of the sourcePid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourcePid() {
        return sourcePid;
    }

    /**
     * Sets the value of the sourcePid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourcePid(String value) {
        this.sourcePid = value;
    }

    /**
     * Gets the value of the sourceBpid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceBpid() {
        return sourceBpid;
    }

    /**
     * Sets the value of the sourceBpid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceBpid(String value) {
        this.sourceBpid = value;
    }

    /**
     * Gets the value of the sourceSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceSystem() {
        return sourceSystem;
    }

    /**
     * Sets the value of the sourceSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceSystem(String value) {
        this.sourceSystem = value;
    }

    /**
     * Gets the value of the destinationSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationSystem() {
        return destinationSystem;
    }

    /**
     * Sets the value of the destinationSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationSystem(String value) {
        this.destinationSystem = value;
    }

    /**
     * Gets the value of the destinationService property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationService() {
        return destinationService;
    }

    /**
     * Sets the value of the destinationService property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationService(String value) {
        this.destinationService = value;
    }

    /**
     * Gets the value of the destinationOperation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationOperation() {
        return destinationOperation;
    }

    /**
     * Sets the value of the destinationOperation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationOperation(String value) {
        this.destinationOperation = value;
    }

}

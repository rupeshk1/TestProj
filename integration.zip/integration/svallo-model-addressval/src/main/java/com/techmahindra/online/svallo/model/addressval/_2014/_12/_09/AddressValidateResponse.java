
package com.techmahindra.online.svallo.model.addressval._2014._12._09;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for addressValidateResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="addressValidateResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="addressList" type="{http://online.techmahindra.com/svallo/model/addressval/2014/12/09}AddressDetail" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="replyStatus" type="{http://online.techmahindra.com/svallo/model/addressval/2014/12/09}ReplyStatus" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "addressValidateResponse", propOrder = {
    "addressList",
    "replyStatus"
})
public class AddressValidateResponse {

    protected List<AddressDetail> addressList;
    protected List<ReplyStatus> replyStatus;

    /**
     * Gets the value of the addressList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addressList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddressList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AddressDetail }
     * 
     * 
     */
    public List<AddressDetail> getAddressList() {
        if (addressList == null) {
            addressList = new ArrayList<AddressDetail>();
        }
        return this.addressList;
    }

    /**
     * Gets the value of the replyStatus property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the replyStatus property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReplyStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReplyStatus }
     * 
     * 
     */
    public List<ReplyStatus> getReplyStatus() {
        if (replyStatus == null) {
            replyStatus = new ArrayList<ReplyStatus>();
        }
        return this.replyStatus;
    }

}

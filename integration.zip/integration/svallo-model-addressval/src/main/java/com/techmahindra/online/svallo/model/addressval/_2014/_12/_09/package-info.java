@javax.xml.bind.annotation.XmlSchema(namespace = "http://online.techmahindra.com/svallo/model/addressval/2014/12/09", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.techmahindra.online.svallo.model.addressval._2014._12._09;

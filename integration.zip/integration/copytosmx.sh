cp svallo-integration-common/target/svallo-integration-common-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-integration-sid-customer/target/svallo-integration-sid-customer-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-model-common/target/svallo-model-common-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-model-sid-customer/target/svallo-model-sid-customer-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-service-common/target/svallo-service-common-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-service-sid-customer/target/svallo-service-sid-customer-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-integration-sid-pas/target/svallo-integration-sid-pas-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-service-sid-plan_services/target/svallo-service-sid-pas-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-integration-sid-ticket/target/svallo-integration-sid-ticket-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-integration-oms/target/svallo-integration-oms-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-service-oms/target/svallo-service-oms-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 
cp svallo-model-oms/target/svallo-model-oms-0.1.jar ../../Sandbox/Binaries/apache-servicemix-4.5.2/deploy 

